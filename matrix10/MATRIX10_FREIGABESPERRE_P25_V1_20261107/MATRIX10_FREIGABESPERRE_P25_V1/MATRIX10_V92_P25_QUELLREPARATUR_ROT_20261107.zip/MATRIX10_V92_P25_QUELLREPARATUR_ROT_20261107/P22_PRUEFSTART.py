#!/usr/bin/env python3
"""P22 Quellen- und Kettenpruefung. Sicher: nur Test-DBs, kein Produktstart.
Status bleibt ROT, solange HTTP/Browser/Restachsen nicht abgenommen sind.
"""
from __future__ import annotations
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys

ROOT = Path(__file__).resolve().parent
LOG = ROOT / "P22_PRUEFLOG_WINDOWS.txt"
ORIG = Path.cwd()
ENV = dict(os.environ)
ENV["PYTHONPATH"] = os.pathsep.join([str(ROOT), str(ROOT / "tests"), ENV.get("PYTHONPATH", "")])
REPORT = []

def report(line: str):
    print(line, flush=True)
    REPORT.append(line)

def code_hashes():
    return {str(p.relative_to(ROOT)):hashlib.sha256(p.read_bytes()).hexdigest()
            for pat in ('matrix_api/**/*.py','src/**/*.ts','src/**/*.tsx','tests/test_v92_p22*.py')
            for p in ROOT.glob(pat) if p.is_file()}

def run(label, cmd, *, optional=False):
    report("\n=== " + label + " ===")
    try:
        done = subprocess.run(cmd, cwd=ROOT, env=ENV, capture_output=True, text=True,
                              encoding="utf-8", errors="replace", timeout=180)
        result=(done.stdout or "")+"\n"+(done.stderr or "")
        tail="\n".join(result.strip().splitlines()[-14:])
        report(tail or "(keine Ausgabe)")
        report(f"EXIT={done.returncode}")
        return done.returncode
    except (OSError,subprocess.TimeoutExpired) as exc:
        report(f"NICHT_PRUEFBAR: {exc}")
        return 3 if optional else 2

report("MATRIX10 P22 | Quellpruefung, KEIN produktiver Start")
report("AMASTER, SPS, Kettenvertrag: Gesamtsystem weiterhin ROT")
report("Python: " + sys.version.splitlines()[0])
if any(ROOT.rglob('*.sqlite')):
    report("WARNUNG: Eine SQLite-Datei liegt im Pruefordner! Keine Nutzerdaten verwenden.")
source_before=code_hashes()
run("P20/P21/P22 regressions (61)", [sys.executable,"-m","unittest","discover","-s","tests","-p","test_v92_p2*.py","-q"])
probe=ROOT/"P22_PRUEFERSKRIPTE"/"MATRIX10_V92_PAKET19_KOERPER_GEGENPROBEN.py"
if probe.is_file():run("P19 Koerpervertrag", [sys.executable,str(probe),str(ROOT)])
else:report("NICHT_PRUEFBAR: P19 Koerperpruefung fehlt")
probe=ROOT/"P22_PRUEFERSKRIPTE"/"MATRIX10_V92_PAKET18_PRUEFERSKRIPT_VOLLER_VERTRAG.py"
if probe.is_file():run("P18 Vollvertrag", [sys.executable,str(probe),str(ROOT)])
else:report("NICHT_PRUEFBAR: P18 Vertragsskript fehlt")
node=shutil.which('node')
if node:
    run("TypeScript-Syntax, KEIN Frontendbuild", [node,str(ROOT/'P22_TYPESCRIPT_SYNTAX.cjs'),str(ROOT)],optional=True)
    run("HTTP-Timeout-Quellcode und Abort-Verhalten", [node,str(ROOT/'P22_TIMEOUT_ABBRUCH_GEGENPROBEN.cjs'),str(ROOT/'src/lib/matrix/api.ts')],optional=True)
else:report("NICHT_PRUEFBAR: Node.js fehlt fuer die TypeScript- und Timeout-Tests")
run("Vollstaendige vorhandene Offline-Suite (muss ohne Flask/Bundle ROT sein)",
    [sys.executable,"-m","unittest","discover","-s","tests","-q"])
source_after=code_hashes()
report("QUELLDATEIEN_UNVERAENDERT=" + str(source_before==source_after))
report("\nSTATUS ROT: kein neuer Build, kein Browser/echter Provider, offene AMASTER-Ketten.")
try:LOG.write_text("\n".join(REPORT)+"\n",encoding="utf-8")
except OSError as exc:print("Prueflog konnte nicht geschrieben werden",exc)
report("PRUEFLOG: " + str(LOG))
# Status ROT is intentionally nonzero. 0 is reserved for a future FULL acceptance.
raise SystemExit(2)
