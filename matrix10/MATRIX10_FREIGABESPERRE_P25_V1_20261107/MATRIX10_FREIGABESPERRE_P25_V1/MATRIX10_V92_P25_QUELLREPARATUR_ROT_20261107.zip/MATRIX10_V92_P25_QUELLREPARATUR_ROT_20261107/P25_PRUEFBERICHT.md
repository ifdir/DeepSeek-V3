# MATRIX10 V92 – P25 Quellreparatur und unabhängige Wiederholungsprüfung

**Stand:** 07.11.2026  
**Status:** ROT – keine Produktfreigabe.  
**Produktcode geändert:** Ja, nur in einer frisch entpackten P24-Arbeitskopie.  
**Originaldatenbank:** Nicht geöffnet, nicht geändert. SQLite-Proben verwenden eine neue temporäre Testdatenbank.  
**VERSION.txt:** Unverändert gegenüber P24 und P22, SHA-256 `188ac609498ded0f88758626661d49aed44c37125cf123f59f81fd331e72fe15`.

## 1. Ausgangsbasis und Vertrag

- Originalbasis: `MATRIX10_V92_P24_QUELLREPARATUR_ROT_20261107.zip` mit 264 ZIP-Einträgen.
- SHA-256 Original-P24-ZIP: `e25db76a69d3da649aeabc1d5008770a3eb0116f74e658eeaeba67d322cf1b99`; ZIP-CRC kontrolliert.
- Geprüft anhand des echten P24-Quellstands und des unabhängigen P24-Berichts vom 07.11.2026; insbesondere AMASTER §§ 24.2, 27.3/27.4, 34.1, SPS und Reparatur-Kettenvertrag § 6.
- Nachgewiesener vorheriger Zustand laut unabhängiger P24-Prüfung mit Flask, gebautem Frontend und Modell: Bau/Anreden/Commit-Zeitgrenzen funktionieren; R1 bricht drei bestehende Puppet-Vertragstests; R2 kann zwei verschiedene Zielpersonen im gleichen Rede-Fact auf die erste zusammenziehen; R3 enthält Abnahmesätze im Sprecher-Prompt.
- Diese früheren Live-Ergebnisse stammen aus dem angelieferten Prüfbericht, nicht aus einer neuen eigenen Live-Abnahme.

## 2. Reparatur der ersten falschen Stellen

### R1 – Eigener Name als Rest und unabhängige Nicht-Handlung

**Erste Naht:** `matrix_api/kernel.py`, `bind_input_components`, Abdeckung aus `_speech_from_components` und `input_binding_outcome`.

1. Lässt der Planer das Subjekt in `segment` weg, z. B. Original „Johann trinkt sein Bier aus.“ und Segment „trinkt sein Bier aus.“, wird der vollständige unmittelbar angrenzende Name im Original nur dann als bereits gebundener Teil behandelt, wenn die kanonische Namenslesung **genau die geführte Akteurs-ID** bestätigt. Der Name wird nicht ins gespeicherte Handlungstextsegment kopiert.
2. „Johann küsst Mara nicht und sagt: Hallo.“: Der abgelehnte Handlungsvorschlag wird nur dann als **gelesenes Nichtevent** markiert, wenn eine vollständige eigenständige Vollzugslesung vorliegt und keinen tatsächlich vollzogenen Vorgang bestätigt. Die selbständig bestätigte Rede bleibt ausführbar; aus der verneinten Handlung entsteht kein Handlung-Fact. Bei fehlendem Vollzugsnachweis bleibt fail-closed aktiv.
3. Fremde Figuren, unbekannte Namen, ungebundene Satzteile und nicht gelesene zweite Sätze bleiben abgelehnt. Keine Liste fester Beispielsätze als Sonderweg.

### R2 – Zwei nachgewiesene Rede-Adressaten

**Erste Naht:** `matrix_api/kernel.py`, `_speech_from_components` → `bind_input_components` → `input_binding_outcome` → vorhandene Puppet-Route.

Sind in derselben zusammengefassten Rede zwei unterschiedliche, ausdrücklich gelesene und kanonisch gebundene Adressaten enthalten, werden sie nicht mehr auf das erste Ziel zusammengeführt. Stattdessen gibt der Binder einen **sichtbaren Konflikt** aus und stellt keine ausführbare Rede bereit. Die Puppet-Route soll dann vor dem Commit 422 `PUPPET_TEILABLEHNUNG` liefern. Das bestehende Frontend zeigt den Fehler. Alternative Teilcommits pro Satz würden eine größere Writer-Änderung verlangen und wurden ausdrücklich nicht erfunden.

Unterschiedliche Adressaten sind nicht gleichbedeutend mit einer unbekannten Zielperson. Der positive Fall eines wiederholten gleichen Adressaten wird weiterhin zugelassen; eine ausdrücklich belegte einzelne Anrede darf die UI-Vorauswahl überschreiben.

### R3 – Keine Prompt-Flicks

Die konkreten P24-Abnahmesätze wurden aus `matrix_api/llm_contract.py`, `SPRECHER_CHECK_RULES`, entfernt. Die Rollenunterscheidung zwischen Anrede, Sprecheransage und unklarem Fall bleibt erhalten. Die Codeentscheidung liegt weiterhin im Binder und nicht in einer Liste von Demoformulierungen.

## 3. Tatsächlich ausgeführte Tests in dieser Umgebung

| Prüfung | Ergebnis | Aussagegrenze |
|---|---:|---|
| P25 neue eigene Code-/ID-/Gegenproben | **12 PASS** plus 2 Subtests | Echte Binderfunktionen, kein HTTP |
| P24 unveränderte Binder-/Negativtests | **9 PASS** | Kein HTTP |
| Weitere alte Komponenten-/Negativtests (mit bestehendem Offline-Importshim) | **64 PASS** | Kein HTTP |
| P25 kanonischer `commit_puppet` → SQLite → neuer `get_session`-Reader | **PASS** | Testdatenbank, keine HTTP-Route |
| P23 SQLite Prepare-/Commit-Rücklesefixture | **PASS** | Offline |
| Frontend-Readback-/UI-Entscheider in Node | **22 PASS** | Kein gebautes Browserfrontend |
| Timeout-/Abort-Vertrag in Node | **5 PASS** | Kein echter Timeout-Server |
| TypeScript-Transpile | **PASS** (3 Dateien) | Kein Vite-Build |
| Build-ID-Konsistenz `VERSION.txt`/`types.ts`/HTML | **PASS** | Kein Vite-Build |
| **Vollständige vorhandene Python-Suite** | **447 Tests; 8 FAIL, 84 ERROR** | Größtenteils Flask-/Frontend-Abhängigkeiten nicht vorhanden; enthält alte Vertragsfehler |
| Echte Flask-Route der 3 R1-Alttests | **NICHT durchführbar** | `flask` nicht installiert |
| Echte Flask-Route R2 inkl. DB-Rücklesung | **NICHT durchführbar** | Prüfskript liegt dem Paket bei |
| Neuer Vite-/Frontend-Build, Browser, echtes Modell | **NICHT durchführbar** | npm-Bauabhängigkeiten/Flask/Provider hier nicht verfügbar |

**Wichtig:** Die drei im P24-Bericht neu gebrochenen Routentests sind hier nicht eigenständig erneut grün bewiesen. Die neuen Offline-Tests ersetzen diese fehlenden Routenbelege nicht.

Die bestehende P22-Quelltextassertion, die den zuvor fehlerhaften Anwesenheits-Guard verlangt, ist unverändert; der Test wird nicht heimlich abgeschwächt. Über deren Vertragskorrektur muss anhand AMASTER/SPS entschieden werden, nicht durch bloßes Umschreiben ihrer erwarteten Zeichenfolge.

## 4. Ausstehende verbindliche Abnahme auf frischem Paket

1. Mit Flask und echten erforderlichen Abhängigkeiten die drei vormals neu roten R1-Routentests unverändert ausführen. Negativ: nicht gelesener Teil und fremde Figur ändern weder Turns noch Facts/Presence. Positiv: „Johann trinkt sein Bier aus.“, „Johann stellt das Glas auf den Tisch.“, unabhängige Verneinung + „Hallo.“, zwei echte Handlungen.
2. `scripts/P25_ROUTE_R2_EMPFAENGER_GEGENPROBEN.py` gegen das **frisch entpackte** Paket laufen lassen: zwei unterschiedliche Anreden ergeben einen sichtbaren 422 ohne SQL-Schreibreste, eine einzelne eindeutige Anrede wird an die richtige kanonische Figuren-ID gebunden. Auch mit UI-Vorauswahl gegenprüfen.
3. Echte Modell-Liveproben mit neuen, **nicht im Prompt enthaltenen** Sätzen. Sprecher, Adressat, Handlung, Verneinung und Wissen/Zeugen im Folgeturn prüfen. Keine pauschale Erfolgsbehauptung aus einem isolierten Binder-Test.
4. Vite bauen, Frontend im Browser wirklich bedienen und Backend-ID gegen UI-ID abgleichen. Prepare-/Commit-Timeout und Wiederaufnahme inklusive SQL-Rücklesung prüfen.
5. Volle Vertragssuite, inklusive aller alten Fehlschläge, an unverändertem Testsatz; alle geänderten Writer-/Reducer-/Reader-Ketten plus Originaldatenbank-Klon prüfen. Keine Produktfreigabe bei ROT.

## 5. Unverändert offen

G-5 God-Vollzug, E-1 Einwilligung, S-1 alte Sessions, R-1 Regie/„setzt sich“, Wortliste in `god_extract`, der alte D-Meldungsfall und die bisherigen acht Vertragstests. Die Arbeit an R1–R3 ist keine vollständige Systemreparatur.

## 6. Reproduzierbarkeit und Originalschutz

P25 ist nur eine **neue fortlaufend bezeichnete Quellenarbeitskopie**. `VERSION.txt` wurde absichtlich nicht verändert. Paket enthält vollständige Ausgangsdateien, die tatsächlich geänderten Quellen, neue Tests und die Prüfberichte, ein vollständiges Diff, SHA-256-Manifest sowie `P25_PRUEFSTART_WINDOWS.bat` für den Doppelklick. `P25_PRUEFSTART.py` führt nur Tests auf temporären Daten aus, protokolliert fehlende Abhängigkeiten und endet absichtlich mit **Exitcode 2 (ROT)**. Kein echter Produktstart. Die Herkunft des Frischpakets und die Hashes werden zusätzlich nach der Paketierung geprüft.
