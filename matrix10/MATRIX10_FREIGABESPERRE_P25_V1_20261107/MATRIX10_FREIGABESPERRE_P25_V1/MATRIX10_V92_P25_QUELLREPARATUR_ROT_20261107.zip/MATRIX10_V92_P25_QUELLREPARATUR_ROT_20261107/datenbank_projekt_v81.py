#!/usr/bin/env python3
"""MATRIX10 V81: one canonical SQLite in THIS project, never a chooser.

Only the exact last V78/V79 active SQLite location is an automatic import source.
An old release ZIP or an arbitrary other project is NEVER a fallback. Data is
backed up with the SQLite online-backup API (including committed WAL content).
"""
from __future__ import annotations

from datetime import datetime, timezone
from contextlib import contextmanager, closing
import errno
import os
from pathlib import Path
import sqlite3
import tempfile

ROOT = Path(__file__).resolve().parent
MARKER = '.matrix10_db_initialized'
NEEDED = {'users', 'worlds', 'characters', 'sessions', 'turns', 'memories', 'logs'}


def project_db_path(root: Path | None = None) -> Path:
    return (Path(root) if root is not None else ROOT) / 'data' / 'matrix10.sqlite'


def known_previous_db(root: Path | None = None) -> Path:
    """The exact former V78/V79 active location, no recursive candidate search."""
    override = os.environ.get('MATRIX_SHARED_DATA_ROOT')
    if override:
        return Path(override).expanduser().resolve() / 'matrix10.sqlite'
    android = Path('/storage/emulated/0/Download')
    if android.is_dir():
        return android / 'MATRIX10_DATEN' / 'matrix10.sqlite'
    parent = (Path(root) if root is not None else ROOT).resolve().parent
    if parent.name.upper().startswith('MATRIX10_V'):
        parent = parent.parent
    return parent / 'MATRIX10_DATEN' / 'matrix10.sqlite'


def verify_db(path: Path) -> None:
    """Never invoke sqlite3.connect in create mode for a supposed existing DB."""
    if not path.is_file():
        raise FileNotFoundError(str(path))
    uri = path.resolve().as_uri() + '?mode=ro'
    with closing(sqlite3.connect(uri, uri=True, timeout=10)) as conn:
        if conn.execute('PRAGMA quick_check').fetchone()[0] != 'ok':
            raise ValueError('SQLite Integritätsprüfung nicht OK')
        violations = conn.execute('PRAGMA foreign_key_check').fetchall()
        if violations:
            raise ValueError(f'SQLite Fremdschlüsselverletzungen: {len(violations)}')
        tables = {r[0] for r in conn.execute("SELECT name FROM sqlite_master WHERE type='table'")}
        if not NEEDED.issubset(tables):
            raise ValueError('Keine vollständige Matrix10-Datenbank: ' + ', '.join(sorted(NEEDED - tables)))


def _temp_sqlite(directory: Path) -> Path:
    fd, name = tempfile.mkstemp(prefix='.matrix10_import_', suffix='.sqlite', dir=directory)
    os.close(fd)
    return Path(name)


def _mark(directory: Path) -> None:
    marker = directory / MARKER
    if not marker.exists():
        marker.write_text('MATRIX10-Projektdatenbank angelegt/übernommen: '
                          + datetime.now(timezone.utc).isoformat() + '\n', encoding='utf-8')



@contextmanager
def _bootstrap_lock(directory: Path):
    """Serialize first-launch replacement across processes (Windows/Android/Linux)."""
    file = directory / '.matrix10_start.lock'
    with file.open('a+b') as handle:
        if os.name == 'nt':
            import msvcrt
            handle.seek(0)
            if handle.read(1) == b'':
                handle.write(b'0')
                handle.flush()
            handle.seek(0)
            msvcrt.locking(handle.fileno(), msvcrt.LK_LOCK, 1)
            try:
                yield
            finally:
                handle.seek(0)
                msvcrt.locking(handle.fileno(), msvcrt.LK_UNLCK, 1)
        else:
            import fcntl
            locked = False
            try:
                fcntl.flock(handle.fileno(), fcntl.LOCK_EX)
                locked = True
            except OSError as exc:
                # Some Android scoped-storage/FUSE mounts do not implement
                # advisory locks. Port ownership and existence checks still
                # protect ordinary single-instance startup on that device.
                if exc.errno not in (errno.ENOSYS, errno.EOPNOTSUPP, errno.ENOTSUP):
                    raise
                print('[DATEN] Hinweis: Dateisystemsperre nicht verfügbar; kein paralleler Start erlaubt.')
            try:
                yield
            finally:
                if locked:
                    fcntl.flock(handle.fileno(), fcntl.LOCK_UN)



# V89 startup migration: adopt the most recent PREVIOUS Matrix10 project DB
# from an adjacent version directory. Only known release names and data paths
# are considered; no old ZIP, unrelated project, or arbitrary search is used.
# The original database is only read through SQLite's backup API.
def previous_release_dbs(project: Path) -> list[tuple[int, Path]]:
    import re
    project = Path(project).resolve()
    current = re.search(r"MATRIX10_V(\d+)", project.name.upper())
    current_version = int(current.group(1)) if current else 89
    homes = [project.parent, project.parent.parent]
    found: dict[str, tuple[int, Path]] = {}
    for home in homes:
        if not home.is_dir():
            continue
        for folder in home.iterdir():
            if not folder.is_dir() or folder.is_symlink():
                continue
            match = re.match(r"MATRIX10_V(\d+)(?:_|$)", folder.name.upper())
            if not match:
                continue
            version = int(match.group(1))
            if not 83 <= version < current_version:
                continue
            roots = [folder]
            # Some older ZIPs contained a repeated root folder.
            roots.extend(child for child in folder.iterdir() if child.is_dir() and not child.is_symlink()
                         and child.name.upper().startswith("MATRIX10_V" + str(version) + "_"))
            for candidate_root in roots:
                candidate = candidate_root / 'data' / 'matrix10.sqlite'
                if candidate.is_file() and not candidate.is_symlink() and candidate.resolve() != project_db_path(project).resolve():
                    found[str(candidate.resolve())] = (version, candidate.resolve())
    return sorted(found.values(), key=lambda item: (-item[0], str(item[1])))


def newest_unambiguous(candidates: list[tuple[int, Path]]) -> Path | None:
    if not candidates:
        return None
    highest = candidates[0][0]
    newest = [p for v, p in candidates if v == highest]
    if len(newest) != 1:
        # Never select one of two potentially diverged live project states.
        raise ValueError('Mehrere Datenbanken derselben letzten Version gefunden. Keine automatische Datenuebernahme.')
    return newest[0]


def copy_missing_user_config(destination: Path, source: Path) -> int:
    """Recover only missing per-user provider settings, never overwrite intent.

    Source and target have to be full independent databases. Existing config
    rows are immutable to this helper. No secrets appear in messages or ZIP.
    """
    verify_db(source)
    verify_db(destination)
    transferred = 0
    with closing(sqlite3.connect(source.resolve().as_uri() + '?mode=ro', uri=True, timeout=15)) as old:
        with closing(sqlite3.connect(destination, timeout=15)) as current:
            users = {str(x[0]) for x in current.execute('SELECT id FROM users')}
            previous = old.execute("SELECT scope,scope_id,json FROM config WHERE scope='user'").fetchall()
            current.execute('BEGIN IMMEDIATE')
            for scope, scope_id, cfg in previous:
                if str(scope_id) not in users:
                    continue
                if current.execute('SELECT 1 FROM config WHERE scope=? AND scope_id=?', (scope,scope_id)).fetchone():
                    continue
                # The row is copied intact only when its owner exists in both DBs.
                if not old.execute('SELECT 1 FROM users WHERE id=?', (scope_id,)).fetchone():
                    continue
                current.execute('INSERT INTO config(scope,scope_id,json) VALUES(?,?,?)', (scope,scope_id,cfg))
                transferred += 1
            current.commit()
    verify_db(destination)
    return transferred


def restore_previous_user_config(project: Path, destination: Path, primary_source: Path,
                                 candidates: list[tuple[int, Path]]) -> str:
    """Only for newly imported databases, before their atomic publish."""
    with closing(sqlite3.connect(destination.resolve().as_uri() + '?mode=ro', uri=True)) as current:
        if current.execute("SELECT COUNT(*) FROM config WHERE scope='user'").fetchone()[0]:
            return ''
    source_version = next((v for v, p in candidates if p == primary_source.resolve()), 999)
    for version in sorted({v for v,p in candidates if v < source_version}, reverse=True):
        possible = []
        for v,p in candidates:
            if v != version:
                continue
            try:
                verify_db(p)
                with closing(sqlite3.connect(p.resolve().as_uri()+'?mode=ro', uri=True)) as conn:
                    if conn.execute("SELECT COUNT(*) FROM config WHERE scope='user'").fetchone()[0]:
                        possible.append(p)
            except (sqlite3.Error, ValueError):
                continue
        if len(possible) > 1:
            raise ValueError('Mehrere alte Providerkonfigurationen gleichrangig vorhanden; kein stiller Import.')
        if possible:
            count = copy_missing_user_config(destination, possible[0])
            return ('; fehlende benutzereigene Provider-Einstellungen aus V' + str(version)
                    + ' uebernommen (' + str(count) + ' Eintraege)') if count else ''
    return '; kein bisheriger Provider-Eintrag gefunden: im Frontend unter Konfiguration einrichten'

def prepare_data(root: Path | None = None, previous_db: Path | None = None) -> tuple[bool, str]:
    """One project DB. Existing data wins; initialize only genuine first run.

    root/previous_db are used only for isolated test fixtures. When root is
    provided without previous_db, no machine-wide history is scanned.
    """
    project = Path(root) if root is not None else ROOT
    destination = project_db_path(project).resolve()
    destination.parent.mkdir(parents=True, exist_ok=True)
    with _bootstrap_lock(destination.parent):
        marker = destination.parent / MARKER
        if destination.is_symlink():
            raise ValueError('Projektdatenbank ist ein Link auf einen anderen Speicherort. Keine externe Masterdatenbank.')
        if destination.exists():
            verify_db(destination)  # corrupt DB never replaced by old or empty data
            _mark(destination.parent)
            os.environ['MATRIX_DB'] = str(destination)
            return True, 'Vorhandene Projektdatenbank bleibt erhalten: ' + str(destination)

        # A previous initialization marker or leftover WAL means the SQLite file
        # was unexpectedly lost. NEVER hide this by silently creating an empty one.
        if marker.exists() or any(destination.parent.joinpath(destination.name + suffix).exists()
                                  for suffix in ('-wal', '-shm', '-journal')):
            return False, ('Projekt-SQLite ist unerwartet verschwunden. Keine leere '
                           'Datenbank als vermeintliche Wiederherstellung erstellt: ' + str(destination))

        source = Path(previous_db) if previous_db is not None else (
            known_previous_db() if root is None else None
        )
        release_candidates = previous_release_dbs(project) if root is None and previous_db is None else []
        # The most recent Matrix10 release is more relevant than the old V79
        # shared-data location. Never guess when multiple V88 copies exist.
        newest = newest_unambiguous(release_candidates) if release_candidates else None
        if newest is not None:
            source = newest
        if root is None and newest is None and previous_db is None:
            # A stale launcher variable must NOT override a uniquely identified
            # newer project database: doing so would discard later sessions.
            # This only remains a fallback when no previous version is found.
            configured = os.environ.get('MATRIX_DB')
            if configured:
                selected = Path(configured).expanduser()
                if not selected.is_absolute():
                    selected = ROOT / selected
                if selected.resolve() != destination and selected.is_file():
                    source = selected
        if source is not None and source.resolve() == destination:
            source = None

        temporary = _temp_sqlite(destination.parent)
        try:
            if source is not None and source.is_file():
                verify_db(source)
                with closing(sqlite3.connect(source.resolve().as_uri() + '?mode=ro', uri=True, timeout=30)) as current:
                    with closing(sqlite3.connect(temporary, timeout=30)) as copy:
                        current.backup(copy)  # commit-safe, including active WAL
                        copy.execute('PRAGMA wal_checkpoint(TRUNCATE)')
                verify_db(temporary)
                info = (restore_previous_user_config(project, temporary, source.resolve(), release_candidates)
                        if root is None and release_candidates else '')
                action = 'Aktive bisherige SQLite verlustfrei ins Projekt kopiert' + info
            else:
                # New installation only, no old ZIP snapshot or hidden world reload.
                from matrix_api.db import init_db
                init_db(temporary)
                verify_db(temporary)
                action = 'Neue SQLite mit originalem Matrix10-Schema im Projekt angelegt'
            # START.py owns the start ports, so no old backend is still writing.
            # Never replace any existing project DB, including a corrupt one.
            if destination.exists():
                raise FileExistsError('Paralleler Start oder Projekt-Datenbank bereits vorhanden')
            os.replace(temporary, destination)
            _mark(destination.parent)
            os.environ['MATRIX_DB'] = str(destination)
            return True, action + ': ' + str(destination)
        finally:
            if temporary.exists():
                temporary.unlink()
            for suffix in ('-wal', '-shm', '-journal'):
                extra = temporary.with_name(temporary.name + suffix)
                if extra.exists():
                    extra.unlink()
