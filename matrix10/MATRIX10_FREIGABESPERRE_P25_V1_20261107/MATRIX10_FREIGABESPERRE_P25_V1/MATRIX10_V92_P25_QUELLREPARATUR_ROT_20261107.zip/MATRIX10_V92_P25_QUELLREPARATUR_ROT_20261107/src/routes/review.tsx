import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { Shell, Panel, Empty } from "@/components/shell";
import { Button, Chip, Textarea } from "@/components/ui";
import { useMatrix } from "@/lib/matrix/store";
import { useHydrated } from "@/lib/matrix/use-hydrated";

export const Route = createFileRoute("/review")({ component: ReviewPage });

function ReviewPage() {
  const hydrated = useHydrated();
  const reviews = useMatrix((s) => s.reviews);
  const resolveReview = useMatrix((s) => s.resolveReview);
  const open = reviews.filter((r) => r.status === "open");
  const [edits, setEdits] = useState<Record<string, string>>({});

  if (!hydrated) {
    return (
      <Shell title="Review">
        <p className="text-sm text-muted">Lädt…</p>
      </Shell>
    );
  }

  return (
    <Shell title="Review">
      <h1 className="font-display text-2xl font-semibold">Review-Queue</h1>
      <p className="mt-1 text-sm text-muted">Sessionerfahrung wird nicht still Stamm. Neuwert prüfen, bearbeiten, dann annehmen, ablehnen oder session-only.</p>
      <p className="mt-2 text-xs text-muted">
        offen {open.length} · angenommen {reviews.filter((r) => r.status === "accepted").length} · abgelehnt {reviews.filter((r) => r.status === "rejected").length}
      </p>
      <Panel className="mt-4">
        {reviews.length === 0 ? <Empty>Keine Vorschläge. Turns können hierher schreiben, der Stamm nicht von allein.</Empty> : null}
        <ul className="space-y-3">
          {reviews.map((r) => (
            <li key={r.id} className="rounded-[12px] border border-border bg-bg p-3 text-sm">
              <div className="flex flex-wrap items-center gap-2">
                <Chip>{r.kind}</Chip>
                <Chip tone={r.status === "open" ? "warn" : r.status === "accepted" ? "ok" : undefined}>{r.status}</Chip>
                <span className="text-faint">{r.field}</span>
              </div>
              {r.kind === "spawn" ? <p className="mt-2 text-xs text-muted">Spawn-Kandidat — Annehmen legt Stamm an.</p> : null}
              <p className="mt-2 text-xs text-muted">alt: {r.oldValue || "—"}</p>
              {r.status === "open" ? (
                <Textarea
                  className="mt-1"
                  rows={3}
                  value={edits[r.id] ?? r.newValue}
                  onChange={(e) => setEdits((m) => ({ ...m, [r.id]: e.target.value }))}
                />
              ) : (
                <p className="text-xs">neu: {r.newValue}</p>
              )}
              <p className="mt-1 text-[11px] text-faint">{r.reason}</p>
              {r.status === "open" ? (
                <div className="mt-2 flex flex-wrap gap-2">
                  <Button
                    className="min-h-9 text-xs"
                    onClick={() => {
                      // V25 REV-01: bearbeiteter Wert geht mit dem Annehmen-Request selbst
                      // an den Server (ein Bedienschritt, ein Wahrheitswert).
                      const v = edits[r.id] ?? r.newValue;
                      resolveReview(r.id, "accepted", v);
                    }}
                  >
                    Annehmen
                  </Button>
                  <Button variant="line" className="min-h-9 text-xs" onClick={() => resolveReview(r.id, "session-only")}>
                    Nur Session
                  </Button>
                  <Button variant="danger" className="min-h-9 text-xs" onClick={() => resolveReview(r.id, "rejected")}>
                    Ablehnen
                  </Button>
                </div>
              ) : null}
            </li>
          ))}
        </ul>
      </Panel>
    </Shell>
  );
}
