import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { PageHead, Panel, Shell, Tabs } from "@/components/shell";
import { Button, Chip, Field, Input, Lines, Select, Switch, Textarea } from "@/components/ui";
import { downloadJson, emptyCharacter, emptySpawnCandidate, hydrateCharacter, localSpawnCandidates, draftFieldGroups, localAnalyzeToDraft, applyCompletedProfiles, applyDraftGroupPick, extendWorldFromDraft, spawnCandidateKey, sameNameStamm, resolveSpawnAction, applyCandidateToStamm, ownedPassagesForName, type SpawnDupDecision } from "@/lib/matrix/normalize";
import { fillCompass } from "@/lib/matrix/compass";
import { uid } from "@/lib/matrix/ids";
import { useMatrix } from "@/lib/matrix/store";
import { useHydrated } from "@/lib/matrix/use-hydrated";
import { type Place, type SpawnCandidate, type StammCharacter, type World, type WorldDraft, type WorldRule } from "@/lib/matrix/types";
import { extractTextFromFile, joinSelectedParts, kindLabel, layerLabel, zoneLabel, assignPartDocIds, type EpubPart } from "@/lib/matrix/epub";
import { persistPartDocuments, packWorldWithSources } from "@/lib/matrix/source-docs";
import { ocrSelectedScanParts, textFromUpload } from "@/lib/matrix/ocr";
import { apiAnalyzeLocal, apiBackupWorld, apiCompleteProfiles, apiGenerateCharacters, apiGenerateWorld, apiGenrePolicy, apiListWorldBackups, apiRestoreWorldBackup, analyzeFailMessage } from "@/lib/matrix/api";

export const Route = createFileRoute("/welt/$worldId")({ component: WeltPage });

function WeltPage() {
  const { worldId } = Route.useParams();
  const nav = useNavigate();
  const hydrated = useHydrated();
  const worlds = useMatrix((s) => s.worlds);
  const characters = useMatrix((s) => s.characters);
  const sessions = useMatrix((s) => s.sessions);
  const uploads = useMatrix((s) => s.uploads);
  const reviews = useMatrix((s) => s.reviews);
  const patchWorld = useMatrix((s) => s.patchWorld);
  const upsertWorld = useMatrix((s) => s.upsertWorld);
  const addReview = useMatrix((s) => s.addReview);
  const addCharacter = useMatrix((s) => s.addCharacter);
  const patchCharacter = useMatrix((s) => s.patchCharacter);
  const startSession = useMatrix((s) => s.startSession);
  const deleteWorld = useMatrix((s) => s.deleteWorld);
  const log = useMatrix((s) => s.log);
  const world = worlds.find((w) => w.id === worldId);
  const chars = characters.filter((c) => c.worldId === worldId && c.isWorldNative);
  const sess = sessions.filter((s) => s.worldId === worldId);
  const ups = uploads.filter((u) => u.worldId === worldId);
  const [tab, setTab] = useState("live");
  const [idea, setIdea] = useState("");
  const [busy, setBusy] = useState(false);
  const [err, setErr] = useState<string | null>(null);
  const [sitId, setSitId] = useState("");
  const [spawnPreview, setSpawnPreview] = useState<SpawnCandidate[]>([]);
  const [spawnPicked, setSpawnPicked] = useState<Record<string, boolean>>({});
  const [spawnDecision, setSpawnDecision] = useState<Record<string, SpawnDupDecision | "">>({});
  const [analysisDraft, setAnalysisDraft] = useState<WorldDraft | null>(null);
  const [groupPick, setGroupPick] = useState<Record<string, boolean>>({});
  const [genrePolicy, setGenrePolicy] = useState<string>("");
  const [backups, setBackups] = useState<Array<{ id?: string; name?: string; createdAt?: string }>>([]);
  const [backupMsg, setBackupMsg] = useState("");
  const [epubParts, setEpubParts] = useState<EpubPart[] | null>(null);
  const [sourceFile, setSourceFile] = useState<File | null>(null);
  const [sourceA11y, setSourceA11y] = useState<{ language?: string; accessMode?: string[]; accessibilityFeature?: string[]; accessibilitySummary?: string } | null>(null);

  useEffect(() => {
    if (!worldId) return;
    void apiListWorldBackups(worldId)
      .then((l) => setBackups(l.backups || []))
      .catch(() => setBackups([]));
  }, [worldId]);

  useEffect(() => {
    if (!world) return;
    const stored = world.spawnCandidates || [];
    const nativeCount = characters.filter((c) => c.worldId === world.id && c.isWorldNative).length;
    if (typeof window !== "undefined" && window.location.hash === "#spawn" && stored.length) {
      setTab("chars");
      const existing = characters.filter((c) => c.worldId === world.id && c.isWorldNative).map((c) => c.name);
      const cands = localSpawnCandidates(world, existing);
      setSpawnPreview(cands);
      setSpawnPicked(Object.fromEntries(cands.map((c, i) => [spawnCandidateKey(c, i), true])));
      setSpawnDecision({});
      return;
    }
    if (stored.length && !nativeCount) setTab("chars");
  }, [world?.id]);

  useEffect(() => {
    const genre = world?.genre;
    if (!genre) return;
    const text = world?.long || world?.short || "";
    void (async () => {
      try {
        const res = await apiGenrePolicy(genre, text);
        const policy = (res.policy as { register?: string; violence?: string; lexicon?: string[] }) || {};
        const hits = (res.textHits as string[]) || [];
        setGenrePolicy(
          [
            `Register ${policy.register || "neutral"}`,
            `Gewalt ${policy.violence || "moderat"}`,
            policy.lexicon?.length ? `Lexikon ${policy.lexicon.join(", ")}` : "",
            hits.length ? `Treffer ${hits.join(", ")}` : "",
            res.inventsTruth ? "erfindet Wahrheit" : "erfindet keine Wahrheit",
          ]
            .filter(Boolean)
            .join(" · "),
        );
      } catch (e) {
        setGenrePolicy(e instanceof Error ? e.message : "Genre-Policy nicht lesbar");
      }
    })();
  }, [world?.id, world?.genre, world?.long, world?.short]);

  if (!hydrated) {
    return (
      <Shell title="Welt">
        <p className="text-sm text-muted">Lädt…</p>
      </Shell>
    );
  }
  if (!world) {
    return (
      <Shell title="Welt">
        <p className="text-sm text-muted">Welt nicht gefunden.</p>
        <Link to="/welt" className="text-accent">
          Zur Liste
        </Link>
      </Shell>
    );
  }

  const p = (patch: Parameters<typeof patchWorld>[1]) => patchWorld(world.id, patch);

  async function kiExtend() {
    if (!world) return;
    setBusy(true);
    setErr(null);
    try {
      const res = await apiGenerateWorld({
        prompt: idea || `Ergänze und verdichte die Welt ${world.name}.`,
        existing: JSON.stringify({ name: world.name, short: world.short, long: world.long, places: world.places, chars: chars.map((c) => c.name) }),
      });
      let draft = res.ok ? (res.draft as WorldDraft | undefined) : undefined;
      if (draft?.world) draft.source = "llm";
      if (!draft?.world) {
        // V25 LLM-02: kein LLM → lokaler Entwurf, sichtbar als solcher; Fehlergrund bleibt sichtbar.
        setErr(String(res.message || res.error || "KI nicht erreichbar — lokaler Entwurf."));
        const fallback = res.localDraft as WorldDraft | undefined;
        if (fallback?.world) {
          draft = { ...fallback, source: "local-fallback", llmError: String(res.llmError || res.error || "") };
        } else {
          const local = await apiAnalyzeLocal(idea || world.long || world.short, world.id);
          if (local.ok === false) throw new Error(String(local.error || "Keine Welt erzeugt."));
          draft = { ...localAnalyzeToDraft(local as Record<string, unknown>, world.name, idea || world.long || world.short), source: "local-fallback" };
        }
      }
      presentAnalysisDraft(draft);
    } catch (e) {
      setErr(e instanceof Error ? e.message : "KI fehlgeschlagen");
    } finally {
      setBusy(false);
    }
  }

  function presentAnalysisDraft(draft: WorldDraft) {
    setAnalysisDraft(draft);
    const groups = draftFieldGroups(draft);
    setGroupPick(Object.fromEntries(groups.map((g) => [g.field, true])));
    setTab("ki");
  }

  function overlayProfiles(draft: WorldDraft, source: string, title: string) {
    void apiCompleteProfiles({
      text: source.slice(0, 8000),
      title,
      candidates: draft.characters.map((c) => ({
        name: c.name,
        role: c.role,
        biography: c.biography,
        personality: c.personality,
      })),
    }).then((extra) => {
      const rows = (extra.characterCandidates || extra.characters) as Array<{ name?: string }>;
      if (extra.ok === false) setErr(String(extra.message || extra.llmError || "Profilvervollständigung ohne LLM — Felder bleiben lokal/unvollständig."));
      if (!Array.isArray(rows) || !rows.length) return;
      presentAnalysisDraft({ ...applyCompletedProfiles(draft, rows), source: extra.ok ? "llm" : "local-fallback" });
    });
  }

  async function runWorldAnalyze(file: File) {
    if (!world) return;
    setBusy(true);
    setErr(null);
    try {
      const image = file.type.startsWith("image/") || /\.(png|jpe?g|webp)$/i.test(file.name);
      const extracted = await extractTextFromFile(file);
      setSourceFile(file);
      setSourceA11y({
        language: extracted.language,
        accessMode: extracted.accessMode,
        accessibilityFeature: extracted.accessibilityFeature,
        accessibilitySummary: extracted.accessibilitySummary,
      });
      if (extracted.parts && extracted.parts.length > 1) {
        setEpubParts(assignPartDocIds(extracted.parts, extracted.title || world.name));
        return;
      }
      setEpubParts(null);
      const ocr =
        image || (!extracted.text.trim() && extracted.dataUrl)
          ? await textFromUpload({ text: extracted.text, dataUrl: extracted.dataUrl, file })
          : { text: extracted.text, status: extracted.text.trim() ? "ready" : "ocr_empty" };
      const source = ocr.text;
      if (!source.trim()) {
        setErr(
          image || extracted.dataUrl
            ? "OCR leer — kein erfundener Text. Cloud-OCR bleibt gesperrt."
            : "Quelle lieferte keinen Text. Ein leerer Parse ist keine Weltanalyse.",
        );
        return;
      }
      const local = await apiAnalyzeLocal(source, world.id, extracted.title || world.name);
      if (local.ok === false) throw new Error(String(local.error || "Analyse fehlgeschlagen."));
      const draft = localAnalyzeToDraft(local as Record<string, unknown>, extracted.title || world.name, source);
      // V25.1: Analysequelle/Abdeckung sichtbar (Vertrag §7.9/§8)
      draft.source = String(local.analysisSource || "local") === "llm" ? "llm" : "local-fallback";
      if (draft.source !== "llm") setErr(String(local.message || "Analyse lief ohne LLM — lokaler Entwurf. Provider unter Konfiguration prüfen."));
      else if (local.message) setErr(String(local.message));
      presentAnalysisDraft(draft);
      if (String(local.profileSource || "") !== "llm") overlayProfiles(draft, source, extracted.title || world.name);
    } catch (e) {
      setErr(e instanceof Error ? analyzeFailMessage(e) : "Analyse fehlgeschlagen");
    } finally {
      setBusy(false);
    }
  }

  async function analyzePickedWorldParts() {
    if (!world || !epubParts?.length) return;
    setBusy(true);
    setErr(null);
    try {
      let rows = epubParts;
      if (sourceFile) {
        const ocr = await ocrSelectedScanParts(sourceFile, rows);
        rows = ocr.parts;
        setEpubParts(rows);
        if (ocr.skipped) setErr(`${ocr.read} Scan-Seite(n) gelesen, ${ocr.skipped} über der Grenze von 8 ausgelassen.`);
      }
      const { text } = joinSelectedParts(rows);
      if (!text.trim()) {
        setErr("OCR leer — Scan-Seiten hakst du, dann analysieren. Kein erfundener Text.");
        return;
      }
      const local = await apiAnalyzeLocal(text, world.id, world.sourceName || world.name);
      if (local.ok === false) throw new Error(String(local.error || "Analyse fehlgeschlagen."));
      const draft = localAnalyzeToDraft(local as Record<string, unknown>, world.sourceName || world.name, text);
      presentAnalysisDraft(draft);
      overlayProfiles(draft, text, world.sourceName || world.name);
      if (text.trim()) {
        void patchWorld(world.id, { sourceText: text, sourceName: world.sourceName || world.name });
      }
      void persistPartDocuments({ worldId: world.id, sourceName: world.sourceName || world.name, parts: rows }).then((ids) => {
        if (ids.length) void patchWorld(world.id, { sourcePartIds: ids });
      });
    } catch (e) {
      setErr(e instanceof Error ? analyzeFailMessage(e) : "Analyse fehlgeschlagen");
    } finally {
      setBusy(false);
    }
  }

  async function rereadSourceNames() {
    if (!world) return;
    const source = String(world.sourceText || "").slice(0, 120_000);
    if (!source.trim()) {
      setErr("Keine gespeicherte Quelle. Zuerst EPUB/Text analysieren.");
      return;
    }
    setBusy(true);
    setErr(null);
    try {
      const local = await apiAnalyzeLocal(source, world.id, world.sourceName || world.name);
      if (local.ok === false) throw new Error(String(local.error || "Analyse fehlgeschlagen."));
      const draft = localAnalyzeToDraft(local as Record<string, unknown>, world.sourceName || world.name, source);
      presentAnalysisDraft(draft);
      overlayProfiles(draft, source, world.sourceName || world.name);
    } catch (e) {
      setErr(e instanceof Error ? analyzeFailMessage(e) : "Analyse fehlgeschlagen");
    } finally {
      setBusy(false);
    }
  }

  async function confirmAnalysisReviews() {
    if (!world || !analysisDraft) return;
    setBusy(true);
    setErr(null);
    try {
      const groups = draftFieldGroups(analysisDraft);
    const now = new Date().toISOString();
    const picked = applyDraftGroupPick(analysisDraft, groupPick);
    const { world: next, characters: merged } = extendWorldFromDraft(world, chars, picked);
    const ok = await upsertWorld(next, merged);
    if (!ok) {
      setErr("Welt und Figuren konnten nicht gespeichert werden.");
      return;
    }
    for (const g of groups) {
      if (groupPick[g.field] === false) continue;
      if (g.kind === "spawn") {
        for (const c of picked.characters) {
          if (!c.name?.trim()) continue;
          addReview({
            id: uid("rev"),
            kind: "spawn",
            sourceSessionId: "",
            worldId: world.id,
            field: "spawn",
            oldValue: "",
            newValue: JSON.stringify(c),
            reason: "Weltanalyse §11 Figurenkandidat übernommen, noch nicht Stamm",
            status: "accepted",
            createdAt: now,
          });
        }
        continue;
      }
      addReview({
        id: uid("rev"),
        kind: "world",
        sourceSessionId: "",
        worldId: world.id,
        field: g.field,
        oldValue: oldWorldField(world, g.field),
        newValue: g.newValue,
        reason: `Weltanalyse §11 Feld ${g.label} bestätigt`,
        status: "accepted",
        createdAt: now,
      });
    }
    log({
      level: "info",
      code: "WORLD_KI_COMMIT",
      message: `${next.name} Entwurf übernommen · ${(next.spawnCandidates || []).length} Kandidaten, ${merged.length} Stämme`,
    });
    setAnalysisDraft(null);
    setTab("chars");
    const cands = localSpawnCandidates(next, merged.map((c) => c.name));
    if (cands.length) {
      setSpawnPreview(cands);
      setSpawnPicked(Object.fromEntries(cands.map((c, i) => [spawnCandidateKey(c, i), true])));
      setSpawnDecision({});
    }
    } catch (e) {
      setErr(e instanceof Error ? e.message : "Übernehmen fehlgeschlagen");
    } finally {
      setBusy(false);
    }
  }

  async function spawnChars() {
    if (!world) return;
    setBusy(true);
    setErr(null);
    try {
      const res = await apiGenerateCharacters({
        worldSummary: `${world.name}\n${world.long}\nOrte: ${world.places.map((x) => x.name).join(", ")}`,
        existingNames: chars.map((c) => c.name),
      });
      if (!res.ok) throw new Error(String(res.message || res.error || "Spawn fehlgeschlagen"));
      const spawned = ((res.characters as Array<Record<string, unknown> & { name: string; provenance?: Record<string, string> }>) || []);
      const str = (v: unknown) => (typeof v === "string" ? v : "");
      const arr = (v: unknown) => (Array.isArray(v) ? v.map(String) : []);
      const preview = spawned.map((c) =>
        emptySpawnCandidate({
          name: c.name,
          role: str(c.role),
          origin: str(c.origin) || world.name,
          biography: str(c.biography),
          personality: str(c.personality),
          appearance: str(c.appearance),
          age: str(c.age),
          gender: str(c.gender),
          occupation: str(c.occupation),
          dialect: str(c.dialect),
          humor: str(c.humor),
          conflictStyle: str(c.conflictStyle),
          typicalPlace: str(c.typicalPlace),
          worldNotes: str(c.worldNotes),
          speechProfile: str(c.speechRegister),
          fears: arr(c.fears),
          secrets: arr(c.secrets),
          values: arr(c.values),
          likes: arr(c.likes),
          dislikes: arr(c.dislikes),
          taboos: arr(c.taboos),
          typicalPhrases: arr(c.typicalPhrases),
          favoriteWords: arr(c.favoriteWords),
          reactionRules: arr(c.reactionRules),
          bindingPatterns: arr(c.bindingPatterns),
          lastingAbilities: arr(c.lastingAbilities),
          traits: arr(c.coreFacts),
          fieldProvenance: (c.provenance as Record<string, string>) || {},
          source: "ki",
          worldRef: world.name,
          goals: arr(c.goals),
          knowledge: arr(c.knowledge),
          uncertainties: ["KI-Ableitung, vor Spawn prüfen"],
          derivedFields: Object.entries(c.provenance || {}).filter(([, v]) => v !== "belegt").map(([k]) => k).length
            ? Object.entries(c.provenance || {}).filter(([, v]) => v !== "belegt").map(([k]) => k)
            : ["biography", "role", "goals"],
          directFields: Object.entries(c.provenance || {}).filter(([, v]) => v === "belegt").map(([k]) => k).length
            ? Object.entries(c.provenance || {}).filter(([, v]) => v === "belegt").map(([k]) => k)
            : ["name"],
        }),
      );
      setSpawnPreview(preview);
      setSpawnPicked(Object.fromEntries(preview.map((c, i) => [spawnCandidateKey(c, i), true])));
      setSpawnDecision({});
      p({ spawnCandidates: preview });
      setTab("chars");
    } catch (e) {
      setErr(e instanceof Error ? e.message : "Spawn fehlgeschlagen");
    } finally {
      setBusy(false);
    }
  }

  function loadLocalSpawn() {
    if (!world) return;
    const cands = localSpawnCandidates(
      world,
      chars.map((c) => c.name),
    );
    setSpawnPreview(cands);
    setSpawnPicked(Object.fromEntries(cands.map((c, i) => [spawnCandidateKey(c, i), true])));
    setSpawnDecision({});
    const stored = world.spawnCandidates || [];
    const needsStamp = !stored.length || stored.some((c) => !c.id);
    if (needsStamp && cands.length) p({ spawnCandidates: cands });
    setTab("chars");
  }

  function editSpawn(id: string, patch: Partial<SpawnCandidate>) {
    setSpawnPreview((rows) => rows.map((x, i) => (spawnCandidateKey(x, i) === id ? { ...x, ...patch } : x)));
  }

  async function discardCandidate(id: string) {
    if (!world) return;
    const rows = spawnPreview.length ? spawnPreview : world.spawnCandidates || [];
    const remaining = rows.filter((c, i) => spawnCandidateKey(c, i) !== id);
    await patchWorld(world.id, { spawnCandidates: remaining });
    setSpawnPreview(remaining);
    setSpawnPicked((prev) => {
      const next = { ...prev };
      delete next[id];
      return next;
    });
    setSpawnDecision((prev) => {
      const next = { ...prev };
      delete next[id];
      return next;
    });
  }

  /** V28 (Nutzerbefund: gespawnte Stämme großteils leer): leere Profilfelder bestehender
   *  Weltfiguren über den konfigurierten Provider ergänzen — nur leere Felder, mit
   *  Provenienz, Belegpassagen aus dem Quelltext als Evidenz; kein Überschreiben (§53). */
  async function completeExistingProfiles() {
    if (!world) return;
    setBusy(true);
    setErr(null);
    try {
      const source = String((world as { sourceText?: string }).sourceText || world.long || "");
      const listKeys = ["typicalPhrases", "favoriteWords", "taboos", "values", "goals", "fears", "secrets", "likes", "dislikes", "reactionRules", "bindingPatterns", "knowledge", "coreFacts", "lastingAbilities"] as const;
      const strKeys = ["age", "gender", "occupation", "origin", "biography", "personality", "speechRegister", "dialect", "humor", "conflictStyle", "appearance", "typicalPlace", "worldNotes"] as const;
      const defaultReaction = "hält inne und prüft, was das mit ihr/ihm macht";
      const isDefaultCompass = (c: StammCharacter["compass"]) => Object.values(c || {}).every((cell) => !cell || !cell.reaction || cell.reaction === defaultReaction);
      let patched = 0;
      let failed = 0;
      // Defekte Listen aus V27-Analysen (Buchstabenlisten wie ["A","r","b"]) gelten als leer.
      const broken = (v: unknown) => Array.isArray(v) && v.length > 0 && v.every((x) => String(x).length <= 2);
      const filledList = (v: unknown) => Array.isArray(v) && v.length > 0 && !broken(v);
      for (const c of chars) {
        const rec = c as unknown as Record<string, unknown>;
        const cand: Record<string, unknown> = { name: c.name, aliases: c.aliases, role: c.role, sourceEvidence: source ? ownedPassagesForName(source, c.name, 8, 360) : [] };
        for (const k of strKeys) if (String(rec[k] || "").trim()) cand[k] = rec[k];
        for (const k of listKeys) if (filledList(rec[k])) cand[k] = rec[k];
        const res = await apiCompleteProfiles({ text: source.slice(0, 6000), title: world.name, candidates: [cand], roster: chars.map((x) => x.name) });
        const rows = (res.characterCandidates || []) as Array<Record<string, unknown> & { name?: string }>;
        const f = rows.find((x) => String(x.name || "").toLowerCase() === c.name.toLowerCase());
        if (!res.ok || !f) {
          failed++;
          if (!res.ok) setErr(String(res.message || res.llmError || "Provider antwortet nicht."));
          continue;
        }
        const patch: Record<string, unknown> = {};
        for (const k of strKeys) if (!String(rec[k] || "").trim() && String(f[k] || "").trim()) patch[k] = f[k];
        for (const k of listKeys) if (!filledList(rec[k]) && Array.isArray(f[k]) && (f[k] as unknown[]).length) patch[k] = f[k];
        if (isDefaultCompass(c.compass) && f.compass && typeof f.compass === "object" && Object.keys(f.compass as object).length) patch.compass = fillCompass(f.compass as Parameters<typeof fillCompass>[0]);
        if (!(c.relations || []).length && Array.isArray(f.relations) && (f.relations as unknown[]).length) patch.relations = f.relations;
        if (Object.keys(patch).length) {
          patch.fieldProvenance = { ...((rec.fieldProvenance as Record<string, string>) || {}), ...((f.fieldProvenance as Record<string, string>) || {}) };
          const ok = await patchCharacter(c.id, patch as Partial<StammCharacter>);
          if (ok) patched++;
          else failed++;
        }
      }
      setErr(`${patched} Figuren ergänzt (nur leere Felder, Provenienz markiert)${failed ? ` · ${failed} ohne Ergebnis` : ""}.`);
    } catch (e) {
      setErr(e instanceof Error ? e.message : "Profilergänzung fehlgeschlagen");
    } finally {
      setBusy(false);
    }
  }

  async function commitSpawn() {
    if (!world) return;
    const plans = spawnPreview.map((c, i) => {
      const key = spawnCandidateKey(c, i);
      const resolved = resolveSpawnAction({
        candidate: c,
        stamm: chars,
        picked: !!spawnPicked[key],
        decision: spawnDecision[key] || "",
      });
      return { c, key, ...resolved };
    });
    if (plans.some((p) => p.action === "need-decision")) {
      setErr("Namenskonflikt: gleiche Namen allein führen keine Identitäten zusammen. Bitte sichtbar entscheiden — neue Figur, vorhandene zuordnen, oder Kandidat verwerfen.");
      return;
    }
    const keep: SpawnCandidate[] = [];
    for (const plan of plans) {
      if (plan.action === "keep") {
        keep.push(plan.c);
        continue;
      }
      if (plan.action === "discard") continue;
      if (plan.action === "assign") {
        const target = plan.matches[0];
        if (!target) {
          keep.push(plan.c);
          continue;
        }
        const ok = await patchCharacter(target.id, applyCandidateToStamm(target, plan.c));
        if (!ok) keep.push(plan.c);
        continue;
      }
      const stammRel = (plan.c.stammRelations || []).filter((r) => r.targetName);
      // V25.1 CHAR-01: Neuer Stamm wird über denselben Kandidat→Stamm-Mapper gebildet wie
      // die Zuordnung zu einem vorhandenen Stamm — kein zweiter, unvollständiger Feldsatz.
      const created = applyCandidateToStamm(hydrateCharacter({
        ...emptyCharacter(world.id, plan.c.name),
        role: plan.c.role,
        origin: plan.c.origin,
        biography: plan.c.biography,
        personality: plan.c.personality || "",
        appearance: plan.c.appearance || "",
        goals: plan.c.goals || [],
        fears: plan.c.fears || [],
        secrets: plan.c.secrets || [],
        values: plan.c.values || [],
        knowledge: plan.c.knowledge || [],
        speechRegister: plan.c.speechProfile || "",
        typicalPhrases: plan.c.typicalPhrases || [],
        taboos: plan.c.taboos || [],
        relations: stammRel,
        bindingPatterns: stammRel.map((r) => `${r.kind} · ${r.targetName}`).slice(0, 4),
        body: { ...emptyCharacter(world.id, plan.c.name).body, notes: plan.c.bodyNotes || "" },
        isWorldNative: true,
        status: "entwurf",
        sourceRefs: [plan.c.source, plan.c.id].filter(Boolean),
        coreFacts: plan.c.traits || [],
        worldNotes: [plan.c.worldRef, ...(plan.c.relations || [])].filter(Boolean).join(" · "),
        canBeAvatar: Boolean(plan.c.canBeAvatar),
        compass: plan.c.compass ?? emptyCharacter(world.id, plan.c.name).compass,
      }), plan.c);
      const ok = await addCharacter(created);
      if (!ok) keep.push(plan.c);
    }
    await patchWorld(world.id, { spawnCandidates: keep });
    setSpawnPreview([]);
    setSpawnPicked({});
    setSpawnDecision({});
  }

  return (
    <Shell title={world.name}>
      <PageHead
        kicker={`Weltseite · ${world.id}`}
        title={world.name}
        lede={world.short}
        actions={
          <>
            <Button
              onClick={() => {
                void startSession({ worldId: world.id, situationId: sitId || undefined }).then((sid) => {
                  if (sid) nav({ href: `/chat/${sid}` });
                });
              }}
            >
              Session starten
            </Button>
            <Button variant="line" onClick={() => nav({ to: "/charakter" })}>
              Stämme
            </Button>
            <Button variant="line" onClick={() => {
              void packWorldWithSources(world, characters)
                .then((pack) => downloadJson(`${world.name.replace(/\s+/g, "_")}.world.json`, pack))
                .catch((e) => setErr(e instanceof Error ? e.message : "Weltexport fehlgeschlagen"));
            }}>
              Export
            </Button>
            <Button
              variant="line"
              onClick={() => {
                void apiBackupWorld(world.id)
                  .then((r) => {
                    setBackupMsg(`Sicherung ${r.backup?.name || r.backup?.id || "ok"}`);
                    return apiListWorldBackups(world.id);
                  })
                  .then((l) => setBackups(l.backups || []))
                  .catch((e) => setBackupMsg(e instanceof Error ? e.message : "Sicherung fehlgeschlagen"));
              }}
            >
              Sichern
            </Button>
            {(
              <Button
                variant="danger"
                onClick={() => {
                  if (confirm("Diese Welt gezielt löschen?")) {
                    deleteWorld(world.id);
                    nav({ to: "/welt" });
                  }
                }}
              >
                Löschen
              </Button>
            )}
          </>
        }
      />
      <Tabs
        value={tab}
        onChange={setTab}
        items={[
          { id: "live", label: "Live-Weltsicht" },
          { id: "basis", label: "Basisdaten" },
          { id: "orte", label: "Orte & Regeln" },
          { id: "struktur", label: "Struktur" },
          { id: "fate", label: "Fate" },
          { id: "wissen", label: "Wissen" },
          { id: "chars", label: "Charaktere" },
          { id: "ki", label: "KI / Analyse" },
          { id: "audit", label: "Audit" },
        ]}
      />

      {tab === "live" ? (
        <div className="grid gap-4 lg:grid-cols-3">
          <Panel title="Profil">
            <Row k="Genre" v={world.genre} />
            {genrePolicy ? <p className="mt-1 text-xs text-muted">{genrePolicy}</p> : null}
            <Row k="Ton" v={world.tone} />
            <Row k="Epoche" v={world.epoch} />
            {(world as { textMeta?: Record<string, string> }).textMeta ? (
              <Row k="Textsorte" v={`${(world as { textMeta?: Record<string, string> }).textMeta?.textsorte || "—"} · ${(world as { textMeta?: Record<string, string> }).textMeta?.erzaehlperspektive || "—"} · ${(world as { textMeta?: Record<string, string> }).textMeta?.sprachstil || "—"}`} />
            ) : null}
            {(world as { facetsSummary?: Record<string, number> }).facetsSummary ? (
              <Row k="Facetten (belegt)" v={Object.entries((world as { facetsSummary?: Record<string, number> }).facetsSummary || {}).filter(([, n]) => n).map(([k, n]) => `${k} ${n}`).join(" · ")} />
            ) : null}
            <Row k="Sichtbarkeit" v={world.visibility} />
            <Row k="Fate" v={world.fateEnabled ? "an" : "aus"} />
            {world.explicitOnly ? <Chip tone="warn">nur explizit wählbar</Chip> : null}
          </Panel>
          <Panel title="Bestand">
            <Row k="Stämme" v={String(chars.length)} />
            <Row k="Sessions" v={String(sess.length)} />
            <Row k="Uploads" v={String(ups.length)} />
            <Row k="Orte" v={String(world.places.length)} />
            <Row k="Regeln" v={String(world.rules.length)} />
            <Row k="Fraktionen" v={String(world.factions.length)} />
          </Panel>
          <Panel title="Startsituation">
            <Select value={sitId} onChange={(e) => setSitId(e.target.value)}>
              <option value="">Standard</option>
              {world.startSituations.map((s) => (
                <option key={s.id} value={s.id}>
                  {s.title}
                </option>
              ))}
            </Select>
            <ul className="mt-3 space-y-2 text-sm">
              {sess.slice(0, 6).map((s) => (
                <li key={s.id} className="flex justify-between">
                  <span>{s.name}</span>
                  <Link to="/chat/$sessionId" params={{ sessionId: s.id }} className="text-accent">
                    Öffnen
                  </Link>
                </li>
              ))}
            </ul>
            <h3 className="mt-4 text-sm font-semibold">Sicherungen</h3>
            {backupMsg ? <p className="mt-1 text-xs text-muted">{backupMsg}</p> : null}
            <ul className="mt-2 space-y-1 text-sm">
              {backups.slice(0, 6).map((b) => (
                <li key={b.id} className="flex items-center justify-between gap-2">
                  <span className="truncate">{b.name || b.id}</span>
                  <Button
                    variant="line"
                    className="min-h-8 px-2 text-xs"
                    onClick={() => {
                      if (!b.id) return;
                      void apiRestoreWorldBackup(world.id, b.id)
                        .then(() => setBackupMsg(`Wiederhergestellt: ${b.name || b.id}`))
                        .catch((e) => setBackupMsg(e instanceof Error ? e.message : "Restore fehlgeschlagen"));
                    }}
                  >
                    Wiederherstellen
                  </Button>
                </li>
              ))}
            </ul>
          </Panel>
        </div>
      ) : null}

      {tab === "basis" ? (
        <Panel>
          <div className="grid gap-3 sm:grid-cols-2">
            <Field label="Name">
              <Input value={world.name} onChange={(e) => p({ name: e.target.value })} />
            </Field>
            <Field label="Genre">
              <Input
                value={world.genre}
                onChange={(e) => p({ genre: e.target.value })}
                onBlur={() => {
                  if (world.genre) void apiGenrePolicy(world.genre, world.long || world.short || "").then((res) => {
                    const policy = (res.policy as { register?: string; violence?: string; lexicon?: string[] }) || {};
                    setGenrePolicy(
                      [`Register ${policy.register || "neutral"}`, `Gewalt ${policy.violence || "moderat"}`, res.inventsTruth ? "erfindet Wahrheit" : "erfindet keine Wahrheit"].join(" · "),
                    );
                  });
                }}
              />
            </Field>
            {genrePolicy ? <p className="text-xs text-muted sm:col-span-2">{genrePolicy}</p> : null}
            <Field label="Ton">
              <Input value={world.tone} onChange={(e) => p({ tone: e.target.value })} />
            </Field>
            <Field label="Epoche">
              <Input value={world.epoch} onChange={(e) => p({ epoch: e.target.value })} />
            </Field>
            <Field label="Geografie">
              <Input value={world.geography} onChange={(e) => p({ geography: e.target.value })} />
            </Field>
            <Field label="Sichtbarkeit">
              <Select value={world.visibility} onChange={(e) => p({ visibility: e.target.value as "public" | "private" })}>
                <option value="public">öffentlich (lokal)</option>
                <option value="private">privat</option>
              </Select>
            </Field>
          </div>
          <Field label="Kurz">
            <Textarea className="mt-1" rows={2} value={world.short} onChange={(e) => p({ short: e.target.value })} />
          </Field>
          <Field label="Lang">
            <Textarea className="mt-1" rows={6} value={world.long} onChange={(e) => p({ long: e.target.value })} />
          </Field>
          <Field label="Atmosphäre">
            <Textarea className="mt-1" rows={2} value={world.atmosphere} onChange={(e) => p({ atmosphere: e.target.value })} />
          </Field>
          <Field label="Ziel / Zweck">
            <Textarea className="mt-1" rows={2} value={world.purpose} onChange={(e) => p({ purpose: e.target.value })} />
          </Field>
          <Switch checked={world.fateEnabled} onChange={(v) => p({ fateEnabled: v })} label="Fate für diese Welt" />
        </Panel>
      ) : null}

      {tab === "orte" ? (
        <div className="grid gap-4 lg:grid-cols-2">
          <Panel title="Orte">
            <ul className="space-y-3">
              {world.places.map((place) => (
                <li key={place.id} className="rounded-[12px] bg-bg p-3">
                  <Input value={place.name} onChange={(e) => p({ places: world.places.map((x) => (x.id === place.id ? { ...x, name: e.target.value } : x)) })} />
                  <Textarea
                    className="mt-1"
                    rows={2}
                    value={place.description}
                    onChange={(e) => p({ places: world.places.map((x) => (x.id === place.id ? { ...x, description: e.target.value } : x)) })}
                  />
                  <Input
                    className="mt-1"
                    value={place.connections.join(", ")}
                    placeholder="Verbindungen"
                    onChange={(e) =>
                      p({ places: world.places.map((x) => (x.id === place.id ? { ...x, connections: e.target.value.split(",").map((s) => s.trim()).filter(Boolean) } : x)) })
                    }
                  />
                  <Select
                    className="mt-1"
                    value={place.parentId || ""}
                    onChange={(e) => p({ places: world.places.map((x) => (x.id === place.id ? { ...x, parentId: e.target.value || undefined } : x)) })}
                  >
                    <option value="">kein Überort</option>
                    {world.places
                      .filter((x) => x.id !== place.id)
                      .map((x) => (
                        <option key={x.id} value={x.id}>
                          Unterort von {x.name}
                        </option>
                      ))}
                  </Select>
                  <Input
                    className="mt-1"
                    value={(place.rules || []).join(", ")}
                    placeholder="Ortsregeln"
                    onChange={(e) =>
                      p({ places: world.places.map((x) => (x.id === place.id ? { ...x, rules: e.target.value.split(",").map((s) => s.trim()).filter(Boolean) } : x)) })
                    }
                  />
                  <Input
                    className="mt-1"
                    value={(place.tags || []).join(", ")}
                    placeholder="Tags"
                    onChange={(e) =>
                      p({ places: world.places.map((x) => (x.id === place.id ? { ...x, tags: e.target.value.split(",").map((s) => s.trim()).filter(Boolean) } : x)) })
                    }
                  />
                </li>
              ))}
            </ul>
            <Button
              variant="line"
              className="mt-2"
              onClick={() => {
                const place: Place = { id: uid("ort"), name: "Neuer Ort", description: "", connections: [], rules: [], tags: [] };
                p({ places: [...world.places, place] });
              }}
            >
              Ort hinzufügen
            </Button>
            <Button
              variant="line"
              className="mt-2 ml-2"
              onClick={() => {
                const parent = world.places[0];
                const place: Place = {
                  id: uid("ort"),
                  name: "Teilort",
                  description: "",
                  connections: parent ? [parent.name] : [],
                  rules: [],
                  tags: [],
                  parentId: parent?.id,
                };
                p({ places: [...world.places, place] });
              }}
            >
              Teilort
            </Button>
          </Panel>
          <Panel title="Regeln">
            <ul className="space-y-2">
              {world.rules.map((r) => (
                <li key={r.id} className="flex gap-2">
                  <Select
                    className="w-36"
                    value={r.kind}
                    onChange={(e) => p({ rules: world.rules.map((x) => (x.id === r.id ? { ...x, kind: e.target.value as WorldRule["kind"] } : x)) })}
                  >
                    {["physisch", "sozial", "rechtlich", "kulturell", "haus", "magie"].map((k) => (
                      <option key={k}>{k}</option>
                    ))}
                  </Select>
                  <Input value={r.text} onChange={(e) => p({ rules: world.rules.map((x) => (x.id === r.id ? { ...x, text: e.target.value } : x)) })} />
                </li>
              ))}
            </ul>
            <Button variant="line" className="mt-2" onClick={() => p({ rules: [...world.rules, { id: uid("rule"), kind: "sozial", text: "" }] })}>
              Regel
            </Button>
            <h3 className="mt-4 text-sm font-semibold">Fraktionen</h3>
            {world.factions.map((f) => (
              <div key={f.id} className="mt-2 rounded-[12px] bg-bg p-2">
                <Input value={f.name} onChange={(e) => p({ factions: world.factions.map((x) => (x.id === f.id ? { ...x, name: e.target.value } : x)) })} />
                <Textarea className="mt-1" rows={2} value={f.description} onChange={(e) => p({ factions: world.factions.map((x) => (x.id === f.id ? { ...x, description: e.target.value } : x)) })} />
                <Input
                  className="mt-1"
                  value={(f.members || []).join(", ")}
                  placeholder="Mitglieder"
                  onChange={(e) =>
                    p({ factions: world.factions.map((x) => (x.id === f.id ? { ...x, members: e.target.value.split(",").map((s) => s.trim()).filter(Boolean) } : x)) })
                  }
                />
              </div>
            ))}
            <Button variant="line" className="mt-2" onClick={() => p({ factions: [...world.factions, { id: uid("fac"), name: "Neue Fraktion", description: "", members: [] }] })}>
              Fraktion
            </Button>
          </Panel>
        </div>
      ) : null}

      {tab === "struktur" ? (
        <div className="grid gap-4 lg:grid-cols-2">
          <Panel title="Timeline (Kanon)">
            <ul className="space-y-2">
              {world.timeline.map((t) => (
                <li key={t.id} className="rounded-[12px] bg-bg p-2">
                  <div className="grid gap-2 sm:grid-cols-[140px_1fr]">
                    <Input value={t.when} onChange={(e) => p({ timeline: world.timeline.map((x) => (x.id === t.id ? { ...x, when: e.target.value } : x)) })} />
                    <Input value={t.text} onChange={(e) => p({ timeline: world.timeline.map((x) => (x.id === t.id ? { ...x, text: e.target.value } : x)) })} />
                  </div>
                </li>
              ))}
            </ul>
            <Button variant="line" className="mt-2" onClick={() => p({ timeline: [...world.timeline, { id: uid("tl"), when: "", text: "", actors: [] }] })}>
              Ereignis
            </Button>
          </Panel>
          <Panel title="Startszenen & Beats">
            {world.startSituations.map((s) => (
              <div key={s.id} className="mb-3 rounded-[12px] bg-bg p-2">
                <Input value={s.title} onChange={(e) => p({ startSituations: world.startSituations.map((x) => (x.id === s.id ? { ...x, title: e.target.value } : x)) })} />
                <Textarea className="mt-1" rows={2} value={s.opening} onChange={(e) => p({ startSituations: world.startSituations.map((x) => (x.id === s.id ? { ...x, opening: e.target.value } : x)) })} />
              </div>
            ))}
            <Field label="Typische Szenen">
              <Lines value={world.typicalScenes} onChange={(typicalScenes) => p({ typicalScenes })} />
            </Field>
            <h3 className="mt-3 text-sm font-semibold">Story-Beats</h3>
            {world.storyBeats.map((b) => (
              <div key={b.id} className="mt-2 rounded-[12px] bg-bg p-2">
                <Input value={b.title} onChange={(e) => p({ storyBeats: world.storyBeats.map((x) => (x.id === b.id ? { ...x, title: e.target.value } : x)) })} />
                <Textarea className="mt-1" rows={2} value={b.text} onChange={(e) => p({ storyBeats: world.storyBeats.map((x) => (x.id === b.id ? { ...x, text: e.target.value } : x)) })} />
              </div>
            ))}
            <Button variant="line" className="mt-2" onClick={() => p({ storyBeats: [...world.storyBeats, { id: uid("beat"), title: "Beat", text: "" }] })}>
              Beat
            </Button>
          </Panel>
        </div>
      ) : null}

      {tab === "fate" ? (
        <Panel title="Fate-Seeds — Druck, keine Wahrheit">
          <p className="mb-3 text-xs text-muted">Fate erzeugt Beats und Druck. Es besitzt keine Masterwahrheit und spricht nie als Figur.</p>
          <ul className="space-y-3">
            {world.fateSeeds.map((s) => (
              <li key={s.id} className="rounded-[12px] bg-bg p-3">
                <Input value={s.title} onChange={(e) => p({ fateSeeds: world.fateSeeds.map((x) => (x.id === s.id ? { ...x, title: e.target.value } : x)) })} />
                <Textarea className="mt-1" rows={2} value={s.beat} onChange={(e) => p({ fateSeeds: world.fateSeeds.map((x) => (x.id === s.id ? { ...x, beat: e.target.value } : x)) })} />
                <Input className="mt-1" value={s.mustNot} onChange={(e) => p({ fateSeeds: world.fateSeeds.map((x) => (x.id === s.id ? { ...x, mustNot: e.target.value } : x)) })} />
              </li>
            ))}
          </ul>
          <Button
            variant="line"
            className="mt-2"
            onClick={() => p({ fateSeeds: [...world.fateSeeds, { id: uid("seed"), title: "Neuer Druck", pressure: "", tags: [], beat: "", mustNot: "" }] })}
          >
            Seed
          </Button>
        </Panel>
      ) : null}

      {tab === "wissen" ? (
        <div className="grid gap-4 lg:grid-cols-2">
          <Panel title="Kanonisches Wissen">
            <Field label="Weltkanon">
              <Textarea className="mt-1" rows={4} value={world.canon || ""} onChange={(e) => p({ canon: e.target.value })} />
            </Field>
            <Field label="Referenzen">
              <Lines value={world.sourceRefs || []} onChange={(sourceRefs) => p({ sourceRefs })} />
            </Field>
            <Field label="Konflikte">
              <Lines value={world.conflicts} onChange={(conflicts) => p({ conflicts })} />
            </Field>
            <Field label="Weltziele">
              <Lines value={world.worldGoals} onChange={(worldGoals) => p({ worldGoals })} />
            </Field>
            <Field label="Wissensgrenzen">
              <Lines value={world.knowledgeLimits} onChange={(knowledgeLimits) => p({ knowledgeLimits })} />
            </Field>
            <Field label="Geheimnisse">
              <Lines value={world.secrets} onChange={(secrets) => p({ secrets })} />
            </Field>
            <Field label="Geheimes Wissen">
              <Lines value={world.secretKnowledge || []} onChange={(secretKnowledge) => p({ secretKnowledge })} />
            </Field>
            <Field label="Weltwissen">
              <Lines value={world.worldKnowledge || []} onChange={(worldKnowledge) => p({ worldKnowledge })} />
            </Field>
            <Field label="Kultur">
              <Lines value={world.culture || []} onChange={(culture) => p({ culture })} />
            </Field>
            <Field label="Sprache">
              <Lines value={world.language || []} onChange={(language) => p({ language })} />
            </Field>
          </Panel>
          <Panel title="Bestand">
            <Field label="Geschichte">
              <Lines value={world.history} onChange={(history) => p({ history })} />
            </Field>
            <Field label="Gegenstände">
              <Lines value={world.items} onChange={(items) => p({ items })} />
            </Field>
            <Field label="Wesen">
              <Lines value={world.beings} onChange={(beings) => p({ beings })} />
            </Field>
            <Field label="Figurenbeziehungen">
              <Lines
                value={(world.figureRelations || []).map((r) => {
                  const row = r as { from?: string; to?: string; kind?: string; text?: string };
                  return `${row.from || "?"} → ${row.to || "?"} · ${row.kind || "kennt"}${row.text ? `: ${row.text}` : ""}`;
                })}
                onChange={(lines) =>
                  p({
                    figureRelations: lines.map((line) => {
                      const m = line.match(/^(.+?)\s*→\s*(.+?)\s*·\s*([^:]+)(?::\s*(.*))?$/);
                      if (!m) return { from: line, to: "", kind: "kennt", text: line };
                      return { from: m[1].trim(), to: m[2].trim(), kind: m[3].trim(), text: (m[4] || "").trim() };
                    }),
                  })
                }
              />
            </Field>
            <p className="mt-3 text-xs text-muted">Uploads dieser Welt: {ups.length}. Weltwissen ist nicht automatisch Figurenwissen.</p>
            <ul className="mt-2 space-y-1 text-xs text-muted">
              {ups.slice(0, 8).map((u) => (
                <li key={u.id}>
                  {u.name} · {u.mode} · {u.status} {u.committed ? "· committed" : ""}
                </li>
              ))}
            </ul>
            <Button variant="line" className="mt-2" onClick={() => nav({ to: "/upload" })}>
              Upload-Center
            </Button>
            <h3 className="mt-4 text-sm font-semibold">Assets</h3>
            <ul className="mt-2 space-y-2">
              {(world.assets || []).map((a) => (
                <li key={a.id} className="rounded-[12px] bg-bg p-2">
                  <Input value={a.name} onChange={(e) => p({ assets: (world.assets || []).map((x) => (x.id === a.id ? { ...x, name: e.target.value } : x)) })} />
                  <Input className="mt-1" value={a.kind} onChange={(e) => p({ assets: (world.assets || []).map((x) => (x.id === a.id ? { ...x, kind: e.target.value } : x)) })} />
                  <Input className="mt-1" value={a.ref || ""} placeholder="Referenz" onChange={(e) => p({ assets: (world.assets || []).map((x) => (x.id === a.id ? { ...x, ref: e.target.value } : x)) })} />
                </li>
              ))}
            </ul>
            <Button variant="line" className="mt-2" onClick={() => p({ assets: [...(world.assets || []), { id: uid("asset"), name: "Asset", kind: "ref", ref: "" }] })}>
              Asset
            </Button>
            <h3 className="mt-4 text-sm font-semibold">Spawn-Vorlagen</h3>
            <ul className="mt-2 space-y-2">
              {(world.spawnTemplates || []).map((t) => (
                <li key={t.id} className="rounded-[12px] bg-bg p-2">
                  <Input value={t.name} onChange={(e) => p({ spawnTemplates: (world.spawnTemplates || []).map((x) => (x.id === t.id ? { ...x, name: e.target.value } : x)) })} />
                  <Textarea className="mt-1" rows={2} value={t.notes || ""} onChange={(e) => p({ spawnTemplates: (world.spawnTemplates || []).map((x) => (x.id === t.id ? { ...x, notes: e.target.value } : x)) })} />
                </li>
              ))}
            </ul>
            <Button variant="line" className="mt-2" onClick={() => p({ spawnTemplates: [...(world.spawnTemplates || []), { id: uid("spawnt"), name: "Vorlage", notes: "" }] })}>
              Spawn-Vorlage
            </Button>
            {(world.spawnCandidates || []).length ? (
              <p className="mt-3 text-xs text-muted">Gespeicherte Spawn-Kandidaten: {world.spawnCandidates!.length}</p>
            ) : null}
          </Panel>
        </div>
      ) : null}

      {tab === "chars" ? (
        <Panel title="Charaktere dieser Welt">
          <div className="mb-3 flex flex-wrap gap-2">
            <Button
              variant="line"
              onClick={() => {
                const c = emptyCharacter(world.id, "Neue Figur");
                addCharacter(c);
                nav({ href: `/charakter/${c.id}` });
              }}
            >
              Manuell anlegen
            </Button>
            <Button variant="line" disabled={busy} onClick={() => void spawnChars()}>
              KI-Kandidaten (Vorschau)
            </Button>
            <Button variant="line" disabled={busy || !chars.length} onClick={() => void completeExistingProfiles()}>
              {busy ? "Ergänzt…" : "Leere Profilfelder mit KI ergänzen"}
            </Button>
            <Button variant="line" onClick={loadLocalSpawn}>
              Lokale Kandidaten
            </Button>
          </div>
          {(world.spawnCandidates || []).length && !spawnPreview.length ? (
            <div className="mb-4 rounded-[12px] border border-border bg-bg p-3" data-testid="stored-spawn-candidates">
              <p className="text-sm font-medium">Figurenkandidaten — noch nicht Stamm</p>
              <ul className="mt-2 space-y-2">
                {(world.spawnCandidates || []).map((c, i) => {
                  const key = spawnCandidateKey(c, i);
                  const hits = sameNameStamm(c.name, chars);
                  return (
                    <li key={key} className="text-sm" data-testid={`stored-cand-${key}`} data-spawn-name={c.name}>
                      {c.name}{" "}
                      <span className="text-xs text-muted">
                        · {c.role || "ohne Rolle"} · {key}
                      </span>
                      {hits.length ? (
                        <p className="text-xs text-danger" data-testid="name-conflict">
                          Namenskonflikt mit Stamm {hits[0]!.name} ({hits[0]!.id}). Name ist kein Identitätsbeweis.
                        </p>
                      ) : null}
                    </li>
                  );
                })}
              </ul>
              <Button variant="line" className="mt-2 min-h-9 text-xs" onClick={loadLocalSpawn}>
                Kandidaten zur Spawn-Vorschau öffnen
              </Button>
            </div>
          ) : null}
          {spawnPreview.length ? (
            <div className="mb-4 rounded-[12px] border border-border bg-bg p-3" data-testid="spawn-preview">
              <p className="text-sm font-medium">Spawn-Vorschau — noch nicht Stamm</p>
              <ul className="mt-2 space-y-3">
                {spawnPreview.map((c, i) => {
                  const key = spawnCandidateKey(c, i);
                  const hits = sameNameStamm(c.name, chars);
                  const peerHits = spawnPreview.filter((x, j) => spawnCandidateKey(x, j) !== key && x.name.trim().toLowerCase() === c.name.trim().toLowerCase());
                  return (
                  <li key={key} className="rounded-[10px] border border-border p-2 text-sm" data-testid={`spawn-cand-${key}`} data-spawn-name={c.name}>
                    <label className="flex items-start gap-2">
                      <input
                        type="checkbox"
                        data-testid={`spawn-pick-${key}`}
                        data-spawn-name={c.name}
                        checked={!!spawnPicked[key]}
                        onChange={(e) => setSpawnPicked((p) => ({ ...p, [key]: e.target.checked }))}
                      />
                      <span className="font-medium">
                        {c.name}{" "}
                        <span className="text-xs text-muted">
                          · {c.role || "ohne Rolle"} · {c.source} · {key}
                        </span>
                      </span>
                    </label>
                    {hits.length || peerHits.length ? (
                      <div className="mt-2 rounded-[8px] border border-danger/40 bg-danger/5 p-2" data-testid="name-conflict">
                        <p className="text-xs text-danger">
                          Namenskonflikt: gleicher Name ist kein Identitätsbeweis.
                          {hits.length ? ` Vorhandener Stamm ${hits[0]!.name} (${hits[0]!.id}).` : ""}
                          {peerHits.length ? ` Weiterer Kandidat mit demselben Namen bleibt getrennt.` : ""}
                        </p>
                        <Select
                          className="mt-2"
                          data-testid={`spawn-decision-${key}`}
                          value={spawnDecision[key] || ""}
                          onChange={(e) => setSpawnDecision((p) => ({ ...p, [key]: e.target.value as SpawnDupDecision | "" }))}
                        >
                          <option value="">Namenskonflikt — sichtbar entscheiden</option>
                          <option value="new">Neue eigenständige Figur</option>
                          {hits.length ? <option value="assign">Vorhandene Figur ist dieselbe — Felder übernehmen</option> : null}
                          <option value="discard">Kandidat verwerfen</option>
                        </Select>
                      </div>
                    ) : null}
                    <div className="mt-2 grid gap-1 sm:grid-cols-2">
                      <Input value={c.name} placeholder="Name" onChange={(e) => editSpawn(key, { name: e.target.value })} />
                      <Input value={c.worldRef || ""} placeholder="Weltbezug" onChange={(e) => editSpawn(key, { worldRef: e.target.value })} />
                      <Input value={c.role} placeholder="Rolle" onChange={(e) => editSpawn(key, { role: e.target.value })} />
                      <Input value={c.origin} placeholder="Herkunft" onChange={(e) => editSpawn(key, { origin: e.target.value })} />
                      <Input value={c.speechProfile || ""} placeholder="Sprachprofil" onChange={(e) => editSpawn(key, { speechProfile: e.target.value })} />
                      <Input value={c.bodyNotes || ""} placeholder="Körper" onChange={(e) => editSpawn(key, { bodyNotes: e.target.value })} />
                    </div>
                    <Textarea className="mt-1" rows={2} value={c.biography} onChange={(e) => editSpawn(key, { biography: e.target.value })} />
                    <Input
                      className="mt-1"
                      value={(c.goals || []).join(", ")}
                      placeholder="Ziele"
                      onChange={(e) => editSpawn(key, { goals: e.target.value.split(",").map((s) => s.trim()).filter(Boolean) })}
                    />
                    <Input
                      className="mt-1"
                      value={(c.fears || []).join(", ")}
                      placeholder="Ängste"
                      onChange={(e) => editSpawn(key, { fears: e.target.value.split(",").map((s) => s.trim()).filter(Boolean) })}
                    />
                    <Input
                      className="mt-1"
                      value={(c.secrets || []).join(", ")}
                      placeholder="Geheimnisse"
                      onChange={(e) => editSpawn(key, { secrets: e.target.value.split(",").map((s) => s.trim()).filter(Boolean) })}
                    />
                    <Input
                      className="mt-1"
                      value={(c.values || []).join(", ")}
                      placeholder="Werte"
                      onChange={(e) => editSpawn(key, { values: e.target.value.split(",").map((s) => s.trim()).filter(Boolean) })}
                    />
                    <Input
                      className="mt-1"
                      value={(c.conflicts || []).join(", ")}
                      placeholder="Konflikte"
                      onChange={(e) => editSpawn(key, { conflicts: e.target.value.split(",").map((s) => s.trim()).filter(Boolean) })}
                    />
                    <Input
                      className="mt-1"
                      value={(c.knowledge || []).join(", ")}
                      placeholder="Wissen"
                      onChange={(e) => editSpawn(key, { knowledge: e.target.value.split(",").map((s) => s.trim()).filter(Boolean) })}
                    />
                    <Input
                      className="mt-1"
                      value={(c.relations || []).join(", ")}
                      placeholder="Beziehungen"
                      onChange={(e) => editSpawn(key, { relations: e.target.value.split(",").map((s) => s.trim()).filter(Boolean) })}
                    />
                    <Input
                      className="mt-1"
                      value={(c.traits || []).join(", ")}
                      placeholder="Eigenschaften"
                      onChange={(e) => editSpawn(key, { traits: e.target.value.split(",").map((s) => s.trim()).filter(Boolean) })}
                    />
                    <Input
                      className="mt-1"
                      value={(c.uncertainties || []).join(", ")}
                      placeholder="Unsicherheiten"
                      onChange={(e) => editSpawn(key, { uncertainties: e.target.value.split(",").map((s) => s.trim()).filter(Boolean) })}
                    />
                    <label className="mt-2 flex items-center gap-2 text-xs">
                      <input
                        type="checkbox"
                        data-testid={`spawn-avatar-${key}`}
                        data-spawn-name={c.name}
                        checked={!!c.canBeAvatar}
                        onChange={(e) => editSpawn(key, { canBeAvatar: e.target.checked })}
                      />
                      Avatarfähig (Charaktereigenschaft, keine automatische Session-Zuordnung)
                    </label>
                    <Button
                      variant="line"
                      className="mt-2 min-h-9 text-xs"
                      data-testid={`spawn-discard-${key}`}
                      onClick={() => void discardCandidate(key)}
                    >
                      Kandidat verwerfen
                    </Button>
                    <p className="mt-1 text-[11px] text-muted">
                      direkt: {(c.directFields || []).join(", ") || "name"} · abgeleitet: {(c.derivedFields || []).join(", ") || "—"}
                    </p>
                  </li>
                  );
                })}
              </ul>
              <Button className="mt-2 min-h-9 text-xs" onClick={() => void commitSpawn()}>
                Ausgewählte spawnen
              </Button>
            </div>
          ) : null}
          <ul className="grid gap-2 sm:grid-cols-2">
            {chars.map((c) => (
              <li key={c.id}>
                <Link to="/charakter/$charId" params={{ charId: c.id }} data-stamm-id={c.id} data-stamm-name={c.name} className="block rounded-[12px] border border-border bg-bg px-3 py-2 hover:border-accent">
                  <p className="text-sm font-medium">{c.name}</p>
                  <p className="text-[11px] text-muted font-mono">{c.id}</p>
                  <p className="text-xs text-muted">{[c.role, ...(c.aliases || []).filter((a) => a !== c.name)].filter(Boolean).join(" · ")}</p>
                  {(c.relations || []).length ? (
                    <p className="text-[11px] text-muted">
                      {(c.relations || []).slice(0, 4).map((r) => `${r.kind} ${r.targetName}`).join(" · ")}
                    </p>
                  ) : null}
                  {(c.canon || []).length ? (
                    <p className="mt-1 text-[11px] text-muted">
                      {(c.canon || [])[0]}
                      {(c.canon || []).length > 1 ? ` → ${(c.canon || [])[(c.canon || []).length - 1]}` : ""}
                    </p>
                  ) : null}
                  <Chip>{c.status}</Chip>
                </Link>
              </li>
            ))}
          </ul>
        </Panel>
      ) : null}

      {tab === "ki" ? (
        <Panel title="Weltanalyse §11 — prüfbarer Entwurf">
          <p className="text-sm text-muted">
            Strukturierte Felder einzeln ticken. Bestätigen schreibt Mode-A-Reviews (Welt-Scope), kein stilles Commit, kein Szenenfakt.
          </p>
          <Textarea className="mt-2" rows={4} value={idea} onChange={(e) => setIdea(e.target.value)} placeholder="Was soll ergänzt oder verdichtet werden?" />
          <div className="mt-3 flex flex-wrap gap-2">
            <Button disabled={busy} onClick={() => void kiExtend()}>
              {busy ? "Arbeitet…" : "Entwurf erzeugen"}
            </Button>
            <label className="inline-flex min-h-11 cursor-pointer items-center rounded-[12px] border border-border bg-elevated px-4 text-sm">
              Quelle analysieren
              <input
                type="file"
                accept=".epub,.txt,.md,.html,.json,.pdf,.pptx"
                className="hidden"
                disabled={busy}
                onChange={(e) => {
                  const f = e.target.files?.[0];
                  if (f) void runWorldAnalyze(f);
                }}
              />
            </label>
            <Button
              disabled={busy || !String(world.sourceText || "").trim()}
              onClick={() => void rereadSourceNames()}
            >
              {busy ? "Arbeitet…" : "Namen aus der Quelle"}
            </Button>
          </div>
          <p className="mt-2 text-xs text-muted">Bild ohne Text: lokale OCR (Tesseract.js, Deutsch). Leer bleibt leer. Cloud-OCR gesperrt.</p>
          <Button
            className="mt-2"
            disabled={busy || !idea.trim()}
            onClick={() => {
              const text = idea.trim();
              const file = new File([text], "quelle.txt", { type: "text/plain" });
              void runWorldAnalyze(file);
            }}
          >
            Text als Quelle analysieren
          </Button>
          {epubParts?.length ? (
            <div className="mt-4 rounded-[12px] border border-border bg-bg p-3">
              <p className="text-sm font-medium">Teile nach Landmarks</p>
              {sourceA11y && (sourceA11y.language || sourceA11y.accessMode?.length) ? (
                <p className="mt-1 flex flex-wrap gap-1">
                  {sourceA11y.language ? <Chip>Sprache {sourceA11y.language}</Chip> : null}
                  {(sourceA11y.accessMode || []).map((m) => (
                    <Chip key={m}>{m}</Chip>
                  ))}
                </p>
              ) : null}
              <ul className="mt-2 max-h-64 space-y-1 overflow-auto">
                {epubParts.map((p, i) => (
                  <li key={`${p.zipPath}#${p.anchor}-${i}`}>
                    <Switch
                      checked={p.selected}
                      onChange={(v) => setEpubParts((rows) => (rows || []).map((x, j) => (j === i ? { ...x, selected: v } : x)))}
                      label={`${p.title || p.zipPath} · ${p.docId ? `${p.docId} · ` : ""}${zoneLabel(p.zone)}${p.kind ? ` · ${kindLabel(p.kind)}` : ""}${layerLabel(p.layer) ? ` · ${layerLabel(p.layer)}` : ""}`}
                    />
                  </li>
                ))}
              </ul>
              <Button className="mt-3" disabled={busy || !epubParts.some((p) => p.selected)} onClick={() => void analyzePickedWorldParts()}>
                {busy ? "Arbeitet…" : "Gewählte Teile analysieren"}
              </Button>
              <p className="mt-2 text-xs text-muted">Scan-Seiten: als Bild OCR (max. 8). Textschicht bleibt unangetastet.</p>
            </div>
          ) : null}
          {analysisDraft ? (
            <div className="mt-4 rounded-[12px] border border-border bg-bg p-3">
              <p className="text-sm font-medium">§11-Felder — einzeln bestätigen</p>
              <p className="mt-1 text-xs text-muted">
                {analysisDraft.recognize === "llm"
                  ? "Erkennung: Original gelesen, Rollen und Keywords etikettiert. Kein neuer Text."
                  : "Erkennung: lokal aus dem Original."}
                {(analysisDraft.keywords || []).length ? ` · ${analysisDraft.keywords!.join(" · ")}` : ""}
              </p>
              <ul className="mt-2 space-y-2">
                {draftFieldGroups(analysisDraft).map((g) => (
                  <li key={g.field} className="rounded-[10px] border border-border p-2 text-sm">
                    <label className="flex items-start gap-2">
                      <input
                        type="checkbox"
                        checked={groupPick[g.field] !== false}
                        onChange={(e) => setGroupPick((p) => ({ ...p, [g.field]: e.target.checked }))}
                      />
                      <span>
                        <span className="font-medium">{g.label}</span>
                        <span className="ml-2 text-[11px] text-muted">{g.field}</span>
                        <span className="mt-1 block text-xs text-muted">{g.preview}</span>
                      </span>
                    </label>
                  </li>
                ))}
              </ul>
              <p className="mt-2 text-xs text-muted">Neue Figuren bleiben Kandidaten. Stamm erst nach sichtbarer Spawn-Vorschau und bewusster Auswahl.</p>
              <Button className="mt-3" disabled={busy} onClick={() => void confirmAnalysisReviews()}>
                Markierte Felder übernehmen — Welt speichern, Kandidaten merken
              </Button>
            </div>
          ) : null}
          {err ? <p className="mt-2 text-sm text-danger">{err}</p> : null}
        </Panel>
      ) : null}

      {tab === "audit" ? (
        <Panel title="Audit">
          <pre className="max-h-96 overflow-auto font-mono text-[11px] text-muted">
            {JSON.stringify(
              {
                id: world.id,
                source: world.sourceName,
                places: world.places.map((x) => x.name),
                stamm: chars.map((c) => c.name),
                sessions: sess.map((s) => ({ id: s.id, turns: s.turnIndex })),
                reviews: reviews.filter((r) => r.worldId === world.id).length,
              },
              null,
              2,
            )}
          </pre>
        </Panel>
      ) : null}
    </Shell>
  );
}

function Row({ k, v }: { k: string; v: string }) {
  return (
    <p className="flex justify-between gap-2 text-sm">
      <span className="text-faint">{k}</span>
      <span className="truncate text-right">{v}</span>
    </p>
  );
}

function oldWorldField(world: World, field: string): string {
  const v = (world as unknown as Record<string, unknown>)[field];
  if (v == null) return "";
  if (typeof v === "string") return v.slice(0, 80);
  try {
    return JSON.stringify(v).slice(0, 80);
  } catch {
    return "";
  }
}
