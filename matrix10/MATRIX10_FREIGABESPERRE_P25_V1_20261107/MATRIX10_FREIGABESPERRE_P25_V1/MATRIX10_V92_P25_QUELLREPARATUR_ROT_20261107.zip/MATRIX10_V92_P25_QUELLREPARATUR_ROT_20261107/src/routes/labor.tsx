import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { confirmReset } from "@/lib/matrix/confirm-reset";
import { useEffect, useMemo, useState } from "react";
import { Shell, Panel } from "@/components/shell";
import { Button, Chip, Input, Select } from "@/components/ui";
import { useHydrated, useMccReaderError } from "@/lib/matrix/use-hydrated";
import { useSelectableWorlds } from "@/lib/matrix/use-selectable";
import { useMatrix } from "@/lib/matrix/store";
import { apiHealth } from "@/lib/matrix/api";
import { BUILD_ID, GASTHAUS_ID } from "@/lib/matrix/types";
import { uid } from "@/lib/matrix/ids";

export const Route = createFileRoute("/labor")({ component: Dashboard });

function Dashboard() {
  const nav = useNavigate();
  const hydrated = useHydrated();
  const users = useMatrix((s) => s.users);
  const worlds = useSelectableWorlds();
  const sessions = useMatrix((s) => s.sessions);
  const activeUserId = useMatrix((s) => s.activeUserId);
  const upsertUser = useMatrix((s) => s.upsertUser);
  const setActiveUser = useMatrix((s) => s.setActiveUser);
  const deleteUser = useMatrix((s) => s.deleteUser);
  const startSession = useMatrix((s) => s.startSession);
  const setActiveSession = useMatrix((s) => s.setActiveSession);
  const deleteSession = useMatrix((s) => s.deleteSession);
  const resetSessionFull = useMatrix((s) => s.resetSessionFull);
  const resetSessionChat = useMatrix((s) => s.resetSessionChat);
  const resetSessionRuntime = useMatrix((s) => s.resetSessionRuntime);
  const resetSessionMemory = useMatrix((s) => s.resetSessionMemory);
  const resetSessionUploads = useMatrix((s) => s.resetSessionUploads);
  const resetUserSessions = useMatrix((s) => s.resetUserSessions);
  const hardResetRuntime = useMatrix((s) => s.hardResetRuntime);
  const kernelReset = useMatrix((s) => s.kernelReset);
  const logs = useMatrix((s) => s.logs);
  const providerOnline = useMatrix((s) => s.providerOnline);
  const readerError = useMccReaderError();

  const [name, setName] = useState("");
  const [worldId, setWorldId] = useState("");
  const [resetUserId, setResetUserId] = useState("");
  const [resetSessionId, setResetSessionId] = useState("");
  const [audit, setAudit] = useState("");
  const [health, setHealth] = useState<{
    ok?: boolean;
    db?: string;
    buildId?: string;
    sqlite?: boolean;
    secondMaster?: boolean;
    pgliteRunning?: boolean;
    neonRunning?: boolean;
    productStore?: string;
    llmKeyPresent?: boolean;
    llmProvider?: string;
    llmModel?: string;
  } | null>(null);

  useEffect(() => {
    void apiHealth()
      .then((h) =>
        setHealth(
          h as {
            ok?: boolean;
            db?: string;
            buildId?: string;
            sqlite?: boolean;
            secondMaster?: boolean;
            pgliteRunning?: boolean;
            neonRunning?: boolean;
            productStore?: string;
            llmKeyPresent?: boolean;
            llmProvider?: string;
            llmModel?: string;
          },
        ),
      )
      .catch(() => setHealth({ ok: false }));
  }, []);

  useEffect(() => {
    setResetUserId(activeUserId || "");
    setResetSessionId("");
  }, [activeUserId]);

  const resetSessions = sessions.filter((s) => s.userId === resetUserId);
  const activeUser = users.find((u) => u.id === activeUserId);
  const canResetSelf = Boolean(resetUserId && resetUserId === activeUserId);
  const resetTargets = users.filter((u) => u.id === activeUserId);

  const inventory = useMemo(() => {
    if (!hydrated) return "";
    return JSON.stringify(
      {
        build: BUILD_ID,
        users: users.map((u) => ({ id: u.id, name: u.name, lastSession: u.lastSessionId })),
        worlds: worlds.map((w) => ({ id: w.id, name: w.name, explicitOnly: !!w.explicitOnly })),
        sessions: sessions.map((s) => ({ id: s.id, name: s.name, user: s.userId, world: s.worldId, turns: s.turnIndex })),
        stamm: useMatrix.getState().characters.filter((c) => c.isWorldNative).length,
      },
      null,
      2,
    );
  }, [hydrated, users, worlds, sessions]);

  async function createUser() {
    const n = name.trim();
    if (!n) return;
    const id = n.toLowerCase() === "admin" ? "admin" : uid("user");
    const ok = await upsertUser({
      id,
      name: n,
      language: "de",
      defaultRole: "teilnehmer",
      lastWorldId: worldId || null,
      lastSessionId: null,
      tts: false,
      sttMode: "dictation",
      largeType: false,
      highContrast: false,
      createdAt: new Date().toISOString(),
      avatarsByWorld: worldId ? { [worldId]: "" } : {},
      avatarsBySession: {},
      providerConfig: { localOnly: true },
    });
    if (!ok) return;
    if (worldId) {
      const sid = await startSession({ worldId, userId: id, name: `${n} Session` });
      if (sid) setActiveSession(sid);
    }
    setName("");
  }

  if (!hydrated) {
    return (
      <Shell title="Dashboard">
        <p className="text-sm text-muted">
          {readerError ? `Reader fehlgeschlagen: ${readerError}` : "Lädt kanonischen Stand aus SQLite…"}
        </p>
      </Shell>
    );
  }

  return (
    <Shell title="MCC Dashboard">
      <div className="mb-5 flex flex-wrap items-end justify-between gap-3">
        <div>
          <p className="text-[11px] uppercase tracking-[0.18em] text-faint">Start</p>
          <h1 className="font-display text-3xl font-semibold tracking-tight">MCC Dashboard</h1>
          <p className="mt-1 text-sm text-muted">Lokales KI-Universum. Stamm bleibt Stamm. Session bleibt isoliert.</p>
        </div>
        <div className="flex flex-wrap gap-3 text-xs text-muted">
          <span>
            Build <strong className="text-fg">{BUILD_ID}</strong>
          </span>
          <span>
            Server <strong className={health?.ok ? "text-ok" : "text-danger"}>{health?.ok ? "verbunden" : health ? "getrennt" : "prüft…"}</strong>
          </span>
          <span>
            SQLite <strong className="text-fg">{health?.sqlite === false ? "nein" : health?.db ? "aktiv" : "…"}</strong>
          </span>
          <span className="max-w-[28ch] truncate" title={health?.db || ""}>
            DB <strong className="text-fg">{health?.db ? String(health.db).split("/").pop() : "—"}</strong>
          </span>
          <span>
            Store <strong className="text-fg">{health?.productStore || "flask-sqlite"}</strong>
          </span>
          <span>
            Zweiter Master <strong className={health?.secondMaster ? "text-danger" : "text-ok"}>{health?.secondMaster ? "ja" : "nein"}</strong>
          </span>
          <span>
            PGLite <strong className="text-fg">{health?.pgliteRunning ? "läuft" : "aus"}</strong>
          </span>
          <span>
            Neon <strong className="text-fg">{health?.neonRunning ? "läuft" : "aus"}</strong>
          </span>
          <span>
            User <strong className="text-fg">{activeUser?.name}</strong>
          </span>
          <span>
            Welten <strong className="tabular-nums text-fg">{worlds.length}</strong>
          </span>
          <span>
            Provider <strong className={health?.llmKeyPresent || providerOnline ? "text-ok" : "text-fg"}>
              {health?.llmKeyPresent
                ? `${health?.llmProvider || "llm"} ${health?.llmModel || ""}`.trim()
                : providerOnline
                  ? "geprüft"
                  : "Synapse lokal"}
            </strong>
          </span>
          <span>
            Letzte Welt <strong className="text-fg">{worlds.find((w) => w.id === activeUser?.lastWorldId)?.name || activeUser?.lastWorldId || "—"}</strong>
          </span>
          <span>
            Letzte Session <strong className="text-fg">{sessions.find((s) => s.id === activeUser?.lastSessionId)?.name || activeUser?.lastSessionId || "—"}</strong>
          </span>
        </div>
      </div>

      <Panel className="mb-5">
        {!activeUserId ? (
          <p className="mb-3 rounded-[12px] border border-accent/40 bg-subtle px-3 py-2 text-sm text-accent">
            Kein aktiver User. Bitte einen vorhandenen User wählen oder einen neuen anlegen — es gibt keinen stillen Admin-Fallback.
          </p>
        ) : null}
        <p className="mb-3 text-xs font-medium uppercase tracking-wide text-muted">Benutzer anlegen</p>
        <div className="flex flex-col gap-2 sm:flex-row">
          <Input value={name} onChange={(e) => setName(e.target.value)} placeholder="Namen eingeben" onKeyDown={(e) => e.key === "Enter" && createUser()} />
          <Select value={worldId} onChange={(e) => setWorldId(e.target.value)}>
            <option value="">Welt wählen (nicht automatisch Gasthaus)</option>
            {worlds.map((w) => (
              <option key={w.id} value={w.id}>
                {w.name}
                {w.explicitOnly ? " — nur explizit" : ""}
              </option>
            ))}
          </Select>
          <Button onClick={createUser}>Erstellen</Button>
        </div>
        <p className="mt-2 text-xs text-faint">
          Gasthaus zum siebten Kreis wird nicht vorausgewählt. Welt, Session und Avatar sind getrennte Entitäten.
        </p>
      </Panel>

      <div className="grid gap-5 lg:grid-cols-[minmax(0,1.4fr)_minmax(0,1fr)]">
        <Panel title="Benutzer und Sessions">
          <ul className="space-y-4">
            {users.map((u) => {
              const mine = sessions.filter((s) => s.userId === u.id);
              return (
                <li key={u.id} className="rounded-[12px] border border-border bg-bg p-3">
                  <div className="flex flex-wrap items-center gap-2">
                    <p className="font-medium">
                      {u.name} {u.id === activeUserId ? <Chip hot>aktiv</Chip> : null}
                    </p>
                    <Button variant="line" className="min-h-9 px-3 text-xs" onClick={() => void setActiveUser(u.id)}>
                      Wählen
                    </Button>
                    <Button
                      variant="ok"
                      className="min-h-9 px-3 text-xs"
                      onClick={() => {
                        const w = worldId || u.lastWorldId || worlds.find((x) => !x.explicitOnly)?.id || (worlds[0] && worlds[0].id === GASTHAUS_ID ? worlds[0].id : worlds[0]?.id);
                        if (!w) return;
                        void setActiveUser(u.id).then(async () => {
                          const sid = await startSession({ worldId: w, userId: u.id, name: `${u.name} Session` });
                          if (sid) nav({ href: `/chat/${sid}` });
                        });
                      }}
                    >
                      Session
                    </Button>
                    {u.id !== "admin" ? (
                      <Button variant="danger" className="min-h-9 px-3 text-xs" onClick={() => deleteUser(u.id)}>
                        User löschen
                      </Button>
                    ) : null}
                  </div>
                  <ul className="mt-2 space-y-1">
                    {mine.length === 0 ? <li className="text-xs text-faint">Keine Session</li> : null}
                    {mine.map((s) => {
                      const w = worlds.find((x) => x.id === s.worldId);
                      return (
                        <li key={s.id} className="flex flex-wrap items-center gap-2 rounded-[8px] bg-elevated px-2 py-1.5 text-sm">
                          <span className="flex-1 truncate">{s.name}</span>
                          <Chip>{w?.name ?? s.worldId}</Chip>
                          <span className="text-[11px] tabular-nums text-faint">Turn {s.turnIndex}</span>
                          <Button
                            variant="line"
                            className="min-h-8 px-2 text-xs"
                            onClick={() => {
                              void setActiveUser(u.id).then(() => {
                                setActiveSession(s.id);
                                nav({ href: `/chat/${s.id}` });
                              });
                            }}
                          >
                            Öffnen
                          </Button>
                          <Button variant="danger" className="min-h-8 px-2 text-xs" onClick={() => confirmReset("delete", s.name) && deleteSession(s.id)}>
                            Löschen
                          </Button>
                        </li>
                      );
                    })}
                  </ul>
                </li>
              );
            })}
          </ul>
        </Panel>

        <div className="space-y-5">
          <Panel title="Reset und Prüfung">
            <div className="grid gap-3 sm:grid-cols-2">
              <div>
                <p className="mb-1 text-xs text-muted">Reset-Ziel: Benutzer</p>
                <Select value={resetUserId} onChange={(e) => setResetUserId(e.target.value)}>
                  {resetTargets.length === 0 ? <option value="">Kein aktiver User</option> : null}
                  {resetTargets.map((u) => (
                    <option key={u.id} value={u.id}>
                      Aktiv: {u.name}
                    </option>
                  ))}
                </Select>
              </div>
              <div>
                <p className="mb-1 text-xs text-muted">Ziel-Session</p>
                <Select value={resetSessionId} onChange={(e) => setResetSessionId(e.target.value)}>
                  <option value="">{resetSessions.length ? "Session wählen" : "Keine Session"}</option>
                  {resetSessions.map((s) => (
                    <option key={s.id} value={s.id}>
                      {s.name}
                    </option>
                  ))}
                </Select>
              </div>
            </div>
            <p className="mt-2 text-xs text-ok">Gewählter Avatar wird nicht gelöscht. Stamm und Welten bleiben.</p>
            <p className="mt-1 text-xs text-muted">Hard Reset und User-Reset nur für den aktiven User. Fremduser werden nicht angeboten.</p>
            <div className="mt-3 grid gap-2">
              <Button
                variant="line"
                disabled={!resetSessionId}
                onClick={() => {
                  if (!resetSessionId || !confirmReset("chat")) return;
                  resetSessionChat(resetSessionId);
                }}
              >
                Nur Chat
              </Button>
              <Button
                variant="line"
                disabled={!resetSessionId}
                onClick={() => {
                  if (!resetSessionId || !confirmReset("runtime")) return;
                  resetSessionRuntime(resetSessionId);
                }}
              >
                Nur Runtime
              </Button>
              <Button
                variant="line"
                disabled={!resetSessionId}
                onClick={() => {
                  if (!resetSessionId || !confirmReset("memory")) return;
                  resetSessionMemory(resetSessionId);
                }}
              >
                Nur Memory
              </Button>
              <Button
                variant="line"
                disabled={!resetSessionId}
                onClick={() => {
                  if (!resetSessionId || !confirmReset("uploads")) return;
                  resetSessionUploads(resetSessionId);
                }}
              >
                Nur Uploadkontext
              </Button>
              <Button
                variant="danger"
                disabled={!resetSessionId}
                onClick={() => {
                  if (!resetSessionId) return;
                  if (confirmReset("full")) resetSessionFull(resetSessionId);
                }}
              >
                Session vollständig
              </Button>
              <Button
                variant="danger"
                disabled={!canResetSelf}
                onClick={() => {
                  if (!canResetSelf) return;
                  if (confirm(`Alle Sessions von ${resetUserId} löschen? Konto, Avatar, Welten, Stamm bleiben.`)) resetUserSessions(resetUserId);
                }}
              >
                User zurücksetzen (alle Sessions + Uploads)
              </Button>
              <Button
                variant="danger"
                disabled={!canResetSelf}
                onClick={() => {
                  if (!canResetSelf) return;
                  if (confirm(`USER HARD RESET: Runtime von ${resetUserId}. Konten, Welten, Stämme bleiben. Kein installationsweiter Wipe.`)) {
                    hardResetRuntime(resetUserId);
                  }
                }}
              >
                USER HARD RESET (dieser User)
              </Button>
              <Button
                variant="line"
                disabled={!resetSessionId}
                onClick={() => {
                  if (!resetSessionId) return;
                  kernelReset(resetSessionId, "chat");
                }}
              >
                Kernel-Reset Chat
              </Button>
              <Button
                variant="line"
                disabled={!resetSessionId}
                onClick={() => {
                  if (!resetSessionId) return;
                  kernelReset(resetSessionId, "runtime");
                }}
              >
                Kernel-Reset Runtime
              </Button>
              <Button
                variant="line"
                disabled={!resetSessionId}
                onClick={() => {
                  if (!resetSessionId) return;
                  kernelReset(resetSessionId, "memory");
                }}
              >
                Kernel-Reset Memory
              </Button>
              <Button
                variant="line"
                disabled={!resetSessionId}
                onClick={() => {
                  if (!resetSessionId) return;
                  kernelReset(resetSessionId, "uploads");
                }}
              >
                Kernel-Reset Uploadkontext
              </Button>
              <Button variant="line" onClick={() => setAudit(inventory)}>
                Runtime-Audit anzeigen
              </Button>
              <Button
                variant="line"
                onClick={() =>
                  setAudit(
                    logs
                      .filter((l) => l.code.startsWith("RESET") || l.code === "HARD_RESET")
                      .slice(0, 12)
                      .map((l) => `${l.at} ${l.code} ${l.message}`)
                      .join("\n") || "Kein Reset-Report.",
                  )
                }
              >
                Reset-Report anzeigen
              </Button>
            </div>
            {audit ? <pre className="mt-3 max-h-64 overflow-auto font-mono text-[11px] leading-relaxed text-muted">{audit}</pre> : null}
          </Panel>
        </div>
      </div>
    </Shell>
  );
}
