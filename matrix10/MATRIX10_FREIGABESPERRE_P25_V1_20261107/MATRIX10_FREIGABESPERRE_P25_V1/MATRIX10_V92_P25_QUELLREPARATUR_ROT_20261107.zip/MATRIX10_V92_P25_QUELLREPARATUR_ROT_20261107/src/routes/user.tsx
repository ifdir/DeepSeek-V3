import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useState } from "react";
import { Shell, Panel } from "@/components/shell";
import { Button, Input, Select } from "@/components/ui";
import { uid } from "@/lib/matrix/ids";
import { useMatrix } from "@/lib/matrix/store";
import { useHydrated } from "@/lib/matrix/use-hydrated";
import type { SpeakerMode } from "@/lib/matrix/types";
import { makeOutsiderAvatar } from "@/lib/matrix/seed-gasthaus";

export const Route = createFileRoute("/user")({ component: UserPage });

function UserPage() {
  const nav = useNavigate();
  const hydrated = useHydrated();
  const users = useMatrix((s) => s.users);
  const worlds = useMatrix((s) => s.worlds);
  const sessions = useMatrix((s) => s.sessions);
  const characters = useMatrix((s) => s.characters);
  const activeUserId = useMatrix((s) => s.activeUserId);
  const setActiveUser = useMatrix((s) => s.setActiveUser);
  const upsertUser = useMatrix((s) => s.upsertUser);
  const patchUser = useMatrix((s) => s.patchUser);
  const deleteUser = useMatrix((s) => s.deleteUser);
  const addCharacter = useMatrix((s) => s.addCharacter);
  const [name, setName] = useState("");
  const [avatarName, setAvatarName] = useState("");
  const [avatarErr, setAvatarErr] = useState<string | null>(null);
  const active = users.find((u) => u.id === activeUserId);

  if (!hydrated) {
    return (
      <Shell title="User">
        <p className="text-sm text-muted">Lädt…</p>
      </Shell>
    );
  }

  return (
    <Shell title="User">
      <h1 className="font-display text-2xl font-semibold">Lokale Benutzer</h1>
      <p className="mt-1 text-sm text-muted">Kein Cloud-Login. Das Profil ist nicht die Avatarfigur.</p>
      <Panel className="mt-4">
        <ul className="space-y-2">
          {users.map((u) => (
            <li key={u.id} className="flex flex-wrap items-center gap-2 rounded-[12px] border border-border bg-bg px-3 py-2">
              <span className="flex-1 text-sm">
                {u.name} {u.id === activeUserId ? "(aktiv)" : ""}
              </span>
              <Button
                variant="line"
                className="min-h-9 text-xs"
                onClick={() => {
                  void setActiveUser(u.id).then(() => nav({ to: "/" }));
                }}
              >
                Wählen
              </Button>
              {u.id !== "admin" ? (
                <Button variant="danger" className="min-h-9 text-xs" onClick={() => deleteUser(u.id)}>
                  Löschen
                </Button>
              ) : null}
            </li>
          ))}
        </ul>
        <div className="mt-3 flex gap-2">
          <Input value={name} onChange={(e) => setName(e.target.value)} placeholder="Neuer Name" />
          <Button
            onClick={() => {
              const n = name.trim();
              if (n.length < 2) return;
              void upsertUser({
                id: uid("user"),
                name: n,
                language: "de",
                defaultRole: "teilnehmer",
                lastWorldId: null,
                lastSessionId: null,
                tts: false,
                sttMode: "dictation",
                largeType: false,
                highContrast: false,
                createdAt: new Date().toISOString(),
                avatarsByWorld: {},
                avatarsBySession: {},
                providerConfig: { localOnly: true },
              });
              setName("");
            }}
          >
            Anlegen
          </Button>
        </div>
      </Panel>
      {active ? (
        <Panel className="mt-4" title="Aktives Profil">
          <div className="grid gap-2 sm:grid-cols-2">
            <Input value={active.name} onChange={(e) => patchUser(active.id, { name: e.target.value })} />
            <Select value={active.language} onChange={(e) => patchUser(active.id, { language: e.target.value })}>
              <option value="de">Deutsch</option>
              <option value="en">English</option>
            </Select>
            <Select value={active.defaultRole} onChange={(e) => patchUser(active.id, { defaultRole: e.target.value as SpeakerMode })}>
              {["beobachter", "teilnehmer", "avatar", "puppet", "regie", "god"].map((r) => (
                <option key={r} value={r}>
                  {r}
                </option>
              ))}
            </Select>
            <Select value={active.lastWorldId || ""} onChange={(e) => patchUser(active.id, { lastWorldId: e.target.value || null })}>
              <option value="">letzte Welt</option>
              {worlds.map((w) => (
                <option key={w.id} value={w.id}>
                  {w.name}
                </option>
              ))}
            </Select>
            <Select value={active.lastSessionId || ""} onChange={(e) => patchUser(active.id, { lastSessionId: e.target.value || null })}>
              <option value="">letzte Session</option>
              {sessions
                .filter((s) => s.userId === active.id)
                .map((s) => (
                  <option key={s.id} value={s.id}>
                    {s.name}
                  </option>
                ))}
            </Select>
          </div>
          <div className="mt-3 grid gap-2 sm:grid-cols-2">
            <Select
              value={(active.avatarsByWorld || {})[active.lastWorldId || ""] || ""}
              onChange={(e) => {
                const wid = active.lastWorldId;
                if (!wid) return;
                patchUser(active.id, { avatarsByWorld: { ...(active.avatarsByWorld || {}), [wid]: e.target.value } });
              }}
            >
              <option value="">Avatar dieser Welt</option>
              {characters
                .filter((c) => !active.lastWorldId || c.worldId === active.lastWorldId)
                .map((c) => (
                  <option key={c.id} value={c.id}>
                    {c.name}
                    {c.isWorldNative === false ? " (Avatar)" : c.canBeAvatar ? " (steuerbar)" : " (Stamm)"}
                  </option>
                ))}
            </Select>
            <Select
              value={(active.avatarsBySession || {})[active.lastSessionId || ""] || ""}
              onChange={(e) => {
                const sid = active.lastSessionId;
                if (!sid) return;
                patchUser(active.id, { avatarsBySession: { ...(active.avatarsBySession || {}), [sid]: e.target.value } });
              }}
            >
              <option value="">Avatar dieser Session</option>
              {characters.map((c) => (
                <option key={c.id} value={c.id}>
                  {c.name}
                </option>
              ))}
            </Select>
            <Input
              placeholder="Lokaler Provider / Modell"
              value={active.providerConfig?.model || ""}
              onChange={(e) =>
                patchUser(active.id, { providerConfig: { ...(active.providerConfig || {}), model: e.target.value, localOnly: true } })
              }
            />
            <Input
              placeholder="Endpoint (lokal)"
              value={active.providerConfig?.endpoint || ""}
              onChange={(e) =>
                patchUser(active.id, { providerConfig: { ...(active.providerConfig || {}), endpoint: e.target.value, localOnly: true } })
              }
            />
          </div>
          <div className="mt-3 grid gap-2">
            <label className="flex items-center gap-2 text-sm">
              <input type="checkbox" checked={active.largeType} onChange={(e) => patchUser(active.id, { largeType: e.target.checked })} />
              Große Schrift
            </label>
            <label className="flex items-center gap-2 text-sm">
              <input type="checkbox" checked={active.highContrast} onChange={(e) => patchUser(active.id, { highContrast: e.target.checked })} />
              Hoher Kontrast
            </label>
            <label className="flex items-center gap-2 text-sm">
              <input type="checkbox" checked={active.tts} onChange={(e) => patchUser(active.id, { tts: e.target.checked })} />
              Vorlesen
            </label>
          </div>
          <p className="mt-2 text-xs text-muted">
            Avatar ist eine Weltfigur, nicht dieses Profil. STT/TTS und Schrift liegen in Config und gelten für denselben User-Writer.
          </p>
          <div className="mt-3 flex flex-col gap-2 sm:flex-row">
            <Input
              value={avatarName}
              onChange={(e) => setAvatarName(e.target.value)}
              placeholder="Neuen Avatar anlegen — Name"
            />
            <Button
              variant="ok"
              onClick={() => {
                const n = avatarName.trim();
                const wid = active.lastWorldId || worlds[0]?.id;
                if (!n) {
                  setAvatarErr("Name nötig.");
                  return;
                }
                if (!wid) {
                  setAvatarErr("Zuerst eine Welt wählen.");
                  return;
                }
                const c = { ...makeOutsiderAvatar(n), id: uid("av"), worldId: wid, canBeAvatar: true };
                setAvatarErr(null);
                void addCharacter(c).then((ok) => {
                  if (!ok) {
                    const fail = useMatrix.getState().logs.find((l) => l.code === "PERSIST_FAILED");
                    setAvatarErr(fail?.message || "Avatar konnte nicht gespeichert werden.");
                    return;
                  }
                  patchUser(active.id, { avatarsByWorld: { ...(active.avatarsByWorld || {}), [wid]: c.id } });
                  setAvatarName("");
                });
              }}
            >
              Avatar anlegen
            </Button>
          </div>
          {avatarErr ? <p className="mt-2 text-sm text-danger">{avatarErr}</p> : null}
        </Panel>
      ) : null}
    </Shell>
  );
}