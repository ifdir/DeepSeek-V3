import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useMemo, useState } from "react";
import { Shell, Panel, Empty } from "@/components/shell";
import { Input, Select, Button } from "@/components/ui";
import { useMatrix } from "@/lib/matrix/store";
import { useHydrated } from "@/lib/matrix/use-hydrated";
import { apiCreateAppointment, apiListAppointments, apiListSessionEvidence } from "@/lib/matrix/api";

export const Route = createFileRoute("/timeline")({ component: TimelinePage });

function TimelinePage() {
  const hydrated = useHydrated();
  const sessions = useMatrix((s) => s.sessions);
  const worlds = useMatrix((s) => s.worlds);
  const characters = useMatrix((s) => s.characters);
  const addProposition = useMatrix((s) => s.addProposition);
  const addGoal = useMatrix((s) => s.addGoal);
  const patchProposition = useMatrix((s) => s.patchProposition);
  const [sessionId, setSessionId] = useState("");
  const [worldId, setWorldId] = useState("");
  const [charId, setCharId] = useState("");
  const [dyadTo, setDyadTo] = useState("");
  const [kind, setKind] = useState("");
  const [propId, setPropId] = useState("");
  const [turnFrom, setTurnFrom] = useState("");
  const [turnTo, setTurnTo] = useState("");
  const [timeFrom, setTimeFrom] = useState("");
  const [timeTo, setTimeTo] = useState("");
  const [when, setWhen] = useState("");
  const [title, setTitle] = useState("");
  const [apts, setApts] = useState<string>("");
  const [propText, setPropText] = useState("");
  const [goalText, setGoalText] = useState("");
  const [evidence, setEvidence] = useState<Array<Record<string, unknown>>>([]);

  const scopedSessions = useMemo(
    () => (worldId ? sessions.filter((s) => s.worldId === worldId) : sessions),
    [sessions, worldId],
  );
  const session = scopedSessions.find((s) => s.id === sessionId) ?? scopedSessions[0];
  useEffect(() => {
    const pick = session?.id;
    if (!pick) {
      setEvidence([]);
      return;
    }
    let alive = true;
    apiListSessionEvidence(pick)
      .then((r) => {
        if (alive) setEvidence(Array.isArray(r.evidence) ? r.evidence : []);
      })
      .catch(() => {
        if (alive) setEvidence([]);
      });
    return () => {
      alive = false;
    };
  }, [session?.id]);
  const nameOf = (id?: string | null) => {
    if (!id) return "—";
    return characters.find((c) => c.id === id)?.name || id;
  };
  const facts = useMemo(() => {
    if (!session) return [];
    const fromView = evidence
      .filter((e) => e.layer === "scene_fact")
      .map((e) => ({
        id: String(e.id || ""),
        text: String(e.text || ""),
        kind: String(e.kind || "scene"),
        turn: Number(e.turn || 0),
        actorId: String(e.actorId || ""),
        targetId: String(e.targetId || ""),
        authority: String(e.authority || ""),
        status: typeof e.status === "string" ? e.status : undefined,
        rejectionReason: typeof e.rejectionReason === "string" ? e.rejectionReason : undefined,
        respondsToFactId: typeof e.respondsToFactId === "string" ? e.respondsToFactId : undefined,
        propositionId: typeof e.propositionId === "string" ? e.propositionId : undefined,
        payload: (e.payload as { time?: string } | undefined) || {},
        userId: String(e.userId || ""),
        worldId: String(e.worldId || ""),
        sessionId: String(e.sessionId || session.id),
      }));
    const rows = fromView.length ? fromView : session.facts;
    const fromT = turnFrom.trim() === "" ? null : Number(turnFrom);
    const toT = turnTo.trim() === "" ? null : Number(turnTo);
    return rows.filter((f) => {
      if (charId && f.actorId !== charId && f.targetId !== charId) return false;
      if (dyadTo) {
        const a = charId || "";
        const pair = (f.actorId === a && f.targetId === dyadTo) || (f.actorId === dyadTo && f.targetId === (a || f.targetId));
        if (a) {
          if (!pair) return false;
        } else if (f.actorId !== dyadTo && f.targetId !== dyadTo) {
          return false;
        }
      }
      if (kind && f.kind !== kind) return false;
      if (propId && f.propositionId !== propId && !session.propositions.find((p) => p.id === propId && p.turn === f.turn)) return false;
      if (fromT !== null && !Number.isNaN(fromT) && (f.turn ?? 0) < fromT) return false;
      if (toT !== null && !Number.isNaN(toT) && (f.turn ?? 0) > toT) return false;
      const when = String((f as { timeRef?: string; time?: string }).timeRef || (f as { time?: string }).time || f.payload?.time || "");
      if (timeFrom.trim() && when && when < timeFrom.trim()) return false;
      if (timeTo.trim() && when && when > timeTo.trim()) return false;
      return true;
    });
  }, [session, evidence, charId, dyadTo, kind, propId, turnFrom, turnTo, timeFrom, timeTo]);

  if (!hydrated) {
    return (
      <Shell title="Timeline">
        <p className="text-sm text-muted">Lädt…</p>
      </Shell>
    );
  }

  return (
    <Shell title="Timeline">
      <h1 className="font-display text-2xl font-semibold">Timeline und Audit</h1>
      <p className="mt-1 text-sm text-muted">Evidenz, nicht aktueller Zustand. Weltkanon und Session nicht mischen.</p>
      <div className="mt-4 grid gap-2 sm:grid-cols-4">
        <Select value={worldId} onChange={(e) => { setWorldId(e.target.value); setSessionId(""); }}>
          <option value="">Welt</option>
          {worlds.map((w) => (
            <option key={w.id} value={w.id}>
              {w.name}
            </option>
          ))}
        </Select>
        <Select value={session?.id ?? ""} onChange={(e) => setSessionId(e.target.value)}>
          <option value="">Session</option>
          {scopedSessions.map((s) => (
            <option key={s.id} value={s.id}>
              {s.name}
            </option>
          ))}
        </Select>
        <Select value={charId} onChange={(e) => setCharId(e.target.value)}>
          <option value="">Figur / Actor</option>
          {characters
            .filter((c) => !session || c.worldId === session.worldId)
            .map((c) => (
              <option key={c.id} value={c.id}>
                {c.name}
              </option>
            ))}
        </Select>
        <Select value={dyadTo} onChange={(e) => setDyadTo(e.target.value)}>
          <option value="">Dyade (Target)</option>
          {characters
            .filter((c) => !session || c.worldId === session.worldId)
            .map((c) => (
              <option key={c.id} value={c.id}>
                {c.name}
              </option>
            ))}
        </Select>
        <Select value={kind} onChange={(e) => setKind(e.target.value)}>
          <option value="">alle Arten</option>
          {["speech", "action", "physical", "god", "regie", "scene", "narrator", "upload"].map((k) => (
            <option key={k}>{k}</option>
          ))}
        </Select>
        <Select value={propId} onChange={(e) => setPropId(e.target.value)}>
          <option value="">Proposition</option>
          {(session?.propositions ?? []).map((p) => (
            <option key={p.id} value={p.id}>
              {p.status} · {p.text.slice(0, 40)}
            </option>
          ))}
        </Select>
        <Input placeholder="Turn von" value={turnFrom} onChange={(e) => setTurnFrom(e.target.value)} />
        <Input placeholder="Turn bis" value={turnTo} onChange={(e) => setTurnTo(e.target.value)} />
        <Input placeholder="Zeitraum von" value={timeFrom} onChange={(e) => setTimeFrom(e.target.value)} />
        <Input placeholder="Zeitraum bis" value={timeTo} onChange={(e) => setTimeTo(e.target.value)} />
        <p className="col-span-full text-[11px] text-muted">SceneFacts nur anhängen. Gleicher Satz bleibt. Widerspruch ist eine neue Zeile.</p>
      </div>
      <Panel className="mt-4">
        {!session ? <Empty>Keine Session.</Empty> : null}
        {session ? (
          <div className="mb-3 flex flex-wrap gap-2">
            <Input placeholder="Termin wann" value={when} onChange={(e) => setWhen(e.target.value)} />
            <Input placeholder="Titel" value={title} onChange={(e) => setTitle(e.target.value)} />
            <Button
              className="min-h-9 text-xs"
              onClick={async () => {
                await apiCreateAppointment(session.id, { title: title || "Termin", when });
                const list = await apiListAppointments(session.id);
                const items = (list.appointments as { title?: string; when?: string }[]) || [];
                setApts(items.map((a) => `${a.when} ${a.title}`).join(" · "));
                setTitle("");
              }}
            >
              Termin speichern
            </Button>
          </div>
        ) : null}
        {apts ? <p className="mb-2 text-xs text-muted">{apts}</p> : null}
        {worldId ? (
          <Panel className="mb-3" title="Weltkanon (nicht Sessionzustand)">
            <ul className="space-y-1 text-sm">
              {(worlds.find((w) => w.id === worldId)?.timeline || []).map((t) => (
                <li key={t.id}>
                  <span className="text-xs text-muted">{t.when || "ohne Zeit"}</span> · {t.text}
                </li>
              ))}
            </ul>
          </Panel>
        ) : null}
        {session ? (
          <div className="mb-3 grid gap-2 sm:grid-cols-2">
            <div className="flex gap-2">
              <Input placeholder="Proposition" value={propText} onChange={(e) => setPropText(e.target.value)} />
              <Button
                variant="line"
                className="min-h-9 text-xs"
                onClick={() => {
                  if (!propText.trim()) return;
                  addProposition(session.id, { text: propText.trim(), status: "open", actors: charId ? [charId] : [], turn: session.turnIndex });
                  setPropText("");
                }}
              >
                Proposition
              </Button>
            </div>
            <div className="flex gap-2">
              <Input placeholder="Goal" value={goalText} onChange={(e) => setGoalText(e.target.value)} />
              <Button
                variant="line"
                className="min-h-9 text-xs"
                onClick={() => {
                  if (!goalText.trim()) return;
                  addGoal(session.id, { ownerId: charId || session.avatarId || session.userId, text: goalText.trim(), status: "open" });
                  setGoalText("");
                }}
              >
                Goal
              </Button>
            </div>
          </div>
        ) : null}
        {session && (session.propositions.length || session.goals.length) ? (
          <div className="mb-3 grid gap-2 sm:grid-cols-2 text-xs">
            <ul className="space-y-1">
              {session.propositions.map((p) => (
                <li key={p.id} className="flex flex-wrap items-center gap-2">
                  <span>
                    Prop · {p.status} · {p.text}
                  </span>
                  {p.status === "open" || p.status === "active" ? (
                    <>
                      <Button variant="line" className="min-h-8 px-2 text-[10px]" onClick={() => patchProposition(session.id, p.id, { status: "accepted" })}>
                        annehmen
                      </Button>
                      <Button variant="line" className="min-h-8 px-2 text-[10px]" onClick={() => patchProposition(session.id, p.id, { status: "declined" })}>
                        ablehnen
                      </Button>
                      <Button variant="line" className="min-h-8 px-2 text-[10px]" onClick={() => patchProposition(session.id, p.id, { status: "revoked" })}>
                        widerrufen
                      </Button>
                      <Button variant="line" className="min-h-8 px-2 text-[10px]" onClick={() => patchProposition(session.id, p.id, { status: "contradicted" })}>
                        widerspruch
                      </Button>
                    </>
                  ) : null}
                </li>
              ))}
            </ul>
            <ul className="space-y-1">
              {session.goals.map((g) => (
                <li key={g.id} className="flex items-center gap-2">
                  <span>
                    Goal · {g.status} · {g.text}
                  </span>
                  <span className="text-[10px] text-muted">
                    Zielstatus folgt gebundener Ereignisevidenz.
                    {(g as { lifecycleFactId?: string }).lifecycleFactId
                      ? ` Quelle: ${(g as { lifecycleFactId?: string }).lifecycleFactId}`
                      : " Noch kein Statusereignis."}
                  </span>
                </li>
              ))}
            </ul>
          </div>
        ) : null}
        <ol className="space-y-2">
          {facts.map((f) => {
            const wk = (session?.witnessKnowledge || []).filter((w) => (w.fact_id || "") === f.id);
            return (
              <li key={f.id} className="rounded-[12px] border border-border bg-bg px-3 py-2 text-sm">
                <p className="text-[11px] uppercase tracking-wide text-faint">
                  Historische Evidenz · Turn {f.turn} · {f.kind} · {f.authority} · {f.id}
                  {f.status ? ` · Fact-Status ${f.status}` : ""}
                  {f.rejectionReason ? ` · ${f.rejectionReason}` : ""}
                </p>
                <p className="mt-1">{f.text}</p>
                {f.respondsToFactId ? (
                  <p className="mt-1 text-[11px] text-muted">Widerspricht {f.respondsToFactId} — der alte Satz bleibt.</p>
                ) : null}
                <p className="mt-1 text-[11px] text-muted">
                  Actor {nameOf(f.actorId)} · Target {nameOf(f.targetId)} · Beteiligte {(f.actorId ? [nameOf(f.actorId)] : []).concat(f.targetId ? [nameOf(f.targetId)] : []).join(", ") || "—"}
                </p>
                <p className="text-[11px] text-muted">
                  Zeugen {(((f as { witnessedBy?: string[] }).witnessedBy) || []).map(nameOf).join(", ") || wk.map((w) => `${w.character_id || w.characterId}:${w.access}`).join(", ") || "—"} · Quelle {(f as { sourceTurnId?: string; sourceType?: string; provenance?: string }).sourceTurnId || (f as { sourceType?: string }).sourceType || (f as { provenance?: string }).provenance || "turn"}
                </p>
                <p className="text-[11px] text-muted">
                  Proposition-Ref {f.propositionId || "—"} · Goal-Ref {(f as { goalId?: string }).goalId || "—"} · Fact-Lifecycle {f.status || "—"}
                </p>
                <p className="text-[11px] text-muted">
                  Wissen zum Fact {wk.map((w) => `${w.character_id || w.characterId}=${w.access}`).join(" · ") || "—"}
                </p>
              </li>
            );
          })}
        </ol>
        {session ? (
          <div className="mt-4 rounded-[12px] border border-border bg-elevated px-3 py-2 text-xs text-muted">
            <p className="text-[11px] uppercase tracking-wide text-faint">Aktueller Stand — nicht die historische Zeile</p>
            <p className="mt-1">
              Runtime {Object.entries(session.runtimes || {})
                .slice(0, 4)
                .map(([id, rt]) => `${nameOf(id)}:${rt.emotion || "—"}/${rt.mobility ?? "—"}`)
                .join(" · ") || "—"}
            </p>
            <p>
              Lifecycle {(session.propositions || [])
                .slice(0, 4)
                .map((p) => `${p.status}:${p.text.slice(0, 32)}`)
                .join(" · ") || "—"}
            </p>
            <p>
              Beziehung {(session.relations || [])
                .slice(0, 4)
                .map((r) => `${r.fromId}→${r.toId} t${r.trust}`)
                .join(" · ") || "—"}
            </p>
          </div>
        ) : null}
      </Panel>
    </Shell>
  );
}
