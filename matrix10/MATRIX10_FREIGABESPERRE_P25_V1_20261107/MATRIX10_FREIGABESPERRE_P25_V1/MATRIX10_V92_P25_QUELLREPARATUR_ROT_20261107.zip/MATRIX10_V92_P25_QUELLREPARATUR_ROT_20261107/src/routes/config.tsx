import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { Shell, Panel } from "@/components/shell";
import { Field, Input, Switch, Button, Select } from "@/components/ui";
import { useMatrix } from "@/lib/matrix/store";
import { useHydrated } from "@/lib/matrix/use-hydrated";
import { apiGetConfig, apiPingProvider, apiPutConfig } from "@/lib/matrix/api";
import type { AppConfig } from "@/lib/matrix/types";

export const Route = createFileRoute("/config")({ component: ConfigPage });

type ScopeName = NonNullable<AppConfig["scope"]>;

function ConfigPage() {
  const hydrated = useHydrated();
  const config = useMatrix((s) => s.config);
  const setConfig = useMatrix((s) => s.setConfig);
  const applyLoadedConfig = useMatrix((s) => s.applyLoadedConfig);
  const users = useMatrix((s) => s.users);
  const activeUserId = useMatrix((s) => s.activeUserId);
  const patchUser = useMatrix((s) => s.patchUser);
  const setProviderOnline = useMatrix((s) => s.setProviderOnline);
  const providerOnline = useMatrix((s) => s.providerOnline);
  const user = users.find((u) => u.id === activeUserId);
  const worlds = useMatrix((s) => s.worlds);
  const sessions = useMatrix((s) => s.sessions);
  const characters = useMatrix((s) => s.characters);
  const [scopeMsg, setScopeMsg] = useState("");
  const [formMsg, setFormMsg] = useState("");
  const [keyPresent, setKeyPresent] = useState(Boolean(config.keyPresent));
  const [keyInfo, setKeyInfo] = useState<{ masked: string; source: string }>({ masked: "", source: "" });
  const [keyDraft, setKeyDraft] = useState("");
  const [keyMsg, setKeyMsg] = useState("");
  const [pingMsg, setPingMsg] = useState("");
  const [pingBusy, setPingBusy] = useState(false);
  const [draftScope, setDraftScope] = useState<ScopeName>((config.scope as ScopeName) || "user");
  const [draftScopeId, setDraftScopeId] = useState(config.scopeId || "");

  async function refreshKeyStatus() {
    // V25 CFG-01: Zustand nach Reload aus dem kanonischen Config-Owner (SQLite), nie der Klartext-Key.
    try {
      const got = await apiGetConfig(config.scope || "user", config.scopeId || undefined);
      const next = (got.config && typeof got.config === "object" ? got.config : got) as Record<string, unknown>;
      const present = Boolean(next.apiKeyPresent) || Boolean(next.keyPresent);
      setKeyPresent(present);
      setProviderOnline(present);
      setKeyInfo({ masked: String(next.apiKeyMasked || ""), source: String(next.keySource || "") });
      applyLoadedConfig({ keyPresent: present, apiKeyPresent: Boolean(next.apiKeyPresent), apiKeyMasked: String(next.apiKeyMasked || ""), keySource: String(next.keySource || "") });
    } catch {
      /* Statusanzeige bleibt beim letzten bekannten Stand */
    }
  }

  useEffect(() => {
    if (!hydrated) return;
    void refreshKeyStatus();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [hydrated, config.scope, config.scopeId]);

  async function saveKey() {
    const raw = keyDraft.trim();
    if (!raw) {
      setKeyMsg("Kein Schlüssel eingegeben.");
      return;
    }
    // V25.1: Key-Form bestimmt den Provider eindeutig (sk-… = OpenAI, xai-… = xAI);
    // ein widersprechender gespeicherter Provider (z. B. V24-Default xAI) wird korrigiert.
    const keyProvider = raw.startsWith("sk-") ? "openai" : raw.startsWith("xai-") ? "xai" : "";
    const provider = keyProvider && (config.provider === "openai" || config.provider === "xai" || !config.provider) ? keyProvider : config.provider || "openai";
    const model = keyProvider === "openai" && (!config.model || /^grok|^synapse/i.test(config.model)) ? "gpt-4o-mini" : keyProvider === "xai" && (!config.model || /^gpt|^synapse/i.test(config.model)) ? "grok-4.5" : config.model;
    if (provider !== config.provider || model !== config.model) setConfig({ provider: provider as AppConfig["provider"], model });
    try {
      await apiPutConfig({
        apiKey: raw,
        provider,
        endpoint: config.endpoint || "",
        model,
        temperature: config.temperature,
        maxTokens: config.maxTokens,
        llmEnabled: true,
        autoChatTurns: config.autoChatTurns,
        autoChatDelayMs: config.autoChatDelayMs,
        contextTurns: config.contextTurns,
        fateDefault: config.fateDefault,
        narratorDefault: config.narratorDefault,
        debug: config.debug,
        scope: config.scope || "user",
        scope_id: config.scopeId || activeUserId,
        scopeId: config.scopeId || activeUserId,
      });
      setKeyDraft("");
      await refreshKeyStatus();
      setKeyMsg("Schlüssel gespeichert (SQLite, gescopt). Wird vom Backend für alle LLM-Funktionen benutzt.");
    } catch (e) {
      setKeyMsg(e instanceof Error ? e.message : "Speichern fehlgeschlagen");
    }
  }

  async function clearKey() {
    try {
      await apiPutConfig({ clearApiKey: true, scope: config.scope || "user", scope_id: config.scopeId || activeUserId, scopeId: config.scopeId || activeUserId, model: config.model, provider: config.provider || "openai" });
      await refreshKeyStatus();
      setKeyMsg("Schlüssel entfernt.");
    } catch (e) {
      setKeyMsg(e instanceof Error ? e.message : "Entfernen fehlgeschlagen");
    }
  }

  async function pingLive() {
    setPingBusy(true);
    setPingMsg("");
    try {
      const r = await apiPingProvider({ live: true, scope: config.scope || "user", scope_id: config.scopeId || undefined });
      const label = r.ok
        ? `OK — ${String(r.providerResolved || r.provider)} · ${String(r.model)} antwortet.`
        : `FEHLER — ${String(r.reason || r.error || "Provider antwortet nicht")}`;
      setPingMsg(`${label} (probe=${String(r.probed)}, Schlüsselquelle=${String(r.keySource || "—")}${r.providerChosen && r.providerResolved && r.providerChosen !== r.providerResolved ? `, gewählt ${String(r.providerChosen)} → nach Key-Form ${String(r.providerResolved)}` : ""})`);
      setProviderOnline(Boolean(r.ok));
    } catch (e) {
      setPingMsg(e instanceof Error ? e.message : "Ping fehlgeschlagen");
    } finally {
      setPingBusy(false);
    }
  }

  if (!hydrated) {
    return (
      <Shell title="Config">
        <p className="text-sm text-muted">Lädt…</p>
      </Shell>
    );
  }

  return (
    <Shell title="Config">
      <h1 className="font-display text-2xl font-semibold">Konfiguration</h1>
      <p className="mt-1 text-sm text-muted">Pipeline, Kontext und Sprachdienst. Scope-Wechsel schreibt nicht. Erst „Scope laden“ macht den Ziel-Scope wirksam.</p>
      <div className="mt-4 grid gap-4 lg:grid-cols-2">
        <Panel title="Pipeline-Defaults">
          <Field label="Scope">
            <Select
              value={draftScope}
              onChange={(e) => {
                const scope = e.target.value as ScopeName;
                setDraftScope(scope);
                setDraftScopeId(scope === "user" ? activeUserId : "");
                setScopeMsg("Scope-Entwurf — noch nicht wirksam");
              }}
            >
              <option value="global">global</option>
              <option value="user">user</option>
              <option value="world">world</option>
              <option value="character">character</option>
              <option value="session">session</option>
              <option value="runtime">runtime</option>
            </Select>
          </Field>
          {(draftScope === "world" || draftScope === "character" || draftScope === "session" || draftScope === "runtime") && (
            <Field label="Scope-Ziel">
              <Select value={draftScopeId} onChange={(e) => setDraftScopeId(e.target.value)}>
                <option value="">wählen</option>
                {draftScope === "world"
                  ? worlds.map((w) => (
                      <option key={w.id} value={w.id}>
                        {w.name}
                      </option>
                    ))
                  : draftScope === "character"
                    ? characters.map((c) => (
                        <option key={c.id} value={c.id}>
                          {c.name}
                        </option>
                      ))
                    : sessions.map((s) => (
                        <option key={s.id} value={s.id}>
                          {s.name}
                        </option>
                      ))}
              </Select>
            </Field>
          )}
          <div className="mb-2 flex gap-2">
            <Button
              variant="line"
              onClick={async () => {
                const needsTarget =
                  draftScope === "world" ||
                  draftScope === "character" ||
                  draftScope === "session" ||
                  draftScope === "runtime";
                if (needsTarget && !draftScopeId) {
                  setScopeMsg("Scope-Ziel fehlt — nichts geladen, nichts geschrieben.");
                  return;
                }
                try {
                  const got = await apiGetConfig(draftScope || "user", draftScopeId || undefined);
                  const next = got.config && typeof got.config === "object" ? (got.config as Record<string, unknown>) : got;
                  const model = String((next as { model?: string }).model || "");
                  applyLoadedConfig({
                    model: model || config.model,
                    temperature: Number((next as { temperature?: number }).temperature ?? config.temperature),
                    maxTokens: Number((next as { maxTokens?: number }).maxTokens ?? config.maxTokens),
                    fateDefault: Boolean((next as { fateDefault?: boolean }).fateDefault ?? config.fateDefault),
                    narratorDefault: Boolean((next as { narratorDefault?: boolean }).narratorDefault ?? config.narratorDefault),
                    autoChatTurns: Number((next as { autoChatTurns?: number }).autoChatTurns ?? config.autoChatTurns),
                    autoChatDelayMs: Number((next as { autoChatDelayMs?: number }).autoChatDelayMs ?? config.autoChatDelayMs),
                    contextTurns: Number((next as { contextTurns?: number }).contextTurns ?? config.contextTurns),
                    debug: Boolean((next as { debug?: boolean }).debug ?? config.debug),
                    provider: ((next as { provider?: AppConfig["provider"] }).provider as AppConfig["provider"]) || config.provider,
                    keyPresent: Boolean((next as { keyPresent?: boolean }).keyPresent),
                    apiKey: "",
                    scope: draftScope,
                    scopeId: draftScopeId,
                  });
                  setKeyPresent(Boolean((next as { keyPresent?: boolean }).keyPresent));
                  setScopeMsg(`Scope ${draftScope || "user"} wirksam · Modell ${model || "—"}`);
                } catch (e) {
                  setScopeMsg(e instanceof Error ? e.message : "Scope nicht geladen");
                }
              }}
            >
              Scope laden
            </Button>
            {scopeMsg ? <p className="text-xs text-muted">{scopeMsg}</p> : null}
          </div>
          <Switch checked={config.fateDefault} onChange={(v) => setConfig({ fateDefault: v })} label="Fate an" />
          <Switch checked={config.narratorDefault} onChange={(v) => setConfig({ narratorDefault: v })} label="Erzähler an" />
          <Switch checked={config.debug} onChange={(v) => setConfig({ debug: v })} label="Debug" />
          <Field label="AutoChat Turns">
            <Input type="number" min={1} max={5} value={config.autoChatTurns} onChange={(e) => setConfig({ autoChatTurns: Number(e.target.value) })} />
          </Field>
          <Field label="AutoChat Pause ms">
            <Input type="number" min={1000} max={15000} value={config.autoChatDelayMs} onChange={(e) => setConfig({ autoChatDelayMs: Number(e.target.value) })} />
          </Field>
          <Field label="Kontext-Turns (Dialog im Spiegel)">
            <Input type="number" min={1} max={50} value={config.contextTurns} onChange={(e) => setConfig({ contextTurns: Number(e.target.value) })} />
          </Field>
        </Panel>
        <Panel title="Sprachdienst (LLM-Provider, API-Key, Modell)">
          <p className="text-sm text-muted">
            Das LLM formuliert nur; es besitzt keine Wahrheit. Provider, API-Key, Modell und Parameter werden hier
            eingegeben, gescopt in SQLite gespeichert und vom Backend für Turns, AutoChat, Welt-/Figurenerzeugung,
            Profilvervollständigung und Kompass benutzt. Der Schlüssel wird nie im Klartext angezeigt oder geloggt.
          </p>
          <p className="mt-2 text-sm" aria-live="polite">
            Status:{" "}
            {keyPresent
              ? `Schlüssel gespeichert ${keyInfo.masked ? `(${keyInfo.masked})` : ""} · Quelle: ${keyInfo.source === "config" ? "Konfiguration" : keyInfo.source === "env" ? "Server-Umgebung" : keyInfo.source || "—"}`
              : "kein Schlüssel — Figuren fallen auf die lokale Synapse zurück, KI-Erzeugung ist nicht verfügbar."}
          </p>
          <Field label="Provider">
            <Select
              value={config.provider || "openai"}
              onChange={(e) => setConfig({ provider: e.target.value as AppConfig["provider"] })}
            >
              <option value="openai">OpenAI (api.openai.com)</option>
              <option value="xai">xAI (api.x.ai)</option>
              <option value="custom">Eigener OpenAI-kompatibler Endpoint (lokal/Server)</option>
              <option value="synapse">Nur lokale Synapse (kein LLM)</option>
            </Select>
          </Field>
          {config.provider === "custom" ? (
            <Field label="Endpoint-URL (chat/completions)">
              <Input
                value={config.endpoint || ""}
                placeholder="http://127.0.0.1:11434/v1/chat/completions"
                onChange={(e) => setConfig({ endpoint: e.target.value })}
              />
            </Field>
          ) : null}
          <Field label="API-Key (wird nur gespeichert, nie angezeigt)">
            <Input
              type="password"
              autoComplete="off"
              value={keyDraft}
              placeholder={keyPresent ? "gespeichert — neuen Schlüssel eingeben, um zu ersetzen" : "sk-… oder xai-…"}
              onChange={(e) => setKeyDraft(e.target.value)}
            />
          </Field>
          <div className="mb-3 flex flex-wrap gap-2">
            <Button className="min-h-11" onClick={() => void saveKey()}>
              Schlüssel speichern
            </Button>
            <Button variant="line" className="min-h-11" onClick={() => void clearKey()} disabled={!keyPresent}>
              Schlüssel entfernen
            </Button>
          </div>
          {keyMsg ? <p className="mb-2 text-sm text-muted" role="status">{keyMsg}</p> : null}
          <Switch
            checked={config.llmEnabled !== false && (config.provider || "openai") !== "synapse"}
            onChange={(v) => setConfig({ llmEnabled: v, provider: v ? (config.provider === "synapse" ? "openai" : config.provider || "openai") : "synapse" })}
            label="LLM-Formulierung an (Turns und AutoChat)"
          />
          <Field label="Modell">
            <Input value={config.model} onChange={(e) => setConfig({ model: e.target.value })} />
          </Field>
          <Field label="Temperature">
            <Input type="number" min={0} max={2} step={0.1} value={config.temperature} onChange={(e) => setConfig({ temperature: Number(e.target.value) })} />
          </Field>
          <Field label="Max Tokens">
            <Input type="number" min={120} max={1024} value={config.maxTokens} onChange={(e) => setConfig({ maxTokens: Number(e.target.value) })} />
          </Field>
          <div className="mt-2 flex flex-wrap gap-2">
            <Button variant="line" className="min-h-11" onClick={() => void pingLive()} disabled={pingBusy}>
              {pingBusy ? "Prüft…" : "Provider live prüfen"}
            </Button>
            <Button
              variant="line"
              className="min-h-11"
              onClick={() => void pingLive()}
            >
              Verbindung pruefen
            </Button>
          </div>
          {pingMsg ? <p className="mt-2 text-sm text-muted" role="status">{pingMsg}</p> : null}
          {formMsg ? <p className="mt-2 text-xs text-muted">{formMsg}</p> : null}
        </Panel>
        <Panel title="Userprofil (nicht die Avatarfigur)">
          {user ? (
            <>
              <Field label="Anzeigename">
                <Input value={user.name} onChange={(e) => patchUser(user.id, { name: e.target.value })} />
              </Field>
              <Switch checked={user.tts} onChange={(v) => patchUser(user.id, { tts: v })} label="Vorlesen (Gerät)" />
              <Switch checked={user.largeType} onChange={(v) => patchUser(user.id, { largeType: v })} label="Große Schrift" />
              <Switch checked={user.highContrast} onChange={(v) => patchUser(user.id, { highContrast: v })} label="Kontrast" />
              <p className="mt-3 text-xs text-muted">
                Spracheingabe: {user.sttMode === "autosend" ? "Auto-Senden" : "Diktat, dann prüfen"}. Umschalten im Chat.
              </p>
              <button type="button" className="mt-2 min-h-11 text-sm text-accent" onClick={() => patchUser(user.id, { sttMode: user.sttMode === "autosend" ? "dictation" : "autosend" })}>
                STT-Modus wechseln
              </button>
            </>
          ) : null}
        </Panel>
      </div>
    </Shell>
  );
}