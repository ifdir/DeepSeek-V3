import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { Shell, Panel } from "@/components/shell";
import { Button } from "@/components/ui";
import { useHydrated } from "@/lib/matrix/use-hydrated";
import { useMatrix } from "@/lib/matrix/store";
import { apiHealth, apiPingProvider } from "@/lib/matrix/api";
import { BUILD_ID } from "@/lib/matrix/types";

export const Route = createFileRoute("/")({ component: StartPage });

/** AMASTERv2 §55: Startseite zeigt Build, DB, Server- und Providerstatus, User,
 *  zuletzt verwendete Welt/Session und direkte Zugänge — ohne Pfadeingabe. */
function StartPage() {
  const nav = useNavigate();
  const hydrated = useHydrated();
  const users = useMatrix((s) => s.users);
  const activeUserId = useMatrix((s) => s.activeUserId);
  const worlds = useMatrix((s) => s.worlds);
  const sessions = useMatrix((s) => s.sessions);
  const ensureLiveSession = useMatrix((s) => s.ensureLiveSession);
  const [health, setHealth] = useState<{ ok: boolean; db: string; build: string } | null>(null);
  const [healthErr, setHealthErr] = useState("");
  const [provider, setProvider] = useState<{ provider?: string; model?: string; keyPresent?: boolean; keySource?: string } | null>(null);
  const [busy, setBusy] = useState(false);
  const [err, setErr] = useState("");

  useEffect(() => {
    if (!hydrated) return;
    void apiHealth()
      .then((h) => setHealth({ ok: Boolean(h.ok), db: String(h.db || ""), build: String(h.buildId || h.build || "") }))
      .catch((e) => setHealthErr(e instanceof Error ? e.message : "Backend nicht erreichbar"));
    void apiPingProvider({ live: false })
      .then((r) => setProvider({ provider: String(r.provider || ""), model: String(r.model || ""), keyPresent: Boolean(r.keyPresent), keySource: String(r.keySource || "") }))
      .catch(() => setProvider(null));
  }, [hydrated]);

  const user = users.find((u) => u.id === activeUserId);
  const lastWorld = user?.lastWorldId ? worlds.find((w) => w.id === user.lastWorldId) : undefined;
  const lastSession = user?.lastSessionId ? sessions.find((s) => s.id === user.lastSessionId) : undefined;

  async function enter() {
    setBusy(true);
    setErr("");
    try {
      const id = await ensureLiveSession();
      if (id) nav({ href: `/chat/${id}` });
      else setErr("Die Szene konnte nicht geöffnet werden.");
    } catch (e) {
      setErr(e instanceof Error ? e.message : "Szene nicht geöffnet");
    } finally {
      setBusy(false);
    }
  }

  const providerLabel = !provider
    ? "wird geprüft…"
    : provider.keyPresent && provider.provider && provider.provider !== "synapse"
      ? `${provider.provider} · ${provider.model || "Modell offen"} (Schlüssel: ${provider.keySource === "config" ? "Konfiguration" : provider.keySource === "env" ? "Server-Umgebung" : "—"})`
      : "kein Provider — Figuren sprechen nur über die lokale Synapse (Konfiguration → Sprachdienst)";

  return (
    <Shell title="Start">
      <div className="mx-auto max-w-4xl">
        <p className="text-[11px] uppercase tracking-[0.18em] text-faint">ChatHere · MATRIX10</p>
        <h1 className="mt-1 font-display text-3xl font-semibold tracking-tight">Start</h1>
        <p className="mt-2 text-base text-muted">Lokales, zustandsbasiertes KI-Universum. Stamm, Spiegel, Session.</p>

        <Panel className="mt-5" title="Systemstatus">
          <dl className="grid gap-2 text-base sm:grid-cols-2">
            <div><dt className="text-xs uppercase tracking-wide text-faint">Build</dt><dd className="tabular-nums">{health?.build || BUILD_ID}</dd></div>
            <div><dt className="text-xs uppercase tracking-wide text-faint">Server</dt><dd>{healthErr ? `nicht erreichbar (${healthErr})` : health ? (health.ok ? "läuft" : "Fehler") : hydrated ? "wird geprüft…" : "…"}</dd></div>
            <div className="sm:col-span-2"><dt className="text-xs uppercase tracking-wide text-faint">Aktive Datenbank</dt><dd className="break-all">{health?.db || "—"}</dd></div>
            <div className="sm:col-span-2"><dt className="text-xs uppercase tracking-wide text-faint">Sprachdienst / Provider</dt><dd>{providerLabel}</dd></div>
            <div><dt className="text-xs uppercase tracking-wide text-faint">Aktiver User</dt><dd>{hydrated ? (user?.name ?? (activeUserId ? activeUserId : "Gast")) : "…"}</dd></div>
            <div><dt className="text-xs uppercase tracking-wide text-faint">Zuletzt verwendete Welt</dt><dd>{lastWorld?.name ?? "—"}</dd></div>
            <div className="sm:col-span-2"><dt className="text-xs uppercase tracking-wide text-faint">Zuletzt verwendete Session</dt><dd>{lastSession?.name ?? "—"}</dd></div>
          </dl>
        </Panel>

        <Panel className="mt-4" title="Weiter">
          <div className="flex flex-wrap gap-3">
            <Button className="min-h-12 px-5 text-base" onClick={() => void enter()} disabled={!hydrated || busy}>
              {busy ? "Öffnet…" : lastSession ? `Weiter: ${lastSession.name}` : "Gespräch beginnen"}
            </Button>
            {lastSession ? (
              <Link to="/chat/$sessionId" params={{ sessionId: lastSession.id }} className="inline-flex min-h-12 items-center rounded-[10px] border border-border px-5 text-base text-accent">
                Session öffnen
              </Link>
            ) : null}
          </div>
          {err ? <p className="mt-2 text-sm text-danger" role="alert">{err}</p> : null}
        </Panel>

        <Panel className="mt-4" title="Direkte Zugänge">
          <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
            {[
              { to: "/welt", label: "Welten", note: "anlegen, analysieren, verwalten" },
              { to: "/charakter", label: "Figuren", note: "Stamm, Kompass, Spawn" },
              { to: "/chat", label: "Chat / Sessions", note: "Szenen führen" },
              { to: "/upload", label: "Uploads", note: "Mode A prägend, Mode B Wissen" },
              { to: "/config", label: "Konfiguration", note: "Provider, API-Key, Modell" },
              { to: "/diagnose", label: "Diagnose", note: "Ketten, Writer, Reader" },
            ].map((item) => (
              <Link key={item.to} to={item.to} className="block min-h-16 rounded-[12px] border border-border bg-bg p-4 hover:bg-subtle">
                <span className="block text-base font-semibold">{item.label}</span>
                <span className="block text-sm text-muted">{item.note}</span>
              </Link>
            ))}
          </div>
        </Panel>
      </div>
    </Shell>
  );
}
