import { createFileRoute, redirect } from "@tanstack/react-router";

export const Route = createFileRoute("/play/$sessionId")({
  beforeLoad: ({ params }) => {
    throw redirect({ href: `/chat/${params.sessionId}` });
  },
  component: () => null,
});
