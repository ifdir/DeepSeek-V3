import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useState } from "react";
import { Empty, PageHead, Panel, Shell, Tabs } from "@/components/shell";
import { Button, Chip, Field, Input, Select, Switch, Textarea } from "@/components/ui";
import { extractTextFromFile, joinSelectedParts, kindLabel, layerLabel, zoneLabel, assignPartDocIds, type EpubPart } from "@/lib/matrix/epub";
import { persistPartDocuments, packWorldWithSources } from "@/lib/matrix/source-docs";
import { uid } from "@/lib/matrix/ids";
import { ocrSelectedScanParts, textFromUpload } from "@/lib/matrix/ocr";
import { apiAnalyzeLocal, apiCompleteProfiles, apiGenerateWorld, analyzeFailMessage } from "@/lib/matrix/api";
import { commitDraft, downloadJson, emptyManualWorld, extendWorldFromDraft, draftFieldGroups, applyDraftGroupPick, localAnalyzeToDraft, applyCompletedProfiles } from "@/lib/matrix/normalize";
import { useMatrix } from "@/lib/matrix/store";
import { useHydrated } from "@/lib/matrix/use-hydrated";
import { useSelectableWorlds } from "@/lib/matrix/use-selectable";
import { type UploadMode, type World, type WorldDraft, type WorldPack } from "@/lib/matrix/types";

export const Route = createFileRoute("/welt/")({ component: WeltList });

function WeltList() {
  const nav = useNavigate();
  const hydrated = useHydrated();
  const worlds = useSelectableWorlds();
  const characters = useMatrix((s) => s.characters);
  const sessions = useMatrix((s) => s.sessions);
  const uploads = useMatrix((s) => s.uploads);
  const activeUserId = useMatrix((s) => s.activeUserId);
  const upsertWorld = useMatrix((s) => s.upsertWorld);
  const patchWorld = useMatrix((s) => s.patchWorld);
  const deleteWorld = useMatrix((s) => s.deleteWorld);
  const startSession = useMatrix((s) => s.startSession);
  const importPack = useMatrix((s) => s.importPack);
  const addUpload = useMatrix((s) => s.addUpload);
  const commitUpload = useMatrix((s) => s.commitUpload);
  const log = useMatrix((s) => s.log);

  const [tab, setTab] = useState("liste");
  const [name, setName] = useState("");
  const [idea, setIdea] = useState("");
  const [busy, setBusy] = useState(false);
  const [err, setErr] = useState<string | null>(null);
  const [draft, setDraft] = useState<WorldDraft | null>(null);
  const [groupPick, setGroupPick] = useState<Record<string, boolean>>({});
  const [extendId, setExtendId] = useState("");
  const [sourceTitle, setSourceTitle] = useState("");
  const [paste, setPaste] = useState("");
  const [epubParts, setEpubParts] = useState<EpubPart[] | null>(null);
  const [omittedParts, setOmittedParts] = useState(0);
  const [sourceFile, setSourceFile] = useState<File | null>(null);
  const [sourceA11y, setSourceA11y] = useState<{ language?: string; accessMode?: string[]; accessibilityFeature?: string[]; accessibilitySummary?: string } | null>(null);
  const [uploadMode, setUploadMode] = useState<UploadMode>("A");
  const [sessionBindId, setSessionBindId] = useState("");
  const [figureFate, setFigureFate] = useState<"candidates" | "spawn-select">("candidates");

  if (!hydrated) {
    return (
      <Shell title="Welten">
        <p className="text-sm text-muted">Lädt…</p>
      </Shell>
    );
  }

  async function createManual() {
    const n = name.trim() || "Neue Welt";
    const { world, characters: chars } = emptyManualWorld(n, activeUserId);
    const ok = await upsertWorld(world, chars);
    if (!ok) {
      setErr("Welt konnte nicht gespeichert werden.");
      return;
    }
    log({ level: "info", code: "WORLD_CREATE", message: world.name });
    nav({ href: `/welt/${world.id}` });
  }

  async function analyzeSource(title: string, source: string, parts?: EpubPart[]) {
    if (!source.trim()) {
      setErr("Quelle lieferte keinen Text. Ein leerer Parse ist keine Weltanalyse.");
      return;
    }
    const local = await apiAnalyzeLocal(source, undefined, title);
    if (local.ok === false) {
      setErr(String(local.error || "Analyse fehlgeschlagen. Ein gescheiterter Parse ist keine Weltanalyse."));
      return;
    }
    const nextDraft = localAnalyzeToDraft(local as Record<string, unknown>, title || "Analyse", source);
    const partIds = (parts || []).filter((p) => p.selected && p.docId && p.text.trim()).map((p) => p.docId!);
    if (partIds.length) nextDraft.world.sourcePartIds = partIds;
    // V25.1 (Vertrag §7.9/§8): Analysequelle und Abdeckung sichtbar; kein lokaler Entwurf als KI.
    const src = String(local.analysisSource || "local");
    nextDraft.source = src === "llm" ? "llm" : "local-fallback";
    if (local.llmError) nextDraft.llmError = String(local.llmError);
    const coverage = local.coverage as { complete?: boolean; chunksAnalyzed?: number; chunksTotal?: number; chars?: number; analyzedChars?: number } | undefined;
    const warn = Array.isArray(local.llmWarnings) ? (local.llmWarnings as string[]) : [];
    if (src !== "llm") setErr(String(local.message || "Analyse lief ohne LLM — lokaler Entwurf, Figurenerkennung unvollständig. Provider unter Konfiguration prüfen."));
    else if (coverage && coverage.complete === false) setErr(String(local.message || `Nur ${coverage.chunksAnalyzed} von ${coverage.chunksTotal} Textblöcken analysiert.`));
    else if (String(local.profileSource || "") !== "llm") setErr(`Profile nicht vom Provider ergänzt (${String(local.llmError || warn[0] || "unbekannt")}) — Figuren tragen nur belegte Extraktionsfelder.`);
    else if (warn.length) setErr(`Analyse mit Warnungen: ${warn.slice(0, 2).join(" · ")}`);
    else {
      const cm = local.castMap as { people?: number; parts?: number } | undefined;
      if (cm && cm.people) setErr(`Ganzbuch-Karte: ${cm.people} Figuren aus ${cm.parts === 1 ? "einem Durchgang über den gesamten Text" : `${cm.parts} Makroblöcken`}; Profile je Figur aus Karte + Textstellen.`);
    }
    setDraft(nextDraft);
    setGroupPick(Object.fromEntries(draftFieldGroups(nextDraft).map((g) => [g.field, true])));
    setTab("entwurf");
    if (String(local.profileSource || "") === "llm") return; // Profile kamen bereits vollständig mit der Analyse
    void apiCompleteProfiles({
      text: source.slice(0, 8000),
      title,
      candidates: nextDraft.characters.map((c) => ({ name: c.name, role: c.role, biography: c.biography, personality: c.personality })),
    }).then((extra) => {
      const rows = (extra.characterCandidates || extra.characters) as Array<{ name?: string }>;
      if (extra.ok === false) setErr(String(extra.message || extra.llmError || "Profilvervollständigung ohne LLM — Felder bleiben lokal/unvollständig."));
      if (!Array.isArray(rows) || !rows.length) return;
      const merged = applyCompletedProfiles(nextDraft, rows);
      merged.source = extra.ok ? nextDraft.source : "local-fallback";
      setDraft(merged);
      setGroupPick(Object.fromEntries(draftFieldGroups(merged).map((g) => [g.field, true])));
    });
  }

  async function runAnalyze(file: File) {
    setBusy(true);
    setErr(null);
    try {
      const image = file.type.startsWith("image/") || /\.(png|jpe?g|webp)$/i.test(file.name);
      const extracted = await extractTextFromFile(file);
      const { title, text, dataUrl, parts, omitted } = extracted;
      setSourceTitle(title);
      setOmittedParts(omitted || 0);
      setSourceFile(file);
      setSourceA11y({
        language: extracted.language,
        accessMode: extracted.accessMode,
        accessibilityFeature: extracted.accessibilityFeature,
        accessibilitySummary: extracted.accessibilitySummary,
      });
      if (parts && parts.length > 1) {
        setEpubParts(assignPartDocIds(parts, title));
        return;
      }
      setEpubParts(null);
      const ocr = image || (!text.trim() && dataUrl) ? await textFromUpload({ text, dataUrl, file }) : { text, status: text.trim() ? "ready" : "ocr_empty", engine: "source" as const };
      const source = ocr.text;
      if (!source.trim()) {
        setErr(
          image || dataUrl
            ? "OCR leer — kein erfundener Text. Cloud-OCR bleibt gesperrt."
            : "Quelle lieferte keinen Text. Ein leerer Parse ist keine Weltanalyse.",
        );
        return;
      }
      await analyzeSource(title || "Analyse", source);
    } catch (e) {
      setErr(e instanceof Error ? analyzeFailMessage(e) : "Analyse fehlgeschlagen");
    } finally {
      setBusy(false);
    }
  }

  async function analyzePickedParts() {
    if (!epubParts?.length) return;
    setBusy(true);
    setErr(null);
    try {
      let rows = epubParts;
      if (sourceFile) {
        const ocr = await ocrSelectedScanParts(sourceFile, rows);
        rows = ocr.parts;
        setEpubParts(rows);
        if (ocr.skipped) setErr(`${ocr.read} Scan-Seite(n) gelesen, ${ocr.skipped} über der Grenze von 8 ausgelassen.`);
      }
      const { text, omitted } = joinSelectedParts(rows);
      setOmittedParts(omitted);
      if (!text.trim()) {
        setErr("OCR leer — kein erfundener Text. Scan-Seiten hakst du, dann nochmal analysieren.");
        return;
      }
      await analyzeSource(sourceTitle || "Analyse", text, rows);
    } catch (e) {
      setErr(e instanceof Error ? analyzeFailMessage(e) : "Analyse fehlgeschlagen");
    } finally {
      setBusy(false);
    }
  }

  async function runGenerate() {
    if (!idea.trim()) return;
    setBusy(true);
    setErr(null);
    try {
      const existing = extendId ? JSON.stringify(worlds.find((w) => w.id === extendId)) : "";
      const res = await apiGenerateWorld({ prompt: idea, existing });
      if (!res.ok) {
        // V25 LLM-02 (Vertrag §7): Ohne LLM gibt es nur einen lokalen Entwurf — sichtbar so benannt, nie als KI.
        const local = res.localDraft as WorldDraft | undefined;
        setErr(String(res.message || res.error || "KI-Erzeugung fehlgeschlagen"));
        if (local?.world) {
          setDraft({ ...local, source: "local-fallback", llmError: String(res.llmError || res.error || "") });
          setGroupPick(Object.fromEntries(draftFieldGroups(local).map((g) => [g.field, true])));
          setTab("entwurf");
        }
        return;
      }
      const draftOut = res.draft as WorldDraft | undefined;
      if (!draftOut?.world) {
        setErr("Keine Welt erzeugt.");
        return;
      }
      draftOut.source = "llm";
      setDraft(draftOut);
      setGroupPick(Object.fromEntries(draftFieldGroups(draftOut).map((g) => [g.field, true])));
      setTab("entwurf");
      // V25.1 CHAR-01: Profile der KI-Figuren vollständig (Backend liefert sie bereits mit;
      // hier zusätzlich über den Profil-Endpunkt, falls der Weltentwurf Figuren ohne Vollprofil hat).
      const incomplete = draftOut.characters.some((c) => !(c as { age?: string }).age || !(c as { fears?: string[] }).fears?.length);
      if (incomplete) {
        void apiCompleteProfiles({
          text: idea.slice(0, 8000),
          title: draftOut.world.name,
          candidates: draftOut.characters.map((c) => ({ name: c.name, role: c.role, biography: c.biography, personality: c.personality })),
        }).then((extra) => {
          const rows = (extra.characterCandidates || extra.characters) as Array<{ name?: string }>;
          if (!Array.isArray(rows) || !rows.length) return;
          const merged = applyCompletedProfiles(draftOut, rows);
          setDraft({ ...merged, source: extra.ok ? "llm" : "local-fallback", llmError: extra.ok ? undefined : String(extra.llmError || extra.error || "") });
          setGroupPick(Object.fromEntries(draftFieldGroups(merged).map((g) => [g.field, true])));
        });
      }
    } catch (e) {
      setErr(e instanceof Error ? e.message : "Generierung fehlgeschlagen");
    } finally {
      setBusy(false);
    }
  }

  async function commitKnowledge() {
    if (uploadMode !== "B") return;
    if (!sessionBindId) {
      setErr("Mode B ist sessionbezogen — zuerst eine Session wählen. Mode B prägt keine Weltidentität.");
      return;
    }
    const sess = sessions.find((s) => s.id === sessionBindId);
    if (!sess) {
      setErr("Mode B: gewählte Session nicht gefunden.");
      return;
    }
    const source =
      (epubParts?.length ? joinSelectedParts(epubParts).text : "") ||
      paste.trim() ||
      String(draft?.world.sourceText || draft?.world.long || "").trim();
    if (!source) {
      setErr("Mode B ohne Quelltext speichert nichts.");
      return;
    }
    if (!activeUserId) {
      setErr("Kein aktiver User.");
      return;
    }
    const upload = {
      id: uid("up"),
      name: sourceTitle || draft?.world.sourceName || draft?.world.name || "Quelle",
      mime: sourceFile?.type || "text/plain",
      text: source.slice(0, 40000),
      mode: "B" as const,
      targetKind: "session" as const,
      targetId: sessionBindId,
      worldId: sess.worldId,
      sessionId: sessionBindId,
      note: "Weltquelle Mode B — Wissen/Referenz, keine Stammprägung",
      committed: false,
      status: "ready" as const,
      createdAt: new Date().toISOString(),
      userId: activeUserId,
    };
    const ok = await addUpload(upload);
    if (!ok) {
      setErr("Mode-B-Upload nicht gespeichert.");
      return;
    }
    const bound = await commitUpload(upload.id);
    if (!bound) {
      setErr("Mode B gespeichert, aber Wissen nicht gebunden.");
      return;
    }
    log({ level: "info", code: "WORLD_SOURCE_MODE_B", message: `${sourceTitle || "Quelle"} → Session ${sessionBindId}` });
    setDraft(null);
    nav({ href: `/upload` });
  }

  async function commitNew() {
    if (!draft) return;
    if (uploadMode === "B") {
      setErr("Mode B prägt keine Weltidentität. Wissen/Referenz speichern oder Mode A wählen.");
      return;
    }
    const picked = applyDraftGroupPick(draft, groupPick);
    const { world, characters: chars } = commitDraft(picked, activeUserId);
    if (epubParts?.length) world.sourcePartIds = [];
    const ok = await upsertWorld(world, chars);
    if (!ok) {
      setErr("Welt konnte nicht gespeichert werden.");
      return;
    }
    if (epubParts?.length) {
      const sourcePartIds = await persistPartDocuments({
        worldId: world.id,
        sourceName: world.sourceName || world.name,
        parts: epubParts,
      });
      if (sourcePartIds.length) {
        world.sourcePartIds = sourcePartIds;
        await patchWorld(world.id, { sourcePartIds });
      }
    }
    const candN = (world.spawnCandidates || []).length;
    log({ level: "info", code: "WORLD_COMMIT", message: `${world.name} · ${candN} Kandidaten, ${chars.length} Stämme` });
    setDraft(null);
    nav({ href: figureFate === "spawn-select" ? `/welt/${world.id}#spawn` : `/welt/${world.id}` });
  }

  async function commitExtend() {
    if (!draft || !extendId) return;
    if (uploadMode === "B") {
      setErr("Mode B prägt keine bestehende Welt. Wissen/Referenz speichern oder Mode A wählen.");
      return;
    }
    const w = worlds.find((x) => x.id === extendId);
    if (!w) return;
    const existing = characters.filter((c) => c.worldId === w.id);
    const picked = applyDraftGroupPick(draft, groupPick);
    const { world, characters: merged } = extendWorldFromDraft(w, existing, picked);
    if (epubParts?.length) {
      world.sourcePartIds = await persistPartDocuments({
        worldId: world.id,
        sourceName: world.sourceName || world.name,
        parts: epubParts,
      });
    }
    const ok = await upsertWorld(world, merged);
    if (!ok) {
      setErr("Erweiterung konnte nicht gespeichert werden.");
      return;
    }
    const candN = (world.spawnCandidates || []).length;
    log({ level: "info", code: "WORLD_EXTEND", message: `${world.name} · ${candN} Kandidaten, ${merged.length} Stämme` });
    setDraft(null);
    nav({ href: figureFate === "spawn-select" ? `/welt/${world.id}#spawn` : `/welt/${world.id}` });
  }

  async function onImport(file: File) {
    setBusy(true);
    setErr(null);
    try {
      const pack = JSON.parse(await file.text()) as WorldPack;
      if (pack.kind !== "matrix10-world-pack" || pack.version !== 1 || !pack.world || !Array.isArray(pack.characters)) {
        throw new Error("Keine gültige Matrix10-Weltpackung (Version 1). EPUB/PDF bitte unter 'Quelle analysieren' wählen.");
      }
      const id = await importPack(pack);
      if (!id) throw new Error("Import wurde nicht gespeichert.");
      nav({ href: `/welt/${id}` });
    } catch (error) {
      setErr(error instanceof Error ? error.message : "Weltimport fehlgeschlagen.");
    } finally {
      setBusy(false);
    }
  }

  async function exportWorld(world: World) {
    setBusy(true);
    setErr(null);
    try {
      const pack = await packWorldWithSources(world, characters);
      downloadJson(`${world.name.replace(/\s+/g, "_")}.world.json`, pack);
    } catch (error) {
      setErr(error instanceof Error ? error.message : "Weltexport fehlgeschlagen.");
    } finally {
      setBusy(false);
    }
  }

  return (
    <Shell title="Welten">
      <PageHead
        kicker="AMASTER §9–12"
        title="Welten-Verwaltung"
        lede="Manuell, aus Kurzbeschreibung, aus Upload oder als Packung. Analyse bleibt Entwurf, bis du bewusst committest. Gasthaus wird nie automatisch gewählt."
      />
      <Tabs
        value={tab}
        onChange={setTab}
        items={[
          { id: "liste", label: "Alle Welten" },
          { id: "neu", label: "Anlegen" },
          { id: "quelle", label: "Quelle analysieren" },
          { id: "ki", label: "Mit KI erzeugen" },
          { id: "entwurf", label: `Entwurf${draft ? " · bereit" : ""}` },
        ]}
      />

      {tab === "liste" ? (
        <div className="grid gap-3 sm:grid-cols-2 xl:grid-cols-3">
          {worlds.map((w) => {
            const n = characters.filter((c) => c.worldId === w.id && c.isWorldNative).length;
            const s = sessions.filter((x) => x.worldId === w.id).length;
            const u = uploads.filter((x) => x.worldId === w.id).length;
            return (
              <article key={w.id} className="rounded-[16px] border border-border bg-elevated p-4">
                <div className="flex items-start justify-between gap-2">
                  <div>
                    <h2 className="font-display text-lg font-semibold">{w.name}</h2>
                    <p className="text-xs text-muted">
                      {w.genre || "ohne Genre"} · {w.epoch || "ohne Epoche"}
                    </p>
                  </div>
                  {w.explicitOnly ? <Chip tone="warn">nur explizit</Chip> : <Chip>{w.visibility ?? "public"}</Chip>}
                </div>
                <p className="mt-2 line-clamp-3 text-sm text-muted">{w.short}</p>
                <p className="mt-3 text-[11px] text-faint">
                  {n} Stämme · {s} Sessions · {u} Uploads · {w.places.length} Orte
                </p>
                <div className="mt-3 flex flex-wrap gap-2">
                  <Button className="min-h-9 text-xs" onClick={() => nav({ href: `/welt/${w.id}` })}>
                    Öffnen
                  </Button>
                  <Button
                    variant="line"
                    className="min-h-9 text-xs"
                    onClick={() => {
                      void startSession({ worldId: w.id }).then((sid) => {
                        if (sid) nav({ href: `/chat/${sid}` });
                      });
                    }}
                  >
                    Session
                  </Button>
                  <Button
                    variant="line"
                    className="min-h-9 text-xs"
                    onClick={() => void exportWorld(w)}
                  >
                    Export
                  </Button>
                  {(
                    <Button
                      variant="danger"
                      className="min-h-9 text-xs"
                      onClick={() => {
                        if (confirm(`Welt „${w.name}“ löschen? Andere Welten bleiben.`)) deleteWorld(w.id);
                      }}
                    >
                      Löschen
                    </Button>
                  )}
                </div>
              </article>
            );
          })}
        </div>
      ) : null}

      {tab === "neu" ? (
        <Panel title="Neue Welt manuell">
          <Field label="Name">
            <Input value={name} onChange={(e) => setName(e.target.value)} placeholder="Name der Welt" />
          </Field>
          <p className="mt-2 text-xs text-muted">Danach füllst du Orte, Regeln, Kanon und Stämme auf der Weltseite. Keine Auto-Übernahme aus Gasthaus.</p>
          <div className="mt-3 flex flex-wrap gap-2">
            <Button onClick={() => void createManual()}>Anlegen und öffnen</Button>
            <label className="inline-flex min-h-11 cursor-pointer items-center rounded-[12px] border border-border bg-elevated px-4 text-sm">
              Packung importieren
              <input
                type="file"
                accept=".json,application/json"
                className="hidden"
                onChange={(e) => {
                  const f = e.target.files?.[0];
                  e.target.value = ""; // same file can be retried after a visible error
                  if (f) void onImport(f);
                }}
              />
            </label>
          </div>
        </Panel>
      ) : null}

      {tab === "quelle" ? (
        <Panel title="Welt aus Quelle (EPUB, Text, Markdown)">
          <p className="text-sm text-muted">
            EPUB folgt Spine und Landmarks. PDF folgt der Textschicht Seite für Seite. Du hakst Teile, dann entsteht der Entwurf. Erst Speichern legt die Welt an.
            Datei nicht wählbar? Text unten einfügen. Ein gescheiterter Parse ist kein Erfolg.
            Uploadmodus vor dem Commit: Mode A prägt Identität. Mode B ist Wissen/Referenz.
          </p>
          <ModeBar mode={uploadMode} onMode={setUploadMode} sessionBindId={sessionBindId} onSession={setSessionBindId} sessions={sessions} />
          <label className="mt-4 flex min-h-28 cursor-pointer flex-col items-center justify-center rounded-[12px] border border-dashed border-border px-4 py-4 text-sm text-muted">
            {busy ? "Analysiert…" : "EPUB oder Textdatei wählen"}
            <input
              type="file"
              className="mt-3 block w-full max-w-md cursor-pointer text-sm text-fg file:mr-3 file:min-h-11 file:cursor-pointer file:rounded-[10px] file:border-0 file:bg-accent file:px-3 file:py-2 file:text-sm file:font-medium file:text-accent-fg"
              data-testid="world-source-file"
              accept=".epub,.txt,.md,.html,.json,.pdf,.pptx"
              disabled={busy}
              onChange={(e) => {
                const f = e.target.files?.[0];
                if (f) void runAnalyze(f);
              }}
            />
          </label>
          <p className="mt-2 text-xs text-muted">Bild ohne Text: lokale OCR (Tesseract.js, Deutsch). Leer bleibt leer. Cloud-OCR gesperrt.</p>
          <Field label="Oder Text einfügen (wenn Datei nicht wählbar)">
            <Textarea rows={6} value={paste} onChange={(e) => setPaste(e.target.value)} placeholder="Buchtext, Szene, Weltbeschreibung…" />
          </Field>
          <Button
            className="mt-2"
            disabled={busy || !paste.trim()}
            onClick={() => {
              const text = paste.trim();
              const title = (sourceTitle.trim() || text.split("\n")[0] || "Quelle").slice(0, 80);
              const file = new File([text], `${title.replace(/\s+/g, "_")}.txt`, { type: "text/plain" });
              void runAnalyze(file);
            }}
          >
            Text als Quelle analysieren
          </Button>
          {sourceTitle ? <p className="mt-2 text-xs text-faint">Quelle: {sourceTitle}</p> : null}
          {sourceA11y && (sourceA11y.language || sourceA11y.accessMode?.length || sourceA11y.accessibilityFeature?.length) ? (
            <p className="mt-2 flex flex-wrap gap-1">
              {sourceA11y.language ? <Chip>Sprache {sourceA11y.language}</Chip> : null}
              {(sourceA11y.accessMode || []).map((m) => (
                <Chip key={m}>{m}</Chip>
              ))}
              {(sourceA11y.accessibilityFeature || []).slice(0, 6).map((m) => (
                <Chip key={m}>{m}</Chip>
              ))}
            </p>
          ) : null}
          {sourceA11y?.accessibilitySummary ? <p className="mt-1 text-xs text-muted">{sourceA11y.accessibilitySummary}</p> : null}
          {epubParts?.length ? (
            <div className="mt-4 rounded-[12px] border border-border bg-bg p-3">
              <p className="text-sm font-medium">Teile nach Landmarks / Seiten</p>
              <p className="mt-1 text-xs text-muted">
                {epubParts.filter((p) => p.selected).length} von {epubParts.length} gewählt
                {omittedParts ? ` · ${omittedParts} Teil(e) über der Längengrenze ausgelassen` : ""}
              </p>
              <ul className="mt-2 max-h-72 space-y-1 overflow-auto">
                {epubParts.map((p, i) => (
                  <li key={`${p.zipPath}#${p.anchor}-${i}`} className="rounded-[10px] border border-border px-2 py-1">
                    <Switch
                      checked={p.selected}
                      onChange={(v) => setEpubParts((rows) => (rows || []).map((x, j) => (j === i ? { ...x, selected: v } : x)))}
                      label={`${p.title || p.zipPath} · ${p.docId ? `${p.docId} · ` : ""}${zoneLabel(p.zone)}${p.kind ? ` · ${kindLabel(p.kind)}` : ""}${layerLabel(p.layer) ? ` · ${layerLabel(p.layer)}` : ""} · ${p.chars} Zeichen`}
                    />
                  </li>
                ))}
              </ul>
              <Button className="mt-3" disabled={busy || !epubParts.some((p) => p.selected)} onClick={() => void analyzePickedParts()}>
                {busy ? "Analysiert…" : "Gewählte Teile analysieren"}
              </Button>
              <p className="mt-2 text-xs text-muted">Scan-Seiten: als Bild OCR (max. 8). Textschicht bleibt unangetastet.</p>
            </div>
          ) : null}
        </Panel>
      ) : null}

      {tab === "ki" ? (
        <Panel title="Welt per Kurzbeschreibung erzeugen">
          <Textarea rows={6} value={idea} onChange={(e) => setIdea(e.target.value)} placeholder="Genre, Ton, Orte, zentrale Figuren, Konflikt…" />
          <Field label="Bestehende Welt ergänzen (optional)">
            <Select value={extendId} onChange={(e) => setExtendId(e.target.value)}>
              <option value="">Neue Welt (nicht ergänzen)</option>
              {worlds.map((w) => (
                <option key={w.id} value={w.id}>
                  {w.name}
                </option>
              ))}
            </Select>
          </Field>
          <Button className="mt-3" disabled={busy || !idea.trim()} onClick={() => void runGenerate()}>
            {busy ? "Erzeugt…" : "Entwurf erzeugen"}
          </Button>
        </Panel>
      ) : null}

      {tab === "entwurf" ? (
        <Panel title="Prüfbarer Entwurf — noch nicht Stamm">
          {draft?.source === "local-fallback" ? (
            <p className="mb-3 rounded-[10px] border border-danger/40 bg-danger/10 p-3 text-sm" role="alert">
              Lokaler Entwurf ohne KI (Heuristik). Felder sind nicht LLM-ergänzt und nicht als vollständig zu werten.
              {draft.llmError ? ` Grund: ${draft.llmError}` : ""}
            </p>
          ) : draft?.source === "llm" ? (
            <p className="mb-3 text-sm text-muted">Entwurf vom konfigurierten Provider erzeugt; Belegtes hat Vorrang, Ergänzungen sind als abgeleitet markiert.</p>
          ) : null}
          {!draft ? <Empty>Kein Entwurf. Analysiere eine Quelle oder erzeuge mit KI.</Empty> : <DraftView draft={draft} onChange={setDraft} groupPick={groupPick} onPick={setGroupPick} />}
          {draft ? (
            <div className="mt-4 space-y-3">
              <ModeBar mode={uploadMode} onMode={setUploadMode} sessionBindId={sessionBindId} onSession={setSessionBindId} sessions={sessions} />
              {uploadMode === "A" ? (
                <div className="grid gap-3 sm:grid-cols-2">
                  <div className="sm:col-span-2 rounded-[12px] border border-border bg-bg p-3">
                    <p className="text-xs text-muted">Figuren vor dem Weltcommit — Analyse legt keinen Stamm an.</p>
                    <div className="mt-2 flex flex-wrap gap-2">
                      <Button
                        variant={figureFate === "candidates" ? "primary" : "line"}
                        data-testid="figure-fate-candidates"
                        onClick={() => setFigureFate("candidates")}
                      >
                        Nur als Kandidaten speichern
                      </Button>
                      <Button
                        variant={figureFate === "spawn-select" ? "primary" : "line"}
                        data-testid="figure-fate-spawn-select"
                        onClick={() => setFigureFate("spawn-select")}
                      >
                        Zur Spawn-Auswahl anbieten
                      </Button>
                    </div>
                    <p className="mt-2 text-xs text-muted">
                      {figureFate === "candidates"
                        ? "Erkannte Figuren bleiben Kandidaten. Stamm erst nach Vorschau und bewusster Auswahl auf der Weltseite."
                        : "Nach dem Speichern öffnet die Weltseite die Spawn-Vorschau. Stamm erst nach „Ausgewählte spawnen“."}
                    </p>
                  </div>
                  <Button onClick={commitNew}>Als neue Welt speichern</Button>
                  <div className="flex gap-2">
                    <Select value={extendId} onChange={(e) => setExtendId(e.target.value)}>
                      <option value="">Zielwelt zum Ergänzen</option>
                      {worlds.map((w) => (
                        <option key={w.id} value={w.id}>
                          {w.name}
                        </option>
                      ))}
                    </Select>
                    <Button variant="line" disabled={!extendId} onClick={commitExtend}>
                      Bestehende ergänzen
                    </Button>
                  </div>
                </div>
              ) : (
                <div className="grid gap-3">
                  <p className="text-xs text-muted">Mode B erzeugt kein Stamm und keine neue Welt. Nur Wissen/Referenz in der gewählten Session.</p>
                  <Button disabled={!sessionBindId} onClick={() => void commitKnowledge()}>
                    Als Wissen/Referenz speichern
                  </Button>
                </div>
              )}
            </div>
          ) : null}
        </Panel>
      ) : null}

      {err ? <p className="mt-3 text-sm text-danger">{err}</p> : null}
      {busy ? <p className="mt-3 text-xs text-accent">Liest das Original. Kein neuer Roman. Nichts wird still committet.</p> : null}
    </Shell>
  );
}

function ModeBar({
  mode,
  onMode,
  sessionBindId,
  onSession,
  sessions,
}: {
  mode: UploadMode;
  onMode: (m: UploadMode) => void;
  sessionBindId: string;
  onSession: (id: string) => void;
  sessions: { id: string; name: string }[];
}) {
  return (
    <div className="mt-3 rounded-[12px] border border-border bg-bg p-3">
      <p className="text-xs text-muted">Uploadmodus — vor dem Commit. Mode A prägt. Mode B ist Beobachtung, kein Stamm.</p>
      <div className="mt-2 flex flex-wrap gap-2">
        <Button variant={mode === "A" ? "primary" : "line"} onClick={() => onMode("A")}>
          Mode A · Prägung
        </Button>
        <Button variant={mode === "B" ? "primary" : "line"} onClick={() => onMode("B")}>
          Mode B · Beobachtung
        </Button>
      </div>
      {mode === "B" ? (
        <Field label="Session für Mode-B-Wissen">
          <Select value={sessionBindId} onChange={(e) => onSession(e.target.value)}>
            <option value="">Session wählen</option>
            {sessions.map((s) => (
              <option key={s.id} value={s.id}>
                {s.name}
              </option>
            ))}
          </Select>
        </Field>
      ) : null}
    </div>
  );
}

function DraftView({
  draft,
  onChange,
  groupPick,
  onPick,
}: {
  draft: WorldDraft;
  onChange: (d: WorldDraft) => void;
  groupPick: Record<string, boolean>;
  onPick: (p: Record<string, boolean>) => void;
}) {
  const w = draft.world;
  const groups = draftFieldGroups(draft);
  return (
    <div className="space-y-4">
      <div className="grid gap-3 sm:grid-cols-2">
        <Field label="Name">
          <Input value={w.name} onChange={(e) => onChange({ ...draft, world: { ...w, name: e.target.value } })} />
        </Field>
        <Field label="Genre">
          <Input value={w.genre} onChange={(e) => onChange({ ...draft, world: { ...w, genre: e.target.value } })} />
        </Field>
      </div>
      <Field label="Kurz">
        <Textarea rows={2} value={w.short} onChange={(e) => onChange({ ...draft, world: { ...w, short: e.target.value } })} />
      </Field>
      <Field label="Lang">
        <Textarea rows={5} value={w.long} onChange={(e) => onChange({ ...draft, world: { ...w, long: e.target.value } })} />
      </Field>
      <p className="text-xs text-muted">
        {draft.recognize === "llm"
          ? "Erkennung: Original gelesen, Rollen und Keywords etikettiert. Kein neuer Text."
          : "Erkennung: lokal aus dem Original (ohne Netz)."}
        {(draft.keywords || []).length ? ` · ${draft.keywords!.join(" · ")}` : ""}
      </p>
      <p className="text-xs text-muted">
        {(w.places ?? []).length} Orte · {(w.rules ?? []).length} Regeln · {draft.characters.length} Figurenkandidaten · Quelle {w.sourceName ?? "—"}
      </p>
      <div className="rounded-[12px] border border-border bg-bg p-3">
        <p className="text-sm font-medium">§11-Felder — einzeln übernehmen</p>
        <ul className="mt-2 space-y-2">
          {groups.map((g) => (
            <li key={g.field} className="rounded-[10px] border border-border p-2 text-sm">
              <label className="flex items-start gap-2">
                <input
                  type="checkbox"
                  checked={groupPick[g.field] !== false}
                  onChange={(e) => onPick({ ...groupPick, [g.field]: e.target.checked })}
                />
                <span>
                  <span className="font-medium">{g.label}</span>
                  <span className="ml-2 text-[11px] text-muted">{g.field}</span>
                  <span className="mt-1 block text-xs text-muted">{g.preview}</span>
                </span>
              </label>
            </li>
          ))}
        </ul>
      </div>
      <ul className="grid gap-2 sm:grid-cols-2">
        {draft.characters.map((c, i) => (
          <li key={`${c.name}-${i}`} className="rounded-[12px] border border-border bg-bg p-3 text-sm">
            <div className="flex items-center justify-between gap-2">
              <Input
                value={c.name}
                onChange={(e) => {
                  const characters = draft.characters.map((x, j) => (j === i ? { ...x, name: e.target.value } : x));
                  onChange({ ...draft, characters });
                }}
              />
              <Button
                variant="danger"
                className="min-h-9 px-3 text-xs"
                onClick={() => onChange({ ...draft, characters: draft.characters.filter((_, j) => j !== i) })}
              >
                Verwerfen
              </Button>
            </div>
            <Input
              className="mt-1"
              value={c.role || ""}
              placeholder="Rolle"
              onChange={(e) => {
                const characters = draft.characters.map((x, j) => (j === i ? { ...x, role: e.target.value } : x));
                onChange({ ...draft, characters });
              }}
            />
            <Input
              className="mt-1"
              value={c.origin || ""}
              placeholder="Herkunft"
              onChange={(e) => {
                const characters = draft.characters.map((x, j) => (j === i ? { ...x, origin: e.target.value } : x));
                onChange({ ...draft, characters });
              }}
            />
            <p className="mt-1 text-xs text-muted">{c.role || "ohne Rolle"}{c.origin ? ` · ${c.origin}` : ""}</p>
            {c.biography ? <p className="mt-1 text-xs text-muted">{String(c.biography).slice(0, 220)}</p> : (
              <p className="mt-1 text-xs text-danger">Kein Originalbeleg — eher kein Charakter.</p>
            )}
            {(c.goals || []).length ? <p className="mt-1 text-[11px] text-muted">Ziele: {(c.goals || []).slice(0, 2).join(" · ")}</p> : null}
            {(c.relations || []).length ? (
              <p className="mt-1 text-[11px] text-muted">
                {(c.relations || []).slice(0, 3).map((r) => `${r.kind} ${r.targetName}`).join(" · ")}
              </p>
            ) : null}
          </li>
        ))}
      </ul>
      <Button
        variant="line"
        onClick={() => onChange({ ...draft, characters: [...draft.characters, { name: "Neue Figur", id: uid("tmp") }] })}
      >
        Kandidat hinzufügen
      </Button>
    </div>
  );
}
