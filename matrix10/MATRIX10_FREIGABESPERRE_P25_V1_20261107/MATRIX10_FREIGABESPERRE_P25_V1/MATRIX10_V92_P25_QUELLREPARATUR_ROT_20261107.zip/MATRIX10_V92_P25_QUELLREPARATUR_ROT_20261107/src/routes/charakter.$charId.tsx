import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useEffect, useMemo, useState } from "react";
import { Empty, PageHead, Panel, Shell, Tabs } from "@/components/shell";
import { Button, Chip, Field, Input, Lines, Select, Textarea } from "@/components/ui";
import { fillCompass } from "@/lib/matrix/compass";
import { downloadJson, packCharacter } from "@/lib/matrix/normalize";
import { uid } from "@/lib/matrix/ids";
import { MEANING_SPACES, type Compass, type StammCharacter, type StammRelation } from "@/lib/matrix/types";
import { useMatrix } from "@/lib/matrix/store";
import { useHydrated } from "@/lib/matrix/use-hydrated";
import { apiBackupCharacter, apiDeriveCompass, apiListCharacterBackups, apiRestoreCharacterBackup, apiSuggestProfile } from "@/lib/matrix/api";

export const Route = createFileRoute("/charakter/$charId")({ component: CharakterPage });

function CharakterPage() {
  const { charId } = Route.useParams();
  const nav = useNavigate();
  const hydrated = useHydrated();
  const characters = useMatrix((s) => s.characters);
  const worlds = useMatrix((s) => s.worlds);
  const sessions = useMatrix((s) => s.sessions);
  const uploads = useMatrix((s) => s.uploads);
  const reviews = useMatrix((s) => s.reviews);
  const patchCharacter = useMatrix((s) => s.patchCharacter);
  const addReview = useMatrix((s) => s.addReview);
  const deleteCharacter = useMatrix((s) => s.deleteCharacter);
  const compassPreview = useMatrix((s) => s.compassPreview);
  const setCompassPreview = useMatrix((s) => s.setCompassPreview);
  const saveSession = useMatrix((s) => s.saveSession);
  const activeUserId = useMatrix((s) => s.activeUserId);
  const char = characters.find((c) => c.id === charId);
  const world = worlds.find((w) => w.id === char?.worldId);
  const [sessionId, setSessionId] = useState("");
  const [tab, setTab] = useState("stamm");
  const [busy, setBusy] = useState(false);
  const [err, setErr] = useState<string | null>(null);
  const [compassDraft, setCompassDraft] = useState<Compass | null>(null);
  const [backups, setBackups] = useState<Array<{ id?: string; name?: string; createdAt?: string }>>([]);
  const [backupMsg, setBackupMsg] = useState("");
  const [profilerField, setProfilerField] = useState("personality");
  const [profilerPreview, setProfilerPreview] = useState<{ field: string; oldValue: string; newValue: string; source: string; reason: string } | null>(null);
  const session = sessions.find((s) => s.id === sessionId);
  const runtime = session && char ? session.runtimes[char.id] : undefined;

  useEffect(() => {
    if (!charId) return;
    void apiListCharacterBackups(charId)
      .then((l) => setBackups(l.backups || []))
      .catch(() => setBackups([]));
  }, [charId]);

  const preview: Compass | null = useMemo(() => {
    if (!compassPreview || compassPreview.characterId !== charId || !compassPreview.json) return null;
    try {
      const parsed = JSON.parse(compassPreview.json) as { spaces?: Partial<Compass> } & Partial<Compass>;
      return fillCompass((parsed.spaces ?? parsed) as Partial<Compass>);
    } catch {
      return null;
    }
  }, [compassPreview, charId]);

  if (!hydrated) {
    return (
      <Shell title="Charakter">
        <p className="text-sm text-muted">Lädt…</p>
      </Shell>
    );
  }
  if (!char) {
    return (
      <Shell title="Charakter">
        <p className="text-sm text-muted">Nicht gefunden.</p>
        <Link to="/charakter" className="text-accent">
          Liste
        </Link>
      </Shell>
    );
  }

  const owned =
    Boolean(activeUserId) &&
    (activeUserId === "admin" ||
      char.ownerUserId === activeUserId ||
      (!char.ownerUserId && !char.id.startsWith("char_g7_")));
  const p = (patch: Partial<StammCharacter>) => {
    if (!owned) {
      setErr("Dieser Stamm ist Weltkanon, nicht deiner. Eigenen Charakter/Avatar anlegen oder Sessionzustand ändern.");
      return;
    }
    patchCharacter(char.id, patch);
  };
  const mems = (session?.memories ?? []).filter((m) => m.characterId === char.id);
  const speaker = mems.filter((m) => m.kind === "gesagt" || m.kind === "getan");
  const listener = mems.filter((m) => m.kind === "gehoert" || m.kind === "gesehen" || m.kind === "erzaehlt");

  async function derive() {
    setBusy(true);
    setErr(null);
    try {
      const profile = JSON.stringify({
        name: char!.name,
        role: char!.role,
        biography: char!.biography,
        personality: char!.personality,
        values: char!.values,
        fears: char!.fears,
        speech: char!.speechRegister,
        rules: char!.reactionRules,
      });
      const res = await apiDeriveCompass({ profile, name: char!.name });
      if (!res.ok) {
        // V25 LLM-02: lokale Kompass-Heuristik ist kein KI-Ergebnis — Vorschau nur mit sichtbarem Hinweis.
        setErr(String(res.message || res.error || "Kompass: kein LLM — lokaler Vorschlag"));
        setCompassPreview(char!.id, String(res.compassJson || res.localCompassJson || ""));
        return;
      }
      setCompassPreview(char!.id, String(res.compassJson || ""));
    } catch (e) {
      setErr(e instanceof Error ? e.message : "Kompass fehlgeschlagen");
    } finally {
      setBusy(false);
    }
  }

  async function suggest() {
    if (!world || !char) return;
    setBusy(true);
    setErr(null);
    try {
      const current = (char as unknown as Record<string, unknown>)[profilerField];
      const res = await apiSuggestProfile({
        name: char.name,
        world: `${world.name}\n${world.short}`,
        field: profilerField,
        source: `${world.name} · Stamm ${char.name}`,
        existing: JSON.stringify({
          role: char.role,
          biography: char.biography,
          personality: char.personality,
          origin: char.origin,
          speechRegister: char.speechRegister,
          conflictStyle: char.conflictStyle,
          humor: char.humor,
          [profilerField]: current,
        }),
      });
      if (!res.ok && !res.patch) throw new Error(String(res.message || res.error || "Vorschlag fehlgeschlagen"));
      if (!res.ok) setErr(String(res.message || res.error || "Kein LLM — lokaler Vorschlag"));
      const patch = (res.patch || {}) as Record<string, unknown>;
      const newValue = patch[profilerField] ?? res.newValue;
      setProfilerPreview({
        field: profilerField,
        oldValue: String(current ?? ""),
        newValue: typeof newValue === "string" ? newValue : JSON.stringify(newValue),
        source: String(res.source || `${world.name} · ${char.name}`),
        reason: String(res.reason || "Profiler-Vorschlag"),
      });
    } catch (e) {
      setErr(e instanceof Error ? e.message : "Vorschlag fehlgeschlagen");
    } finally {
      setBusy(false);
    }
  }

  function saveProfilerReview() {
    if (!char || !profilerPreview) return;
    addReview({
      id: uid("rev"),
      kind: "stamm",
      sourceSessionId: "",
      characterId: char.id,
      worldId: char.worldId,
      field: profilerPreview.field,
      oldValue: profilerPreview.oldValue.slice(0, 400),
      newValue: profilerPreview.newValue.slice(0, 400),
      reason: `${profilerPreview.reason} · Quelle: ${profilerPreview.source}`,
      status: "open",
      createdAt: new Date().toISOString(),
    });
    setProfilerPreview(null);
  }

  return (
    <Shell title={char.name}>
      <PageHead
        kicker={`${char.isWorldNative ? "Stamm" : "Avatar"} · ${char.id}`}
        title={char.name}
        lede={`${world?.name ?? "ohne Welt"} — Stamm ist nicht Runtime. Verletzungen dieser Session gehören nicht hierher.`}
        actions={
          <>
            <Chip>{char.status}</Chip>
            <Button
              variant="line"
              onClick={() => {
                const target =
                  session ||
                  sessions.find((s) => s.worldId === char.worldId) ||
                  null;
                if (!target) {
                  setErr("Keine Session dieser Welt — zuerst unter Chat eine Session anlegen.");
                  return;
                }
                if (owned && char.isWorldNative && !char.canBeAvatar) p({ canBeAvatar: true });
                saveSession({ ...target, avatarId: char.id, alias: char.name });
                setSessionId(target.id);
              }}
            >
              Als Avatar der Session
            </Button>
            <Button variant="line" onClick={() => downloadJson(`${char.name.replace(/\s+/g, "_")}.char.json`, packCharacter(char))}>
              Export
            </Button>
            <Button
              variant="line"
              onClick={() => {
                void apiBackupCharacter(char.id)
                  .then((r) => {
                    setBackupMsg(`Sicherung ${r.backup?.name || r.backup?.id || "ok"}`);
                    return apiListCharacterBackups(char.id);
                  })
                  .then((l) => setBackups(l.backups || []))
                  .catch((e) => setErr(e instanceof Error ? e.message : "Sichern fehlgeschlagen"));
              }}
            >
              Sichern
            </Button>
            <Button
              variant="danger"
              disabled={!owned || busy}
              onClick={async () => {
                if (!owned || !confirm(`Stamm ${char.name} löschen?\nDie Figur und ihre zugeordneten Erinnerungen, Ereignisse und Gesprächsdaten werden endgültig gelöscht.`)) return;
                setBusy(true);
                setErr(null);
                try {
                  const ok = await deleteCharacter(char.id);
                  if (ok) nav({ to: "/charakter" });
                  else {
                    const fail = useMatrix.getState().logs.find((l) => l.code === "PERSIST_FAILED");
                    setErr(fail?.message || "Löschen fehlgeschlagen.");
                  }
                } finally { setBusy(false); }
              }}
            >
              Löschen
            </Button>
          </>
        }
      />

      {err ? <p className="mb-3 text-sm text-danger">{err}</p> : null}
      {!owned ? (
        <p className="mb-3 rounded-[12px] border border-accent/40 bg-subtle px-3 py-2 text-sm">
          {char.name} ist Weltkanon ({char.ownerUserId || "admin"}). Stamm und Kompass sind hier nicht schreibbar — Isolation.
          Eigenen Charakter oder Avatar anlegen, oder unten den Sessionzustand dieser Figur ändern.
        </p>
      ) : null}

      {backups.length || backupMsg ? (
        <Panel className="mb-4" title="Stamm-Sicherungen">
          {backupMsg ? <p className="mb-2 text-xs text-muted">{backupMsg}</p> : null}
          <ul className="space-y-1">
            {backups.slice(0, 6).map((b) => (
              <li key={b.id} className="flex items-center justify-between gap-2 text-sm">
                <span>{b.name || b.id}</span>
                <Button
                  variant="line"
                  className="min-h-8 text-xs"
                  onClick={() => {
                    if (!b.id) return;
                    void apiRestoreCharacterBackup(char.id, b.id)
                      .then(() => setBackupMsg("Wiederhergestellt"))
                      .catch((e) => setErr(e instanceof Error ? e.message : "Wiederherstellen fehlgeschlagen"));
                  }}
                >
                  Wiederherstellen
                </Button>
              </li>
            ))}
          </ul>
        </Panel>
      ) : null}

      <Panel className="mb-4" title="Session-Sicht (ändert den Stamm nicht)">
        <Select value={sessionId} onChange={(e) => setSessionId(e.target.value)}>
          <option value="">Keine Session — nur Stamm</option>
          {sessions
            .filter((s) => s.worldId === char.worldId)
            .map((s) => (
              <option key={s.id} value={s.id}>
                {s.name}
              </option>
            ))}
        </Select>
        {runtime ? (
          <dl className="mt-3 grid grid-cols-2 gap-2 text-sm sm:grid-cols-4">
            <Stat k="Emotion" v={runtime.emotion} />
            <Stat k="Schmerz" v={runtime.pain.toFixed(2)} />
            <Stat k="Mobilität" v={runtime.mobility.toFixed(2)} />
            <Stat k="Absicht" v={runtime.intent} />
            <Stat k="Gefesselt" v={runtime.restrained ? "ja" : "nein"} />
            <Stat k="Sprechen" v={runtime.canSpeak && !runtime.gagged ? "ja" : "nein"} />
            <Stat k="Ort" v={runtime.position} />
            <Stat k="Angst" v={runtime.fear.toFixed(2)} />
          </dl>
        ) : (
          <p className="mt-2 text-xs text-faint">Wähle eine Session, um Live-Körper, Emotion und Ziele zu sehen.</p>
        )}
      </Panel>

      <Tabs
        value={tab}
        onChange={setTab}
        items={[
          { id: "stamm", label: "Basisdaten" },
          { id: "alltag", label: "Persönlichkeit" },
          { id: "koerper", label: "Körper" },
          { id: "bezug", label: "Beziehungen" },
          { id: "kompass", label: "Kompass" },
          { id: "memory", label: "Memory" },
          { id: "wort", label: "Wortschatz" },
          { id: "gelernt", label: `Gelernt${(char.learnedItems || []).length ? ` (${(char.learnedItems || []).length})` : ""}` },
          { id: "ki", label: "KI & Uploads" },
        ]}
      />

      <div className={!owned && tab !== "memory" ? "pointer-events-none opacity-70" : undefined}>
      {tab === "stamm" ? (
        <div className="grid gap-4 lg:grid-cols-2">
          <Panel title="Identität">
            <div className="grid gap-3 sm:grid-cols-2">
              <Field label="Name">
                <Input value={char.name} onChange={(e) => p({ name: e.target.value })} />
              </Field>
              <Field label="Rolle">
                <Input value={char.role} onChange={(e) => p({ role: e.target.value })} />
              </Field>
              <Field label="Alter">
                <Input value={char.age} onChange={(e) => p({ age: e.target.value })} />
              </Field>
              <Field label="Geschlecht">
                <Input value={char.gender} onChange={(e) => p({ gender: e.target.value })} />
              </Field>
              <Field label="Beruf">
                <Input value={char.occupation} onChange={(e) => p({ occupation: e.target.value })} />
              </Field>
              <Field label="Herkunft">
                <Input value={char.origin} onChange={(e) => p({ origin: e.target.value })} />
              </Field>
              <Field label="Spezies / Wesentyp">
                <Input value={char.species || ""} onChange={(e) => p({ species: e.target.value })} />
              </Field>
              <Field label="Quellen-Freigabe">
                <Select
                  value={char.sourceReleaseStatus || "draft"}
                  onChange={(e) => p({ sourceReleaseStatus: e.target.value as NonNullable<StammCharacter["sourceReleaseStatus"]> })}
                >
                  <option value="draft">Entwurf</option>
                  <option value="reviewed">geprüft</option>
                  <option value="released">freigegeben</option>
                  <option value="blocked">gesperrt</option>
                </Select>
              </Field>
              <Field label="Dialekt">
                <Input value={char.dialect} onChange={(e) => p({ dialect: e.target.value })} />
              </Field>
              <Field label="Typischer Ort">
                <Input value={char.typicalPlace} onChange={(e) => p({ typicalPlace: e.target.value })} />
              </Field>
              <label className="col-span-full flex min-h-11 items-center gap-2 text-sm">
                <input
                  type="checkbox"
                  checked={Boolean(char.canBeAvatar) || char.isWorldNative === false}
                  onChange={(e) => p({ canBeAvatar: e.target.checked })}
                />
                {char.isWorldNative ? "Stamm als Avatar verwendbar" : "Avatar — vom Nutzer gesteuert, nicht weltzugehörig"}
              </label>
              <Field label="Status">
                <Select value={char.status} onChange={(e) => p({ status: e.target.value as StammCharacter["status"] })}>
                  <option value="entwurf">Entwurf</option>
                  <option value="bereit">bereit</option>
                  <option value="archiv">archiv</option>
                </Select>
              </Field>
              <Field label="Sichtbarkeit">
                <Select value={char.visibility} onChange={(e) => p({ visibility: e.target.value as StammCharacter["visibility"] })}>
                  <option value="public">sichtbar</option>
                  <option value="private">privat</option>
                </Select>
              </Field>
            </div>
            <Field label="Anreden / Aliase">
              <Lines value={char.aliases} onChange={(aliases) => p({ aliases })} />
            </Field>
          </Panel>
          <Panel title="Hintergrund">
            <Field label="Erscheinung">
              <Textarea rows={2} value={char.appearance} onChange={(e) => p({ appearance: e.target.value })} />
            </Field>
            <Field label="Biografie">
              <Textarea rows={5} value={char.biography} onChange={(e) => p({ biography: e.target.value })} />
            </Field>
            <Field label="Welt-Notizen">
              <Textarea rows={2} value={char.worldNotes} onChange={(e) => p({ worldNotes: e.target.value })} />
            </Field>
            <Field label="Kanon">
              <Lines value={char.canon} onChange={(canon) => p({ canon })} />
            </Field>
            <Field label="Kernfakten">
              <Lines value={char.coreFacts || []} onChange={(coreFacts) => p({ coreFacts })} />
            </Field>
            <Field label="Bindungsmuster">
              <Lines value={char.bindingPatterns || []} onChange={(bindingPatterns) => p({ bindingPatterns })} />
            </Field>
            <Field label="Dauerhafte Fähigkeiten">
              <Lines value={char.lastingAbilities || []} onChange={(lastingAbilities) => p({ lastingAbilities })} />
            </Field>
          </Panel>
        </div>
      ) : null}

      {tab === "alltag" ? (
        <div className="grid gap-4 lg:grid-cols-2">
          <Panel title="Persönlichkeit">
            <Field label="Kurzform">
              <Textarea rows={3} value={char.personality} onChange={(e) => p({ personality: e.target.value })} />
            </Field>
            <Field label="Konfliktstil">
              <Input value={char.conflictStyle} onChange={(e) => p({ conflictStyle: e.target.value })} />
            </Field>
            <Field label="Humor">
              <Input value={char.humor} onChange={(e) => p({ humor: e.target.value })} />
            </Field>
            <Field label="Sprechregister">
              <Input value={char.speechRegister} onChange={(e) => p({ speechRegister: e.target.value })} />
            </Field>
          </Panel>
          <Panel title="Antrieb">
            {(char.drives || []).length ? (
              <p className="mb-2 text-sm"><span className="text-faint">Urtriebe: </span>{(char.drives || []).map((d) => `${d.drive} ${Number(d.strength).toFixed(1)}${d.evidence ? ` (${d.evidence.slice(0, 50)})` : ""}`).join(" · ")}</p>
            ) : null}
            <p className="mb-2 text-xs text-muted">Stammfelder aus dem Original. Der Kernel liest sie als Spiegel — kein extra System-Prompt, kein erfundener Antrieb.</p>
            <Field label="Werte">
              <Lines value={char.values} onChange={(values) => p({ values })} />
            </Field>
            <Field label="Ziele">
              <Lines value={char.goals} onChange={(goals) => p({ goals })} />
            </Field>
            <Field label="Ängste">
              <Lines value={char.fears} onChange={(fears) => p({ fears })} />
            </Field>
            <Field label="Geheimnisse">
              <Lines value={char.secrets} onChange={(secrets) => p({ secrets })} />
            </Field>
            <Field label="Vorlieben">
              <Lines value={char.likes} onChange={(likes) => p({ likes })} />
            </Field>
            <Field label="Abneigungen">
              <Lines value={char.dislikes} onChange={(dislikes) => p({ dislikes })} />
            </Field>
            <Field label="Tabus">
              <Lines value={char.taboos} onChange={(taboos) => p({ taboos })} />
            </Field>
            <Field label="Reaktionsregeln">
              <Lines value={char.reactionRules} onChange={(reactionRules) => p({ reactionRules })} />
            </Field>
            <Field label="Stammwissen">
              <Lines value={char.knowledge} onChange={(knowledge) => p({ knowledge })} />
            </Field>
          </Panel>
        </div>
      ) : null}

      {tab === "koerper" ? (
        <Panel title="Körperliche Grundlage (Stamm, nicht Runtime)">
          <div className="grid grid-cols-2 gap-3 sm:grid-cols-4">
            {(["mobility", "strength", "pain", "consciousness"] as const).map((k) => (
              <Field key={k} label={k}>
                <Input
                  type="number"
                  step="0.05"
                  min={0}
                  max={1}
                  value={char.body[k]}
                  onChange={(e) => p({ body: { ...char.body, [k]: Number(e.target.value) } })}
                />
              </Field>
            ))}
          </div>
          <Field label="Notizen">
            <Textarea rows={2} value={char.body.notes} onChange={(e) => p({ body: { ...char.body, notes: e.target.value } })} />
          </Field>
          <Field label="Einschränkungen">
            <Input
              value={char.body.constraints.join(", ")}
              onChange={(e) => p({ body: { ...char.body, constraints: e.target.value.split(",").map((s) => s.trim()).filter(Boolean) } })}
            />
          </Field>
        </Panel>
      ) : null}

      {tab === "bezug" ? (
        <Panel title="Stamm-Ausgangsbeziehungen (gerichtet)">
          <ul className="space-y-3">
            {char.relations.map((r, i) => (
              <li key={`${r.targetName}-${i}`} className="rounded-[12px] bg-bg p-3">
                <div className="grid gap-2 sm:grid-cols-2">
                  <Input
                    value={r.targetName}
                    onChange={(e) => p({ relations: char.relations.map((x, j) => (j === i ? { ...x, targetName: e.target.value } : x)) })}
                  />
                  <Input
                    value={r.kind}
                    onChange={(e) => p({ relations: char.relations.map((x, j) => (j === i ? { ...x, kind: e.target.value } : x)) })}
                  />
                </div>
                <Textarea
                  className="mt-1"
                  rows={2}
                  value={r.note}
                  onChange={(e) => p({ relations: char.relations.map((x, j) => (j === i ? { ...x, note: e.target.value } : x)) })}
                />
                <p className="mt-1 text-xs text-muted">
                  Trust {r.trust.toFixed(2)} · Nähe {r.closeness.toFixed(2)} · Angst {r.fear.toFixed(2)}
                </p>
              </li>
            ))}
          </ul>
          <Button
            variant="line"
            className="mt-2"
            onClick={() => {
              const rel: StammRelation = { targetName: "", kind: "", note: "", trust: 0.4, closeness: 0.3, fear: 0.1 };
              p({ relations: [...char.relations, rel] });
            }}
          >
            Beziehung
          </Button>
        </Panel>
      ) : null}

      {tab === "kompass" ? (
        <Panel title="Chathere-Kompass — Vorschau, dann bewusst speichern">
          <p className="text-xs text-muted">Verhaltenslinse. Keine Fakten, kein Wissen, keine Beziehungen, keine God-Wirkung.</p>
          <div className="mt-3 flex flex-wrap gap-2">
            <Button variant="line" disabled={busy} onClick={() => void derive()}>
              Aus Profil ableiten
            </Button>
            {preview || compassDraft ? (
              <Button
                onClick={() => {
                  p({ compass: compassDraft ?? preview ?? char.compass });
                  setCompassDraft(null);
                  setCompassPreview(char.id, "");
                }}
              >
                Kompass speichern
              </Button>
            ) : null}
            <Button variant="danger" onClick={() => p({ compass: fillCompass({}) })}>
              Kompass löschen
            </Button>
          </div>
          {err ? <p className="mt-2 text-sm text-danger">{err}</p> : null}
          <div className="mt-4 grid gap-2 sm:grid-cols-2 lg:grid-cols-3">
            {(MEANING_SPACES as unknown as string[]).map((space) => {
              const shown = compassDraft ?? preview ?? char.compass;
              const cell = shown[space as keyof Compass];
              return (
                <article key={space} className="rounded-[12px] border border-border bg-bg p-3">
                  <p className="text-sm font-medium">{space}</p>
                  <p className="text-[11px] tabular-nums text-faint">
                    stance {cell.stance.toFixed(2)} · Schwelle {cell.threshold.toFixed(2)}
                  </p>
                  <p className="mt-1 text-xs text-muted">{cell.reaction}</p>
                  <p className="text-[11px] text-faint">{cell.bodyCue}</p>
                  <label className="mt-2 block text-[11px] text-muted">
                    Schwelle
                    <input
                      type="range"
                      min={0.2}
                      max={0.8}
                      step={0.01}
                      value={cell.threshold}
                      className="w-full"
                      onChange={(e) => {
                        const base = compassDraft ?? preview ?? char.compass;
                        const next = { ...base, [space]: { ...cell, threshold: Number(e.target.value), space } };
                        setCompassDraft(next as Compass);
                      }}
                    />
                  </label>
                </article>
              );
            })}
          </div>
        </Panel>
      ) : null}

      {tab === "memory" ? (
        <div className="grid gap-4 lg:grid-cols-3">
          <Panel title="Gesagt / getan">
            <MemList items={speaker} />
          </Panel>
          <Panel title="Gehört / gesehen">
            <MemList items={listener} />
          </Panel>
          <Panel title="Stammwissen">
            <ul className="space-y-1 text-sm">
              {char.knowledge.map((k) => (
                <li key={k}>{k}</li>
              ))}
            </ul>
          </Panel>
        </div>
      ) : null}

      {tab === "gelernt" ? (
        <Panel title="Sitzungslernen und freigegebener Stamm">
          <p className="mb-3 text-sm text-muted">
            Sitzungslernen ist kein neuer Ausgangscharakter. Ohne Freigabe wirkt es nicht in neuen Sitzungen.
            Dauerhaft übernehmen gibt einen Wert ausdrücklich für den Stamm frei. Alte Gespräche und Fakten bleiben erhalten.
          </p>
          {owned && (char.learnedItems || []).length ? (
            <Button variant="danger" disabled={busy} onClick={async () => {
              if (!confirm(`Alle ${(char.learnedItems || []).length} alten Lernwerte aus ${char.name} entfernen?\nGespräche und Erinnerungen bleiben.`)) return;
              setBusy(true); setErr(null);
              try {
                const ok = await patchCharacter(char.id, { removeLearnedAll: true } as unknown as Partial<StammCharacter>);
                if (!ok) {
                  const fail = useMatrix.getState().logs.find((l) => l.code === "PERSIST_FAILED");
                  setErr(fail?.message || "Lernwerte konnten nicht entfernt werden.");
                }
              } finally { setBusy(false); }
            }}>
              {busy ? "Speichert…" : "Alle alten Lernwerte entfernen"}
            </Button>
          ) : null}
          {(char.learnedItems || []).length ? (
            <ul className="space-y-2">
              {[...(char.learnedItems || [])].reverse().map((it) => (
                <li key={it.id} className="flex flex-wrap items-center justify-between gap-2 rounded-[10px] border border-border bg-bg p-3">
                  <div>
                    <p className="text-sm"><span className="text-faint">{it.field}:</span> {it.value}</p>
                    <p className="text-xs text-muted">{it.source}{typeof it.turn === "number" ? ` · Turn ${it.turn}` : ""}{it.at ? ` · ${String(it.at).slice(0, 16).replace("T", " ")}` : ""}</p>
                  </div>
                  {owned && it.status !== "approved" ? (
                    <Button variant="line" className="min-h-11" disabled={busy} onClick={() => {
                      if (confirm(`Diesen Wert dauerhaft in den Stamm von ${char.name} uebernehmen?`))
                        void patchCharacter(char.id, { approveLearned: it.id } as unknown as Partial<StammCharacter>);
                    }}>Dauerhaft übernehmen</Button>
                  ) : <span className="text-xs">Freigegeben</span>}
                  <Button variant="line" className="min-h-11" onClick={() => patchCharacter(char.id, { removeLearned: it.id } as unknown as Partial<StammCharacter>)}>
                    Entfernen
                  </Button>
                </li>
              ))}
            </ul>
          ) : (
            <Empty>Keine alten automatischen Lernwerte vorhanden. Neues Gesprächswissen bleibt in Session-Fakten und Erinnerungen.</Empty>
          )}
        </Panel>
      ) : null}
      {tab === "wort" ? (
        <Panel title="Wortschatz & Ausdruck">
          <Field label="Typische Sätze">
            <Lines value={char.typicalPhrases} onChange={(typicalPhrases) => p({ typicalPhrases })} />
          </Field>
          <Field label="Lieblingswörter">
            <Lines value={char.favoriteWords} onChange={(favoriteWords) => p({ favoriteWords })} />
          </Field>
          <Field label="Tabus">
            <Lines value={char.taboos} onChange={(taboos) => p({ taboos })} />
          </Field>
        </Panel>
      ) : null}

      {tab === "ki" ? (
        <Panel title="KI-Unterstützung und Quellen">
          <p className="mb-2 text-xs text-muted">Profiler: ein Feld wählen, Vorschlag prüfen, bewusst als Review speichern. Kein Autosave.</p>
          <label className="text-xs text-muted">
            Feld
            <Select className="mt-1" value={profilerField} onChange={(e) => setProfilerField(e.target.value)}>
              <option value="personality">Persönlichkeit</option>
              <option value="biography">Biografie</option>
              <option value="role">Rolle</option>
              <option value="origin">Herkunft</option>
              <option value="speechRegister">Sprechregister</option>
              <option value="conflictStyle">Konfliktstil</option>
              <option value="humor">Humor</option>
            </Select>
          </label>
          <div className="mt-3 flex flex-wrap gap-2">
            <Button disabled={busy} onClick={() => void suggest()}>
              Profilvorschlag
            </Button>
            <Button variant="line" onClick={() => nav({ to: "/upload" })}>
              Uploads
            </Button>
          </div>
          {profilerPreview ? (
            <div className="mt-3 rounded-[12px] border border-border bg-bg p-3 text-sm">
              <p className="text-xs text-muted">Feld {profilerPreview.field} · Quelle {profilerPreview.source}</p>
              <p className="mt-2 text-xs text-faint">Bisher</p>
              <p className="whitespace-pre-wrap">{profilerPreview.oldValue || "—"}</p>
              <p className="mt-2 text-xs text-faint">Vorschlag</p>
              <p className="whitespace-pre-wrap">{profilerPreview.newValue}</p>
              <Button className="mt-3 min-h-9 text-xs" onClick={saveProfilerReview}>
                Als Review speichern
              </Button>
            </div>
          ) : null}
          {err ? <p className="mt-2 text-sm text-danger">{err}</p> : null}
          <p className="mt-3 text-xs text-muted">Quellen: {char.sourceRefs.join(", ") || "—"}</p>
          <ul className="mt-2 space-y-1 text-xs text-faint">
            {uploads
              .filter((u) => u.characterId === char.id)
              .map((u) => (
                <li key={u.id}>
                  {u.name} · {u.mode} · {u.status}
                </li>
              ))}
          </ul>
          <p className="mt-3 text-xs text-muted">Review-Vorschläge: {reviews.filter((r) => r.characterId === char.id).length}</p>
        </Panel>
      ) : null}
      </div>
    </Shell>
  );
}

function MemList({ items }: { items: { id: string; kind: string; text: string; turn: number }[] }) {
  if (!items.length) return <p className="text-xs text-faint">Keine Einträge in dieser Session.</p>;
  return (
    <ul className="space-y-2 text-sm">
      {items.map((m) => (
        <li key={m.id} className="rounded-[8px] bg-bg px-2 py-1.5">
          <p className="text-[11px] text-faint">
            {m.kind} · Turn {m.turn}
          </p>
          <p>{m.text}</p>
        </li>
      ))}
    </ul>
  );
}

function Stat({ k, v }: { k: string; v: string }) {
  return (
    <div className="rounded-[12px] bg-bg px-2 py-1.5">
      <dt className="text-[11px] text-faint">{k}</dt>
      <dd className="text-sm">{v}</dd>
    </div>
  );
}
