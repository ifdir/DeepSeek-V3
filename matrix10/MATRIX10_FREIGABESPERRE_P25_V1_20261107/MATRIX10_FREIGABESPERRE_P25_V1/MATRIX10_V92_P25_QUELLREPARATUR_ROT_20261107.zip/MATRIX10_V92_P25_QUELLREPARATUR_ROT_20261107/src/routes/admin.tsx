import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { Shell, Panel } from "@/components/shell";
import { Button, Chip } from "@/components/ui";
import { BUILD_ID } from "@/lib/matrix/types";
import { useMatrix } from "@/lib/matrix/store";
import { useHydrated } from "@/lib/matrix/use-hydrated";
import { apiListLogs, apiLiveLog } from "@/lib/matrix/api";

export const Route = createFileRoute("/admin")({ component: AdminPage });

type SqlLog = { id?: string; at?: string; level?: string; code?: string; message?: string };
type LiveLine = { ts?: string; stage?: string; trace_id?: string; endpoint?: string; session_id?: string; raw?: string };

function AdminPage() {
  const hydrated = useHydrated();
  const worlds = useMatrix((s) => s.worlds);
  const characters = useMatrix((s) => s.characters);
  const sessions = useMatrix((s) => s.sessions);
  const uploads = useMatrix((s) => s.uploads);
  const reviews = useMatrix((s) => s.reviews);
  const users = useMatrix((s) => s.users);
  const [sql, setSql] = useState<SqlLog[]>([]);
  const [live, setLive] = useState<LiveLine[]>([]);
  const [err, setErr] = useState<string | null>(null);

  async function reloadLogs() {
    setErr(null);
    try {
      const [a, b] = await Promise.all([apiListLogs(), apiLiveLog()]);
      setSql(((a.logs as SqlLog[]) || []).slice().reverse());
      setLive(((b.lines as LiveLine[]) || []).slice().reverse());
    } catch (e) {
      setErr(e instanceof Error ? e.message : "Logs nicht lesbar");
    }
  }

  useEffect(() => {
    if (hydrated) void reloadLogs();
  }, [hydrated]);

  if (!hydrated) {
    return (
      <Shell title="Admin">
        <p className="text-sm text-muted">Lädt…</p>
      </Shell>
    );
  }

  const cards = [
    ["Build", BUILD_ID],
    ["User", String(users.length)],
    ["Welten", String(worlds.length)],
    ["Stämme", String(characters.filter((c) => c.isWorldNative).length)],
    ["Sessions", String(sessions.length)],
    ["Uploads", String(uploads.length)],
    ["Review offen", String(reviews.filter((r) => r.status === "open").length)],
    ["SQLite-Logs", String(sql.length)],
  ];

  return (
    <Shell title="Admin">
      <div className="mb-4 flex items-center gap-2">
        <h1 className="font-display text-2xl font-semibold">Systemstatus</h1>
        <Chip tone="ok">verbunden</Chip>
      </div>
      <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
        {cards.map(([k, v]) => (
          <Panel key={k}>
            <p className="text-[11px] uppercase tracking-wide text-faint">{k}</p>
            <p className="mt-1 break-all font-mono text-sm">{v}</p>
          </Panel>
        ))}
      </div>
      <div className="mt-3">
        <Button variant="line" className="min-h-9 text-xs" onClick={() => void reloadLogs()}>
          Reader neu laden
        </Button>
      </div>
      {err ? <p className="mt-2 text-sm text-danger">{err}</p> : null}
      <div className="mt-4 grid gap-4 lg:grid-cols-2">
        <Panel title={`SQLite /api/logs · ${sql.length}`}>
          <ul className="max-h-80 space-y-1 overflow-auto font-mono text-[11px] text-muted">
            {sql.slice(0, 40).map((l, i) => (
              <li key={String(l.id || i)}>
                {l.at} {l.level} {l.code} {l.message}
              </li>
            ))}
          </ul>
        </Panel>
        <Panel title={`Live-Trace · ${live.length}`}>
          <ul className="max-h-80 space-y-1 overflow-auto font-mono text-[11px] text-muted">
            {live.slice(0, 40).map((l, i) => (
              <li key={`${l.trace_id || "t"}-${i}`}>
                {l.ts} {l.stage} {l.endpoint || ""} {l.trace_id || l.raw || ""}
              </li>
            ))}
          </ul>
        </Panel>
      </div>
    </Shell>
  );
}
