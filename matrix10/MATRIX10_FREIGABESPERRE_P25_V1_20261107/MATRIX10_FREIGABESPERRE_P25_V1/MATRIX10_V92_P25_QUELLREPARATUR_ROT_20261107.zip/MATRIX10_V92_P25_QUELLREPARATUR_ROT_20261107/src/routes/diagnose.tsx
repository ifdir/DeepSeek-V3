import { createFileRoute, useRouter } from "@tanstack/react-router";
import { useState } from "react";
import { Shell, Panel } from "@/components/shell";
import { Chip } from "@/components/ui";
import { BUILD_ID } from "@/lib/matrix/types";
import { NAV, NAV_MORE } from "@/lib/matrix/nav";
import { useMatrix } from "@/lib/matrix/store";
import { useHydrated } from "@/lib/matrix/use-hydrated";
import { createSession, pickSpeaker } from "@/lib/matrix/session-engine";
import { applyGodMutation, ingestEvent, parseAction } from "@/lib/matrix/event-engine";
import { resolveAddress } from "@/lib/matrix/address";
import { buildSpiegel } from "@/lib/matrix/spiegel";
import { GASTHAUS_CHARS, GASTHAUS_WORLD } from "@/lib/matrix/seed-gasthaus";
import { apiListSnapshots, apiGetLog, apiGetSession, apiHealth, apiLiveLog, apiListLogs, apiProbeLogDelete, apiProbeLogPut, apiSystemLoop } from "@/lib/matrix/api";

export const Route = createFileRoute("/diagnose")({ component: DiagnosePage });

function chainChecks() {
  const world = structuredClone(GASTHAUS_WORLD);
  const chars = structuredClone(GASTHAUS_CHARS).filter((c) => c.isWorldNative);
  const clara = chars.find((c) => c.name.startsWith("Clara"))!;
  const mara = chars.find((c) => c.name.startsWith("Mara"))!;
  const session = createSession({ world, characters: chars, avatar: null, userId: "admin" });

  const addr = resolveAddress({
    text: "Mara, was hat Clara gemacht?",
    present: chars.filter((c) => session.scene.presentIds.includes(c.id)),
    all: chars,
    session,
  });
  const speakerQ = pickSpeaker({
    world,
    session,
    natives: chars,
    stimulus: "Mara, was hat Clara gemacht?",
  });

  const before = structuredClone(session);
  ingestEvent(before, world, chars, {
    actorId: clara.id,
    targetId: mara.id,
    kind: "physical",
    verb: "strike",
    text: "Clara schlägt Mara",
    authority: "regie",
  });
  const maraMem = before.memories.filter((m) => m.characterId === mara.id);
  const claraHeardOnly = before.memories.filter((m) => m.characterId !== mara.id && m.characterId !== clara.id && m.kind === "betroffen");
  const factsRead = buildSpiegel({
    world,
    session: before,
    speaker: mara,
    present: chars.filter((c) => before.scene.presentIds.includes(c.id)),
    fired: [],
    stimulus: "Warum?",
    mode: "teilnehmer",
    fateSeed: null,
  });
  const secretLeak = factsRead.unknown.some((u) => /affäre|affare|johann/i.test(u));

  const godSes = structuredClone(session);
  applyGodMutation(godSes, world, chars, "Mara hat einen gebrochenen Arm.", "body", mara.id);
  const arm = godSes.runtimes[mara.id];

  const parsed = parseAction("Clara zieht Mara an den Haaren", chars, world);
  const schatz = resolveAddress({
    text: "Hey Schatz, alles in Ordnung?",
    present: chars.filter((c) => session.scene.presentIds.includes(c.id)),
    all: chars,
    session: { ...session, avatarId: chars.find((c) => c.name.startsWith("Robert"))!.id },
  });

  return [
    { id: "vocative", ok: addr.addressed?.id === mara.id && addr.topic?.id === clara.id, text: "Vocative: „Mara, was hat Clara gemacht?“ → Mara, Thema Clara" },
    { id: "speaker", ok: speakerQ?.id === mara.id, text: "Sprecherwahl folgt der Angesprochenen, nicht der Wirtin" },
    { id: "witness", ok: maraMem.some((m) => m.kind === "betroffen") && claraHeardOnly.length === 0, text: "Witness: Betroffene erleben, Unbeteiligte kopieren keine Innenwelt" },
    { id: "facts-in-spiegel", ok: factsRead.facts.some((f) => /schlägt|schlag/i.test(f.text)), text: "SceneFacts liegen im Spiegel der Zeugin" },
    { id: "no-secret-leak", ok: !secretLeak, text: "Weltgeheimnisse stehen nicht im Unwissen-Feld" },
    { id: "god-body", ok: (arm?.pain ?? 0) >= 0.7 && arm?.constraints.some((c) => /arm/i.test(c)) === true, text: "God/body mutiert Runtime, nicht nur Prompttext" },
    { id: "parse-hair", ok: parsed.actor?.id === clara.id && parsed.target?.id === mara.id && parsed.verb === "hold", text: "Regie/Puppet: „zieht an den Haaren“ ist Handlung mit Ziel" },
    { id: "schatz", ok: schatz.addressed?.name.startsWith("Mara") === true, text: "„Schatz“ löst über Roberts Liebe auf Mara auf" },
    { id: "dialogue", ok: (factsRead.dialogue.length >= 0 && session.autoChat.contextTurns >= 1), text: "contextTurns existiert und speist den Dialogspiegel" },
  ];
}

function DiagnosePage() {
  const hydrated = useHydrated();
  const router = useRouter();
  const [loopMsg, setLoopMsg] = useState<string | null>(null);
  const [chainLive, setChainLive] = useState("");
  const [systemLoopMsg, setSystemLoopMsg] = useState<string | null>(null);
  const [probeMsg, setProbeMsg] = useState<string | null>(null);
  async function runSystemLoop() {
    setSystemLoopMsg("läuft…");
    try {
      const res = await apiSystemLoop();
      const created = (res.created as Record<string, unknown>) || res;
      const failed = (res.failed as unknown[]) || [];
      const rotten = res.ok === false || failed.length > 0;
      setSystemLoopMsg(
        `Systemschleife ${rotten ? "ROT" : "ok"} · failed=${JSON.stringify(failed).slice(0, 240)} · ${JSON.stringify(created).slice(0, 240)}`,
      );
    } catch (e) {
      setSystemLoopMsg(e instanceof Error ? e.message : "Systemschleife fehlgeschlagen");
    }
  }
  async function runLoop() {
    setLoopMsg("läuft…");
    try {
      const res = await apiHealth();
      const shownBuild = res.buildId || res.build;
      setLoopMsg(res.ok && res.db ? `API+SQLite ${shownBuild}` : "ROT");
      let liveTail = "";
      try {
        const live = await apiLiveLog();
        liveTail = `LiveLog ${live.count ?? ((live.lines as unknown[]) || []).length}`;
      } catch {
        liveTail = "LiveLog —";
      }
      const st = useMatrix.getState();
      const sid = st.sessions[0]?.id;
      if (sid) {
        const got = await apiGetSession(sid);
        const s = (got.session || {}) as Record<string, unknown>;
        setChainLive(
          [
            `Build ${shownBuild}`,
            `DB ${res.db}`,
            `User ${s.userId || st.activeUserId}`,
            `Welt ${s.worldId || ""}`,
            `Session ${s.id || sid}`,
            `Turn ${s.turnIndex ?? ""}`,
            `Rolle ${s.role || ""}`,
            `Avatar ${s.avatarId || "—"}`,
            `Facts ${Array.isArray(s.facts) ? s.facts.length : 0}`,
            `Memory ${Array.isArray(s.memories) ? s.memories.length : 0}`,
            `Props ${Array.isArray(s.propositions) ? s.propositions.length : 0}`,
            `Runtime ${s.runtimes ? Object.keys(s.runtimes as object).length : 0}`,
            `Witness ${Array.isArray(s.witnessKnowledge) ? s.witnessKnowledge.length : 0}`,
            // V65Y: stored legacy rows outside the write boundary (read view, nothing changed) and the identity model
            `Schreibgrenze ${(s.schreibgrenze as { altzeilen?: number } | undefined)?.altzeilen ?? 0} Altzeilen`,
            // V70 (Audit10 §7): the reader boundary - stored rows that are no effective evidence (kept, never read as truth),
            // and the matters whose state an unproven order of one turn would decide (shown as "unklar", never guessed)
            `Nicht wirksam ${(s.altbestand as { anzahl?: number } | undefined)?.anzahl ?? 0} Zeilen`,
            `Reihenfolge unbelegt ${Object.values(((s.altbestand as { reihenfolgeUnbelegt?: Record<string, number[]> } | undefined)?.reihenfolgeUnbelegt) ?? {}).reduce((n, l) => n + l.length, 0)} Turns, unklar ${((s.altbestand as { mehrdeutig?: unknown[] } | undefined)?.mehrdeutig ?? []).length}`,
            // V66 (Audit5 E03): imported rows and the God/Regie authority the owner accepted with the import
            `Import ${(s.schreibgrenze as { importiert?: number } | undefined)?.importiert ?? 0} Zeilen, davon angenommene Autorität ${(s.schreibgrenze as { importierteAutoritaet?: number } | undefined)?.importierteAutoritaet ?? 0}`,
            `Kennung ${res.identitaet?.hinweis || "—"}`,
            `Reader GET /api/sessions/${sid}`,
            liveTail,
          ].join(" → "),
        );
      } else {
        setChainLive(`Build ${shownBuild} → DB ${res.db} → Kennung ${res.identitaet?.hinweis || "—"} → keine Session (Reader leer)`);
      }
    } catch (e) {
      setLoopMsg(e instanceof Error ? e.message : "Fehler");
    }
  }
  async function runForbiddenLogProbe() {
    setProbeMsg("läuft…");
    try {
      const listed = await apiListLogs();
      const first = ((listed.logs as { id?: string }[]) || []).find((l) => l.id);
      const logId = first?.id || "missing";
      let getLine = "GET —";
      if (first?.id) {
        const row = await apiGetLog(first.id);
        getLine = `GET ${first.id} ok=${Boolean(row.ok ?? row.log ?? row.id)}`;
      }
      const put = await apiProbeLogPut(logId);
      const del = await apiProbeLogDelete(logId);
      // V66 (Audit6 N05; AMASTER §68 Nr. 91 Diagnose ohne Sonderwrite): the probe only reads the snapshots - it created
      // one before ("Diagnose-Stand"), with the client's session blob merged into it
      let snapLine = "GET /api/snapshots —";
      try {
        const listed = await apiListSnapshots();
        const all = (listed.snapshots || []).filter((x) => x.sessionId); // session snapshots (not world/character backups)
        const own = all.filter((x) => x.erfasst?.durch === "server").length;
        snapLine = `GET /api/snapshots Session-Stände ${all.length} (vom Server erfasst ${own}, nur Archiv ${all.length - own})`;
      } catch (e) {
        snapLine = `GET /api/snapshots ${e instanceof Error ? e.message : "fehl"}`;
      }
      setProbeMsg(
        `${getLine} · PUT ${put.status} ${put.error || ""} · DELETE ${del.status} ${del.error || ""} · ${snapLine}`,
      );
    } catch (e) {
      setProbeMsg(e instanceof Error ? e.message : "Probe fehlgeschlagen");
    }
  }
  const sessions = useMatrix((s) => s.sessions);
  const worlds = useMatrix((s) => s.worlds);
  const characters = useMatrix((s) => s.characters);
  const lastSpiegelJson = useMatrix((s) => s.lastSpiegelJson);
  const config = useMatrix((s) => s.config);

  let spiegelFacts = false;
  let spiegelHasGodDirective = false;
  if (lastSpiegelJson) {
    try {
      const sp = JSON.parse(lastSpiegelJson) as { facts?: unknown[]; god?: string[] };
      spiegelFacts = Array.isArray(sp.facts);
      spiegelHasGodDirective = Array.isArray(sp.god) && sp.god.some((g) => /\[(body|knowledge|relationship)\]/i.test(g));
    } catch {
      spiegelFacts = false;
    }
  }

  const live = sessions[0];
  // V67 (Audit7 V66-07; AMASTER §54 jede Produktfunktion bedienbar/prüfbar): the navigation check asks the router - every
  // target of the main navigation and of "Mehr" must be a registered route. V66 required at least 12 main entries and reported the 7
  // main entries as a failure while 10 more stand under "Mehr" (a self-test that measured nothing).
  const routes = (router as unknown as { routesByPath?: Record<string, unknown> }).routesByPath || {};
  const navTargets = [...NAV, ...NAV_MORE];
  const navMissing = navTargets.filter((n) => !routes[n.to] && !routes[`${n.to}/`]).map((n) => n.to);
  const hygiene = [
    { id: "build", ok: true, text: `Build ${BUILD_ID}` },
    {
      id: "nav",
      ok: navMissing.length === 0,
      text: `${NAV.length} + ${NAV_MORE.length} (Mehr) Navigationsziele, ${navTargets.length - navMissing.length} im Router${navMissing.length ? ` — fehlt: ${navMissing.join(", ")}` : ""}`,
    },
    { id: "welten", ok: Array.isArray(worlds), text: `Weltenstand aus SQLite: ${worlds.length} Welten (0 ist erlaubt)` },
    { id: "stamm", ok: characters.every((c) => Boolean(c.id && c.worldId)), text: `Charakterstämme: ${characters.length} (0 ist erlaubt)` },
    { id: "iso", ok: sessions.every((s) => s.userId && s.worldId), text: "Sessions an User+Welt gebunden" },
    { id: "facts-ids", ok: sessions.every((s) => s.facts.every((f) => f.id && Array.isArray(f.witnessedBy))), text: "Facts haben IDs und witnessedBy" },
    { id: "focus", ok: sessions.every((s) => s.focus !== undefined), text: "Turn-Focus vorhanden" },
    { id: "context", ok: config.contextTurns >= 1, text: `Kontext-Turns ${config.contextTurns}` },
    { id: "live-facts-reader", ok: !lastSpiegelJson || spiegelFacts, text: "Letzter Spiegel enthält Facts-Feld" },
    { id: "no-god-prompt", ok: !spiegelHasGodDirective, text: "Letzter Spiegel trägt keine God-Direktive" },
    { id: "live-runtime", ok: !live || Object.values(live.runtimes).every((r) => typeof r.pain === "number"), text: "Runtimes tragen Körperwerte" },
  ];

  const chain = chainChecks();
  const checks = [...hygiene, ...chain];

  if (!hydrated) {
    return (
      <Shell title="Diagnose">
        <p className="text-sm text-muted">Lädt…</p>
      </Shell>
    );
  }

  return (
    <Shell title="Diagnose">
      <Panel title="AMASTER Frontend ↔ Backend" className="mb-4">
        <p className="mb-2 text-xs text-muted">Jede Zeile ist eine Bedienfläche mit SQLite-Owner. BLOCKED ist bewusst leer, nicht vorgetäuscht.</p>
        <ul className="grid gap-2 sm:grid-cols-2">
          {[
            { k: "Kerninteraktion", v: "Chat → kernel prepare/commit", s: "live" },
            { k: "Welten anlegen", v: "Welten → POST /api/worlds + Figuren", s: "live" },
            { k: "Charaktere anlegen", v: "Charaktere → POST /api/characters", s: "live" },
            { k: "Session anlegen", v: "Chat/Start → POST /api/sessions + Turns", s: "live" },
            { k: "Upload A/B", v: "Upload → ingest/commit, A nur nach Review", s: "live" },
            { k: "Gedächtnis", v: "Gedächtnis → Session-Memory SQL", s: "live" },
            { k: "Beziehungen", v: "Beziehungen → relations SQL", s: "live" },
            { k: "Timeline", v: "Timeline → Facts append-only", s: "live" },
            { k: "Review/Stamm", v: "Review → resolve, kein stilles Prägen", s: "live" },
            { k: "Config/LLM", v: "Config → PUT /api/config, formulate", s: "live" },
            { k: "AutoChat/Fate/God/Regie", v: "Chat + Fate → kernel-Pfade", s: "live" },
            { k: "OCR/Realbild", v: "Tesseract.js lokal (deu). Leer = ocr_empty. Cloud gesperrt.", s: "live" },
            { k: "Dokument-IDs", v: "doc.src.v1 / doc.world.v1 / doc.upload.v1 — Kopf plus .rN, nicht überschreiben", s: "live" },
            { k: "STT", v: "nur mit Gerätemikrofon", s: "teil" },
            { k: "Kompass", v: "Charakterseite → Stammfeld", s: "live" },
          ].map((row) => (
            <li key={row.k} className="flex items-start gap-2 text-sm">
              <Chip tone={row.s === "live" ? "ok" : row.s === "blocked" ? "danger" : "warn"}>{row.s}</Chip>
              <span>
                <span className="font-medium">{row.k}</span>
                <span className="block text-[11px] text-muted">{row.v}</span>
              </span>
            </li>
          ))}
        </ul>
      </Panel>
      <Panel title="API / SQLite" className="mb-4">
        <button type="button" className="rounded-md bg-accent px-3 py-2 text-sm text-accent-fg" onClick={() => void runLoop()}>
          Health prüfen
        </button>
        <button type="button" className="ml-2 rounded-md border border-border px-3 py-2 text-sm" onClick={() => void runSystemLoop()}>
          Systemschleife
        </button>
        <button type="button" className="ml-2 rounded-md border border-border px-3 py-2 text-sm" onClick={() => void runForbiddenLogProbe()}>
          Log PUT/DELETE prüfen
        </button>
        {loopMsg ? <p className="mt-2 text-sm text-muted">{loopMsg}</p> : null}
        {systemLoopMsg ? <p className="mt-2 text-sm text-muted" data-testid="system-loop-result">{systemLoopMsg}</p> : null}
        {probeMsg ? <p className="mt-2 text-sm text-muted" data-testid="log-probe-result">{probeMsg}</p> : null}
        {chainLive ? <p className="mt-2 text-xs text-muted">{chainLive}</p> : null}
      </Panel>
      <h1 className="font-display text-2xl font-semibold">Diagnose</h1>
      <p className="mt-1 text-sm text-muted">Hygiene plus die echte Kette: Event → Zeugen → Runtime → Spiegel. Ein schöner Satz ist kein Nachweis.</p>
      <Panel className="mt-4">
        <ul className="space-y-2">
          {checks.map((c) => (
            <li key={c.id} className="flex items-center gap-2 text-sm">
              <Chip tone={c.ok ? "ok" : "danger"}>{c.ok ? "ok" : "fehl"}</Chip>
              {c.text}
            </li>
          ))}
        </ul>
      </Panel>
    </Shell>
  );
}
