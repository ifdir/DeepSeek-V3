import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { Shell, Panel, Empty } from "@/components/shell";
import { Button, Select } from "@/components/ui";
import { useMatrix } from "@/lib/matrix/store";
import { useHydrated } from "@/lib/matrix/use-hydrated";
import { apiListGraph, apiListAppointments } from "@/lib/matrix/api";

export const Route = createFileRoute("/social")({ component: SocialPage });

function SocialPage() {
  const hydrated = useHydrated();
  const sessions = useMatrix((s) => s.sessions);
  const characters = useMatrix((s) => s.characters);
  const addRelation = useMatrix((s) => s.addRelation);
  const [sessionId, setSessionId] = useState("");
  const [fromId, setFromId] = useState("");
  const [toId, setToId] = useState("");
  const [kind, setKind] = useState("trust");
  const [graphInfo, setGraphInfo] = useState("");
  const [edges, setEdges] = useState<Array<{ fromId?: string; toId?: string; kind?: string }>>([]);
  const session = sessions.find((s) => s.id === sessionId) ?? sessions[0];
  const name = (id: string) => characters.find((c) => c.id === id)?.name ?? id;
  const rels = (session?.relations ?? []).filter((r) => !fromId || r.fromId === fromId);
  const stamm = characters.filter((c) => !session || c.worldId === session.worldId);

  async function reloadGraph(sid?: string) {
    const id = sid || session?.id;
    if (!id) return;
    try {
      const [g, a] = await Promise.all([apiListGraph(id), apiListAppointments(id)]);
      const e = (g.edges as Array<{ fromId?: string; toId?: string; kind?: string }>) || [];
      const apts = (a.appointments as unknown[]) || [];
      setEdges(e);
      setGraphInfo(`Graph ${e.length} · Termine ${apts.length}`);
    } catch (e) {
      setGraphInfo(e instanceof Error ? e.message : "Graph/Termine nicht lesbar");
    }
  }

  useEffect(() => {
    void reloadGraph(session?.id);
  }, [session?.id]);

  if (!hydrated) {
    return (
      <Shell title="Beziehungen">
        <p className="text-sm text-muted">Lädt…</p>
      </Shell>
    );
  }

  return (
    <Shell title="Beziehungen">
      <h1 className="font-display text-2xl font-semibold">Beziehungen</h1>
      {graphInfo ? <p className="text-sm text-muted">{graphInfo}</p> : null}
      <p className="mt-1 text-sm text-muted">Stamm-Ausgang, gerichtete Sessionbeziehung und Evidenz. Mara nach Alrik ist nicht Alrik nach Mara.</p>
      <div className="mt-4 grid gap-2 sm:grid-cols-2">
        <Select value={session?.id ?? ""} onChange={(e) => setSessionId(e.target.value)}>
          {sessions.map((s) => (
            <option key={s.id} value={s.id}>
              {s.name}
            </option>
          ))}
        </Select>
        <Select value={fromId} onChange={(e) => setFromId(e.target.value)}>
          <option value="">von allen</option>
          {stamm.map((c) => (
            <option key={c.id} value={c.id}>
              {c.name}
            </option>
          ))}
        </Select>
      </div>
      {session ? (
        <Panel className="mt-4" title="Kante schreiben">
          <div className="grid gap-2 sm:grid-cols-4">
            <Select value={fromId} onChange={(e) => setFromId(e.target.value)}>
              <option value="">von</option>
              {stamm.map((c) => (
                <option key={c.id} value={c.id}>
                  {c.name}
                </option>
              ))}
            </Select>
            <Select value={toId} onChange={(e) => setToId(e.target.value)}>
              <option value="">zu</option>
              {stamm.map((c) => (
                <option key={c.id} value={c.id}>
                  {c.name}
                </option>
              ))}
            </Select>
            <Select value={kind} onChange={(e) => setKind(e.target.value)}>
              {["trust", "fear", "hostility", "related", "debt"].map((k) => (
                <option key={k}>{k}</option>
              ))}
            </Select>
            <Button
              className="min-h-9 text-xs"
              onClick={() => {
                if (!fromId || !toId || fromId === toId) return;
                addRelation(session.id, {
                  fromId,
                  toId,
                  trust: kind === "trust" ? 0.7 : 0.4,
                  closeness: 0.3,
                  fear: kind === "fear" ? 0.6 : 0.1,
                  hostility: kind === "hostility" ? 0.6 : 0,
                  note: kind,
                  kind,
                });
                void reloadGraph(session.id);
              }}
            >
              Graph speichern
            </Button>
          </div>
        </Panel>
      ) : null}
      <div className="mt-4 grid gap-4 lg:grid-cols-3">
        <Panel title="Session, gerichtet">
          {rels.length === 0 ? <Empty>Keine.</Empty> : null}
          <ul className="space-y-2 text-sm">
            {rels.map((r, i) => (
              <li key={`${r.fromId}-${r.toId}-${i}`}>
                {name(r.fromId)} → {name(r.toId)}
                <p className="text-xs text-muted">
                  Trust {r.trust.toFixed(2)} · Nähe {r.closeness.toFixed(2)} · Angst {r.fear.toFixed(2)}
                </p>
              </li>
            ))}
          </ul>
        </Panel>
        <Panel title="Graph-Kanten (SQLite)">
          {edges.length === 0 ? <Empty>Keine Kanten.</Empty> : null}
          <ul className="space-y-1 text-sm">
            {edges.map((e, i) => (
              <li key={`${e.fromId}-${e.toId}-${i}`}>
                {name(String(e.fromId))} → {name(String(e.toId))}
                <span className="text-xs text-muted"> · {e.kind}</span>
              </li>
            ))}
          </ul>
        </Panel>
        <Panel title="Stamm-Ausgang">
          <ul className="space-y-2 text-sm">
            {stamm.flatMap((c) =>
              c.relations
                .filter((r) => !fromId || c.id === fromId)
                .map((r, i) => (
                  <li key={`${c.id}-${i}`}>
                    {c.name} → {r.targetName}
                    <p className="text-xs text-muted">{r.kind}</p>
                  </li>
                )),
            )}
          </ul>
        </Panel>
      </div>
      {session ? (
        <div className="mt-4 grid gap-4 lg:grid-cols-2">
          <Panel title="Abgeleitete Social-Werte">
            <ul className="space-y-1 text-sm">
              {rels.map((r) => (
                <li key={`d-${r.fromId}-${r.toId}`}>
                  {name(r.fromId)} → {name(r.toId)} · Bond {(r.trust * 0.6 + r.closeness * 0.4).toFixed(2)} · Risiko{" "}
                  {(r.fear * 0.5 + r.hostility * 0.5).toFixed(2)}
                </li>
              ))}
            </ul>
          </Panel>
          <Panel title="Quellereignisse / Änderungshistorie / bearbeitete Schicht">
            <p className="text-xs text-muted">
              Graph-Kanten tragen sourceTurnId wenn aus einem Turn. Session-Schicht ist bearbeitet, Stamm bleibt Ausgang.
            </p>
            <ul className="mt-2 space-y-1 text-sm">
              {edges.map((e, i) => (
                <li key={`src-${i}`}>
                  {name(String(e.fromId))} → {name(String(e.toId))} · Schicht session
                  {"sourceTurnId" in e && e.sourceTurnId ? ` · Turn ${String(e.sourceTurnId)}` : " · manuell"}
                </li>
              ))}
            </ul>
          </Panel>
        </div>
      ) : null}
    </Shell>
  );
}