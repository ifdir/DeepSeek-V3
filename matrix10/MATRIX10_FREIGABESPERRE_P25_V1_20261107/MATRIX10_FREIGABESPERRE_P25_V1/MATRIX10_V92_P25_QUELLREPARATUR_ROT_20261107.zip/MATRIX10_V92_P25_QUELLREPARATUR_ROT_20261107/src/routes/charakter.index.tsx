import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useState } from "react";
import { Shell, Panel, Empty } from "@/components/shell";
import { Button, Chip, Input, Select } from "@/components/ui";
import { uid } from "@/lib/matrix/ids";
import { emptyCharacter } from "@/lib/matrix/normalize";
import { makeOutsiderAvatar } from "@/lib/matrix/seed-gasthaus";
import { useMatrix } from "@/lib/matrix/store";
import { useHydrated } from "@/lib/matrix/use-hydrated";
import { useSelectableWorlds, useSelectableCharacters } from "@/lib/matrix/use-selectable";
import type { StammCharacter } from "@/lib/matrix/types";

export const Route = createFileRoute("/charakter/")({ component: CharakterList });

function CharakterList() {
  const nav = useNavigate();
  const hydrated = useHydrated();
  const worlds = useSelectableWorlds();
  const characters = useSelectableCharacters();
  const addCharacter = useMatrix((s) => s.addCharacter);
  const deleteCharacter = useMatrix((s) => s.deleteCharacter);
  const patchCharacter = useMatrix((s) => s.patchCharacter);
  const [worldFilter, setWorldFilter] = useState("");
  const [name, setName] = useState("");
  const [asAvatar, setAsAvatar] = useState(false);
  const [err, setErr] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);
  const [deletingId, setDeletingId] = useState<string | null>(null);

  const list = characters.filter((c) => !worldFilter || c.worldId === worldFilter);

  async function persistFigure(c: StammCharacter) {
    setBusy(true);
    setErr(null);
    const ok = await addCharacter(c);
    setBusy(false);
    if (!ok) {
      const fail = useMatrix.getState().logs.find((l) => l.code === "PERSIST_FAILED");
      setErr(fail?.message || "Figur konnte nicht gespeichert werden.");
      return;
    }
    setName("");
    nav({ href: `/charakter/${c.id}` });
  }

  function createStamm() {
    const w = worldFilter || worlds[0]?.id;
    if (!w || !name.trim()) {
      setErr("Name und Welt nötig.");
      return;
    }
    void persistFigure({ ...emptyCharacter(w, name.trim()), canBeAvatar: asAvatar });
  }

  async function removeFigure(id: string, name: string) {
    if (deletingId || !confirm(`Figur ${name} wirklich löschen?\nDie Figur und ihre zugeordneten Erinnerungen, Ereignisse und Gesprächsdaten werden endgültig gelöscht. Andere Figuren bleiben erhalten.`)) return;
    setDeletingId(id);
    setErr(null);
    try {
      const ok = await deleteCharacter(id);
      if (!ok) {
        const fail = useMatrix.getState().logs.find((l) => l.code === "PERSIST_FAILED");
        setErr(fail?.message || "Figur wurde nicht gelöscht.");
      }
    } finally { setDeletingId(null); }
  }

  function createAvatar() {
    const w = worldFilter || worlds[0]?.id;
    if (!w || !name.trim()) {
      setErr("Name und Welt nötig.");
      return;
    }
    const c: StammCharacter = {
      ...makeOutsiderAvatar(name.trim()),
      id: uid("av"),
      worldId: w,
      canBeAvatar: true,
    };
    void persistFigure(c);
  }

  if (!hydrated) {
    return (
      <Shell title="Charaktere">
        <p className="text-sm text-muted">Lädt…</p>
      </Shell>
    );
  }

  return (
    <Shell title="Charaktere">
      <h1 className="font-display text-2xl font-semibold">Charakterstämme und Avatare</h1>
      <p className="mt-1 text-sm text-muted">
        Stamm ist dauerhaft weltzugehörig. Ein Avatar ist eine eigene Figur, die du steuerst — nicht das Userprofil.
      </p>
      <div className="mt-4 flex flex-col gap-2 sm:flex-row sm:flex-wrap">
        <Select name="worldFilter" aria-label="Weltfilter" value={worldFilter} onChange={(e) => setWorldFilter(e.target.value)}>
          <option value="">Alle Welten</option>
          {worlds.map((w) => (
            <option key={w.id} value={w.id}>
              {w.name}
            </option>
          ))}
        </Select>
        <Input value={name} onChange={(e) => setName(e.target.value)} placeholder="Neuer Stamm — Name" />
        <label className="inline-flex min-h-11 cursor-pointer items-center gap-2 rounded-[12px] border border-border bg-elevated px-3 text-sm">
          <input type="checkbox" checked={asAvatar} onChange={(e) => setAsAvatar(e.target.checked)} />
          Stamm als Avatar verwendbar
        </label>
        <Button onClick={createStamm} disabled={busy}>
          Stamm anlegen
        </Button>
        <Button variant="ok" onClick={createAvatar} disabled={busy}>
          Avatar anlegen
        </Button>
        <label className="inline-flex min-h-11 cursor-pointer items-center rounded-[12px] border border-border bg-elevated px-4 text-sm">
          Packung importieren
          <input
            type="file"
            accept="application/json"
            className="hidden"
            onChange={(e) => {
              const f = e.target.files?.[0];
              if (!f) return;
              void f.text().then((raw) => {
                try {
                  const pack = JSON.parse(raw) as { kind?: string; character?: StammCharacter };
                  if (pack.kind !== "matrix10-character-pack" || !pack.character) return;
                  const w = worldFilter || pack.character.worldId || worlds[0]?.id;
                  if (!w) return;
                  void persistFigure({ ...emptyCharacter(w, pack.character.name), ...pack.character, worldId: w, id: uid("char") });
                } catch {
                  setErr("Packung ungültig.");
                }
              });
            }}
          />
        </label>
      </div>
      {err ? <p className="mt-2 text-sm text-danger">{err}</p> : null}
      <Panel className="mt-5">
        {list.length === 0 ? <Empty>Keine Figuren in diesem Filter.</Empty> : null}
        <ul className="grid gap-2 sm:grid-cols-2">
          {list.map((c) => (
            <li key={c.id} className="rounded-[12px] border border-border bg-bg p-3">
              <p className="font-medium">{c.name}</p>
              <p className="text-xs text-muted">{c.role}</p>
              <p className="mt-1 text-[11px] text-faint">{worlds.find((w) => w.id === c.worldId)?.name}</p>
              <div className="mt-1 flex flex-wrap gap-1">
                <Chip>{c.status}</Chip>
                {c.isWorldNative ? <Chip>Stamm</Chip> : <Chip hot>Avatar</Chip>}
                {c.canBeAvatar || !c.isWorldNative ? <Chip>steuerbar</Chip> : null}
              </div>
              <div className="mt-2 flex flex-wrap gap-2">
                <Button variant="line" className="min-h-9 text-xs" onClick={() => nav({ href: `/charakter/${c.id}` })}>
                  Öffnen
                </Button>
                {c.isWorldNative && !c.canBeAvatar ? (
                  <Button variant="ok" className="min-h-9 text-xs" onClick={() => patchCharacter(c.id, { canBeAvatar: true })}>
                    Als Avatar freigeben
                  </Button>
                ) : null}
                <Button variant="danger" className="min-h-9 text-xs" disabled={!!deletingId} onClick={() => void removeFigure(c.id, c.name)}>
                  {deletingId === c.id ? "Löscht…" : "Löschen"}
                </Button>
              </div>
            </li>
          ))}
        </ul>
      </Panel>
    </Shell>
  );
}
