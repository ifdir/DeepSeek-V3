import { createFileRoute, Link } from "@tanstack/react-router";
import { useState } from "react";
import { Shell, Panel } from "@/components/shell";
import { Select, Switch } from "@/components/ui";
import { useMatrix } from "@/lib/matrix/store";
import { useHydrated } from "@/lib/matrix/use-hydrated";
import { kernelFate } from "@/lib/matrix/kernel-bridge";

export const Route = createFileRoute("/fate")({ component: FatePage });

function FatePage() {
  const hydrated = useHydrated();
  const sessions = useMatrix((s) => s.sessions);
  const worlds = useMatrix((s) => s.worlds);
  const acceptKernelSession = useMatrix((s) => s.acceptKernelSession);
  const log = useMatrix((s) => s.log);
  const [sessionId, setSessionId] = useState("");
  const s = sessions.find((x) => x.id === sessionId) ?? sessions[0];
  const w = worlds.find((x) => x.id === s?.worldId);

  if (!hydrated) {
    return (
      <Shell title="Fate">
        <p className="text-sm text-muted">Lädt…</p>
      </Shell>
    );
  }

  return (
    <Shell title="Fate">
      <h1 className="font-display text-2xl font-semibold">Fate</h1>
      <p className="mt-1 text-sm text-muted">Druck und Beat — nie Figurensprache, kein Wahrheitsmaster. Schalter schreibt die Session.</p>
      <div className="mt-4">
        <Select value={s?.id ?? ""} onChange={(e) => setSessionId(e.target.value)}>
          <option value="">Session</option>
          {sessions.map((x) => (
            <option key={x.id} value={x.id}>
              {x.name}
            </option>
          ))}
        </Select>
      </div>
      <Panel className="mt-4" title={s ? s.name : "Keine Session"}>
        {s ? (
          <div className="space-y-3 text-sm">
            <Switch
              checked={s.pipeline.fate && s.fate.enabled}
              onChange={(v) => {
                void kernelFate({ session: s, enabled: v }).then(({ session: next, trace }) => {
                  acceptKernelSession(next);
                  log({
                    level: "info",
                    code: "KERNEL_WRITE",
                    message: `${trace.writePath} fate=${v}`,
                    sessionId: next.id,
                  });
                });
              }}
              label="Fate in dieser Session"
            />
            <p>Druck: {s.fate.pressure.toFixed(2)}</p>
            <p>Beat: {s.fate.beat || "—"}</p>
            <p>Pipeline Fate: {s.pipeline.fate ? "an" : "aus"}</p>
            <p className="text-xs text-muted">Samen der Welt (kanonisch auf der Weltseite):</p>
            <ul className="list-disc pl-5 text-xs text-muted">
              {(w?.fateSeeds ?? []).map((f) => (
                <li key={f.id}>
                  {f.title} — {f.beat} {f.mustNot ? `· darf nicht: ${f.mustNot}` : ""}
                </li>
              ))}
            </ul>
            {w ? (
              <Link to="/welt/$worldId" params={{ worldId: w.id }} className="text-accent">
                Seeds auf der Weltseite bearbeiten
              </Link>
            ) : null}
          </div>
        ) : (
          <p className="text-sm text-muted">
            Erst eine Session öffnen. <Link to="/chat">Zum Chat</Link>
          </p>
        )}
      </Panel>
    </Shell>
  );
}
