import { createFileRoute } from "@tanstack/react-router";
import { confirmReset } from "@/lib/matrix/confirm-reset";
import { useEffect, useState } from "react";
import { Shell, Panel, Empty } from "@/components/shell";
import { Button, Chip, Select, Textarea } from "@/components/ui";
import { extractTextFromFile } from "@/lib/matrix/epub";
import { textFromUpload } from "@/lib/matrix/ocr";
import { uid } from "@/lib/matrix/ids";
import { useMatrix } from "@/lib/matrix/store";
import { useHydrated } from "@/lib/matrix/use-hydrated";
import { useSelectableWorlds, useSelectableCharacters } from "@/lib/matrix/use-selectable";
import type { UploadMode } from "@/lib/matrix/types";
import { persistVersionedDocument } from "@/lib/matrix/source-docs";
import { uploadDocId } from "@/lib/matrix/epub";
import { apiAnalyzeLocal, apiDeleteDocument, apiListDocuments, apiPatchDocument, apiSearchLocal } from "@/lib/matrix/api";
import { downloadJson } from "@/lib/matrix/normalize";

export const Route = createFileRoute("/upload")({ component: UploadPage });

type KnowledgeDoc = {
  id?: string;
  title?: string;
  name?: string;
  ocrStatus?: string;
  text?: string;
  mime?: string;
  uploadId?: string;
  articleNo?: string;
  documentGroup?: string;
  rev?: number;
  schema?: number;
  previousId?: string;
};

function UploadPage() {
  const hydrated = useHydrated();
  const worlds = useSelectableWorlds();
  const characters = useSelectableCharacters();
  const sessions = useMatrix((s) => s.sessions);
  const uploads = useMatrix((s) => s.uploads);
  const addUpload = useMatrix((s) => s.addUpload);
  const commitUpload = useMatrix((s) => s.commitUpload);
  const deleteUpload = useMatrix((s) => s.deleteUpload);
  const patchUpload = useMatrix((s) => s.patchUpload);
  const activeUserId = useMatrix((s) => s.activeUserId);
  const [mode, setMode] = useState<UploadMode>("B");
  const [targetKind, setTargetKind] = useState<"world" | "character" | "session" | "scene">("session");
  const [targetId, setTargetId] = useState("");
  const [note, setNote] = useState("");
  const [docGroup, setDocGroup] = useState("");
  const [sessionBindId, setSessionBindId] = useState("");
  const [sourceId, setSourceId] = useState("");
  const [err, setErr] = useState<string | null>(null);
  const [q, setQ] = useState("");
  const [hits, setHits] = useState("");
  const [docs, setDocs] = useState<KnowledgeDoc[]>([]);
  const [analysis, setAnalysis] = useState("");
  const reviews = useMatrix((s) => s.reviews);
  const resolveReview = useMatrix((s) => s.resolveReview);
  const users = useMatrix((s) => s.users);
  const active = users.find((u) => u.id === activeUserId);
  const [paste, setPaste] = useState("");
  const [busy, setBusy] = useState(false);

  useEffect(() => {
    if (mode !== "B") return;
    if (targetId) return;
    const sid =
      (active?.lastSessionId && sessions.some((s) => s.id === active.lastSessionId) ? active.lastSessionId : "") ||
      sessions.find((s) => s.userId === activeUserId)?.id ||
      "";
    if (!sid) return;
    setTargetKind("session");
    setTargetId(sid);
    setSessionBindId(sid);
  }, [mode, active?.lastSessionId, activeUserId, sessions, targetId]);

  async function reloadDocs() {
    try {
      const r = await apiListDocuments();
      setDocs(((r.documents as KnowledgeDoc[]) || []).slice());
    } catch (e) {
      setDocs([]);
      setErr(e instanceof Error ? e.message : "Dokumente nicht lesbar");
    }
  }

  useEffect(() => {
    void reloadDocs();
  }, []);

  async function persistUpload(opts: { name: string; mime: string; text: string; status?: "ready" | "ocr_empty" | "error" }) {
    if (!activeUserId) {
      setErr("Kein aktiver User.");
      return false;
    }
    if (mode === "A" && !targetId) {
      setErr("Mode A ohne Ziel prägt nichts.");
      return false;
    }
    if (mode === "A" && (targetKind === "session" || targetKind === "scene")) {
      setErr("Mode A nur für Welt oder Charakterstamm. Session/Scene haben keinen dauerhaften Mode-A-Owner.");
      return false;
    }
    if (mode === "B") {
      const sid = sessionBindId || (targetKind === "session" || targetKind === "scene" ? targetId : "");
      if (!sid) {
        setErr("Mode B ist sessionbezogen — zuerst eine Session wählen oder unter Chat anlegen.");
        return false;
      }
    }
    const provisionalUploadId = uid("up");
    const worldId =
      targetKind === "world"
        ? targetId
        : targetKind === "character"
          ? characters.find((c) => c.id === targetId)?.worldId
          : sessions.find((s) => s.id === targetId)?.worldId;
    const sessionId = sessionBindId || (targetKind === "session" || targetKind === "scene" ? targetId : undefined);
    setBusy(true);
    const upload = {
      id: provisionalUploadId,
      name: opts.name,
      mime: opts.mime,
      text: opts.text.slice(0, 40000),
      mode,
      targetKind,
      targetId,
      worldId,
      sessionId,
      characterId: targetKind === "character" ? targetId : undefined,
      note,
      committed: false,
      status: opts.status || "ready",
      createdAt: new Date().toISOString(),
      userId: activeUserId,
    };
    const ok = await addUpload(upload);
    setBusy(false);
    if (!ok) {
      const fail = useMatrix.getState().logs.find((l) => l.code === "PERSIST_FAILED");
      setErr(fail?.message || "Upload nicht gespeichert.");
      return false;
    }
    if (opts.text.trim()) {
      try {
        await persistVersionedDocument({
          id: uploadDocId(opts.name, targetKind, targetId),
          uploadId: upload.id,
          name: opts.name,
          title: opts.name,
          text: opts.text.slice(0, 20000),
          ocrStatus: opts.status || "ready",
          mime: opts.mime,
          mode,
          targetKind,
          targetId,
          documentGroup: docGroup || undefined,
          docKind: "upload",
          schema: 1,
        });
        await reloadDocs();
      } catch (e) {
        setErr(e instanceof Error ? e.message : "Dokument nicht geschrieben");
      }
    }
    return true;
  }

  async function onFile(file: File) {
    setErr(null);
    const extracted = await extractTextFromFile(file);
    const ocr = await textFromUpload({ text: extracted.text, dataUrl: extracted.dataUrl, file });
    const text = ocr.text;
    const status: "ready" | "ocr_empty" | "error" = ocr.status === "ocr_empty" ? "ocr_empty" : "ready";
    if (status === "ocr_empty") {
      setErr(ocr.error ? `OCR leer (${ocr.engine}) — ${ocr.error}` : "OCR leer — Commit gesperrt bis Text vorliegt. Kein erfundener Text.");
    }
    const ok = await persistUpload({ name: file.name || extracted.title, mime: file.type || "text/plain", text, status });
    if (ok && status === "ocr_empty") setErr("OCR leer — Commit gesperrt bis Text vorliegt.");
  }

  if (!hydrated) {
    return (
      <Shell title="Upload">
        <p className="text-sm text-muted">Lädt…</p>
      </Shell>
    );
  }

  const targets =
    targetKind === "world"
      ? worlds.map((w) => ({ id: w.id, name: w.name }))
      : targetKind === "character"
        ? characters.map((c) => ({ id: c.id, name: `${c.name}${c.isWorldNative ? "" : " (Avatar)"}` }))
        : targetKind === "scene"
          ? sessions.map((s) => ({ id: s.id, name: `${s.name} · Szene ${s.scene.placeName}` }))
          : sessions.map((s) => ({ id: s.id, name: s.name }));

  return (
    <Shell title="Upload">
      <h1 className="font-display text-2xl font-semibold">Upload-Center</h1>
      <p className="mt-1 text-sm text-muted">A prägt nur das gewählte Ziel nach Commit. B ist Beobachtung oder Referenz — ein Krimi macht niemanden zum Täter. Mode B folgt Hören/Sehen der Chat-Szene: ausdrücklich „Niemand hört“ bleibt leer.</p>
      <Panel className="mt-4">
        <div className="flex flex-wrap gap-2">
          <Button variant={mode === "A" ? "primary" : "line"} onClick={() => {
            setMode("A");
            if (targetKind === "session" || targetKind === "scene") {
              setTargetKind("world");
              setTargetId("");
            }
          }}>
            A · Prägung
          </Button>
          <Button variant={mode === "B" ? "primary" : "line"} onClick={() => setMode("B")}>
            B · Beobachtung
          </Button>
        </div>
        <div className="mt-3 grid gap-2 sm:grid-cols-2">
          <Select
            name="targetKind"
            aria-label="Upload-Zielart"
            value={targetKind}
            onChange={(e) => {
              setTargetKind(e.target.value as typeof targetKind);
              setTargetId("");
            }}
          >
            {mode === "B" ? (
              <>
                <option value="session">Session</option>
                <option value="scene">Scene</option>
              </>
            ) : null}
            <option value="character">Charakterstamm</option>
            <option value="world">Welt</option>
          </Select>
          <Select name="targetId" aria-label="Upload-Ziel" value={targetId} onChange={(e) => setTargetId(e.target.value)}>
            <option value="">Ziel wählen</option>
            {targets.map((t) => (
              <option key={t.id} value={t.id}>
                {t.name}
              </option>
            ))}
          </Select>
        </div>
        {mode === "B" && targetKind === "character" ? (
          <Select className="mt-2" value={sessionBindId} onChange={(e) => setSessionBindId(e.target.value)}>
            <option value="">Session für Mode-B-Wissen ausdrücklich wählen</option>
            {sessions
              .filter((s) => s.worldId === (characters.find((c) => c.id === targetId)?.worldId || s.worldId))
              .map((s) => (
                <option key={s.id} value={s.id}>
                  {s.name}
                </option>
              ))}
          </Select>
        ) : null}
        <Textarea className="mt-2" rows={2} value={note} onChange={(e) => setNote(e.target.value)} placeholder="Hinweis / Bezug" />
        <input className="mt-2 min-h-9 w-full rounded-md border border-border bg-elevated px-2 text-sm" value={docGroup} onChange={(e) => setDocGroup(e.target.value)} placeholder="Dokumentgruppe (optional)" />
        {sessions.length === 0 ? (
          <p className="mt-2 text-sm text-danger">Keine Session — Upload ist standardmäßig sessionbezogen. Zuerst unter Chat eine Session anlegen.</p>
        ) : null}
        <label className="mt-3 flex min-h-16 cursor-pointer flex-col items-center justify-center rounded-[12px] border border-dashed border-border px-3 py-4 text-sm text-muted">
          Datei auswählen (Text, PDF, Bild, EPUB, JSON)
          <input
            type="file"
            className="mt-2"
            onChange={(e) => {
              const f = e.target.files?.[0];
              if (f) void onFile(f);
            }}
          />
        </label>
        <p className="mt-2 text-xs text-muted">Bild ohne eingebetteten Text: Tesseract.js (Deutsch) im Gerät. Leer bleibt leer. Cloud-OCR gesperrt.</p>
        <Textarea
          className="mt-3"
          rows={4}
          value={paste}
          onChange={(e) => setPaste(e.target.value)}
          placeholder="Oder Text hier einfügen — Charakterbeschreibung, Welttext, Szene, Referenz"
        />
        <Button
          className="mt-2"
          disabled={busy || !paste.trim()}
          onClick={() => {
            const t = paste.trim();
            if (!t) return;
            setErr(null);
            void persistUpload({ name: "einfuegen.txt", mime: "text/plain", text: t }).then((ok) => {
              if (ok) setPaste("");
            });
          }}
        >
          {busy ? "Speichert…" : "Text als Upload speichern"}
        </Button>
        {err ? <p className="mt-2 text-sm text-danger">{err}</p> : null}
        <div className="mt-3 flex flex-wrap gap-2">
          <input className="min-h-9 flex-1 rounded-md border border-border bg-elevated px-2 text-sm" value={q} onChange={(e) => setQ(e.target.value)} placeholder="Dokument/Welt suchen" />
          <Button
            variant="line"
            className="min-h-9 text-xs"
            onClick={async () => {
              const r = await apiSearchLocal(q);
              const list = ((r.hits as { kind?: string; id?: string; match?: string; score?: number }[]) || [])
                .map((h) => `${h.kind}:${h.id}${h.match ? `(${h.match})` : ""}`)
                .join(" · ");
              setHits(list || "keine Treffer");
            }}
          >
            Suchen
          </Button>
        </div>
        {hits ? <p className="mt-2 text-xs text-muted">{hits}</p> : null}
        <div className="mt-3">
          <p className="mb-1 text-[11px] uppercase tracking-wide text-muted">Analysequelle</p>
          <Select
            className="mb-2"
            value={sourceId}
            onChange={(e) => setSourceId(e.target.value)}
          >
            <option value="">Quelle wählen (Upload, Dokument oder Hinweis)</option>
            {uploads.map((u) => (
              <option key={u.id} value={`up:${u.id}`}>
                Upload · {u.name}
              </option>
            ))}
            {docs.map((d) => (
              <option key={String(d.id)} value={`doc:${d.id}`}>
                Dokument · {d.title || d.name || d.id}
              </option>
            ))}
          </Select>
          <Button
            variant="line"
            className="min-h-9 text-xs"
            onClick={async () => {
              const selectedUpload = sourceId.startsWith("up:") ? uploads.find((u) => u.id === sourceId.slice(3)) : undefined;
              const selectedDoc = sourceId.startsWith("doc:") ? docs.find((d) => String(d.id) === sourceId.slice(4)) : undefined;
              const src = selectedUpload?.text || selectedDoc?.text || note || "";
              const worldForAnalysis =
                (targetKind === "world" ? targetId : undefined) ||
                selectedUpload?.worldId ||
                (targetKind === "character" ? characters.find((c) => c.id === targetId)?.worldId : undefined) ||
                sessions.find((s) => s.id === targetId)?.worldId;
              if (!src.trim()) {
                setAnalysis("Kein Text für Analyse. Quelle und Zielwelt wählen.");
                return;
              }
              try {
                const r = await apiAnalyzeLocal(src, worldForAnalysis, selectedUpload?.name || selectedDoc?.name);
                if (r.ok === false) {
                  setAnalysis(`Analyse fehlgeschlagen: ${String(r.error || "parse_failed")}`);
                  return;
                }
                const world = (r.world as Record<string, unknown>) || {};
                const fields = Object.entries(world)
                  .filter(([, v]) => (Array.isArray(v) ? v.length : v))
                  .map(([k]) => k)
                  .join(", ");
                const rec = r.recognize === "llm" ? "Original gelesen" : "lokal";
                setAnalysis(`Erkennung ${rec}. Felder: ${fields || "—"}\n${JSON.stringify(r).slice(0, 1200)}`);
              } catch (e) {
                setAnalysis(e instanceof Error ? e.message : "Analyse fehlgeschlagen");
              }
            }}
          >
            Quelle analysieren
          </Button>
          {analysis ? <p className="mt-2 whitespace-pre-wrap text-xs text-muted">{analysis}</p> : null}
        </div>
      </Panel>
      <Panel className="mt-4" title="Preview / Review / Commit">
        <p className="mb-2 text-xs text-muted">
          Mode B: Anwesende erhalten Wissen nach Commit. Mode A: nur Review, dann Annehmen — kein stilles Prägen.
        </p>
        {uploads.filter((u) => !u.committed).slice(0, 3).map((u) => (
          <div key={`prev-${u.id}`} className="mb-2 rounded-[12px] border border-border bg-bg p-3 text-sm">
            <p className="font-medium">{u.name} · {u.mode}</p>
            <p className="mt-1 text-xs text-muted whitespace-pre-wrap">{(u.text || u.note || "kein Text").slice(0, 400)}</p>
          </div>
        ))}
        {reviews.length === 0 ? <Empty>Keine offenen Reviews (Mode B erzeugt keine Stamm-Reviews).</Empty> : null}
        <ul className="space-y-2">
          {reviews.slice(0, 8).map((r) => (
            <li key={r.id} className="rounded-[12px] border border-border bg-bg px-3 py-2 text-sm">
              {r.kind} · {r.status}
              {r.status === "open" ? (
                <Button className="ml-2 min-h-8 px-2 text-xs" onClick={() => resolveReview(r.id, "accepted")}>
                  Annehmen
                </Button>
              ) : null}
            </li>
          ))}
        </ul>
      </Panel>
      <Panel className="mt-4" title="Knowledge Base">
        {docs.length === 0 ? <Empty>Keine Dokumente in SQLite.</Empty> : null}
        <ul className="space-y-2">
          {docs.map((d) => (
            <li key={String(d.id)} className="rounded-[12px] border border-border bg-bg p-3 text-sm">
              <div className="flex flex-wrap items-center gap-2">
                <span>{d.title || d.name || d.id}</span>
                <Chip tone={d.ocrStatus === "ready" ? "ok" : "warn"}>{d.ocrStatus || "offen"}</Chip>
                {d.schema ? <Chip>v{d.schema}</Chip> : null}
                {d.rev ? <Chip>r{d.rev}</Chip> : null}
                {d.id ? <Chip>{String(d.id)}</Chip> : null}
                {d.articleNo ? <Chip>{d.articleNo}</Chip> : null}
                {d.documentGroup ? <Chip>{d.documentGroup}</Chip> : null}
                {d.id ? (
                  <input
                    className="min-h-8 w-36 rounded-md border border-border bg-elevated px-2 text-xs"
                    defaultValue={d.documentGroup || ""}
                    placeholder="Gruppe"
                    onBlur={async (e) => {
                      const v = e.target.value.trim();
                      if (v === (d.documentGroup || "")) return;
                      await apiPatchDocument(String(d.id), { documentGroup: v });
                      void reloadDocs();
                    }}
                  />
                ) : null}
                {d.id ? (
                  <Button
                    variant="danger"
                    className="min-h-8 px-2 text-xs"
                    onClick={async () => {
                      await apiDeleteDocument(String(d.id));
                      void reloadDocs();
                    }}
                  >
                    Löschen
                  </Button>
                ) : null}
              </div>
              <p className="mt-1 text-xs text-muted">{(d.text || "").slice(0, 160) || "kein Text"}</p>
            </li>
          ))}
        </ul>
        <Button variant="line" className="mt-2 min-h-9 text-xs" onClick={() => void reloadDocs()}>
          Reader neu laden
        </Button>
        <Button
          variant="line"
          className="ml-2 mt-2 min-h-9 text-xs"
          onClick={() => downloadJson("dokumentexport.json", { kind: "matrix10-document-export", documents: docs })}
        >
          Dokumentexport
        </Button>
      </Panel>
      <Panel className="mt-4" title="Bestand">
        {uploads.length === 0 ? <Empty>Keine Uploads.</Empty> : null}
        <ul className="space-y-2">
          {uploads.map((u) => (
            <li key={u.id} className="rounded-[12px] border border-border bg-bg p-3 text-sm">
              <div className="flex flex-wrap items-center gap-2">
                <span>{u.name}</span>
                <Chip>{u.mode}</Chip>
                <Chip tone={u.committed ? "ok" : "warn"}>{u.status}</Chip>
              </div>
              <p className="mt-1 text-xs text-muted">
                {u.targetKind} · {u.targetId || "kein Ziel"}
                {u.error ? ` · ${u.error}` : ""}
              </p>
              <p className="mt-1 text-xs text-faint whitespace-pre-wrap">{(u.text || "").slice(0, 180)}</p>
              <input
                className="mt-2 min-h-8 w-full rounded-md border border-border bg-elevated px-2 text-xs"
                defaultValue={u.note}
                placeholder="Hinweis ändern (PATCH)"
                onBlur={(e) => {
                  const v = e.target.value;
                  if (v === u.note) return;
                  patchUpload(u.id, { note: v });
                }}
              />
              <div className="mt-2 flex gap-2">
                {!u.committed ? (
                  <Button
                    className="min-h-9 text-xs"
                    onClick={() => {
                      void commitUpload(u.id).then((ok) => {
                        if (!ok) setErr("Commit fehlgeschlagen — siehe Fehlerbanner.");
                      });
                    }}
                  >
                    Commit
                  </Button>
                ) : u.mode === "B" ? (
                  <Button
                    variant="line"
                    className="min-h-9 text-xs"
                    onClick={() => {
                      void commitUpload(u.id);
                    }}
                  >
                    Wissen nachziehen
                  </Button>
                ) : null}
                <Button variant="danger" className="min-h-9 text-xs" onClick={() => confirmReset("upload-delete", u.name) && deleteUpload(u.id)}>
                  Löschen
                </Button>
              </div>
            </li>
          ))}
        </ul>
      </Panel>
    </Shell>
  );
}