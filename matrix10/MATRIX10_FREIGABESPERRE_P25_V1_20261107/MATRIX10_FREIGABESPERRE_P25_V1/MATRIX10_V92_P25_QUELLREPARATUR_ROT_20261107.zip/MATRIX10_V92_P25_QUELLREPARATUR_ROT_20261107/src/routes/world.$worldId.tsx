import { createFileRoute, redirect } from "@tanstack/react-router";

export const Route = createFileRoute("/world/$worldId")({
  beforeLoad: ({ params }) => {
    throw redirect({ href: `/welt/${params.worldId}` });
  },
  component: () => null,
});
