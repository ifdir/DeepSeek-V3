import { createFileRoute, redirect } from "@tanstack/react-router";

export const Route = createFileRoute("/char/$charId")({
  beforeLoad: ({ params }) => {
    throw redirect({ href: `/charakter/${params.charId}` });
  },
  component: () => null,
});
