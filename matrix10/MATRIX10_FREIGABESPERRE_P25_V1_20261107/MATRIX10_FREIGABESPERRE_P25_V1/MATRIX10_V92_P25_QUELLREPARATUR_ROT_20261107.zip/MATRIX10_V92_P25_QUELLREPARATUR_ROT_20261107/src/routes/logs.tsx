import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { Shell, Panel } from "@/components/shell";
import { Button, Chip } from "@/components/ui";
import { useMatrix } from "@/lib/matrix/store";
import { useHydrated } from "@/lib/matrix/use-hydrated";
import { apiGetLog, apiListLogs, apiLiveLog } from "@/lib/matrix/api";

export const Route = createFileRoute("/logs")({ component: LogsPage });

type SqlLog = { id?: string; at?: string; level?: string; code?: string; message?: string; sessionId?: string };
type LiveLine = { ts?: string; stage?: string; trace_id?: string; session_id?: string; endpoint?: string; raw?: string };

function LogsPage() {
  const hydrated = useHydrated();
  const local = useMatrix((s) => s.logs);
  const [sql, setSql] = useState<SqlLog[]>([]);
  const [live, setLive] = useState<LiveLine[]>([]);
  const [err, setErr] = useState<string | null>(null);
  const [detail, setDetail] = useState<string>("");

  async function reload() {
    setErr(null);
    try {
      const [a, b] = await Promise.all([apiListLogs(), apiLiveLog()]);
      setSql(((a.logs as SqlLog[]) || []).slice().reverse());
      setLive(((b.lines as LiveLine[]) || []).slice().reverse());
    } catch (e) {
      setErr(e instanceof Error ? e.message : "Logs nicht lesbar");
    }
  }

  useEffect(() => {
    void reload();
  }, []);

  if (!hydrated) {
    return (
      <Shell title="Logs">
        <p className="text-sm text-muted">Lädt…</p>
      </Shell>
    );
  }

  return (
    <Shell title="Logs">
      <h1 className="font-display text-2xl font-semibold">Logs</h1>
      <p className="mt-1 text-sm text-muted">SQLite-Reader und Kernel-Trace. MODEL_REQUEST / MODEL_RESPONSE enthalten den vollständigen gesendeten Kontext, Rohantwort und Tokenverbrauch des Providers. Reader öffnet alle Details.</p>
      <div className="mt-3">
        <Button variant="line" className="min-h-9 text-xs" onClick={() => void reload()}>
          Reader neu laden
        </Button>
      </div>
      {err ? <p className="mt-2 text-sm text-danger">{err}</p> : null}
      {detail ? <pre className="mt-2 max-h-[70vh] overflow-auto whitespace-pre-wrap break-all rounded-lg border p-3 text-sm" tabIndex={0}>{detail}</pre> : null}
      <div className="mt-4 grid gap-4 lg:grid-cols-2">
        <Panel title={`SQLite /api/logs · ${sql.length || local.length}`}>
          <ul className="space-y-2">
            {(sql.length ? sql : local).slice(0, 80).map((l, i) => (
              <li key={String(l.id || i)} className="flex flex-wrap items-baseline gap-2 text-sm">
                <Chip tone={l.level === "error" ? "danger" : l.level === "warn" ? "warn" : "ok"}>{l.code || "log"}</Chip>
                <span className="text-muted">{l.at ? new Date(l.at).toLocaleString("de-AT") : ""}</span>
                <span>{l.message}</span>
                {l.id ? (
                  <Button
                    variant="line"
                    className="min-h-7 px-2 text-[11px]"
                    onClick={() => {
                      void apiGetLog(String(l.id))
                        .then((row) => setDetail(JSON.stringify(row, null, 2)))
                        .catch((e) => setDetail(e instanceof Error ? e.message : "GET fehlgeschlagen"));
                    }}
                  >
                    Reader
                  </Button>
                ) : null}
              </li>
            ))}
          </ul>
        </Panel>
        <Panel title={`Live-Trace KERNEL/SQLITE · ${live.length}`}>
          {live.length === 0 ? <p className="text-sm text-muted">Noch kein Trace.</p> : null}
          <ul className="space-y-2 font-mono text-[11px] text-muted">
            {live.slice(0, 80).map((l, i) => (
              <li key={`${l.trace_id || "t"}-${i}`}>
                {l.ts} {l.stage} {l.endpoint || ""} {l.session_id || ""} {l.trace_id || l.raw || ""}
              </li>
            ))}
          </ul>
        </Panel>
      </div>
    </Shell>
  );
}
