import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { Shell, Panel, Empty } from "@/components/shell";
import { Button, Field, Input, Select, Switch, Textarea } from "@/components/ui";
import { uid } from "@/lib/matrix/ids";
import { useMatrix } from "@/lib/matrix/store";
import { useHydrated } from "@/lib/matrix/use-hydrated";

export const Route = createFileRoute("/triggers")({ component: TriggersPage });

function TriggersPage() {
  const hydrated = useHydrated();
  const worlds = useMatrix((s) => s.worlds);
  const triggers = useMatrix((s) => s.triggers);
  const addTrigger = useMatrix((s) => s.addTrigger);
  const patchTrigger = useMatrix((s) => s.patchTrigger);
  const deleteTrigger = useMatrix((s) => s.deleteTrigger);
  const [name, setName] = useState("");
  const [match, setMatch] = useState("");
  const [effect, setEffect] = useState("");
  const [worldId, setWorldId] = useState("");

  if (!hydrated) {
    return (
      <Shell title="Trigger">
        <p className="text-sm text-muted">Lädt…</p>
      </Shell>
    );
  }

  return (
    <Shell title="Trigger">
      <h1 className="font-display text-2xl font-semibold">Trigger</h1>
      <p className="mt-1 text-sm text-muted">Analysehinweise bei Treffer im Eingabetext. Kein Szenenautomat, keine kanonische Wirkung (AMASTER §16).</p>
      <Panel className="mt-4" title="Neu">
        <div className="grid gap-3 sm:grid-cols-2">
          <Field label="Name">
            <Input value={name} onChange={(e) => setName(e.target.value)} />
          </Field>
          <Field label="Welt">
            <Select value={worldId} onChange={(e) => setWorldId(e.target.value)}>
              <option value="">—</option>
              {worlds.map((w) => (
                <option key={w.id} value={w.id}>
                  {w.name}
                </option>
              ))}
            </Select>
          </Field>
          <Field label="Match">
            <Input value={match} onChange={(e) => setMatch(e.target.value)} placeholder="Teilstring" />
          </Field>
          <Field label="Wirkung">
            <Textarea rows={2} value={effect} onChange={(e) => setEffect(e.target.value)} />
          </Field>
        </div>
        <Button
          className="mt-3"
          onClick={() => {
            if (!name.trim() || !worldId) return;
            addTrigger({
              id: uid("trg"),
              name: name.trim(),
              active: true,
              worldId,
              targetIds: [],
              match,
              effectType: "hint",
              effectText: effect,
            });
            setName("");
            setMatch("");
            setEffect("");
          }}
        >
          Speichern
        </Button>
      </Panel>
      <Panel className="mt-4" title="Bestand">
        {triggers.length === 0 ? <Empty>Keine Trigger.</Empty> : null}
        <ul className="space-y-2">
          {triggers.map((t) => (
            <li key={t.id} className="flex flex-wrap items-center gap-2 rounded-[12px] border border-border bg-bg p-3 text-sm">
              <Switch checked={t.active} onChange={(v) => patchTrigger(t.id, { active: v })} label={t.name} />
              <span className="text-xs text-muted">
                {t.match} → {t.effectText}
              </span>
              <Button variant="danger" className="ml-auto min-h-9 text-xs" onClick={() => deleteTrigger(t.id)}>
                Löschen
              </Button>
            </li>
          ))}
        </ul>
      </Panel>
    </Shell>
  );
}
