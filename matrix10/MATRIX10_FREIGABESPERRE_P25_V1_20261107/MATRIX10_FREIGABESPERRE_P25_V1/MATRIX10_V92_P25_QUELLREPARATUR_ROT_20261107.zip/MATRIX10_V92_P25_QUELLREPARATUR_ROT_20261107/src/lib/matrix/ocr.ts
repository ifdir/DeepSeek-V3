import type { EpubPart } from "./epub";

export type OcrStatus = "ready" | "ocr_empty";

export type OcrResult = {
  ok: boolean;
  text: string;
  status: OcrStatus;
  engine: "tesseract.js" | "source" | "none";
  confidence?: number;
  error?: string;
};

/** Druckseite: ein Block, 300 dpi, Wortabstände, kein Symbolmüll. */
export const PRINT_OCR_PARAMS = {
  tessedit_pageseg_mode: "6",
  preserve_interword_spaces: "1",
  user_defined_dpi: "300",
  tessedit_char_blacklist: "{}[]_|<>",
} as const;

/** LSTM-only, integerisiertes tessdata_best für Deutsch. Kein Legacy-Engine. */
export function ocrLangFromBcp47(lang?: string): string {
  const l = (lang || "").toLowerCase();
  if (l.startsWith("en")) return "eng";
  if (l.startsWith("fr")) return "fra";
  return "deu";
}

export const LSTM_OCR = {
  lang: "deu",
  oem: 1,
  langPath: "https://tessdata.projectnaptha.com/4.0.0_best_int",
  gzip: true,
  legacyCore: false,
  legacyLang: false,
} as const;

export const LSTM_DAWGS = {
  load_system_dawg: "1",
  load_freq_dawg: "1",
  load_unambig_dawg: "1",
  load_punc_dawg: "1",
  load_number_dawg: "1",
  load_bigram_dawg: "1",
} as const;

/** CTC-Beam: Matrix an, Choices aus CTC, 8 Kaskaden, weicher Cutoff. */
export const CTC_BEAM = {
  lstm_use_matrix: "1",
  lstm_choice_mode: "2",
  lstm_choice_iterations: "8",
  lstm_rating_coefficient: "4",
} as const;

/** Beam + kein Wort-Verwerfen + leichter Wörterbuch-Druck. */
export const LSTM_DECODE_PARAMS = {
  ...CTC_BEAM,
  tessedit_zero_rejection: "0",
  tessedit_minimal_rejection: "1",
  language_model_ngram_on: "0",
  language_model_penalty_non_dict_word: "0.05",
  language_model_penalty_non_freq_dict_word: "0.03",
};

export const MAX_OCR_SCAN_PAGES = 8;

export function scanPartsNeedingOcr(parts: EpubPart[]): { indexes: number[]; skipped: number } {
  const indexes = parts
    .map((p, i) => i)
    .filter((i) => parts[i].selected && parts[i].layer === "scan" && !String(parts[i].text || "").trim());
  return { indexes: indexes.slice(0, MAX_OCR_SCAN_PAGES), skipped: Math.max(0, indexes.length - MAX_OCR_SCAN_PAGES) };
}

type TessWorker = {
  recognize: (image: string | File | Blob) => Promise<{ data: { text: string; confidence?: number } }>;
  setParameters?: (p: Record<string, string>) => Promise<unknown>;
};
type RecognizeFn = (image: string | File | Blob) => Promise<{ text: string; confidence?: number }>;

let testRecognize: RecognizeFn | null = null;
let workerOnce: Promise<TessWorker> | null = null;

export function setOcrRecognizeForTests(fn: RecognizeFn | null): void {
  testRecognize = fn;
}

function empty(error?: string): OcrResult {
  return { ok: false, text: "", status: "ocr_empty", engine: "tesseract.js", error };
}

export function cleanOcrText(raw: string): string {
  return String(raw || "")
    .replace(/\u00ad/g, "")
    .replace(/(\p{L})-\n(\p{L})/gu, "$1$2")
    .replace(/[ \t]+\n/g, "\n")
    .replace(/\n{3,}/g, "\n\n")
    .replace(/[ \t]{2,}/g, " ")
    .trim();
}

export function ocrLooksEmpty(text: string, confidence?: number): boolean {
  const letters = (text.match(/[A-Za-zÄÖÜäöüßÀ-ž]/g) || []).length;
  if (letters < 8) return true;
  if (confidence != null && confidence < 20 && letters < 24) return true;
  return false;
}

export async function recognizeImage(image: string | File | Blob, onProgress?: (p: number) => void): Promise<OcrResult> {
  if (!image || (typeof image === "string" && !image.trim())) return empty("kein Bild");
  try {
    const prepared = await preparePrintImage(image);
    if (testRecognize) {
      const got = await testRecognize(prepared);
      return finishOcr(got.text, got.confidence);
    }
    const worker = await getWorker(onProgress);
    const res = await worker.recognize(prepared);
    return finishOcr(res.data.text, res.data.confidence);
  } catch (e) {
    workerOnce = null;
    return empty(e instanceof Error ? e.message : "OCR fehlgeschlagen");
  }
}

function finishOcr(raw: string, confidence?: number): OcrResult {
  const text = cleanOcrText(raw);
  if (!text || ocrLooksEmpty(text, confidence)) return empty();
  return { ok: true, text, status: "ready", engine: "tesseract.js", confidence };
}

async function getWorker(onProgress?: (p: number) => void) {
  if (!workerOnce) {
    workerOnce = (async () => {
      const { createWorker } = await import("tesseract.js");
      const logger = (m: { progress?: number }) => {
        if (onProgress && typeof m.progress === "number") onProgress(m.progress);
      };
      const lstmOpts = {
        logger,
        langPath: LSTM_OCR.langPath,
        gzip: LSTM_OCR.gzip,
        legacyCore: LSTM_OCR.legacyCore,
        legacyLang: LSTM_OCR.legacyLang,
      };
      let worker: TessWorker;
      try {
        worker = await createWorker(LSTM_OCR.lang, LSTM_OCR.oem, lstmOpts, { ...LSTM_DAWGS });
      } catch {
        try {
          worker = await createWorker(LSTM_OCR.lang, LSTM_OCR.oem, { logger, gzip: true, legacyCore: false, legacyLang: false }, { ...LSTM_DAWGS });
        } catch {
          worker = await createWorker("eng", LSTM_OCR.oem, { logger, gzip: true, legacyCore: false, legacyLang: false });
        }
      }
      if (worker.setParameters) {
        await worker.setParameters({ ...PRINT_OCR_PARAMS, ...LSTM_DECODE_PARAMS });
      }
      return worker;
    })();
  }
  return workerOnce;
}

/** Kleine Fotos hochskalieren; Graustufen. Ohne Canvas (Tests) unverändert. */
export async function preparePrintImage(image: string | File | Blob): Promise<string | File | Blob> {
  if (typeof document === "undefined") return image;
  try {
    const bmp = await loadImage(image);
    if (!bmp) return image;
    const minEdge = Math.min(bmp.width, bmp.height);
    const scale = minEdge > 0 && minEdge < 1200 ? Math.min(2.4, 1400 / minEdge) : 1;
    const w = Math.max(1, Math.round(bmp.width * scale));
    const h = Math.max(1, Math.round(bmp.height * scale));
    const canvas = document.createElement("canvas");
    canvas.width = w;
    canvas.height = h;
    const ctx = canvas.getContext("2d");
    if (!ctx) return image;
    ctx.filter = "grayscale(1) contrast(1.15)";
    ctx.drawImage(bmp, 0, 0, w, h);
    return canvas.toDataURL("image/png");
  } catch {
    return image;
  }
}

function loadImage(image: string | File | Blob): Promise<HTMLImageElement | null> {
  return new Promise((resolve) => {
    const img = new Image();
    img.onload = () => resolve(img);
    img.onerror = () => resolve(null);
    if (typeof image === "string") {
      img.src = image;
      return;
    }
    const url = URL.createObjectURL(image);
    img.onload = () => {
      URL.revokeObjectURL(url);
      resolve(img);
    };
    img.onerror = () => {
      URL.revokeObjectURL(url);
      resolve(null);
    };
    img.src = url;
  });
}

export async function textFromUpload(opts: {
  text: string;
  dataUrl?: string;
  file: File;
}): Promise<OcrResult> {
  const source = (opts.text || "").trim();
  if (source) return { ok: true, text: source, status: "ready", engine: "source" };
  const image = opts.dataUrl || (opts.file.type.startsWith("image/") ? opts.file : null);
  if (!image) return { ok: false, text: "", status: "ocr_empty", engine: "none", error: "kein Bildtext" };
  return recognizeImage(image);
}

export async function ocrSelectedScanParts(file: File, parts: EpubPart[]): Promise<{ parts: EpubPart[]; read: number; skipped: number }> {
  const { indexes, skipped } = scanPartsNeedingOcr(parts);
  if (!indexes.length) return { parts, read: 0, skipped };
  const next = parts.slice();
  let read = 0;
  for (const i of indexes) {
    const pageNum = Number(String(next[i].zipPath || "").replace(/^page-/, "")) || i + 1;
    const img = await renderPdfPageImage(file, pageNum);
    if (!img) continue;
    const got = await recognizeImage(img);
    if (!got.text) continue;
    next[i] = { ...next[i], text: got.text, chars: got.text.length };
    read += 1;
  }
  return { parts: next, read, skipped };
}

async function renderPdfPageImage(file: File, pageNum: number): Promise<string | null> {
  if (typeof document === "undefined") return null;
  try {
    const buf = await file.arrayBuffer();
    const pdfjs =
      typeof window === "undefined"
        ? await import("pdfjs-dist/legacy/build/pdf.mjs")
        : await import("pdfjs-dist");
    if (typeof window !== "undefined" && !pdfjs.GlobalWorkerOptions.workerSrc) {
      pdfjs.GlobalWorkerOptions.workerSrc = new URL("pdfjs-dist/build/pdf.worker.min.mjs", import.meta.url).toString();
    }
    const pdf = await pdfjs.getDocument({
      data: new Uint8Array(buf),
      isEvalSupported: false,
      useSystemFonts: true,
    } as Parameters<typeof pdfjs.getDocument>[0]).promise;
    const page = await pdf.getPage(pageNum);
    const viewport = page.getViewport({ scale: 2 });
    const canvas = document.createElement("canvas");
    canvas.width = Math.max(1, Math.floor(viewport.width));
    canvas.height = Math.max(1, Math.floor(viewport.height));
    const ctx = canvas.getContext("2d");
    if (!ctx) return null;
    await page.render({ canvasContext: ctx, canvas, viewport }).promise;
    return canvas.toDataURL("image/png");
  } catch {
    return null;
  }
}
