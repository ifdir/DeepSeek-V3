import { uid } from "./ids.ts";
import type { SceneFact } from "./types.ts";

export const SCENEFACT_IMMUTABLE = "SCENEFACT_IMMUTABLE";

const CORE = ["text", "kind", "actorId", "targetId", "verb", "authority", "turn", "placeId"] as const;

export type FactAppendPlan =
  | { action: "insert"; fact: SceneFact }
  | { action: "keep"; fact: SceneFact }
  | { action: "reject"; fact: SceneFact; error: typeof SCENEFACT_IMMUTABLE }
  | { action: "contradict"; fact: SceneFact; prior: SceneFact };

function coreOf(f: Pick<SceneFact, (typeof CORE)[number]>): string {
  return CORE.map((k) => String(f[k] ?? "")).join("\u001f");
}

export function sameSceneFactCore(a: SceneFact, b: Partial<SceneFact>): boolean {
  return CORE.every((k) => String(a[k] ?? "") === String(b[k] ?? a[k] ?? ""));
}

export function planSceneFactAppend(existing: SceneFact[], next: SceneFact): FactAppendPlan {
  const hit = existing.find((f) => f.id === next.id);
  if (!hit) return { action: "insert", fact: next };
  if (coreOf(hit) === coreOf(next)) return { action: "keep", fact: hit };
  return { action: "reject", fact: hit, error: SCENEFACT_IMMUTABLE };
}

export function appendSceneFact(existing: SceneFact[], next: SceneFact): { facts: SceneFact[]; plan: FactAppendPlan } {
  const plan = planSceneFactAppend(existing, next);
  if (plan.action === "insert") return { facts: [...existing, plan.fact], plan };
  return { facts: existing, plan };
}

/** Widerspruch ist ein neuer Fact. Der alte Satz bleibt. */
export function contradictSceneFact(
  existing: SceneFact[],
  priorId: string,
  patch: Pick<SceneFact, "text" | "kind" | "actorId" | "authority" | "turn"> & Partial<SceneFact>,
): { facts: SceneFact[]; plan: FactAppendPlan } {
  const prior = existing.find((f) => f.id === priorId);
  if (!prior) {
    const fact: SceneFact = {
      id: patch.id || uid("fact"),
      turn: patch.turn,
      actorId: patch.actorId,
      kind: patch.kind,
      text: patch.text,
      authority: patch.authority,
      witnessedBy: patch.witnessedBy || [],
      targetId: patch.targetId,
      verb: patch.verb,
      placeId: patch.placeId,
      userId: patch.userId,
      worldId: patch.worldId,
      sessionId: patch.sessionId,
      sourceTurnId: patch.sourceTurnId,
      sourceType: patch.sourceType ?? "contradiction",
      status: patch.status ?? "claimed",
      provenance: patch.provenance ?? "contradict",
      respondsToFactId: priorId,
    };
    return appendSceneFact(existing, fact);
  }
  const fact: SceneFact = {
    ...prior,
    ...patch,
    id: uid("fact"),
    text: patch.text,
    kind: patch.kind,
    actorId: patch.actorId,
    authority: patch.authority,
    turn: patch.turn,
    witnessedBy: patch.witnessedBy || prior.witnessedBy,
    sourceType: patch.sourceType ?? "contradiction",
    status: patch.status ?? "claimed",
    provenance: patch.provenance ?? "contradict",
    respondsToFactId: prior.id,
  };
  const plan: FactAppendPlan = { action: "contradict", fact, prior };
  return { facts: [...existing, fact], plan };
}

export function pushSceneFact<T extends { facts: SceneFact[] }>(session: T, next: SceneFact): SceneFact {
  const { facts, plan } = appendSceneFact(session.facts, next);
  session.facts = facts;
  if (plan.action === "insert") return plan.fact;
  return plan.fact;
}
