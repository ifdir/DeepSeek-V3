/** Transient input reconciliation only. SQLite and its Owner APIs remain authoritative.
 * This tracker prevents an asynchronous PATCH response from replacing subsequent
 * typing, and rolls back only the fields whose most recent write failed.
 */
type FieldState = { confirmed: unknown; latest: number; pending: number };

export class FieldWriteTracker {
  private readonly fields = new Map<string, FieldState>();
  private sequence = 0;

  begin(scope: string, id: string, patch: Record<string, unknown>, current: Record<string, unknown>) {
    const sequence = ++this.sequence;
    const requests = Object.entries(patch).map(([field, value]) => {
      const key = JSON.stringify([scope, id, field]);
      let state = this.fields.get(key);
      if (!state) {
        state = { confirmed: current[field], latest: sequence, pending: 0 };
        this.fields.set(key, state);
      }
      state.latest = sequence;
      state.pending += 1;
      return { key, field, value, state };
    });
    return {
      committed: () => {
        for (const request of requests) {
          request.state.confirmed = request.value;
          request.state.pending -= 1;
          if (request.state.pending === 0) this.fields.delete(request.key);
        }
      },
      failed: (): Record<string, unknown> => {
        const rollback: Record<string, unknown> = {};
        for (const request of requests) {
          request.state.pending -= 1;
          if (request.state.latest === sequence) rollback[request.field] = request.state.confirmed;
          if (request.state.pending === 0) this.fields.delete(request.key);
        }
        return rollback;
      },
    };
  }
}
