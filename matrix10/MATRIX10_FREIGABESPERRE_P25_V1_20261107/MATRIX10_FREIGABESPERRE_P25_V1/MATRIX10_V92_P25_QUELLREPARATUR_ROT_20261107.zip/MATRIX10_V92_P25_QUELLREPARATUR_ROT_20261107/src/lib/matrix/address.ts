import type { DirectedRel, Session, StammCharacter, TurnFocus } from "./types.ts";

const LOVE_KIND = /liebe|lover|partner|gatte|gattin|ehe|schatz|geliebte|beziehung|hoffnung/i;
const NICK = [
  { re: /\b(schatz|liebling|darling|honey|Schatz|mein schatz|meine liebe|mein lieber)\b/i, kind: "love" },
  { re: /\b(chef|chefin|wirt|wirtin|boss)\b/i, kind: "host" },
  { re: /\b(junge|bursche|mädchen|maedchen)\b/i, kind: "dim" },
];

export interface AddressResult {
  addressed?: StammCharacter;
  topic?: StammCharacter;
  relationTerm?: string;
  isQuestion: boolean;
  vocative?: boolean;
}

export function firstName(c: StammCharacter): string {
  return c.name.split(/\s+/)[0] ?? c.name;
}

export function nameTokens(c: StammCharacter): string[] {
  const toks = new Set<string>();
  toks.add(c.name.toLowerCase());
  toks.add(firstName(c).toLowerCase());
  for (const a of c.aliases) if (a.trim()) toks.add(a.toLowerCase());
  return [...toks].filter((t) => t.length >= 3);
}

export function mentionsIn(text: string, chars: StammCharacter[]): { char: StammCharacter; index: number; vocative: boolean }[] {
  const n = text;
  const low = n.toLowerCase();
  const hits: { char: StammCharacter; index: number; vocative: boolean }[] = [];
  for (const c of chars) {
    for (const tok of nameTokens(c)) {
      const idx = low.indexOf(tok);
      if (idx < 0) continue;
      const before = idx === 0 || /[\s,.;:!?„"']/.test(low[idx - 1] ?? " ");
      const afterCh = low[idx + tok.length] ?? " ";
      const after = /[\s,.;:!?„"'s]/.test(afterCh);
      if (!before || !after) continue;
      const slice = n.slice(idx, idx + tok.length + 2);
      const vocative = idx < 12 && /,/.test(slice + n.slice(idx + tok.length, idx + tok.length + 2));
      const startVocative = idx <= 1 && /,\s/.test(n.slice(idx + tok.length, idx + tok.length + 3));
      hits.push({ char: c, index: idx, vocative: vocative || startVocative });
      break;
    }
  }
  hits.sort((a, b) => a.index - b.index);
  return hits;
}

export function isQuestion(text: string): boolean {
  const t = text.trim();
  if (t.endsWith("?")) return true;
  return /^(wer|was|warum|wieso|weshalb|wo|wie|wann|wen|wem|wovon|weswegen)\b/i.test(t);
}

function topicPattern(text: string, char: StammCharacter): boolean {
  const tok = firstName(char);
  const re = new RegExp(
    `(?:was|warum|wieso|wie|wo|wann).{0,24}(?:hat|haben|hatte|ist|war|macht|gemacht|getan|gesagt).{0,8}${escapeRe(tok)}|${escapeRe(tok)}.{0,8}(?:gemacht|getan|gesagt|angetan)`,
    "i",
  );
  return re.test(text);
}

function escapeRe(s: string) {
  return s.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
}

function resolveLove(fromId: string | null, present: StammCharacter[], rels: DirectedRel[]): StammCharacter | undefined {
  if (!fromId) return undefined;
  const outgoing = rels.filter((r) => r.fromId === fromId);
  const scored = present
    .map((c) => {
      const r = outgoing.find((x) => x.toId === c.id);
      if (!r) return { c, s: 0 };
      let s = r.closeness;
      if (LOVE_KIND.test(`${r.kind ?? ""} ${r.note}`)) s += 0.5;
      return { c, s };
    })
    .filter((x) => x.s >= 0.55)
    .sort((a, b) => b.s - a.s);
  return scored[0]?.c;
}

function resolveHost(present: StammCharacter[]): StammCharacter | undefined {
  return present.find((c) => /wirt|host|chefin|inhaber/i.test(`${c.role} ${c.occupation}`));
}

export function resolveAddress(opts: {
  text: string;
  present: StammCharacter[];
  all: StammCharacter[];
  session: Session;
  uiTargetId?: string;
  speakerId?: string | null;
}): AddressResult {
  const { text, present, session, uiTargetId, speakerId } = opts;
  const q = isQuestion(text);
  const result: AddressResult = { isQuestion: q };
  const ui = uiTargetId ? present.find((c) => c.id === uiTargetId) : undefined;

  const mentions = mentionsIn(text, present);
  const voc = mentions.find((m) => m.vocative);
  const topics = mentions.filter((m) => topicPattern(text, m.char));

  if (voc) {
    result.addressed = voc.char;
    result.vocative = true;
    const other = mentions.find((m) => m.char.id !== voc.char.id);
    if (other) result.topic = other.char;
    if (topics[0] && topics[0].char.id !== voc.char.id) result.topic = topics[0].char;
    return result;
  }

  if (ui) result.addressed = ui;

  for (const nick of NICK) {
    if (!nick.re.test(text)) continue;
    result.relationTerm = nick.re.source;
    if (nick.kind === "love") {
      result.addressed =
        resolveLove(speakerId ?? session.avatarId, present, session.relations) ??
        present.find((c) => c.id === session.focus.addressedId);
    }
    if (nick.kind === "host") result.addressed = result.addressed ?? resolveHost(present);
  }

  if (topics.length === 1) result.topic = topics[0]!.char;

  if (!result.addressed && mentions.length === 1 && !topics.length) {
    result.addressed = mentions[0]!.char;
  }

  if (!result.addressed && mentions.length > 1 && !q) {
    result.addressed = mentions[0]!.char;
    result.topic = mentions[1]!.char;
  }

  if (!result.addressed && /\b(sie|ihn|ihm|ihr)\b/i.test(text) && session.focus.addressedId) {
    result.addressed = present.find((c) => c.id === session.focus.addressedId);
  }

  if (!result.topic && session.focus.topicId) {
    result.topic = present.find((c) => c.id === session.focus.topicId) ?? opts.all.find((c) => c.id === session.focus.topicId);
  }

  if (!result.addressed && !q && session.focus.addressedId) {
    result.addressed = present.find((c) => c.id === session.focus.addressedId);
  }

  return result;
}

export function nextFocus(prev: TurnFocus, addr: AddressResult, speakerId?: string, fact?: { actorId: string; targetId?: string; id: string }): TurnFocus {
  return {
    addressedId: addr.addressed?.id ?? prev.addressedId,
    topicId: addr.topic?.id ?? fact?.targetId ?? prev.topicId,
    lastSpeakerId: speakerId ?? prev.lastSpeakerId,
    lastActorId: fact?.actorId ?? prev.lastActorId,
    lastTargetId: fact?.targetId ?? prev.lastTargetId,
    lastQuestion: addr.isQuestion ? undefined : prev.lastQuestion,
    lastFactId: fact?.id ?? prev.lastFactId,
  };
}

export function bindFollowup(text: string, session: Session): { prior?: string; about?: string } {
  const t = text.trim();
  const follow = /^(warum|wieso|weshalb|und\??|was genau|wie das|weswegen)\b/i.test(t) || t === "?" || t.length < 8;
  if (!follow) return {};
  const last = session.facts.filter((f) => f.kind === "action" || f.kind === "physical" || f.kind === "speech").at(-1);
  return { prior: last?.text, about: last?.targetId };
}
