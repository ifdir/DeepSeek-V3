import { fillCompass, compassFromPassages } from "./compass";
import { uid } from "./ids";
import { MEANING_SPACES, type Memory, type Place, type Preference, type Session, type SpawnCandidate, type StammCharacter, type StammRelation, type World, type WorldDraft, type WorldPack } from "./types";

export function emptyCharacter(worldId: string, name: string): StammCharacter {
  return {
    id: uid("char"),
    worldId,
    name,
    aliases: [name],
    role: "",
    age: "",
    gender: "",
    origin: "",
    occupation: "",
    biography: "",
    canon: [],
    personality: "",
    values: [],
    goals: [],
    fears: [],
    secrets: [],
    likes: [],
    dislikes: [],
    conflictStyle: "",
    humor: "",
    speechRegister: "",
    typicalPhrases: [],
    taboos: [],
    favoriteWords: [],
    body: { mobility: 0.8, strength: 0.5, pain: 0, consciousness: 1, notes: "", constraints: [] },
    knowledge: [],
    relations: [],
    compass: fillCompass({}),
    reactionRules: [],
    isWorldNative: true,
    sourceRefs: [],
    status: "entwurf",
    appearance: "",
    dialect: "",
    visibility: "public",
    typicalPlace: "",
    worldNotes: "",
    species: "",
    coreFacts: [],
    bindingPatterns: [],
    lastingAbilities: [],
    sourceReleaseStatus: "draft",
    canBeAvatar: false,
  };
}

export function hydrateCharacter(c: StammCharacter): StammCharacter {
  return {
    ...emptyCharacter(c.worldId, c.name),
    ...c,
    aliases: c.aliases ?? [c.name],
    canon: c.canon ?? [],
    values: c.values ?? [],
    goals: c.goals ?? [],
    fears: c.fears ?? [],
    secrets: c.secrets ?? [],
    likes: c.likes ?? [],
    dislikes: c.dislikes ?? [],
    typicalPhrases: c.typicalPhrases ?? [],
    taboos: c.taboos ?? [],
    favoriteWords: c.favoriteWords ?? [],
    knowledge: c.knowledge ?? [],
    relations: (c.relations && c.relations.length
      ? c.relations
      : ((c as StammCharacter & { relationships?: StammRelation[] }).relationships ?? [])) ?? [],
    reactionRules: c.reactionRules ?? [],
    sourceRefs: c.sourceRefs ?? [],
    compass: fillCompass(c.compass ?? {}),
    body: c.body ?? { mobility: 0.8, strength: 0.5, pain: 0, consciousness: 1, notes: "", constraints: [] },
    appearance: c.appearance ?? "",
    dialect: c.dialect ?? "",
    visibility: c.visibility ?? "public",
    typicalPlace: c.typicalPlace ?? "",
    worldNotes: c.worldNotes ?? "",
    species: c.species ?? "",
    coreFacts: c.coreFacts ?? [],
    bindingPatterns: c.bindingPatterns ?? [],
    lastingAbilities: c.lastingAbilities ?? [],
    drives: Array.isArray((c as { drives?: unknown[] }).drives) ? ((c as { drives?: StammCharacter["drives"] }).drives as StammCharacter["drives"]) : [],
    sourceReleaseStatus: c.sourceReleaseStatus ?? "draft",
    canBeAvatar: c.isWorldNative === false ? true : Boolean(c.canBeAvatar),
    ownerUserId: c.ownerUserId,
  };
}

export function hydrateWorld(w: World): World {
  return {
    ...w,
    places: w.places ?? [],
    rules: w.rules ?? [],
    factions: w.factions ?? [],
    timeline: w.timeline ?? [],
    conflicts: w.conflicts ?? [],
    items: w.items ?? [],
    secrets: w.secrets ?? [],
    history: w.history ?? [],
    beings: w.beings ?? [],
    knowledgeLimits: w.knowledgeLimits ?? [],
    worldGoals: w.worldGoals ?? [],
    startSituations: w.startSituations ?? [],
    fateSeeds: w.fateSeeds ?? [],
    characterIds: w.characterIds ?? [],
    epoch: w.epoch ?? "",
    geography: w.geography ?? "",
    atmosphere: w.atmosphere ?? "",
    purpose: w.purpose ?? "",
    visibility: w.visibility ?? "public",
    typicalScenes: w.typicalScenes ?? [],
    storyBeats: w.storyBeats ?? [],
    fateEnabled: w.fateEnabled ?? true,
    ownerUserId: w.ownerUserId ?? "admin",
    canon: w.canon ?? "",
    assets: w.assets ?? [],
    spawnTemplates: w.spawnTemplates ?? [],
    sourceRefs: w.sourceRefs ?? [],
    sourceName: w.sourceName ?? "",
    sourceText: w.sourceText ?? "",
    sourcePartIds: w.sourcePartIds ?? [],
    spawnCandidates: w.spawnCandidates ?? [],
    culture: w.culture ?? [],
    language: w.language ?? [],
    worldKnowledge: w.worldKnowledge ?? [],
    secretKnowledge: w.secretKnowledge ?? [],
    knowledgeBounds: w.knowledgeBounds ?? [],
    startScenes: w.startScenes ?? [],
    storyGoals: w.storyGoals ?? [],
    fateBeats: w.fateBeats ?? [],
    figureRelations: w.figureRelations ?? [],
    subplaces: w.subplaces ?? [],
    placeRelations: w.placeRelations ?? [],
  };
}

export function hydrateSession(s: Session): Session {
  return {
    ...s,
    createdAt: s.createdAt || new Date().toISOString(),
    updatedAt: s.updatedAt || s.createdAt || new Date().toISOString(),
    goals: s.goals ?? [],
    propositions: s.propositions ?? [],
    memories: (s.memories ?? []).map((m) => ({
      ...m,
      truthStatus: m.truthStatus ?? "canon",
      layer: m.layer ?? "session",
    })),
    facts: (s.facts ?? []).map((f) => ({
      ...f,
      witnessedBy: f.witnessedBy ?? [],
    })),
    godFacts: (s.godFacts ?? []).map((g) => ({ ...g, applied: g.applied ?? false })),
    pipeline: s.pipeline ?? { fate: true, meta: true, narrator: true },
    autoChat: s.autoChat ?? { enabled: false, turns: 2, delayMs: 5000, contextTurns: 10 },
    focus: s.focus ?? {},
    witnessKnowledge: s.witnessKnowledge ?? [],
    currentState: s.currentState ?? null,
    scene: {
      ...s.scene,
      hearsIds: s.scene?.hearsIds,
      seesIds: s.scene?.seesIds,
      hearsExplicit: s.scene?.hearsExplicit,
      seesExplicit: s.scene?.seesExplicit,
      actors: s.scene?.actors ?? s.scene?.presentIds ?? [],
      goals: s.scene?.goals ?? [],
      witnesses: s.scene?.witnesses ?? [],
      ongoingActions: s.scene?.ongoingActions ?? [],
      bodyPositions: s.scene?.bodyPositions ?? {},
      openQuestions: s.scene?.openQuestions ?? [],
      openDemands: s.scene?.openDemands ?? [],
      openPromises: s.scene?.openPromises ?? [],
      conflicts: s.scene?.conflicts ?? [],
      bounds: s.scene?.bounds ?? [],
      items: s.scene?.items ?? [],
      aftereffects: s.scene?.aftereffects ?? [],
      foreground: s.scene?.foreground ?? [],
      nextScene: s.scene?.nextScene ?? "",
    },
  };
}

export function hydrateMemory(m: Memory): Memory {
  return { ...m, truthStatus: m.truthStatus ?? "canon", layer: m.layer ?? "session" };
}

const TRAIT_WORDS = [
  "stolz",
  "ängstlich",
  "kühl",
  "impulsiv",
  "loyal",
  "gierig",
  "barsch",
  "streng",
  "freundlich",
  "distanziert",
  "hart",
  "weich",
  "misstrauisch",
  "vorsichtig",
  "ruhig",
  "nervös",
];
const GOAL_MARKERS = ["ziel", "will ", "möchte", "muss ", "soll ", "versucht", "sucht ", "braucht ", "helfen"];
const FEAR_MARKERS = ["fürchtet", "furcht", "ängst", "angst vor", "panik", "schreck"];
const SECRET_MARKERS = ["geheim", "heimlich", "verborgen", "verschweig", "niemand darf", "nicht sagen", "nicht erzähl"];
const APPEAR_MARKERS = ["auge", "haar", "stimme", "gesicht", "narbe", "kleid", "anzug", "blass", "schön", "klein", "groß", "blick"];
const VALUE_MARKERS = ["anstand", "ehre", "gewissen", "pflicht", "familie", "kontrolle", "ordnung", "loyal"];
const CONFLICT_MARKERS = ["konflikt", "krieg", "streit", "fehde", "verrat", "pakt"];

function hits(s: string, markers: string[]): boolean {
  const low = s.toLowerCase();
  return markers.some((m) => {
    if (m.includes(" ") || m.endsWith(" ")) return low.includes(m);
    return new RegExp(`\\b${m.replace(/[.*+?^${}()|[\]\\]/g, "\\$&")}\\b`, "i").test(s);
  });
}

const AGENT_VERBS =
  "sagt|sagte|spricht|sprach|geht|ging|hat|hatte|ist|war|arbeitet|arbeitete|kennt|kannte|bleibt|blieb|fragt|fragte|will|wollte|muss|kommt|kam|ruft|rief|wartet|öffnet|sieht|sah|nimmt|nahm|lacht|fürchtet|steht|gibt|gab";

function nameIsAgent(name: string, sent: string, narrator = false): boolean {
  const first = (name.split(" ")[0] || "").trim();
  if (first.length < 2) return false;
  if (new RegExp(`ich bin\\s+${first}`, "i").test(sent)) return true;
  if (new RegExp(`mein name ist\\s+${name.replace(/[.*+?^${}()|[\]\\]/g, "\\$&")}`, "i").test(sent)) return true;
  const stripped = sent.trim().replace(/^["„»«“]+|["„»«“]+$/g, "");
  if (narrator && /^\s*(?:und\s+)?ich\b/i.test(stripped)) return true;
  const poss = new RegExp(`\\b${first}s\\b`, "i").test(sent);
  const own = new RegExp(`\\b${first}\\b(?!s)`, "i").test(sent);
  if (poss && !own) return false;
  if (/^\s*(?:und\s+)?ich\b/i.test(stripped)) return false;
  const escapedName = name.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
  if (new RegExp(`^${escapedName}\\s*,\\s*(?:der|die|das)\\b`, "i").test(stripped) && /\bich\b/i.test(sent)) return false;
  if (stripped.startsWith(first) || stripped.startsWith(name)) return true;
  const last = name.split(" ").slice(-1)[0] || "";
  const namePat = last && last.toLowerCase() !== first.toLowerCase() ? `${first}(?:\\s+${last})?` : first;
  if (new RegExp(`\\b${namePat}\\b\\s+(?:${AGENT_VERBS})\\b`, "i").test(sent)) return true;
  if (new RegExp(`\\b${namePat}\\b\\s*,\\s*(?:der|die)\\s+`, "i").test(sent) && !/\bich\b/i.test(sent)) return true;
  return false;
}

function occupationFromText(text: string): string {
  const t = text || "";
  const fuer = t.match(/\bfür die\s+([^.,;!?"»«]{2,40})\s+gearbeitet\b/i);
  if (fuer) return `arbeitet für die ${fuer[1].trim()}`.slice(0, 80);
  const als = t.match(/\barbeitet(?:e)?\s+als\s+([^.,;!?"»«]{3,40})/i);
  if (als) return als[1].trim().slice(0, 80);
  const bei = t.match(/\b(?:tätig|arbeitet(?:e)?)\s+bei\s+([^.,;!?"»«]{3,40})/i);
  if (bei) return `bei ${bei[1].trim()}`.slice(0, 80);
  return "";
}

function stripHeadingPrefix(s: string): string {
  let t = (s || "").trim();
  let prev = "";
  const lead =
    /^(?:#+\s*)*(?:(?:prolog|epilog|kapitel|chapter|band|titelblatt)(?:\s+[A-ZÄÖÜ0-9][\w\-äöüß]*)?\s*)+/i;
  while (t !== prev) {
    prev = t;
    t = t.replace(/^#+\s*/, "").trim();
    t = t.replace(lead, "");
    t = t.replace(/\s+/g, " ").trim();
  }
  return t;
}

function genderFromPassages(name: string, passages: string[]): string {
  const first = (name.split(" ")[0] || "").trim();
  let male = 0;
  let female = 0;
  const re = new RegExp(`\\b${first}\\b`, "g");
  for (const p of passages) {
    re.lastIndex = 0;
    let m: RegExpExecArray | null;
    while ((m = re.exec(p))) {
      const before = p.slice(Math.max(0, m.index - 16), m.index);
      const rest = p.slice(m.index + m[0].length, m.index + m[0].length + 48);
      if (/(?:Mr|Herr)\.?\s+$/i.test(before) || /^\s*[,:]?\s*\b(er|ihn|ihm|sein|seine)\b/i.test(rest)) male += 1;
      if (/(?:Mrs|Miss|Ms|Frau|Fräulein)\.?\s+$/i.test(before) || /^\s*[,:]?\s*\b(sie|ihr|ihre)\b/i.test(rest)) female += 1;
    }
  }
  if (male > female && male) return "männlich";
  if (female > male && female) return "weiblich";
  return "";
}

/** Profilfelder nur aus Originalsätzen — kein erfundener Charakter. */
export function profileFromPassages(name: string, passages: string[], role = ""): Partial<StammCharacter> {
  const nearby = passages.map((p) => p.replace(/\s+/g, " ").trim()).filter(Boolean);
  const firstTok = (name.split(" ")[0] || "").trim();
  const narrator = nearby.some(
    (s) => new RegExp(`ich bin\\s+${firstTok}|mein name ist\\s+${name.replace(/[.*+?^${}()|[\]\\]/g, "\\$&")}`, "i").test(s),
  );
  const agent = nearby.filter((s) => nameIsAgent(name, s, narrator));
  const quotes: string[] = [];
  const quoteRe = /"([^"]{8,120})"|„([^“]{8,120})“|»([^«]{8,120})«|«([^»]{8,120})»/g;
  for (const s of nearby) {
    for (const m of s.matchAll(quoteRe)) {
      const q = (m[1] || m[2] || m[3] || m[4] || "").trim();
      if (q && !quotes.includes(q)) quotes.push(q);
      if (quotes.length >= 4) break;
    }
    if (quotes.length >= 4) break;
  }
  const drive = agent.concat(quotes.filter((q) => !agent.includes(q))).filter((s) => !foreignNarratorDeixis(name, s));
  const blob = drive.join(" ");
  const low = blob.toLowerCase();
  const traits = TRAIT_WORDS.filter((w) => low.includes(w));
  let personality = [role, ...traits].filter(Boolean).join(" · ");
  if (!personality) {
    const desc = agent.find((s) => !s.startsWith('"') && firstTok && s.toLowerCase().includes(firstTok.toLowerCase()));
    personality = desc ? desc.slice(0, 180) : "";
  }
  const appearance = nearby.find((s) => hits(s, APPEAR_MARKERS))?.slice(0, 160) || "";
  const conflict = drive.find((s) => hits(s, CONFLICT_MARKERS))?.slice(0, 160) || "";
  const picked: string[] = [];
  const roleL = role.toLowerCase();
  for (const s of nearby) {
    if (foreignNarratorDeixis(name, s)) continue;
    const sl = s.toLowerCase();
    if (roleL && sl.includes(roleL)) picked.push(s.slice(0, 280));
    else if (["ich bin", "heißt", "ist die ", "ist der "].some((m) => sl.includes(m))) picked.push(s.slice(0, 280));
    if (picked.length >= 3) break;
  }
  if (picked.length < 2) {
    for (const s of nearby) {
      if (foreignNarratorDeixis(name, s)) continue;
      if (!picked.includes(s.slice(0, 280))) picked.push(s.slice(0, 280));
      if (picked.length >= 3) break;
    }
  }
  return {
    biography: picked.join(" ").slice(0, 1200),
    personality,
    appearance,
    goals: drive.filter((s) => hits(s, GOAL_MARKERS)).slice(0, 3),
    fears: drive.filter((s) => hits(s, FEAR_MARKERS)).slice(0, 3),
    secrets: drive.filter((s) => hits(s, SECRET_MARKERS)).slice(0, 3),
    values: VALUE_MARKERS.filter((w) => low.includes(w)).slice(0, 4),
    conflictStyle: conflict,
    typicalPhrases: quotes,
    coreFacts: traits,
    gender: genderFromPassages(name, nearby),
    occupation: role || occupationFromText(nearby.join(" ")) || occupationFromText(quotes.join(" ")),
  };
}

const PREP_CHILD = /^(?:im|in der|in dem|am|auf dem|auf der|unter dem|über der|hinter|neben)\s+/i;
const ROOM_CHILD = /zimmer|küche|bibliothek|büro|garten|auffahrt|salon|kammer|keller|schank|theke/i;
const HOUSE_PARENT = /villa|anwesen|haus|herrenhaus|palast|schloss|gut\b/i;

function relKey(r: { from?: unknown; to?: unknown; kind?: unknown }): string {
  return `${String(r.from || "").toLowerCase()}|${String(r.to || "").toLowerCase()}|${String(r.kind || "")}`;
}

function mergeRelRows(a: unknown[] | undefined, b: unknown[] | undefined): unknown[] {
  const out: unknown[] = [];
  const seen = new Set<string>();
  for (const row of [...(a || []), ...(b || [])]) {
    if (!row || typeof row !== "object") continue;
    const k = relKey(row as { from?: unknown; to?: unknown; kind?: unknown });
    if (!k.replace(/\|/g, "") || seen.has(k)) continue;
    seen.add(k);
    out.push(row);
  }
  return out.slice(0, 32);
}

/** Rooms become Unterorte of Villa/Haus; locative echoes of the parent are dropped. */
export function applySubplacesToPlaces(places: Place[], subplaces: unknown[] | undefined): Place[] {
  const out: Place[] = places.map((p) => ({
    ...p,
    connections: [...(p.connections || [])],
    rules: [...(p.rules || [])],
    tags: [...(p.tags || [])],
  }));
  const byName = new Map(out.map((p) => [p.name.toLowerCase(), p]));
  const house = out.find((p) => HOUSE_PARENT.test(p.name));
  if (house) {
    for (const p of out) {
      if (p.id === house.id || p.parentId) continue;
      if (!ROOM_CHILD.test(p.name)) continue;
      p.parentId = house.id;
      if (!p.connections.includes(house.name)) p.connections.push(house.name);
    }
  }
  for (const raw of subplaces || []) {
    if (!raw || typeof raw !== "object") continue;
    const row = raw as { name?: string; parent?: string };
    const parent = byName.get(String(row.parent || "").toLowerCase());
    const childName = String(row.name || "")
      .replace(PREP_CHILD, "")
      .trim();
    if (!parent || !childName || childName.toLowerCase() === parent.name.toLowerCase()) continue;
    let child = byName.get(childName.toLowerCase());
    if (!child) {
      child = {
        id: uid("ort"),
        name: childName,
        description: `${childName} liegt in ${parent.name}.`,
        connections: [parent.name],
        rules: [],
        tags: ["unterort"],
        parentId: parent.id,
      };
      out.push(child);
      byName.set(childName.toLowerCase(), child);
    } else if (!child.parentId) {
      child.parentId = parent.id;
      if (!child.connections.includes(parent.name)) child.connections.push(parent.name);
    }
  }
  return out;
}

function draftWorldExtras(d: WorldDraft["world"]): Partial<World> {
  return {
    culture: d.culture ?? [],
    language: d.language ?? [],
    worldKnowledge: d.worldKnowledge ?? [],
    secretKnowledge: d.secretKnowledge ?? d.secrets ?? [],
    knowledgeBounds: d.knowledgeBounds ?? d.knowledgeLimits ?? [],
    startScenes: d.startScenes ?? [],
    storyGoals: d.storyGoals ?? d.worldGoals ?? [],
    fateBeats: d.fateBeats ?? [],
    figureRelations: d.figureRelations ?? [],
    subplaces: d.subplaces ?? [],
    placeRelations: d.placeRelations ?? [],
    spawnCandidates: d.spawnCandidates ?? [],
    // V49: Textsorte/Genre-Meta, Facetten-Zusammenfassung, strukturierte Details und Feldprovenienz
    ...(pickExtra(d as Record<string, unknown>, ["textMeta", "facetsSummary", "worldProvenance", "rulesDetail", "conflictsDetail", "secretsDetail", "itemsDetail", "socialOrder", "physicalRules", "socialRules", "language", "culture", "worldKnowledge", "narratorName"]) as Partial<World>),
  };
}

function pickExtra(d: Record<string, unknown>, keys: string[]): Record<string, unknown> {
  const out: Record<string, unknown> = {};
  for (const k of keys) if (d[k] !== undefined && d[k] !== null) out[k] = d[k];
  return out;
}

export function commitDraft(draft: WorldDraft, ownerUserId: string): { world: World; characters: StammCharacter[] } {
  const worldId = uid("world");
  const spawnFromDraft = draftToSpawnCandidates(draft);
  const spawnCandidates = mergeSpawnCandidates(draft.world.spawnCandidates, spawnFromDraft);
  const presentNames = spawnCandidates.map((c) => c.name);
  const characters: StammCharacter[] = [];
  const world = hydrateWorld({
    id: worldId,
    name: draft.world.name,
    short: draft.world.short,
    long: draft.world.long,
    genre: draft.world.genre,
    tone: draft.world.tone ?? "",
    epoch: draft.world.epoch ?? "",
    geography: draft.world.geography ?? "",
    places: draft.world.places ?? [],
    rules: draft.world.rules ?? [],
    factions: draft.world.factions ?? [],
    timeline: draft.world.timeline ?? [],
    conflicts: draft.world.conflicts ?? [],
    items: draft.world.items ?? [],
    secrets: draft.world.secrets ?? [],
    history: draft.world.history ?? [],
    beings: draft.world.beings ?? [],
    knowledgeLimits: draft.world.knowledgeLimits ?? [],
    worldGoals: draft.world.worldGoals ?? [],
    startSituations: draft.world.startSituations ?? [],
    fateSeeds: draft.world.fateSeeds ?? [],
    fateEnabled: draft.world.fateEnabled ?? true,
    sourceName: draft.world.sourceName,
    sourceText: String((draft.world as { sourceText?: string }).sourceText || draft.world.long || ""),
    sourcePartIds: Array.isArray(draft.world.sourcePartIds) ? draft.world.sourcePartIds : [],
    characterIds: [],
    ownerUserId,
    atmosphere: draft.world.atmosphere ?? "",
    purpose: draft.world.purpose ?? "",
    visibility: draft.world.visibility ?? "public",
    typicalScenes: draft.world.typicalScenes ?? [],
    storyBeats: draft.world.storyBeats ?? [],
    ...draftWorldExtras(draft.world),
    spawnCandidates,
  });
  world.places = applySubplacesToPlaces(world.places, world.subplaces);
  if (!world.places.length) {
    world.places = [
      { id: "ort-1", name: "Erster Ort", description: world.short || "Noch unbeschrieben.", connections: [], rules: [], tags: [] },
    ];
  }
  if (!world.startSituations.length) {
    world.startSituations = [
      {
        id: "start",
        title: "Beginn",
        placeId: world.places[0]!.id,
        time: "jetzt",
        presentNames: presentNames.length ? presentNames : [],
        opening: world.short || `${world.name} liegt offen.`,
      },
    ];
  }
  for (const sit of world.startSituations) {
    if (!sit.placeId) sit.placeId = world.places[0]?.id || "";
    if (!sit.presentNames?.length) sit.presentNames = presentNames.slice();
  }
  if (!characters.length && !spawnCandidates.length) {
    const host = placeHost(world.id, world.name, world.places[0]?.name || "Erster Ort");
    characters.push(host);
    world.characterIds = [host.id];
    const sit = world.startSituations[0];
    if (sit && !sit.presentNames.length) sit.presentNames = [host.name];
  }
  return { world, characters };
}

function placeHost(worldId: string, worldName: string, placeName: string): StammCharacter {
  return hydrateCharacter({
    ...emptyCharacter(worldId, "Stimme des Ortes"),
    role: "Ortstimme",
    origin: worldName,
    occupation: "erste Stimme",
    biography: `Kennt ${worldName} und ${placeName}. Spricht, wenn sonst niemand da ist.`,
    personality: "nüchtern, beobachtend",
    typicalPhrases: ["Hier beginnt es.", "Der Ort ist noch offen."],
    isWorldNative: true,
    status: "bereit",
    typicalPlace: placeName,
  });
}

export function emptyManualWorld(name: string, ownerUserId: string): { world: World; characters: StammCharacter[] } {
  const id = uid("world");
  const hall = {
    id: "ort-1",
    name: "Erster Ort",
    description: "Noch unbeschrieben.",
    connections: [] as string[],
    rules: [] as string[],
    tags: [] as string[],
  };
  const world = hydrateWorld({
    id,
    name,
    short: "",
    long: "",
    genre: "",
    tone: "",
    epoch: "",
    geography: "",
    places: [hall],
    rules: [],
    factions: [],
    timeline: [],
    conflicts: [],
    items: [],
    secrets: [],
    history: [],
    beings: [],
    knowledgeLimits: [],
    worldGoals: [],
    startSituations: [
      {
        id: "start",
        title: "Beginn",
        placeId: "ort-1",
        time: "jetzt",
        presentNames: ["Stimme des Ortes"],
        opening: `${name} liegt offen. Die Stimme des Ortes ist da.`,
      },
    ],
    fateSeeds: [],
    fateEnabled: true,
    characterIds: [],
    ownerUserId,
    atmosphere: "",
    purpose: "",
    visibility: "public",
    typicalScenes: [],
    storyBeats: [],
  });
  const host = placeHost(id, name, hall.name);
  world.characterIds = [host.id];
  return { world, characters: [host] };
}

export function passagesForName(text: string, name: string, maxPassages = 8, width = 420): string[] {
  const raw = text || "";
  const n = (name || "").trim();
  if (!raw.trim() || n.length < 2) return [];
  const sents = raw.split(/[.!?\n]+/).map((s) => s.trim()).filter(Boolean);
  const needle = n.toLowerCase();
  const first = (n.split(/\s+/)[0] || needle).toLowerCase();
  const out: string[] = [];
  const seen = new Set<string>();
  for (let i = 0; i < sents.length; i++) {
    const sl = sents[i]!.toLowerCase();
    if (!sl.includes(needle) && (first.length < 3 || !sl.includes(first))) continue;
    let chunk = sents[i]!;
    if (chunk.length < width && sents[i + 1]) chunk = `${chunk}. ${sents[i + 1]}`;
    chunk = chunk.slice(0, width);
    const key = chunk.toLowerCase();
    if (seen.has(key)) continue;
    seen.add(key);
    out.push(chunk);
    if (out.length >= maxPassages) break;
  }
  return out;
}

function ownIchRe(name: string): RegExp | null {
  const first = ((name || "").split(/\s+/)[0] || "").replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
  return first.length >= 2 ? new RegExp(`ich bin\\s+${first}\\b`, "i") : null;
}

/** True when a sentence is the narrator's I/me/my, not this figure's own voice. */
export function foreignNarratorDeixis(name: string, s: string): boolean {
  const t = s || "";
  const own = ownIchRe(name);
  if (own && own.test(t)) return false;
  return /\b(ich|mir|mich|mein|meine|meinen|meinem|meiner)\b/i.test(t);
}

/** Passages the figure owns: no foreign first-person. Mentions alone are not knowledge. */
export function ownedPassagesForName(text: string, name: string, maxPassages = 8, width = 420): string[] {
  return passagesForName(text, name, maxPassages * 2, width)
    .filter((s) => {
      const t = (s || "").trim();
      if (!t) return false;
      if (foreignNarratorDeixis(name, t)) return false;
      return true;
    })
    .slice(0, maxPassages);
}

export function displayTitle(raw: string): string {
  const t = (raw || "").replace(/\s+/g, " ").trim();
  if (!t) return t;
  const letters = t.replace(/[^A-Za-zÄÖÜäöüß]/g, "");
  if (letters.length >= 8 && letters === letters.toUpperCase()) {
    return t.toLocaleLowerCase("de").replace(/(^|[\s\-–—:]\s*)(\S)/g, (_, a, c) => a + c.toLocaleUpperCase("de"));
  }
  return t;
}

export function localAnalyzeToDraft(local: Record<string, unknown>, fallbackName: string, sourceText = ""): WorldDraft {
  const world = (local.world || {}) as Record<string, unknown>;
  const rawChars = (local.characterCandidates || local.spawnCandidates || []) as Array<
    Partial<StammCharacter> & { name: string; biography?: string; origin?: string; role?: string }
  >;
  const startScenes = (world.startScenes as string[]) || [];
  const places = (world.places as World["places"]) || [];
  const blob = `${world.short || ""} ${world.long || ""} ${startScenes.join(" ")} ${sourceText.slice(0, 800)}`;
  const meaningSpaces = MEANING_SPACES.filter((m) => blob.toLowerCase().includes(m.toLowerCase()));
  const itemsRaw = world.items;
  const items = Array.isArray(itemsRaw)
    ? itemsRaw
        .map((it) => {
          if (typeof it === "string") return it;
          const row = it as { name?: string; text?: string };
          const name = String(row.name || "").trim();
          const text = String(row.text || "").trim();
          if (name && text && !text.toLowerCase().startsWith(name.toLowerCase())) return `${name}: ${text}`.slice(0, 180);
          return (text || name).slice(0, 180);
        })
        .filter(Boolean)
    : [];
  const characters = rawChars
    .filter((c) => c.name)
    .slice(0, 24)
    .map((c) => {
      // V26 (V1-Befund §1/§3/§4): Kandidaten aus der Provider-Analyse tragen fieldProvenance.
      // Für sie werden KEINE Textpassagen mehr als Wissen/Biografie/Kompass eingekopiert —
      // Zitate anderer über die Figur sind kein Stammwissen. Passagen-Heuristik nur lokal.
      const llmCand = Boolean((c as { fieldProvenance?: Record<string, string> }).fieldProvenance && Object.keys((c as { fieldProvenance?: Record<string, string> }).fieldProvenance || {}).length);
      const fromSource = llmCand ? [] : ownedPassagesForName(sourceText, c.name);
      const etymon = llmCand ? "" : String((c as { nameEtymon?: string }).nameEtymon || "").trim();
      const rawBio = String(c.biography || fromSource.join(". ") || "").slice(0, 1200);
      const biography = foreignNarratorDeixis(c.name, rawBio) ? fromSource.join(". ").slice(0, 1200) : rawBio;
      const analyzedKnowledge = (Array.isArray(c.knowledge) ? c.knowledge.map(String) : []).filter((x) => !foreignNarratorDeixis(c.name, x));
      const knowledge = [
        etymon,
        ...analyzedKnowledge,
        ...(analyzedKnowledge.length || llmCand ? [] : fromSource),
      ].filter((x, i, a) => x && a.indexOf(x) === i && !foreignNarratorDeixis(c.name, x)).slice(0, 8);
      const aliases = [
        c.name,
        ...(Array.isArray((c as { aliases?: string[] }).aliases) ? (c as { aliases: string[] }).aliases : []),
      ].filter((x, i, a) => x && a.findIndex((y) => y.toLowerCase() === x.toLowerCase()) === i);
      const relsRaw = Array.isArray((c as unknown as { relationships?: Array<{ from?: string; to?: string; kind?: string; text?: string }> }).relationships)
        ? (c as unknown as { relationships: Array<{ from?: string; to?: string; kind?: string; text?: string }> }).relationships
        : [];
      const stammRels = Array.isArray((c as { relations?: Array<{ targetName?: string; kind?: string; note?: string; trust?: number; closeness?: number; fear?: number }> }).relations)
        ? (c as { relations: Array<{ targetName?: string; kind?: string; note?: string; trust?: number; closeness?: number; fear?: number }> }).relations
        : [];
      const relWeight = (kind: string) => {
        const k = (kind || "kennt").toLowerCase();
        if (k === "liebe" || k === "bindung" || k === "familie") return { trust: 0.75, closeness: 0.75, fear: 0.1 };
        if (k === "vertrauen") return { trust: 0.85, closeness: 0.6, fear: 0.1 };
        if (k === "angst" || k === "feind" || k === "verrat") return { trust: 0.25, closeness: 0.2, fear: 0.65 };
        if (k === "dienst") return { trust: 0.45, closeness: 0.35, fear: 0.2 };
        if (k === "schutz") return { trust: 0.6, closeness: 0.5, fear: 0.25 };
        if (k === "nachbar") return { trust: 0.55, closeness: 0.35, fear: 0.2 };
        return { trust: 0.5, closeness: 0.4, fear: 0.1 };
      };
      const relations = (
        stammRels.length
          ? stammRels
              .filter((r) => r.targetName && r.targetName !== c.name)
              .map((r) => {
                const w = relWeight(String(r.kind || "kennt"));
                return {
                  targetName: String(r.targetName),
                  kind: String(r.kind || "kennt"),
                  note: String(r.note || "").slice(0, 180),
                  trust: Number(r.trust ?? w.trust),
                  closeness: Number(r.closeness ?? w.closeness),
                  fear: Number(r.fear ?? w.fear),
                };
              })
          : relsRaw
              .map((r) => {
                const target = r.from === c.name ? r.to : r.from;
                if (!target || target === c.name) return null;
                const w = relWeight(String(r.kind || "kennt"));
                const raw = r as { trust?: number; closeness?: number; fear?: number; text?: string };
                return {
                  targetName: String(target),
                  kind: String(r.kind || "kennt"),
                  note: String(raw.text || "").slice(0, 180),
                  trust: Number(raw.trust ?? w.trust),
                  closeness: Number(raw.closeness ?? w.closeness),
                  fear: Number(raw.fear ?? w.fear),
                };
              })
              .filter((x): x is NonNullable<typeof x> => Boolean(x))
      )
        .filter((x, i, a) => a.findIndex((y) => y.targetName === x.targetName) === i)
        .slice(0, 8);
      const arcRaw = Array.isArray((c as unknown as { development?: Array<{ beat?: string; text?: string }> }).development)
        ? (c as unknown as { development: Array<{ beat?: string; text?: string }> }).development
        : [];
      const beatLabel: Record<string, string> = { start: "Anfang", change: "Umschlag", later: "Später" };
      const canon = arcRaw
        .map((b) => {
          const lab = beatLabel[String(b.beat || "")] || "Beleg";
          const t = String(b.text || "").trim();
          return t ? `${lab}: ${t}` : "";
        })
        .filter(Boolean)
        .slice(0, 4);
      const phrase = llmCand ? "" : etymon || biography.split(/[.!?]/)[0]?.trim();
      const goalsIn = (Array.isArray(c.goals) ? c.goals.map(String) : []).filter((g) => !foreignNarratorDeixis(c.name, g));
      const fearsIn = (Array.isArray(c.fears) ? c.fears.map(String) : []).filter((g) => !foreignNarratorDeixis(c.name, g));
      const secretsIn = (Array.isArray(c.secrets) ? c.secrets.map(String) : []).filter((g) => !foreignNarratorDeixis(c.name, g));
      const valuesIn = Array.isArray((c as { values?: string[] }).values) ? (c as { values: string[] }).values.map(String) : [];
      const phrasesIn = Array.isArray((c as { typicalPhrases?: string[] }).typicalPhrases)
        ? (c as { typicalPhrases: string[] }).typicalPhrases.map(String)
        : [];
      const formed = llmCand ? ({} as Partial<StammCharacter>) : profileFromPassages(c.name, [etymon, biography, ...fromSource, ...goalsIn, ...fearsIn].filter(Boolean), c.role || "");
      const compass = fillCompass({
        ...(llmCand ? {} : compassFromPassages([etymon, biography, ...fromSource, ...goalsIn, ...fearsIn].filter(Boolean))),
        ...(((c as { compass?: Parameters<typeof fillCompass>[0] }).compass) || {}),
      });
      const appearance = String((c as { appearance?: string }).appearance || "").trim() || formed.appearance || "";
      const gender = String((c as { gender?: string }).gender || "").trim() || formed.gender || "";
      const occupation = String((c as { occupation?: string }).occupation || c.role || formed.occupation || "");
      const age = String((c as { age?: string }).age || "").trim() || formed.age || "";
      return {
        name: c.name,
        aliases,
        role: c.role || occupation || "",
        occupation,
        origin: c.origin || "",
        age,
        gender,
        dialect: String((c as { dialect?: string }).dialect || ""),
        humor: String((c as { humor?: string }).humor || ""),
        speechRegister: String((c as { speechRegister?: string }).speechRegister || "").trim() || (phrasesIn.length || formed.typicalPhrases?.length ? "Rede aus dem Original" : ""),
        typicalPlace: String((c as { typicalPlace?: string }).typicalPlace || c.origin || ""),
        worldNotes: String((c as { worldNotes?: string }).worldNotes || "").trim() || (etymon || biography.split(/[.!?]/)[0]?.trim() || "").slice(0, 240),
        biography: biography || formed.biography || "",
        personality: String((c as { personality?: string }).personality || "").trim() || formed.personality || "",
        appearance,
        relations,
        canon,
        goals: goalsIn.length ? goalsIn : formed.goals || [],
        fears: fearsIn.length ? fearsIn : formed.fears || [],
        knowledge,
        coreFacts: Array.isArray(c.coreFacts) ? c.coreFacts.map(String) : formed.coreFacts || [],
        secrets: secretsIn.length ? secretsIn : formed.secrets || [],
        values: valuesIn.length ? valuesIn : formed.values || [],
        likes: Array.isArray((c as { likes?: string[] }).likes) ? (c as { likes: string[] }).likes.map(String) : [],
        dislikes: Array.isArray((c as { dislikes?: string[] }).dislikes) ? (c as { dislikes: string[] }).dislikes.map(String) : [],
        taboos: Array.isArray((c as { taboos?: string[] }).taboos) ? (c as { taboos: string[] }).taboos.map(String) : [],
        favoriteWords: Array.isArray((c as { favoriteWords?: string[] }).favoriteWords)
          ? (c as { favoriteWords: string[] }).favoriteWords.map(String)
          : [],
        reactionRules: Array.isArray((c as { reactionRules?: string[] }).reactionRules)
          ? (c as { reactionRules: string[] }).reactionRules.map(String)
          : formed.conflictStyle
            ? [formed.conflictStyle]
            : [],
        bindingPatterns: Array.isArray((c as { bindingPatterns?: string[] }).bindingPatterns)
          ? (c as { bindingPatterns: string[] }).bindingPatterns.map(String)
          : relations.map((r) => `${r.kind} · ${r.targetName}`).slice(0, 4),
        conflictStyle: String((c as { conflictStyle?: string }).conflictStyle || "").trim() || formed.conflictStyle || "",
        typicalPhrases: phrasesIn.length ? phrasesIn : phrase ? [phrase.slice(0, 160)] : formed.typicalPhrases || [],
        species: String((c as { species?: string }).species || "").trim() || (gender ? "Mensch" : ""),
        lastingAbilities: Array.isArray((c as { lastingAbilities?: string[] }).lastingAbilities)
          ? (c as { lastingAbilities: string[] }).lastingAbilities.map(String)
          : [],
        drives: Array.isArray((c as { drives?: unknown[] }).drives) ? ((c as { drives: Array<{ drive: string; strength: number; evidence?: string }> }).drives) : [],
        fieldProvenance: ((c as { fieldProvenance?: Record<string, string> }).fieldProvenance || {}),
        compass,
        sourceRefs: [fallbackName],
        isWorldNative: true,
        status: "bereit" as const,
      };
    });
  const opening = stripHeadingPrefix(startScenes[0] || String(world.short || sourceText.slice(0, 180) || `${fallbackName} liegt offen.`));
  const openingLow = opening.toLowerCase();
  const presentFromOpening = characters
    .filter((c) => {
      const first = (c.name.split(" ")[0] || "").toLowerCase();
      return (first.length >= 3 && openingLow.includes(first)) || openingLow.includes(c.name.toLowerCase());
    })
    .map((c) => c.name);
  const narratorName = String((world as { narratorName?: string }).narratorName || "").trim();
  if (!presentFromOpening.length && narratorName && characters.some((c) => c.name === narratorName)) {
    presentFromOpening.push(narratorName);
  }
  const startPlace = String(places[0]?.name || "").toLowerCase();
  for (const c of characters) {
    const tp = String(c.typicalPlace || c.origin || "").toLowerCase();
    if (!startPlace || !tp) continue;
    if (!(tp.includes(startPlace) || startPlace.includes(tp))) continue;
    if (!presentFromOpening.some((n) => n.toLowerCase() === c.name.toLowerCase())) presentFromOpening.push(c.name);
  }
  const shortRaw = String(world.short || "");
  const short = stripHeadingPrefix(shortRaw) || opening.slice(0, 180);
  const knowledgeLimits = Array.isArray(world.knowledgeLimits) && (world.knowledgeLimits as string[]).length
    ? (world.knowledgeLimits as string[])
    : ((world.knowledgeBounds as string[]) || []);
  return {
    world: {
      name: displayTitle(String(world.name || fallbackName)),
      short: short.slice(0, 180),
      long: stripHeadingPrefix(String(world.long || short || sourceText.slice(0, 1200))).slice(0, 1200),
      genre: String(world.genre || ""),
      tone: String(world.tone || world.atmosphere || ""),
      epoch: String(world.epoch || ""),
      geography: String(world.geography || ""),
      atmosphere: stripHeadingPrefix(String(world.atmosphere || opening)).slice(0, 240),
      purpose: stripHeadingPrefix(String(world.purpose || (Array.isArray(world.storyGoals) ? world.storyGoals[0] : "") || "")).slice(0, 240),
      sourceName: fallbackName,
      sourceText,
      places,
      rules: (world.rules as World["rules"]) || [],
      factions: (world.factions as World["factions"]) || [],
      timeline: (world.timeline as World["timeline"]) || [],
      conflicts: (world.conflicts as string[]) || [],
      items,
      history: (world.history as string[]) || [],
      secrets: (world.secretKnowledge as string[]) || [],
      culture: (world.culture as string[]) || [],
      language: (world.language as string[]) || [],
      worldKnowledge: (world.worldKnowledge as string[]) || [],
      secretKnowledge: (world.secretKnowledge as string[]) || [],
      knowledgeBounds: (world.knowledgeBounds as string[]) || knowledgeLimits,
      knowledgeLimits,
      startScenes,
      typicalScenes: Array.isArray((world as { typicalScenes?: string[] }).typicalScenes)
        ? ((world as { typicalScenes: string[] }).typicalScenes)
        : startScenes,
      storyGoals: (world.storyGoals as string[]) || [],
      worldGoals: (world.worldGoals as string[]) || (world.storyGoals as string[]) || [],
      fateBeats: (world.fateBeats as string[]) || [],
      fateSeeds: Array.isArray(world.fateSeeds) && world.fateSeeds.length
        ? (world.fateSeeds as World["fateSeeds"])
        : ((world.fateBeats as string[]) || []).slice(0, 5).map((beat, i) => ({
            id: `seed_${i + 1}`,
            title: String(beat).slice(0, 48),
            pressure: String(beat).slice(0, 160),
            tags: [] as World["fateSeeds"][number]["tags"],
            beat: String(beat).slice(0, 240),
            mustNot: "Kein erfundenes Wissen. Abwesende wissen nichts. Avatar nicht steuern.",
          })),
      storyBeats: Array.isArray(world.storyBeats) && world.storyBeats.length
        ? (world.storyBeats as World["storyBeats"])
        : (world.timeline as World["timeline"] || []).slice(0, 8).map((ev, i) => ({
            id: `beat_${i + 1}`,
            title: String(ev.when || ev.text || `Beat ${i + 1}`).slice(0, 48),
            text: String(ev.text || "").slice(0, 240),
          })),
      fateEnabled: world.fateEnabled !== false,
      figureRelations: world.figureRelations,
      subplaces: world.subplaces,
      placeRelations: world.placeRelations,
      // V49: Meta/Facetten/Details/Provenienz aus dem universellen Extraktor mitnehmen
      ...pickExtra(world, ["textMeta", "facetsSummary", "worldProvenance", "rulesDetail", "conflictsDetail", "secretsDetail", "itemsDetail", "socialOrder", "physicalRules", "socialRules", "language", "culture", "worldKnowledge", "narratorName"]),
      startSituations: [
        {
          id: "start",
          title: (startScenes[0] || "Beginn").slice(0, 48),
          placeId: places[0]?.id || "",
          time: "jetzt",
          presentNames: presentFromOpening.length ? presentFromOpening : characters.slice(0, 3).map((c) => c.name),
          opening,
        },
      ],
      meaningSpaces,
    } as WorldDraft["world"] & { meaningSpaces?: string[] },
    characters,
    recognize: local.recognize === "llm" ? "llm" : "local",
    keywords: Array.isArray(local.keywords) ? local.keywords.map(String).filter(Boolean).slice(0, 12) : [],
  };
}

function filled<T>(next: T | undefined, prev: T): T {
  if (next === undefined || next === null) return prev;
  if (typeof next === "string") return (next.trim() ? next : prev) as T;
  if (Array.isArray(next)) return ((next.length ? next : prev) as T);
  return next;
}

/** Overlay LLM/local complete onto an already shown draft. Empty never wins. */
export function applyCompletedProfiles(
  draft: WorldDraft,
  rows: Array<Partial<StammCharacter> & { name?: string }>,
): WorldDraft {
  const by = new Map(rows.filter((r) => r.name).map((r) => [String(r.name).toLowerCase(), r]));
  return {
    ...draft,
    characters: draft.characters.map((c) => {
      const p = by.get(c.name.toLowerCase());
      if (!p) return c;
      return {
        ...c,
        role: filled(p.role, c.role),
        occupation: filled(p.occupation, c.occupation),
        age: filled(p.age, c.age),
        gender: filled(p.gender, c.gender),
        origin: filled(p.origin, c.origin),
        personality: filled(p.personality, c.personality),
        appearance: filled(p.appearance, c.appearance),
        speechRegister: filled(p.speechRegister, c.speechRegister),
        dialect: filled(p.dialect, c.dialect),
        humor: filled(p.humor, c.humor),
        conflictStyle: filled(p.conflictStyle, c.conflictStyle),
        typicalPlace: filled(p.typicalPlace, c.typicalPlace),
        worldNotes: filled(p.worldNotes, c.worldNotes),
        biography: filled(p.biography, c.biography),
        goals: filled(p.goals, c.goals),
        fears: filled(p.fears, c.fears),
        secrets: filled(p.secrets, c.secrets),
        values: filled(p.values, c.values),
        likes: filled(p.likes, c.likes),
        dislikes: filled(p.dislikes, c.dislikes),
        taboos: filled(p.taboos, c.taboos),
        typicalPhrases: filled(p.typicalPhrases, c.typicalPhrases),
        favoriteWords: filled(p.favoriteWords, c.favoriteWords),
        reactionRules: filled(p.reactionRules, c.reactionRules),
        bindingPatterns: filled(p.bindingPatterns, c.bindingPatterns),
        knowledge: filled(p.knowledge, c.knowledge),
        relations: filled(p.relations, c.relations),
        lastingAbilities: filled(p.lastingAbilities, c.lastingAbilities),
        drives: Array.isArray((p as { drives?: unknown[] }).drives) && (p as { drives: unknown[] }).drives.length ? ((p as { drives: Array<{ drive: string; strength: number; evidence?: string }> }).drives) : ((c as { drives?: Array<{ drive: string; strength: number; evidence?: string }> }).drives ?? []),
        fieldProvenance: { ...((c as unknown as { fieldProvenance?: Record<string, string> }).fieldProvenance || {}), ...((p as unknown as { fieldProvenance?: Record<string, string> }).fieldProvenance || {}) },
      } as typeof c;
    }),
  };
}

export function extendWorldFromDraft(
  world: World,
  existing: StammCharacter[],
  draft: WorldDraft,
): { world: World; characters: StammCharacter[] } {
  const havePlaces = new Set(world.places.map((p) => p.name.toLowerCase()));
  // AMASTER §13: name is not identity. Existing Stamm stays untouched.
  // Same-named draft figures become spawn candidates, never silent field merges.
  const mergedChars: StammCharacter[] = existing.slice();
  const fillStr = (cur: string | undefined, next: string | undefined) => (cur && cur.trim() ? cur : (next || "").trim());
  const places = [...world.places];
  for (const p of draft.world.places ?? []) {
    if (havePlaces.has(p.name.toLowerCase())) continue;
    places.push({ ...p, id: p.id || uid("ort") });
  }
  const mergeLines = (a: string[], b?: string[]) => Array.from(new Set([...a, ...(b ?? [])]));
  const headingDump = (s: string) => {
    const t = (s || "").trim();
    if (!t) return true;
    if (/^#+\s/.test(t)) return true;
    if (/^(?:PROLOG|EPILOG|KAPITEL|CHAPTER)\b/i.test(t) && /PROLOG|EPILOG|KAPITEL|CHAPTER/i.test(t.slice(0, 40))) return true;
    return false;
  };
  const next: World = hydrateWorld({
    ...world,
    places,
    epoch: fillStr(world.epoch, draft.world.epoch),
    geography: fillStr(world.geography, draft.world.geography),
    atmosphere: headingDump(world.atmosphere) ? stripHeadingPrefix(draft.world.atmosphere || world.atmosphere) : fillStr(world.atmosphere, draft.world.atmosphere),
    purpose: headingDump(world.purpose) ? stripHeadingPrefix(draft.world.purpose || world.purpose) : fillStr(world.purpose, draft.world.purpose),
    tone: fillStr(world.tone, draft.world.tone),
    genre: fillStr(world.genre, draft.world.genre),
    short: headingDump(world.short) ? stripHeadingPrefix(draft.world.short || world.short) : world.short,
    rules: [...world.rules, ...(draft.world.rules ?? []).filter((r) => !world.rules.some((x) => x.text === r.text))],
    factions: [...world.factions, ...(draft.world.factions ?? []).filter((f) => !world.factions.some((x) => x.name === f.name))],
    timeline: [...world.timeline, ...(draft.world.timeline ?? [])],
    conflicts: mergeLines(world.conflicts, draft.world.conflicts),
    items: mergeLines(world.items, draft.world.items),
    secrets: mergeLines(world.secrets, draft.world.secrets),
    history: mergeLines(world.history, draft.world.history),
    beings: mergeLines(world.beings, draft.world.beings),
    knowledgeLimits: mergeLines(world.knowledgeLimits, draft.world.knowledgeLimits),
    worldGoals: mergeLines(world.worldGoals, draft.world.worldGoals || draft.world.storyGoals),
    typicalScenes: mergeLines(world.typicalScenes, draft.world.typicalScenes || draft.world.startScenes),
    fateSeeds: world.fateSeeds?.length ? world.fateSeeds : (draft.world.fateSeeds || []),
    storyBeats: world.storyBeats?.length ? world.storyBeats : (draft.world.storyBeats || []),
    secretKnowledge: mergeLines(world.secretKnowledge || [], draft.world.secretKnowledge),
    culture: mergeLines(world.culture || [], draft.world.culture),
    language: mergeLines(world.language || [], draft.world.language),
    worldKnowledge: mergeLines(world.worldKnowledge || [], draft.world.worldKnowledge),
    knowledgeBounds: mergeLines(world.knowledgeBounds || [], draft.world.knowledgeBounds || draft.world.knowledgeLimits),
    startScenes: mergeLines(world.startScenes || [], draft.world.startScenes),
    storyGoals: mergeLines(world.storyGoals || [], draft.world.storyGoals || draft.world.worldGoals),
    fateBeats: mergeLines(world.fateBeats || [], draft.world.fateBeats),
    figureRelations: mergeRelRows(world.figureRelations, draft.world.figureRelations),
    subplaces: [...(world.subplaces || []), ...(draft.world.subplaces || [])].slice(0, 24),
    placeRelations: mergeRelRows(world.placeRelations, draft.world.placeRelations),
    characterIds: Array.from(new Set([...world.characterIds, ...mergedChars.map((c) => c.id)])),
    spawnCandidates: mergeSpawnCandidates(world.spawnCandidates, draftToSpawnCandidates(draft)),
    long: headingDump(world.long)
      ? stripHeadingPrefix(draft.world.long || world.long)
      : stripHeadingPrefix(world.long || draft.world.long || ""),
    sourceName: world.sourceName || draft.world.sourceName || "",
    sourceText: world.sourceText || String((draft.world as { sourceText?: string }).sourceText || ""),
    sourcePartIds: world.sourcePartIds?.length
      ? world.sourcePartIds
      : Array.isArray(draft.world.sourcePartIds)
        ? draft.world.sourcePartIds
        : [],
  });
  next.places = applySubplacesToPlaces(next.places, next.subplaces);
  return { world: next, characters: mergedChars };
}

export function downloadJson(filename: string, data: unknown) {
  const blob = new Blob([JSON.stringify(data, null, 2)], { type: "application/json" });
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = filename;
  a.click();
  URL.revokeObjectURL(url);
}

export function packWorld(world: World, characters: StammCharacter[]): WorldPack {
  return {
    kind: "matrix10-world-pack",
    version: 1,
    world,
    characters: characters.filter((c) => c.worldId === world.id),
    exportedAt: new Date().toISOString(),
  };
}

export function packCharacter(c: StammCharacter) {
  return {
    kind: "matrix10-character-pack",
    version: 1,
    character: c,
    exportedAt: new Date().toISOString(),
  };
}

export function remapPack(pack: WorldPack, ownerUserId: string): { world: World; characters: StammCharacter[] } {
  const worldId = uid("world");
  const idMap = new Map<string, string>();
  const raw = pack.characters.map((c) => {
    const id = uid("char");
    idMap.set(c.id, id);
    return { ...c, id, worldId };
  });
  const characters = raw.map((c) =>
    hydrateCharacter({
      ...c,
      relations: (c.relations ?? []).map((r) =>
        r.targetId ? { ...r, targetId: idMap.get(r.targetId) ?? r.targetId } : r,
      ),
    }),
  );
  const world = hydrateWorld({
    ...pack.world,
    id: worldId,
    ownerUserId,
    characterIds: characters.map((c) => c.id),
    explicitOnly: false,
  });
  return { world, characters };
}

export function emptyPreference(characterId: string): Preference {
  return {
    id: uid("pref"),
    characterId,
    target: "",
    valence: "pos",
    category: "allgemein",
    intensity: 0.5,
    text: "",
  };
}

export function displayNameKey(name: string): string {
  return (name || "").trim().toLowerCase();
}

export function spawnCandidateKey(c: { id?: string; name?: string }, index = 0): string {
  const id = String(c.id || "").trim();
  if (id) return id;
  return `cand-row-${index}`;
}

export function sameNameStamm(name: string, stamm: StammCharacter[]): StammCharacter[] {
  const k = displayNameKey(name);
  if (!k) return [];
  return stamm.filter((c) => displayNameKey(c.name) === k);
}

export type SpawnDupDecision = "new" | "assign" | "discard";

export function resolveSpawnAction(opts: {
  candidate: SpawnCandidate;
  stamm: StammCharacter[];
  picked: boolean;
  decision?: SpawnDupDecision | "";
}): {
  action: "keep" | "spawn-new" | "assign" | "discard" | "need-decision";
  matches: StammCharacter[];
} {
  const matches = sameNameStamm(opts.candidate.name, opts.stamm);
  const decision = opts.decision || "";
  if (decision === "discard") return { action: "discard", matches };
  if (decision === "assign") {
    if (!matches.length) return { action: "need-decision", matches };
    return { action: "assign", matches };
  }
  if (decision === "new") {
    if (!opts.picked) return { action: "keep", matches };
    return { action: "spawn-new", matches };
  }
  if (matches.length && opts.picked) return { action: "need-decision", matches };
  if (opts.picked) return { action: "spawn-new", matches };
  return { action: "keep", matches };
}

export function applyCandidateToStamm(stamm: StammCharacter, c: SpawnCandidate): StammCharacter {
  const takeStr = (next: string | undefined, cur: string) => (next && next.trim() ? next.trim() : cur);
  const takeArr = (next: string[] | undefined, cur: string[]) => (next && next.length ? next : cur);
  return hydrateCharacter({
    ...stamm,
    role: takeStr(c.role, stamm.role),
    origin: takeStr(c.origin, stamm.origin),
    biography: takeStr(c.biography, stamm.biography),
    personality: takeStr(c.personality, stamm.personality),
    appearance: takeStr(c.appearance, stamm.appearance),
    goals: takeArr(c.goals, stamm.goals || []),
    fears: takeArr(c.fears, stamm.fears || []),
    secrets: takeArr(c.secrets, stamm.secrets || []),
    values: takeArr(c.values, stamm.values || []),
    knowledge: takeArr(c.knowledge, stamm.knowledge || []),
    speechRegister: takeStr(c.speechProfile, stamm.speechRegister),
    typicalPhrases: takeArr(c.typicalPhrases, stamm.typicalPhrases || []),
    taboos: takeArr(c.taboos, stamm.taboos || []),
    relations: c.stammRelations?.length ? c.stammRelations : stamm.relations || [],
    coreFacts: takeArr(c.traits, stamm.coreFacts || []),
    // V25.1 CHAR-01: alle Frontend-Profilfelder aus dem Kandidaten übernehmen
    age: takeStr(c.age, stamm.age || ""),
    gender: takeStr(c.gender, stamm.gender || ""),
    occupation: takeStr(c.occupation, stamm.occupation || ""),
    dialect: takeStr(c.dialect, stamm.dialect || ""),
    humor: takeStr(c.humor, stamm.humor || ""),
    conflictStyle: takeStr(c.conflictStyle || (c.conflicts && c.conflicts[0]) || undefined, stamm.conflictStyle || ""),
    typicalPlace: takeStr(c.typicalPlace, stamm.typicalPlace || ""),
    worldNotes: takeStr(c.worldNotes, stamm.worldNotes || ""),
    likes: takeArr(c.likes, stamm.likes || []),
    dislikes: takeArr(c.dislikes, stamm.dislikes || []),
    favoriteWords: takeArr(c.favoriteWords, stamm.favoriteWords || []),
    reactionRules: takeArr(c.reactionRules, stamm.reactionRules || []),
    bindingPatterns: takeArr(c.bindingPatterns, stamm.bindingPatterns || []),
    lastingAbilities: takeArr(c.lastingAbilities, stamm.lastingAbilities || []),
    drives: Array.isArray((c as { drives?: unknown[] }).drives) && (c as { drives: unknown[] }).drives.length ? ((c as { drives: Array<{ drive: string; strength: number; evidence?: string }> }).drives) : ((stamm as { drives?: Array<{ drive: string; strength: number; evidence?: string }> }).drives ?? []),
    fieldProvenance: { ...((stamm as unknown as { fieldProvenance?: Record<string, string> }).fieldProvenance || {}), ...(c.fieldProvenance || {}) },
    canBeAvatar: c.canBeAvatar ? true : stamm.canBeAvatar,
    sourceRefs: Array.from(new Set([...(stamm.sourceRefs || []), c.source, c.id].filter(Boolean))),
  });
}

export function mergeSpawnCandidates(
  base: SpawnCandidate[] | undefined,
  incoming: SpawnCandidate[] | undefined,
  _skipNames: string[] = [],
): SpawnCandidate[] {
  const seen = new Set<string>();
  const out: SpawnCandidate[] = [];
  for (const c of [...(incoming || []), ...(base || [])]) {
    const name = (c.name || "").trim();
    if (!name) continue;
    const row = emptySpawnCandidate({ ...c, name });
    if (seen.has(row.id)) continue;
    seen.add(row.id);
    out.push(row);
  }
  return out.slice(0, 24);
}

export function draftToSpawnCandidates(draft: WorldDraft, _existingNames: string[] = []): SpawnCandidate[] {
  const source = String(draft.world.sourceName || "analyse");
  const worldName = String(draft.world.name || "");
  const out: SpawnCandidate[] = [];
  for (const c of (draft.characters || []).slice(0, 24)) {
    const name = (c.name || "").trim();
    if (!name) continue;
    const stammRel = Array.isArray(c.relations) ? c.relations.filter((r) => r.targetName) : [];
    const filled = (key: string) => {
      const v = (c as Record<string, unknown>)[key];
      if (typeof v === "string") return Boolean(v.trim());
      return Array.isArray(v) && v.length > 0;
    };
    out.push(
      emptySpawnCandidate({
        id: uid("cand"),
        name,
        role: c.role || "",
        origin: c.origin || worldName,
        biography: c.biography || "",
        source,
        worldRef: worldName,
        goals: c.goals || [],
        fears: c.fears || [],
        secrets: c.secrets || [],
        values: c.values || [],
        knowledge: c.knowledge || [],
        speechProfile: c.speechRegister || "",
        personality: c.personality || "",
        appearance: c.appearance || "",
        typicalPhrases: c.typicalPhrases || [],
        taboos: c.taboos || [],
        stammRelations: stammRel,
        relations: stammRel.map((r) => `${r.kind} · ${r.targetName}`),
        compass: c.compass,
        canBeAvatar: Boolean(c.canBeAvatar),
        traits: c.coreFacts || [],
        bodyNotes: c.body?.notes || "",
        conflicts: c.conflictStyle ? [c.conflictStyle] : [],
        age: c.age || "",
        gender: c.gender || "",
        occupation: c.occupation || "",
        dialect: c.dialect || "",
        humor: c.humor || "",
        conflictStyle: c.conflictStyle || "",
        typicalPlace: c.typicalPlace || "",
        worldNotes: c.worldNotes || "",
        likes: c.likes || [],
        dislikes: c.dislikes || [],
        favoriteWords: c.favoriteWords || [],
        reactionRules: c.reactionRules || [],
        bindingPatterns: c.bindingPatterns || [],
        lastingAbilities: c.lastingAbilities || [],
        drives: (c as { drives?: Array<{ drive: string; strength: number; evidence?: string }> }).drives || [],
        fieldProvenance: ((c as unknown as { fieldProvenance?: Record<string, string> }).fieldProvenance || (c as unknown as { provenance?: Record<string, string> }).provenance || {}),
        directFields: Object.entries(((c as unknown as { fieldProvenance?: Record<string, string> }).fieldProvenance || {})).filter(([, v]) => v === "belegt").map(([k]) => k).length
          ? ["name", ...Object.entries(((c as unknown as { fieldProvenance?: Record<string, string> }).fieldProvenance || {})).filter(([, v]) => v === "belegt").map(([k]) => k)]
          : ["name", ...(c.role ? ["role"] : []), ...(c.origin ? ["origin"] : [])],
        derivedFields: Object.entries(((c as unknown as { fieldProvenance?: Record<string, string> }).fieldProvenance || {})).filter(([, v]) => v !== "belegt").map(([k]) => k).length
          ? Object.entries(((c as unknown as { fieldProvenance?: Record<string, string> }).fieldProvenance || {})).filter(([, v]) => v !== "belegt").map(([k]) => k)
          : ["biography", "goals", "fears", "secrets"].filter((f) => filled(f)),
        uncertainties: c.biography ? [] : ["Kein Originalbeleg"],
      }),
    );
  }
  return out;
}

export function emptySpawnCandidate(partial: Partial<SpawnCandidate> & { name: string }): SpawnCandidate {
  return {
    age: partial.age || "",
    gender: partial.gender || "",
    occupation: partial.occupation || "",
    dialect: partial.dialect || "",
    humor: partial.humor || "",
    conflictStyle: partial.conflictStyle || "",
    typicalPlace: partial.typicalPlace || "",
    worldNotes: partial.worldNotes || "",
    likes: partial.likes || [],
    dislikes: partial.dislikes || [],
    favoriteWords: partial.favoriteWords || [],
    reactionRules: partial.reactionRules || [],
    bindingPatterns: partial.bindingPatterns || [],
    lastingAbilities: partial.lastingAbilities || [],
    drives: (partial as { drives?: Array<{ drive: string; strength: number; evidence?: string }> }).drives || [],
    fieldProvenance: partial.fieldProvenance || {},
    id: String(partial.id || "").trim() || uid("cand"),
    name: partial.name,
    role: partial.role || "",
    origin: partial.origin || "",
    biography: partial.biography || "",
    source: partial.source || "",
    worldRef: partial.worldRef || partial.origin || "",
    goals: partial.goals || [],
    fears: partial.fears || [],
    secrets: partial.secrets || [],
    values: partial.values || [],
    conflicts: partial.conflicts || [],
    relations: partial.relations || [],
    stammRelations: (partial.stammRelations || []) as StammRelation[],
    knowledge: partial.knowledge || [],
    speechProfile: partial.speechProfile || "",
    personality: partial.personality || "",
    appearance: partial.appearance || "",
    typicalPhrases: partial.typicalPhrases || [],
    taboos: partial.taboos || [],
    bodyNotes: partial.bodyNotes || "",
    traits: partial.traits || [],
    compass: partial.compass,
    uncertainties: partial.uncertainties || [],
    derivedFields: partial.derivedFields || ["biography", "role"],
    directFields: partial.directFields || ["name", "source"],
    canBeAvatar: Boolean(partial.canBeAvatar),
  };
}

export function localSpawnCandidates(
  world: World,
  _existingNames: string[] = [],
): SpawnCandidate[] {
  const stored = (world.spawnCandidates || []).filter((c) => c.name);
  if (stored.length) {
    return stored.slice(0, 24).map((c) => emptySpawnCandidate({ ...c, name: c.name }));
  }
  const out: SpawnCandidate[] = [];
  const derived = new Set<string>();
  const push = (name: string, role: string, biography: string, source: string, extra?: Partial<SpawnCandidate>) => {
    const n = name.split(/[,:(]/)[0]?.trim() || "";
    if (!n || n.length < 2) return;
    const derivedKey = `${source}:${n.toLowerCase()}`;
    if (derived.has(derivedKey)) return;
    derived.add(derivedKey);
    out.push(
      emptySpawnCandidate({
        name: n,
        role,
        origin: world.name,
        biography,
        source,
        worldRef: world.name,
        ...extra,
      }),
    );
  };
  for (const b of world.beings ?? []) push(b, "Wesen", b, "beings", { traits: [b], directFields: ["name"], derivedFields: ["role"] });
  for (const f of world.factions ?? []) {
    for (const m of f.members ?? []) push(m, f.name, f.description, "faction", { relations: [f.name], knowledge: [f.description].filter(Boolean) });
    if ((f.members ?? []).length === 0) push(f.name, "Fraktion", f.description, "faction");
  }
  for (const t of world.timeline ?? []) {
    for (const a of t.actors ?? []) push(a, "Timeline", t.text, "timeline", { knowledge: [t.text], uncertainties: ["Rolle nur aus Timeline abgeleitet"] });
  }
  return out.slice(0, 12);
}

export type DraftFieldGroup = {
  field: string;
  label: string;
  preview: string;
  newValue: string;
  kind: "world" | "spawn";
};

function compactDraftValue(value: unknown): string {
  if (value == null || value === "") return "";
  if (typeof value === "string") return value.trim();
  if (typeof value === "number" || typeof value === "boolean") return String(value);
  if (Array.isArray(value)) {
    if (!value.length) return "";
    return JSON.stringify(value);
  }
  if (typeof value === "object") {
    if (!Object.keys(value as object).length) return "";
    return JSON.stringify(value);
  }
  return String(value);
}

export function draftFieldGroups(draft: WorldDraft): DraftFieldGroup[] {
  const w = draft.world as World & Record<string, unknown>;
  const out: DraftFieldGroup[] = [];
  const push = (field: string, label: string, value: unknown, kind: "world" | "spawn" = "world") => {
    const newValue = compactDraftValue(value);
    if (!newValue) return;
    out.push({
      field,
      label,
      preview: newValue.length > 220 ? `${newValue.slice(0, 220)}…` : newValue,
      newValue: newValue.slice(0, 4000),
      kind,
    });
  };
  push("genre", "Genre", w.genre);
  push("tone", "Register / Ton", w.tone || w.atmosphere);
  push("places", "Orte", w.places);
  push("subplaces", "Unterorte", w.subplaces);
  push("rules", "Regeln", w.rules);
  push("factions", "Fraktionen", w.factions);
  push("conflicts", "Konflikte", w.conflicts);
  push("timeline", "Timeline", w.timeline);
  push("items", "Gegenstände", w.items);
  push("history", "Geschichte", w.history);
  push("culture", "Kultur", w.culture);
  push("language", "Sprache", w.language);
  push("worldKnowledge", "Weltwissen", w.worldKnowledge);
  push("secretKnowledge", "Geheimes Wissen", w.secretKnowledge || w.secrets);
  push("knowledgeBounds", "Wissensgrenzen", w.knowledgeBounds || w.knowledgeLimits);
  push("startScenes", "Startszenen", (w.startSituations && w.startSituations.length ? w.startSituations : w.startScenes) || []);
  push("storyGoals", "Storyziele", w.storyGoals || w.worldGoals);
  push("fateBeats", "Fate-Beats", w.fateBeats || w.fateSeeds);
  const blob = `${w.long || ""} ${w.short || ""} ${JSON.stringify(w.fateBeats || w.fateSeeds || [])}`.toLowerCase();
  const spaces = Array.isArray(w.meaningSpaces)
    ? w.meaningSpaces
    : MEANING_SPACES.filter((m) => blob.includes(m.toLowerCase()));
  push("meaningSpaces", "Bedeutungsräume", spaces);
  push("figureRelations", "Figurenbeziehungen", w.figureRelations);
  push("long", "Langtext", w.long);
  push("characters", "Figurenkandidaten", draft.characters, "spawn");
  return out;
}

export function applyDraftGroupPick(draft: WorldDraft, pick: Record<string, boolean>): WorldDraft {
  const w = { ...draft.world };
  if (pick.genre === false) w.genre = "";
  if (pick.tone === false) {
    w.tone = "";
    w.atmosphere = "";
  }
  if (pick.places === false) w.places = [];
  if (pick.subplaces === false) w.subplaces = [];
  if (pick.rules === false) w.rules = [];
  if (pick.factions === false) w.factions = [];
  if (pick.conflicts === false) w.conflicts = [];
  if (pick.timeline === false) w.timeline = [];
  if (pick.items === false) w.items = [];
  if (pick.history === false) w.history = [];
  if (pick.culture === false) w.culture = [];
  if (pick.language === false) w.language = [];
  if (pick.worldKnowledge === false) w.worldKnowledge = [];
  if (pick.secretKnowledge === false) {
    w.secretKnowledge = [];
    w.secrets = [];
  }
  if (pick.knowledgeBounds === false) {
    w.knowledgeBounds = [];
    w.knowledgeLimits = [];
  }
  if (pick.startScenes === false) {
    w.startSituations = [];
    w.startScenes = [];
  }
  if (pick.storyGoals === false) {
    w.storyGoals = [];
    w.worldGoals = [];
  }
  if (pick.fateBeats === false) {
    w.fateBeats = [];
    w.fateSeeds = [];
  }
  if (pick.figureRelations === false) w.figureRelations = [];
  if (pick.long === false) w.long = "";
  return {
    world: w,
    characters: pick.characters === false ? [] : draft.characters,
  };
}
