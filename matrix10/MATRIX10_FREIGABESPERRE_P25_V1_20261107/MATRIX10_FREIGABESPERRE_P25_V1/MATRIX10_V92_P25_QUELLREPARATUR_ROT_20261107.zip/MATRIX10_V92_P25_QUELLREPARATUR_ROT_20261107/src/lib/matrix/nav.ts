export const NAV = [
  { to: "/", label: "Start" },
  { to: "/chat", label: "Chat" },
  { to: "/welt", label: "Welten" },
  { to: "/charakter", label: "Figuren" },
  { to: "/upload", label: "Upload" },
  { to: "/config", label: "Config" },
  { to: "/diagnose", label: "Diagnose" },
] as const;

export const NAV_MORE = [
  { to: "/timeline", label: "Timeline" },
  { to: "/memory", label: "Gedächtnis" },
  { to: "/social", label: "Beziehungen" },
  { to: "/fate", label: "Fate" },
  { to: "/review", label: "Review" },
  { to: "/triggers", label: "Trigger" },
  { to: "/labor", label: "Labor" },
  { to: "/admin", label: "Admin" },
  { to: "/logs", label: "Logs" },
  { to: "/user", label: "User" },
] as const;
