import type { FormulateResult, Spiegel } from "./types.ts";

export function finalizeFormulate(spiegel: Spiegel, raw: FormulateResult): FormulateResult {
  let speech = (raw.speech ?? "").trim();
  let action = raw.action ? raw.action.trim() : null;

  if (!speech) speech = spiegel.fired[0]?.cell.speech || spiegel.fired[0]?.cell.reaction || "…";

  const cannot = spiegel.body.cannotDo.map((x) => x.toLowerCase());
  if (action) {
    const a = action.toLowerCase();
    const blocked =
      (cannot.some((c) => /fessel|festgehalten|nicht frei/.test(c)) && /rennt|läuft|geht|schlägt|greift/.test(a)) ||
      (cannot.some((c) => /knebel|nicht sprechen/.test(c)) && /sagt|ruft|schreit/.test(a)) ||
      (spiegel.runtime.consciousness < 0.25 && action.length > 0) ||
      (spiegel.runtime.mobility < 0.25 && /rennt|steht auf|läuft|geht/.test(a));
    if (blocked) action = null;
  }

  const secretLeak = spiegel.unknown;
  for (const u of secretLeak) {
    if (u.length > 12 && speech.toLowerCase().includes(u.toLowerCase().slice(0, 18))) {
      speech = speech.replace(new RegExp(escapeRe(u.slice(0, 24)), "ig"), "…");
    }
  }

  if (speech.length > 900) speech = speech.slice(0, 900);

  return { speech: speech || "…", action, source: raw.source };
}

function escapeRe(s: string) {
  return s.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
}

export function synapseSpeech(spiegel: Spiegel): FormulateResult {
  const f = spiegel.fired[0];
  const phrase = spiegel.profile.typicalPhrases[0] || spiegel.profile.favoriteWords?.[0];
  const speech =
    f?.cell.speech ||
    [f?.cell.reaction, phrase, spiegel.profile.humor].filter(Boolean).join(". ") ||
    spiegel.profile.coreFacts?.[0] ||
    "…";
  const action = spiegel.body.cannotDo.length && f?.cell.bodyCue && /rennt|läuft|greift/.test(f.cell.bodyCue) ? null : (f?.cell.bodyCue ?? null);
  return { speech, action, source: "synapse" };
}
