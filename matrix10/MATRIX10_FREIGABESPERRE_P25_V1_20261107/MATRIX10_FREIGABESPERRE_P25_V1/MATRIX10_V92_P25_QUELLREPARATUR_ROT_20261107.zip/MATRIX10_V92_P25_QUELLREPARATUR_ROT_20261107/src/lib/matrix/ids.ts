// R4.1 / B.27: Frontend IDs are PROVISIONAL only.
// Canonical persisted IDs are allocated by the Flask backend via /api/ids/allocate.
// A per-page nonce prevents the old reload collision even before canonicalization.
let _idCounter = 0;
let _bootNonce = newBootNonce();

function newBootNonce(): string {
  try {
    const c = globalThis.crypto;
    if (c && typeof c.getRandomValues === "function") {
      const bytes = new Uint32Array(2);
      c.getRandomValues(bytes);
      return Array.from(bytes, (n) => n.toString(16).padStart(8, "0")).join("");
    }
  } catch {
    // Fall through to the non-cryptographic compatibility fallback.
  }
  return `${Date.now().toString(36)}${Math.random().toString(36).slice(2, 12)}`;
}

function cleanPrefix(prefix: string): string {
  const p = String(prefix || "id").toLowerCase().replace(/[^a-z0-9-]+/g, "");
  return p || "id";
}

export function uid(prefix = "id"): string {
  _idCounter += 1;
  return `tmp_${cleanPrefix(prefix)}_${_bootNonce}_${_idCounter.toString(36)}`;
}

/** Test isolation: model a fresh page load, including a fresh nonce. */
export function _resetIdCounter(): void {
  _idCounter = 0;
  _bootNonce = newBootNonce();
}

export function isProvisionalId(value: unknown): value is string {
  return typeof value === "string" && /^tmp_[a-z0-9-]+_[a-z0-9]+_[a-z0-9]+$/i.test(value);
}

export function provisionalPrefix(value: string): string | null {
  const m = /^tmp_([a-z0-9-]+)_/i.exec(String(value || ""));
  return m ? m[1].toLowerCase() : null;
}
