/** P23 - evidence for a committed FIGURE response, never the stored input.
 * Pure reader of the canonical GET /api/sessions/:id state. No second owner.
 * Do not infer rollback if this returns false: a timed-out server can still finish.
 */
export type ResponseReadbackStatus = "antwort_gespeichert" | "ungewiss";

export function responseReadbackStatus(
  session: unknown, sourceTurnId: string, figureId: string,
): ResponseReadbackStatus {
  if (!session || typeof session !== "object" || !sourceTurnId || !figureId) return "ungewiss";
  const s = session as Record<string, unknown>;
  // A truncated/legacy GET is not an authoritative success receipt.
  if (!Object.prototype.hasOwnProperty.call(s, "pendingInputTurnId")) return "ungewiss";
  if (String(s.pendingInputTurnId || "") === sourceTurnId) return "ungewiss";
  const truths = Array.isArray(s.turnTruths) ? s.turnTruths : [];
  const facts = Array.isArray(s.facts) ? s.facts : [];
  const turns = Array.isArray(s.turns) ? s.turns : [];
  const truth = truths.find((t) => {
    if (!t || typeof t !== "object") return false;
    const row = t as Record<string, unknown>;
    return row.id === sourceTurnId && (row.speaker_id ?? row.speakerId) === figureId;
  });
  if (!truth) return "ungewiss";
  const answerFacts = facts.filter((f) => {
    if (!f || typeof f !== "object") return false;
    const row = f as Record<string, unknown>;
    return (row.sourceTurnId ?? row.source_turn_id) === sourceTurnId &&
      row.actorId === figureId && row.validated === true &&
      (row.kind === "speech" || row.kind === "action" || row.kind === "physical") &&
      typeof row.text === "string" && row.text.trim() !== "" && row.text.trim() !== "—" &&
      !row.rejectionReason && !row.rejection_reason;
  });
  if (!answerFacts.length) return "ungewiss";
  // An input Fact may have the same sourceTurnId and even an identical actor;
  // a real response must ALSO have the committed 'character' dialogue row.
  const answerRow = turns.some((t) => {
    if (!t || typeof t !== "object") return false;
    const row = t as Record<string, unknown>;
    if (row.speakerId !== figureId || row.role !== "character" ||
        (typeof row.speech !== "string" || !row.speech.trim() || row.speech.trim() === "—") &&
        (typeof row.action !== "string" || !row.action.trim())) return false;
    return answerFacts.some((fact) => Number((fact as Record<string, unknown>).turn) === Number(row.turn));
  });
  return answerRow ? "antwort_gespeichert" : "ungewiss";
}
