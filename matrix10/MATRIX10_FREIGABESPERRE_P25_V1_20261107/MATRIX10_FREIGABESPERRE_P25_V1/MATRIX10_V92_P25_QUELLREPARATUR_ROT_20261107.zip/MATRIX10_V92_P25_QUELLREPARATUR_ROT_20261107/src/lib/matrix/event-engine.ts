import { uid } from "./ids.ts";
import { firstName, mentionsIn } from "./address.ts";
import { pushSceneFact } from "./scene-facts.ts";
import type {
  Authority,
  DirectedRel,
  GodScope,
  MemoryKind,
  PhysicalVerb,
  RuntimeState,
  SceneFact,
  Session,
  StammCharacter,
  World,
} from "./types.ts";

function clamp01(n: number) {
  return Math.max(0, Math.min(1, n));
}

export function peopleAtPlace(session: Session, placeName: string): string[] {
  return Object.values(session.runtimes)
    .filter((rt) => rt.position === placeName)
    .map((rt) => rt.characterId);
}

export function syncPresent(session: Session): Session {
  const s = session;
  s.scene.presentIds = peopleAtPlace(s, s.scene.placeName);
  return s;
}

const VERBS: { re: RegExp; verb: PhysicalVerb }[] = [
  { re: /ohrfeig|schlägt|schlag|hieb|tritt\b|box|prügel|haut /i, verb: "strike" },
  { re: /an den haaren|zerrt|reißt|reisst/i, verb: "hold" },
  { re: /packt|greift|hält fest|festhält|hält .* fest/i, verb: "hold" },
  { re: /knebel|knebelt|stopft/i, verb: "gag" },
  { re: /fesselt|bindet|schnürt/i, verb: "bind" },
  { re: /lässt los|befreit|löst|entfesselt|gibt frei/i, verb: "release" },
  { re: /küsst|umarmt|berührt|streichelt|zieht näher/i, verb: "intimacy" },
  { re: /verlässt|geht weg|läuft davon|rennt weg/i, verb: "leave" },
  { re: /betritt|kommt (herein|rein|dazu)|tritt ein|erscheint/i, verb: "enter" },
  { re: /geht nach|geht in|geht zur|geht zum|läuft in/i, verb: "move" },
  { re: /gibt|reicht|nimmt|stiehlt|raubt/i, verb: "give" },
];

export interface ParsedAction {
  actor?: StammCharacter;
  target?: StammCharacter;
  verb: PhysicalVerb;
  placeName?: string;
  raw: string;
}

export function parseAction(
  text: string,
  chars: StammCharacter[],
  world: World,
  defaultActor?: StammCharacter,
): ParsedAction {
  const mentions = mentionsIn(text, chars);
  const verbHit = VERBS.find((v) => v.re.test(text));
  const verb = verbHit?.verb ?? "other";
  let actor = defaultActor;
  let target: StammCharacter | undefined;
  if (mentions.length) {
    const beforeVerb = verbHit ? text.search(verbHit.re) : -1;
    const first = mentions[0]!;
    if (beforeVerb >= 0 && first.index < beforeVerb) actor = first.char;
    else if (!actor) actor = first.char;
    const other = mentions.find((m) => m.char.id !== actor?.id);
    if (other) target = other.char;
    else if (mentions[0] && actor && mentions[0].char.id !== actor.id) target = mentions[0].char;
  }
  if (!target && mentions.length === 1 && actor && mentions[0]!.char.id !== actor.id) target = mentions[0]!.char;
  if (!target && mentions.length === 1 && !defaultActor) {
    // "Clara schlägt Mara" handled; "schlägt Mara" needs default actor
  }
  if (!target && mentions.length === 1 && defaultActor && mentions[0]!.char.id !== defaultActor.id) {
    actor = defaultActor;
    target = mentions[0]!.char;
  }
  let placeName: string | undefined;
  for (const p of world.places) {
    if (text.toLowerCase().includes(p.name.toLowerCase())) placeName = p.name;
  }
  return { actor, target, verb, placeName, raw: text };
}

export function canPerform(rt: RuntimeState | undefined, verb: PhysicalVerb, asSpeech = false): { ok: boolean; reason?: string } {
  if (!rt) return { ok: true };
  if (rt.consciousness < 0.25) return { ok: false, reason: "nicht bei Bewusstsein" };
  if (asSpeech && (rt.gagged || !rt.canSpeak)) return { ok: false, reason: "kann nicht sprechen" };
  if (rt.restrained) {
    if (verb === "move" || verb === "leave" || verb === "enter" || verb === "strike") {
      return { ok: false, reason: "ist festgehalten oder gefesselt" };
    }
  }
  if (rt.mobility < 0.25 && (verb === "move" || verb === "leave" || verb === "strike" || verb === "enter")) {
    return { ok: false, reason: "kann sich nicht so bewegen" };
  }
  if (rt.pain > 0.9 && verb === "strike") return { ok: false, reason: "Schmerz lässt das nicht zu" };
  return { ok: true };
}

function ensureRel(s: Session, fromId: string, toId: string): DirectedRel {
  let r = s.relations.find((x) => x.fromId === fromId && x.toId === toId);
  if (!r) {
    r = { fromId, toId, trust: 0.4, closeness: 0.2, fear: 0.1, hostility: 0, note: "" };
    s.relations.push(r);
  }
  return r;
}

function bumpRel(s: Session, fromId: string, toId: string, d: Partial<DirectedRel>) {
  const r = ensureRel(s, fromId, toId);
  if (d.trust != null) r.trust = clamp01(r.trust + d.trust);
  if (d.closeness != null) r.closeness = clamp01(r.closeness + d.closeness);
  if (d.fear != null) r.fear = clamp01(r.fear + d.fear);
  if (d.hostility != null) r.hostility = clamp01(r.hostility + d.hostility);
}

function remember(
  s: Session,
  characterId: string,
  kind: MemoryKind,
  text: string,
  turn: number,
  salience: number,
  factId: string,
  witnesses: string[],
) {
  if (!characterId || characterId === "god" || characterId === "regie" || characterId === "user") return;
  s.memories.push({
    id: uid("mem"),
    characterId,
    kind,
    text,
    salience,
    turn,
    witnesses,
    layer: "session",
    truthStatus: "canon",
    factId,
  });
}

export interface WorldEvent {
  actorId: string;
  targetId?: string;
  kind: SceneFact["kind"];
  verb?: PhysicalVerb;
  text: string;
  authority: Authority;
  placeName?: string;
  sourceTurnId?: string;
  sourceType?: string;
  eventKind?: string;
  speechAct?: string;
  validated?: boolean;
  rejectionReason?: string;
  propositionId?: string;
  goalId?: string;
  respondsToFactId?: string;
}

export function ingestEvent(s: Session, world: World, chars: StammCharacter[], ev: WorldEvent): SceneFact {
  const placeName = ev.placeName ?? s.scene.placeName;
  const place = world.places.find((p) => p.name === placeName);
  const witnesses = peopleAtPlace(s, placeName).filter((id) => id);
  const validated = ev.validated !== false;
  const eventKind = ev.eventKind ?? ev.kind;
  const fact: SceneFact = {
    id: uid("fact"),
    turn: s.turnIndex,
    actorId: ev.actorId,
    targetId: ev.targetId,
    kind: ev.kind,
    verb: ev.verb,
    text: ev.text,
    authority: ev.authority,
    witnessedBy: witnesses.slice(),
    placeId: place?.id,
    userId: s.userId,
    worldId: s.worldId,
    sessionId: s.id,
    sourceTurnId: ev.sourceTurnId,
    sourceType: ev.sourceType ?? "turn",
    eventKind,
    speechAct: ev.speechAct,
    payload: { text: ev.text, kind: ev.kind, verb: ev.verb },
    validated,
    status: validated ? "canon" : "unvalidated",
    provenance: "engine",
    propositionId: ev.propositionId,
    goalId: ev.goalId,
    respondsToFactId: ev.respondsToFactId,
    rejectionReason: ev.rejectionReason,
  };
  pushSceneFact(s, fact);

  if (!validated) {
    return fact;
  }

  const actorRt = s.runtimes[ev.actorId];
  const targetRt = ev.targetId ? s.runtimes[ev.targetId] : undefined;

  if (ev.kind === "speech") {
    remember(s, ev.actorId, "gesagt", ev.text, s.turnIndex, 0.55, fact.id, witnesses);
    for (const w of witnesses) {
      if (w === ev.actorId) continue;
      remember(s, w, "gehoert", ev.text, s.turnIndex, 0.6, fact.id, witnesses);
    }
  }

  if (ev.kind === "action" || ev.kind === "physical") {
    applyPhysical(s, ev.verb ?? "other", actorRt, targetRt, ev.actorId, ev.targetId);
    remember(s, ev.actorId, "getan", ev.text, s.turnIndex, 0.75, fact.id, witnesses);
    if (ev.targetId) {
      remember(s, ev.targetId, "betroffen", ev.text, s.turnIndex, 0.9, fact.id, witnesses);
      remember(s, ev.targetId, "erlebt", ev.text, s.turnIndex, 0.88, fact.id, witnesses);
    }
    for (const w of witnesses) {
      if (w === ev.actorId || w === ev.targetId) continue;
      remember(s, w, "gesehen", ev.text, s.turnIndex, 0.7, fact.id, witnesses);
    }
    if (ev.verb === "strike" || ev.verb === "hold" || ev.verb === "bind") {
      s.scene.danger = clamp01(s.scene.danger + 0.18);
      s.scene.tension = clamp01(s.scene.tension + 0.2);
    }
    if (ev.verb === "intimacy") s.scene.tension = clamp01(s.scene.tension + 0.08);
  }

  if (ev.verb === "move" || ev.verb === "enter" || ev.verb === "leave") {
    applyMove(s, world, ev.actorId, ev.verb, ev.text, chars);
  }

  return fact;
}

function applyPhysical(
  s: Session,
  verb: PhysicalVerb,
  actorRt: RuntimeState | undefined,
  targetRt: RuntimeState | undefined,
  actorId: string,
  targetId?: string,
) {
  if (verb === "strike" && targetRt) {
    targetRt.pain = clamp01(targetRt.pain + 0.22);
    targetRt.fear = clamp01(targetRt.fear + 0.18);
    targetRt.stress = clamp01(targetRt.stress + 0.16);
    targetRt.emotion = "Schmerz";
    targetRt.mobility = clamp01(targetRt.mobility - 0.08);
    if (actorRt) actorRt.anger = clamp01(actorRt.anger + 0.1);
    if (targetId) {
      bumpRel(s, targetId, actorId, { fear: 0.18, trust: -0.12, hostility: 0.14 });
      bumpRel(s, actorId, targetId, { hostility: 0.1, closeness: -0.06 });
    }
  }
  if (verb === "hold" && targetRt) {
    targetRt.restrained = true;
    targetRt.heldBy = actorId;
    targetRt.mobility = clamp01(Math.min(targetRt.mobility, 0.35));
    targetRt.pain = clamp01(targetRt.pain + 0.1);
    targetRt.emotion = "festgehalten";
    if (actorRt) actorRt.holding = targetId;
    if (targetId) bumpRel(s, targetId, actorId, { fear: 0.12, hostility: 0.1 });
    const c = "wird festgehalten";
    if (!targetRt.constraints.includes(c)) targetRt.constraints.push(c);
  }
  if (verb === "bind" && targetRt) {
    targetRt.restrained = true;
    targetRt.mobility = clamp01(Math.min(targetRt.mobility, 0.15));
    if (!targetRt.constraints.includes("gefesselt")) targetRt.constraints.push("gefesselt");
  }
  if (verb === "gag" && targetRt) {
    targetRt.gagged = true;
    targetRt.canSpeak = false;
    if (!targetRt.constraints.includes("geknebelt")) targetRt.constraints.push("geknebelt");
  }
  if (verb === "release" && targetRt) {
    targetRt.restrained = false;
    targetRt.gagged = false;
    targetRt.canSpeak = true;
    targetRt.heldBy = undefined;
    targetRt.constraints = targetRt.constraints.filter((x) => !/fessel|halt|knebel/i.test(x));
    if (actorRt) actorRt.holding = undefined;
  }
  if (verb === "intimacy" && targetRt && targetId) {
    targetRt.lust = clamp01(targetRt.lust + 0.08);
    if (actorRt) actorRt.lust = clamp01(actorRt.lust + 0.1);
    bumpRel(s, actorId, targetId, { closeness: 0.08 });
    bumpRel(s, targetId, actorId, { closeness: 0.04 });
  }
}

function applyMove(s: Session, world: World, actorId: string, verb: PhysicalVerb, text: string, _chars: StammCharacter[]) {
  const rt = s.runtimes[actorId];
  if (!rt) return;
  if (verb === "leave") {
    const other = world.places.find((p) => p.id !== s.scene.placeId) ?? world.places[0];
    if (other) rt.position = other.name;
    if (rt.holding) {
      const held = s.runtimes[rt.holding];
      if (held) held.position = rt.position;
    }
    syncPresent(s);
    return;
  }
  const dest = world.places.find((p) => text.toLowerCase().includes(p.name.toLowerCase()));
  if (dest) {
    rt.position = dest.name;
    if (rt.holding) {
      const held = s.runtimes[rt.holding];
      if (held) held.position = dest.name;
    }
    if (actorId === s.avatarId) {
      s.scene.placeId = dest.id;
      s.scene.placeName = dest.name;
    }
    syncPresent(s);
  }
}

export function applyGodMutation(
  s: Session,
  world: World,
  chars: StammCharacter[],
  text: string,
  scope: GodScope,
  targetId?: string,
): Session {
  const target = targetId ? chars.find((c) => c.id === targetId) : mentionsIn(text, chars)[0]?.char;
  const tid = target?.id ?? targetId;
  const rt = tid ? s.runtimes[tid] : undefined;
  const t = text.toLowerCase();

  if (scope === "body" && rt) {
    if (/gebrochen|bruch|arm/.test(t)) {
      rt.pain = clamp01(Math.max(rt.pain, 0.7));
      rt.mobility = clamp01(Math.min(rt.mobility, 0.35));
      if (!rt.constraints.includes("gebrochener Arm")) rt.constraints.push("gebrochener Arm");
    }
    if (/bein/.test(t) && /gebrochen|wund|verletz/.test(t)) {
      rt.pain = clamp01(Math.max(rt.pain, 0.75));
      rt.mobility = clamp01(Math.min(rt.mobility, 0.15));
      if (!rt.constraints.includes("verletztes Bein")) rt.constraints.push("verletztes Bein");
    }
    if (/bewusstlos|ohnmächtig|ohnmaechtig/.test(t)) {
      rt.consciousness = 0.05;
      rt.canSpeak = false;
      rt.emotion = "bewusstlos";
    }
    if (/tot|gestorben/.test(t)) {
      rt.consciousness = 0;
      rt.canSpeak = false;
      rt.mobility = 0;
      rt.emotion = "tot";
    }
    if (/gefesselt|gebunden/.test(t)) {
      rt.restrained = true;
      rt.mobility = clamp01(Math.min(rt.mobility, 0.15));
      if (!rt.constraints.includes("gefesselt")) rt.constraints.push("gefesselt");
    }
    if (/frei|los|entfesselt/.test(t)) {
      rt.restrained = false;
      rt.gagged = false;
      rt.canSpeak = rt.consciousness > 0.4;
      rt.constraints = rt.constraints.filter((x) => !/fessel|knebel|halt/i.test(x));
    }
    if (/schmerz|wunde|blut/.test(t)) rt.pain = clamp01(Math.max(rt.pain, 0.55));
    if (/knebel/.test(t)) {
      rt.gagged = true;
      rt.canSpeak = false;
    }
  }

  if (scope === "relationship") {
    const pair = mentionsIn(text, chars);
    const a = pair[0]?.char;
    const b = pair[1]?.char;
    if (a && b) {
      const d: Partial<DirectedRel> = {};
      if (/hass|feind/.test(t)) {
        d.hostility = 0.4;
        d.trust = -0.3;
      }
      if (/liebe|vertraut/.test(t)) {
        d.closeness = 0.3;
        d.trust = 0.2;
      }
      if (/furcht|angst/.test(t)) d.fear = 0.3;
      bumpRel(s, a.id, b.id, d);
    }
  }

  if (scope === "knowledge" && tid) {
    s.memories.push({
      id: uid("mem"),
      characterId: tid,
      kind: "gelesen",
      text,
      salience: 0.8,
      turn: s.turnIndex,
      witnesses: [tid],
      layer: "session",
      truthStatus: "canon",
    });
  }

  if (scope === "time") s.scene.time = text;
  if (scope === "scene") {
    s.scene.notes = text;
    if (/gefahr|gewalt|kampf/.test(t)) s.scene.danger = clamp01(s.scene.danger + 0.25);
    if (/ruhe|frieden/.test(t)) {
      s.scene.danger = clamp01(s.scene.danger - 0.2);
      s.scene.tension = clamp01(s.scene.tension - 0.2);
    }
  }
  if (scope === "world" || scope === "session") {
    if (!s.scene.openMatters.includes(text)) s.scene.openMatters = [...s.scene.openMatters.slice(-5), text];
  }
  void world;
  return s;
}

export function factsWitnessedBy(session: Session, characterId: string, limit = 8): SceneFact[] {
  return session.facts.filter((f) => f.witnessedBy.includes(characterId)).slice(-limit);
}

export function splitPuppet(text: string, figure: StammCharacter): { speech: string; action?: string } {
  const trimmed = text.trim();
  const labeled = trimmed.match(/^(?:rede\s*:\s*)?([\s\S]*?)\s*(?:\/\s*)?(?:handlung|action)\s*:\s*([\s\S]+)$/i);
  if (labeled && labeled[2]!.trim()) {
    return { speech: labeled[1]!.replace(/^rede\s*:\s*/i, "").trim(), action: labeled[2]!.trim() };
  }
  const starPart = trimmed.match(/^(.*?)\s*\*(.+?)\*\s*(.*)$/s);
  if (starPart && starPart[2]!.trim()) {
    const speech = [starPart[1]!.trim(), starPart[3]!.trim()].filter(Boolean).join(" ").trim();
    const action = starPart[2]!.trim();
    return speech ? { speech, action } : { speech: "", action };
  }
  const star = trimmed.match(/^\*(.+)\*$/s);
  if (star) return { speech: "", action: star[1]!.trim() };
  const fn = firstName(figure);
  if (new RegExp(`^${escapeRe(fn)}\\s+\\S+`, "i").test(trimmed) && VERBS.some((v) => v.re.test(trimmed))) {
    return { speech: "", action: trimmed };
  }
  if (VERBS.some((v) => v.re.test(trimmed)) && mentionsIn(trimmed, [figure]).length === 0) {
    return { speech: "", action: `${figure.name} ${trimmed}` };
  }
  if (/^(zieht|schlägt|packt|greift|fesselt|küsst|geht|nimmt|hält)/i.test(trimmed)) {
    return { speech: "", action: `${figure.name} ${trimmed}` };
  }
  return { speech: trimmed };
}

function escapeRe(s: string) {
  return s.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
}

export function narratorLine(fact: SceneFact, chars: StammCharacter[]): string {
  const nameOf = (id: string) => chars.find((c) => c.id === id)?.name ?? id;
  if (fact.kind === "speech") return `${nameOf(fact.actorId)} sagt: ${fact.text}`;
  return fact.text;
}

export function syncRuntimeTrust(rt: RuntimeState, rel?: DirectedRel): RuntimeState {
  if (!rel) return rt;
  return { ...rt, trust: rel.trust, fear: Math.max(rt.fear, rel.fear * 0.6) };
}
