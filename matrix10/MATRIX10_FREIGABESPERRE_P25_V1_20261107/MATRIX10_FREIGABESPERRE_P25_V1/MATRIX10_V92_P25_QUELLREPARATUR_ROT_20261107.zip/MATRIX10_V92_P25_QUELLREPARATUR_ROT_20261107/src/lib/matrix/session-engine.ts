import { applyFireToRuntime, fireSynapses } from "./compass.ts";
import { pickFate, scenePressureTags } from "./fate.ts";
import { uid } from "./ids.ts";
import { pushSceneFact } from "./scene-facts.ts";
import { buildSpiegel } from "./spiegel.ts";
import { bindFollowup, isQuestion, mentionsIn, resolveAddress } from "./address.ts";
import {
  applyGodMutation,
  canPerform,
  ingestEvent,
  narratorLine,
  parseAction,
  splitPuppet,
  syncPresent,
  syncRuntimeTrust,
} from "./event-engine.ts";
import type {
  DirectedRel,
  FormulateResult,
  GodScope,
  PipelineFlags,
  RuntimeState,
  Session,
  SpeakerMode,
  Spiegel,
  StammCharacter,
  SynapseFire,
  World,
} from "./types.ts";

export function runtimeFromStamm(c: StammCharacter, position: string): RuntimeState {
  const trusts = (c.relations || []).map((r) => Number(r.trust)).filter((n) => Number.isFinite(n));
  const fearHit = (c.fears || []).some((f) => /angst|furcht|falle|gefahr/i.test(String(f)));
  return {
    characterId: c.id,
    emotion: "wach",
    intensity: 0.35,
    fear: c.fears.length ? (fearHit ? 0.4 : 0.25) : 0.1,
    trust: trusts.length ? Math.max(0.05, Math.min(0.95, trusts.reduce((a, b) => a + b, 0) / trusts.length)) : 0.4,
    lust: 0.05,
    pain: c.body.pain,
    shame: 0.1,
    anger: 0.1,
    fatigue: 0.2,
    stress: 0.25,
    intent: c.goals.find((g) => String(g).trim()) || c.role || "",
    mobility: c.body.mobility,
    consciousness: c.body.consciousness,
    position,
    constraints: [...c.body.constraints],
    canSpeak: true,
    restrained: false,
    gagged: false,
  };
}

function voiceOk(rt: RuntimeState | undefined): boolean {
  if (!rt) return true;
  return rt.canSpeak !== false && !rt.gagged;
}

export function seedRelations(chars: StammCharacter[]): DirectedRel[] {
  const byName = new Map(chars.map((c) => [c.name.toLowerCase(), c]));
  const out: DirectedRel[] = [];
  for (const c of chars) {
    for (const r of c.relations) {
      const t = r.targetId ? chars.find((x) => x.id === r.targetId) : byName.get(r.targetName.toLowerCase());
      if (!t) continue;
      out.push({
        fromId: c.id,
        toId: t.id,
        trust: r.trust,
        closeness: r.closeness,
        fear: r.fear,
        hostility: r.fear > 0.5 ? 0.2 : 0,
        note: r.note,
        kind: r.kind,
      });
    }
  }
  return out;
}

// V65Z (SPS-Audit V65Y A08): the client copy of the re-keying is gone - the server re-keys an import (kernel.rekey_session_graph).

export function createSession(opts: {
  world: World;
  characters: StammCharacter[];
  avatar: StammCharacter | null;
  situationId?: string;
  name?: string;
  // V65F (AMASTER §19): chosen start presence; without it the start situation decides.
  presentIds?: string[];
  userId: string;
  pipeline?: PipelineFlags;
  autoChat?: Session["autoChat"];
}): Session {
  if (opts.avatar?.worldId && opts.avatar.worldId !== opts.world.id) {
    throw new Error("Avatar gehört nicht zur gewählten Welt");
  }
  const sit = opts.world.startSituations.find((s) => s.id === opts.situationId) ?? opts.world.startSituations[0];
  const place = opts.world.places.find((p) => p.id === sit?.placeId) ?? opts.world.places[0];
  const natives = opts.characters.filter((c) => c.worldId === opts.world.id && c.isWorldNative);
  const presentNames = new Set((sit?.presentNames ?? natives.map((c) => c.name)).map((n) => n.toLowerCase()));
  const present = Array.isArray(opts.presentIds)
    ? natives.filter((c) => opts.presentIds!.includes(c.id))
    : natives.filter((c) => presentNames.has(c.name.toLowerCase()));
  if (!present.length && natives[0]) present.push(natives[0]);
  const all = opts.avatar ? [...natives, opts.avatar] : [...natives];
  const presentIds = [...present.map((c) => c.id), ...(opts.avatar ? [opts.avatar.id] : [])];
  const runtimes: Record<string, RuntimeState> = {};
  for (const c of all) {
    runtimes[c.id] = runtimeFromStamm(c, presentIds.includes(c.id) ? place.name : "anderswo");
  }
  const opening = sit?.opening ?? `${place.name}. Die Szene steht.`;
  const openingLow = opening.toLowerCase();
  const sceneItems = (opts.world.items || [])
    .map(String)
    .filter((it) => {
      const key = it.split(":")[0].trim().toLowerCase();
      return key.length >= 4 && (openingLow.includes(key) || (place.description || "").toLowerCase().includes(key) || (place.name || "").toLowerCase().includes(key));
    })
    .slice(0, 6);
  return {
    id: uid("ses"),
    worldId: opts.world.id,
    userId: opts.userId,
    name: opts.name ?? `${opts.world.name} · ${new Date().toLocaleTimeString("de-AT", { hour: "2-digit", minute: "2-digit" })}`,
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
    avatarId: opts.avatar?.id ?? null,
    alias: opts.avatar?.name ?? "Spieler",
    role: "teilnehmer",
    scene: {
      placeId: place.id,
      placeName: place.name,
      time: sit?.time ?? "jetzt",
      presentIds,
      tension: 0.35,
      danger: 0.15,
      openMatters: [opening, ...(place.rules || []).slice(0, 2)].filter(Boolean),
      notes: opening,
      phase: "Anfang",
      items: sceneItems,
      bounds: (opts.world.knowledgeLimits || []).slice(0, 4),
      conflicts: (opts.world.conflicts || []).slice(0, 4),
    },
    runtimes,
    relations: seedRelations(all),
    memories: [],
    facts: [],
    godFacts: [],
    fate: {
      enabled: opts.world.fateEnabled,
      pressure: opts.world.fateEnabled ? 0.45 : 0,
      beat: opts.world.fateSeeds[0]?.beat || opening,
      activeSeedId: opts.world.fateSeeds[0]?.id,
      lastShiftTurn: 0,
      mustNot: opts.world.fateSeeds[0]?.mustNot || "Kein erfundenes Wissen. Abwesende wissen nichts. Avatar nicht steuern.",
    },
    turns: [
      {
        id: uid("ln"),
        turn: 0,
        speakerId: "narrator",
        speakerName: "Szene",
        role: "narrator",
        speech: opening,
        firedSpaces: [],
        source: "engine",
      },
    ],
    turnIndex: 0,
    pipeline: opts.pipeline ?? { fate: true, meta: true, narrator: true },
    autoChat: opts.autoChat ?? { enabled: false, turns: 2, delayMs: 5000, contextTurns: 10 },
    goals: natives
      .filter((c) => (c.goals || []).some((g) => String(g).trim()))
      .slice(0, 8)
      .map((c) => ({
        id: uid("goal"),
        ownerId: c.id,
        text: String(c.goals.find((g) => String(g).trim()) || "").trim(),
        status: "open" as const,
      })),
    propositions: [],
    focus: {},
  };
}

function scenePresent(session: Session, natives: StammCharacter[]): StammCharacter[] {
  return natives.filter((c) => session.scene.presentIds.includes(c.id) && c.id !== session.avatarId);
}

function nativesPresent(session: Session, natives: StammCharacter[]): StammCharacter[] {
  const here = scenePresent(session, natives);
  const atPlace = here.filter((c) => {
    const pos = session.runtimes[c.id]?.position;
    return !pos || pos === session.scene.placeName;
  });
  return atPlace.length ? atPlace : here;
}

export function pickSpeaker(opts: {
  world: World;
  session: Session;
  natives: StammCharacter[];
  stimulus: string;
  explicitName?: string;
  uiTargetId?: string;
  excludeId?: string;
}): StammCharacter | null {
  const addressedPool = scenePresent(opts.session, opts.natives).filter((c) => c.id !== opts.excludeId && voiceOk(opts.session.runtimes[c.id]));
  const present = nativesPresent(opts.session, opts.natives).filter((c) => c.id !== opts.excludeId);
  if (!addressedPool.length) return null;
  // V65R (AMASTER §25 Z. 1309–1320 Zielbindung: Namensnennung als Anrede, UI-Auswahl, adressierte
  // Frage; Prüfung v2.9 Q-B, deine Session T25): a name that is only MENTIONED ("… zwischen dir und
  // mara …") no longer picks the speaker before the address. resolveAddress decides in one order -
  // vocative, then the UI target, then a single mention - the same order as kernel.pick_speaker.
  const addr = resolveAddress({
    text: opts.stimulus,
    present: addressedPool,
    all: opts.natives,
    session: opts.session,
    uiTargetId: opts.uiTargetId,
    speakerId: opts.session.avatarId,
  });
  if (addr.addressed && addressedPool.some((c) => c.id === addr.addressed!.id)) {
    const hit = addressedPool.find((c) => c.id === addr.addressed!.id)!;
    if (hit) return hit;
  }
  if (opts.explicitName) {
    const n = opts.explicitName.toLowerCase();
    const hit = addressedPool.find((c) => c.name.toLowerCase() === n || c.aliases.some((a) => a.toLowerCase() === n) || c.name.toLowerCase().startsWith(n));
    if (hit) return hit;
  }
  if (opts.uiTargetId) {
    const hit = addressedPool.find((c) => c.id === opts.uiTargetId);
    if (hit) return hit;
  }

  const greeting = /^(hallo|hi|guten|moin|abend|tag|servus)\b/i.test(opts.stimulus.trim());
  if (greeting) {
    const host = present.find((c) => /wirt|host|chefin|inhaber/i.test(`${c.role} ${c.occupation}`));
    if (host && voiceOk(opts.session.runtimes[host.id])) return host;
  }

  if (addr.isQuestion || bindFollowup(opts.stimulus, opts.session).prior) {
    const last = opts.session.facts.filter((f) => f.kind === "action" || f.kind === "physical" || f.kind === "speech").at(-1);
    if (last) {
      if (addr.topic && last.actorId === addr.topic.id) {
        const witness = present.find((c) => last.witnessedBy.includes(c.id) && c.id !== addr.topic!.id && voiceOk(opts.session.runtimes[c.id]));
        if (witness) return witness;
      }
      const target = last.targetId ? present.find((c) => c.id === last.targetId) : undefined;
      if (target && voiceOk(opts.session.runtimes[target.id])) return target;
      const w = present.find((c) => last.witnessedBy.includes(c.id) && voiceOk(opts.session.runtimes[c.id]));
      if (w) return w;
    }
  }

  let best: { c: StammCharacter; s: number } | null = null;
  const lived = opts.session.facts
    .filter((f) => f.witnessedBy.some((id) => present.some((p) => p.id === id)))
    .slice(-6)
    .map((f) => f.text)
    .join(" ");
  for (const c of present) {
    const rt = opts.session.runtimes[c.id];
    if (!voiceOk(rt)) continue;
    const rel = addr.addressed
      ? opts.session.relations.find((r) => r.fromId === c.id && r.toId === addr.addressed!.id)
      : undefined;
    const fired = fireSynapses({
      stamm: c,
      runtime: rt,
      scene: opts.session.scene,
      stimulus: opts.stimulus,
      fateTags: scenePressureTags(opts.session.scene),
      relation: rel,
      lived,
    });
    const involvement = opts.session.memories.filter((m) => m.characterId === c.id && m.turn >= opts.session.turnIndex - 3).length * 0.05;
    const score = (fired[0]?.activation ?? 0) + involvement;
    if (!best || score > best.s) best = { c, s: score };
  }
  return best?.c ?? addressedPool[0] ?? present[0] ?? null;
}

export function prepareTurn(opts: {
  world: World;
  session: Session;
  speaker: StammCharacter;
  present: StammCharacter[];
  stimulus: string;
  mode: SpeakerMode;
  addressedTo?: string;
  topic?: string;
}): { fired: SynapseFire[]; spiegel: Spiegel; session: Session } {
  const addr = resolveAddress({
    text: opts.stimulus,
    present: opts.present,
    all: opts.present,
    session: opts.session,
    speakerId: opts.session.avatarId,
  });
  const addressedTo = opts.addressedTo ?? addr.addressed?.name;
  const topic = opts.topic ?? addr.topic?.name;
  const follow = bindFollowup(opts.stimulus, opts.session);
  const query = addr.isQuestion || follow.prior ? { question: opts.stimulus, about: topic, prior: follow.prior } : undefined;

  const lived = opts.session.facts
    .filter((f) => f.witnessedBy.includes(opts.speaker.id))
    .slice(-8)
    .map((f) => f.text)
    .join("\n");
  const addressedId = addr.addressed?.id;
  const relTo =
    (addressedId ? opts.session.relations.find((r) => r.fromId === opts.speaker.id && r.toId === addressedId) : undefined) ||
    (opts.session.avatarId ? opts.session.relations.find((r) => r.fromId === opts.speaker.id && r.toId === opts.session.avatarId) : undefined);

  let rt = opts.session.runtimes[opts.speaker.id] ?? runtimeFromStamm(opts.speaker, opts.session.scene.placeName);
  rt = syncRuntimeTrust(rt, relTo);

  const fateTags = opts.session.pipeline.fate ? scenePressureTags(opts.session.scene) : [];
  const fired = fireSynapses({
    stamm: opts.speaker,
    runtime: rt,
    scene: opts.session.scene,
    stimulus: [opts.stimulus, follow.prior, query?.prior].filter(Boolean).join("\n"),
    fateTags,
    relation: relTo,
    lived,
  });
  const { seed, state } = pickFate({
    world: opts.world,
    session: opts.session,
    speaker: opts.speaker,
    fired,
    stimulus: opts.stimulus,
  });
  // Compass is a lens: preview runtime for Spiegel only; do not persist fire into owner.
  const previewRuntime = applyFireToRuntime(rt, fired);
  const session: Session = {
    ...opts.session,
    fate: opts.session.pipeline.fate ? state : { ...opts.session.fate, enabled: false },
    runtimes: {
      ...opts.session.runtimes,
      [opts.speaker.id]: rt,
    },
    focus: {
      ...opts.session.focus,
      addressedId: addr.addressed?.id ?? opts.session.focus.addressedId,
      topicId: addr.topic?.id ?? opts.session.focus.topicId,
      lastQuestion: isQuestion(opts.stimulus) ? opts.stimulus : opts.session.focus.lastQuestion,
    },
  };
  const spiegelSession: Session = {
    ...session,
    runtimes: { ...session.runtimes, [opts.speaker.id]: previewRuntime },
  };
  const spiegel = buildSpiegel({
    world: opts.world,
    session: spiegelSession,
    speaker: opts.speaker,
    present: opts.present,
    fired,
    stimulus: opts.stimulus,
    mode: opts.mode,
    addressedTo,
    topic,
    fateSeed: seed,
    query,
  });
  return { fired, spiegel, session };
}

export function commitTurn(opts: {
  session: Session;
  world: World;
  speaker: StammCharacter;
  present: StammCharacter[];
  all: StammCharacter[];
  avatarId: string | null;
  fired: SynapseFire[];
  result: FormulateResult;
  userSpeech?: string;
  userName?: string;
  userRole?: AuthorityLike;
}): Session {
  const s = structuredClone(opts.session) as Session;
  s.turnIndex += 1;
  const turn = s.turnIndex;
  const chars = opts.all.length ? opts.all : opts.present;

  const sourceTurnId = uid("tt");

  if (opts.userSpeech) {
    s.turns.push({
      id: uid("ln"),
      turn,
      speakerId: opts.avatarId ?? "user",
      speakerName: opts.userName ?? s.alias,
      role: opts.userRole ?? "avatar",
      speech: opts.userSpeech,
      firedSpaces: [],
      source: "engine",
    });
    ingestEvent(s, opts.world, chars, {
      actorId: opts.avatarId ?? "user",
      kind: "speech",
      text: `${opts.userName ?? s.alias}: ${opts.userSpeech}`,
      authority: opts.userRole ?? "avatar",
      sourceTurnId,
    });
  }

  const rt = s.runtimes[opts.speaker.id];
  const parsed = opts.result.action ? parseAction(opts.result.action, chars, opts.world, opts.speaker) : null;
  const gate = parsed ? canPerform(rt, parsed.verb) : { ok: true };
  const gagged = rt.gagged || !rt.canSpeak;
  const speech = gagged ? "—" : opts.result.speech;
  const action = gate.ok ? opts.result.action ?? undefined : undefined;

  s.turns.push({
    id: uid("ln"),
    turn,
    speakerId: opts.speaker.id,
    speakerName: opts.speaker.name,
    role: "character",
    speech,
    action,
    firedSpaces: opts.fired.map((f) => f.space),
    source: opts.result.source,
  });

  if (!gagged && speech && speech !== "—") {
    ingestEvent(s, opts.world, chars, {
      actorId: opts.speaker.id,
      kind: "speech",
      text: `${opts.speaker.name}: ${speech}`,
      authority: "character",
      sourceTurnId,
    });
  }
  if (action && parsed) {
    ingestEvent(s, opts.world, chars, {
      actorId: parsed.actor?.id ?? opts.speaker.id,
      targetId: parsed.target?.id,
      kind: "physical",
      verb: parsed.verb,
      text: action,
      authority: "character",
      sourceTurnId,
    });
  } else if (opts.result.action && parsed && !gate.ok) {
    ingestEvent(s, opts.world, chars, {
      actorId: parsed.actor?.id ?? opts.speaker.id,
      targetId: parsed.target?.id,
      kind: "physical",
      verb: parsed.verb,
      text: opts.result.action,
      authority: "character",
      sourceTurnId,
      validated: false,
      rejectionReason: "capability",
    });
  }

  s.focus.lastSpeakerId = opts.speaker.id;
  s.focus.lastActorId = parsed?.actor?.id ?? opts.speaker.id;
  s.focus.lastTargetId = parsed?.target?.id;
  return s;
}

type AuthorityLike = Session["turns"][number]["role"];

export function commitPuppet(opts: {
  session: Session;
  world: World;
  figure: StammCharacter;
  chars: StammCharacter[];
  text: string;
}): Session {
  const s = structuredClone(opts.session) as Session;
  s.turnIndex += 1;
  const split = splitPuppet(opts.text, opts.figure);
  const parsed = split.action ? parseAction(split.action, opts.chars, opts.world, opts.figure) : null;
  const gate = parsed ? canPerform(s.runtimes[opts.figure.id], parsed.verb) : { ok: true };
  const action = gate.ok ? split.action : undefined;

  s.turns.push({
    id: uid("ln"),
    turn: s.turnIndex,
    speakerId: opts.figure.id,
    speakerName: opts.figure.name,
    role: "character",
    speech: split.speech,
    action,
    firedSpaces: [],
    source: "engine",
  });
  if (split.speech) {
    ingestEvent(s, opts.world, opts.chars, {
      actorId: opts.figure.id,
      kind: "speech",
      text: `${opts.figure.name}: ${split.speech}`,
      authority: "character",
    });
  }
  if (action && parsed) {
    ingestEvent(s, opts.world, opts.chars, {
      actorId: parsed.actor?.id ?? opts.figure.id,
      targetId: parsed.target?.id,
      kind: "physical",
      verb: parsed.verb,
      text: action,
      authority: "character",
    });
  }
  return s;
}

export function applyGod(
  session: Session,
  worldOrText: World | string,
  charsOrScope?: StammCharacter[] | GodScope,
  text?: string,
  scope?: GodScope,
  targetId?: string,
  meta = true,
): Session {
  // Overload: applyGod(session, text, scope, targetId?) — characterization / REF path.
  // Chat path: applyGod(live, world, worldChars, msg, godScope, targetId, meta).
  if (typeof worldOrText === "string") {
    const body = worldOrText;
    const godScope = (charsOrScope as GodScope) || "scene";
    const tid = typeof text === "string" ? text : (targetId as string | undefined);
    const s = structuredClone(session) as Session;
    s.turnIndex += 1;
    s.godFacts.push({ id: uid("god"), scope: godScope, targetId: tid, text: body, turn: s.turnIndex, applied: true });
    pushSceneFact(s, {
      id: uid("fact"),
      turn: s.turnIndex,
      actorId: "god",
      targetId: tid,
      kind: "god",
      text: `[${godScope}${tid ? `:${tid}` : ""}] ${body}`,
      authority: "god",
      witnessedBy: [],
    });
    s.turns.push({
      id: uid("ln"),
      turn: s.turnIndex,
      speakerId: "god",
      speakerName: "Gott",
      role: "god",
      speech: body,
      firedSpaces: [],
      source: "engine",
    });
    if (godScope === "time") s.scene.time = body.slice(0, 80);
    if (godScope === "scene") s.scene.notes = body;
    if (godScope === "body" && tid && s.runtimes[tid]) {
      s.runtimes[tid].pain = Math.min(1, s.runtimes[tid].pain + 0.2);
    }
    return s;
  }
  const world = worldOrText;
  const chars = Array.isArray(charsOrScope) ? charsOrScope : [];
  const s = structuredClone(session) as Session;
  s.turnIndex += 1;
  s.godFacts.push({ id: uid("god"), scope: scope ?? "scene", targetId, text: text ?? "", turn: s.turnIndex, applied: true });
  applyGodMutation(s, world, chars, text ?? "", scope ?? "scene", targetId);
  pushSceneFact(s, {
    id: uid("fact"),
    turn: s.turnIndex,
    actorId: "god",
    targetId,
    kind: "god",
    text: `[${scope ?? "scene"}] Zustand geändert`,
    authority: "god",
    witnessedBy: [],
  });
  if (meta) {
    s.turns.push({
      id: uid("ln"),
      turn: s.turnIndex,
      speakerId: "god",
      speakerName: "Gott",
      role: "god",
      speech: `Zustand (${scope ?? "scene"}) gesetzt.`,
      firedSpaces: [],
      source: "engine",
    });
  }
  return s;
}

export function applyRegie(
  session: Session,
  world: World,
  text: string,
  chars: StammCharacter[] = [],
  targetId?: string,
): Session {
  const s = structuredClone(session) as Session;
  s.turnIndex += 1;
  const list = Array.isArray(chars) ? chars : [];
  const target = targetId ? list.find((c) => c.id === targetId) : undefined;

  if (!list.length) {
    pushSceneFact(s, {
      id: uid("fact"),
      turn: s.turnIndex,
      actorId: "regie",
      kind: "regie",
      text,
      authority: "regie",
      targetId,
      witnessedBy: s.scene.presentIds.slice(),
      placeId: s.scene.placeId,
    });
    s.turns.push({
      id: uid("ln"),
      turn: s.turnIndex,
      speakerId: "regie",
      speakerName: "Regie",
      role: "regie",
      speech: text,
      firedSpaces: [],
      source: "engine",
    });
    s.scene.notes = text;
    return s;
  }

  const parsed = parseAction(text, list, world, target);
  const enterAsked = /betritt|kommt (herein|rein|dazu)|tritt ein|erscheint/i.test(text);
  const leaveAsked = /verlässt|geht weg|verschwindet/i.test(text);

  if (enterAsked && target) {
    const rt = s.runtimes[target.id] ?? runtimeFromStamm(target, s.scene.placeName);
    rt.position = s.scene.placeName;
    s.runtimes[target.id] = rt;
    syncPresent(s);
  } else if (leaveAsked && target) {
    const rt = s.runtimes[target.id];
    if (rt) {
      const other = world.places.find((p) => p.id !== s.scene.placeId);
      rt.position = other?.name ?? "anderswo";
    }
    syncPresent(s);
  }

  if (parsed.verb !== "other" || parsed.target || parsed.actor) {
    const actor = parsed.actor ?? target;
    if (actor) {
      const gate = canPerform(s.runtimes[actor.id], parsed.verb);
      if (gate.ok) {
        ingestEvent(s, world, list, {
          actorId: actor.id,
          targetId: parsed.target?.id,
          kind: "physical",
          verb: parsed.verb,
          text,
          authority: "regie",
          placeName: parsed.placeName,
        });
      }
    }
  } else {
    pushSceneFact(s, {
      id: uid("fact"),
      turn: s.turnIndex,
      actorId: "regie",
      kind: "regie",
      text,
      authority: "regie",
      witnessedBy: s.scene.presentIds.slice(),
      placeId: s.scene.placeId,
    });
    for (const id of s.scene.presentIds) {
      s.memories.push({
        id: uid("mem"),
        characterId: id,
        kind: "gesehen",
        text,
        salience: 0.5,
        turn: s.turnIndex,
        witnesses: s.scene.presentIds.slice(),
        layer: "session",
        truthStatus: "canon",
      });
    }
  }

  const last = s.facts.at(-1);
  s.turns.push({
    id: uid("ln"),
    turn: s.turnIndex,
    speakerId: "regie",
    speakerName: s.pipeline.narrator ? "Szene" : "Regie",
    role: s.pipeline.narrator ? "narrator" : "regie",
    speech: last ? narratorLine(last, list) : text,
    firedSpaces: [],
    source: "engine",
  });
  return s;
}

export function togglePresence(session: Session, characterId: string, world: World, chars: StammCharacter[]): Session {
  const s = structuredClone(session) as Session;
  const c = chars.find((x) => x.id === characterId);
  if (!s.runtimes[characterId] && c) s.runtimes[characterId] = runtimeFromStamm(c, "anderswo");
  const rt = s.runtimes[characterId];
  if (!rt) return s;
  if (rt.position === s.scene.placeName) {
    const other = world.places.find((p) => p.id !== s.scene.placeId);
    rt.position = other?.name ?? "anderswo";
  } else {
    rt.position = s.scene.placeName;
  }
  syncPresent(s);
  return s;
}

export function moveAvatar(session: Session, world: World, placeId: string, moverId: string, natives?: StammCharacter[]): Session {
  const place = world.places.find((p) => p.id === placeId);
  if (!place) return session;
  const s = structuredClone(session) as Session;
  const rt = s.runtimes[moverId];
  if (rt) {
    rt.position = place.name;
    if (rt.holding && s.runtimes[rt.holding]) s.runtimes[rt.holding]!.position = place.name;
  }
  s.scene.placeId = place.id;
  s.scene.placeName = place.name;
  for (const c of natives ?? []) {
    if (!s.runtimes[c.id]) continue;
    const tags = place.tags.map((t) => t.toLowerCase());
    const first = c.name.split(" ")[0]!.toLowerCase();
    if (tags.includes(first) && s.runtimes[c.id].position === "anderswo") {
      s.runtimes[c.id].position = place.name;
    }
  }
  syncPresent(s);
  s.turnIndex += 1;
  s.turns.push({
    id: uid("ln"),
    turn: s.turnIndex,
    speakerId: moverId,
    speakerName: "Bewegung",
    role: "avatar",
    speech: `geht nach ${place.name}.`,
    action: `betritt ${place.name}`,
    firedSpaces: [],
    source: "engine",
  });
  ingestEvent(s, world, natives ?? [], {
    actorId: moverId,
    kind: "action",
    verb: "move",
    text: `betritt ${place.name}`,
    authority: "avatar",
    placeName: place.name,
  });
  return s;
}

export function matchTriggers(
  text: string,
  session: Session,
  rules: { active: boolean; match: string; effectText: string; worldId: string; sessionId?: string; targetIds: string[] }[],
): string[] {
  const n = text.toLowerCase();
  const hits: string[] = [];
  for (const r of rules) {
    if (!r.active) continue;
    if (r.worldId && r.worldId !== session.worldId) continue;
    if (r.sessionId && r.sessionId !== session.id) continue;
    if (r.match && n.includes(r.match.toLowerCase())) hits.push(r.effectText);
  }
  return hits;
}

export function detectAddressed(text: string, chars: StammCharacter[], session?: Session): string | undefined {
  if (!session) {
    const dummy = { focus: {}, relations: [], avatarId: null, facts: [], scene: { presentIds: chars.map((c) => c.id) } } as unknown as Session;
    return resolveAddress({ text, present: chars, all: chars, session: dummy }).addressed?.name;
  }
  return resolveAddress({ text, present: chars, all: chars, session }).addressed?.name;
}

export function pickAutoSpeaker(session: Session, natives: StammCharacter[]): { speaker: StammCharacter; stimulus: string } | null {
  const last = session.facts.filter((f) => f.kind === "speech" || f.kind === "action" || f.kind === "physical").at(-1);
  const exclude = last?.actorId;
  const speaker = pickSpeaker({
    world: { id: session.worldId } as World,
    session,
    natives,
    stimulus: last?.text ?? session.fate.beat,
    excludeId: exclude,
  });
  if (!speaker) return null;
  if (!voiceOk(session.runtimes[speaker.id])) return null;
  const stimulus = last?.text ?? "Die Szene geht weiter.";
  return { speaker, stimulus };
}

export function resetChatOnly(session: Session): Session {
  const s = structuredClone(session) as Session;
  const opening = s.scene.notes || s.scene.openMatters[0] || "Die Szene steht.";
  s.turns = [
    {
      id: uid("ln"),
      turn: 0,
      speakerId: "narrator",
      speakerName: "Szene",
      role: "narrator",
      speech: opening,
      firedSpaces: [],
      source: "engine",
    },
  ];
  s.turnIndex = 0;
  s.focus = {};
  return s;
}

export function resetRuntimeOnly(session: Session, chars: StammCharacter[]): Session {
  const s = structuredClone(session) as Session;
  for (const c of chars) {
    if (s.runtimes[c.id] || s.scene.presentIds.includes(c.id) || s.avatarId === c.id) {
      s.runtimes[c.id] = runtimeFromStamm(c, s.runtimes[c.id]?.position ?? s.scene.placeName);
    }
  }
  s.relations = seedRelations(chars);
  return s;
}

export function resetMemoryOnly(session: Session): Session {
  const s = structuredClone(session) as Session;
  s.memories = [];
  return s;
}
