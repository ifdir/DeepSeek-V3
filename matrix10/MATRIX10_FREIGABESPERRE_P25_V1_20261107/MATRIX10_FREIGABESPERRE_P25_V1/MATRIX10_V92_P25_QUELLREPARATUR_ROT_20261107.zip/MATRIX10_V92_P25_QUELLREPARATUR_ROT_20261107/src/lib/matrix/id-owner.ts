import { isProvisionalId, provisionalPrefix } from "./ids";

export type IdAllocationRequest = { tempId: string; prefix: string };
export type IdAllocation = { tempId: string; prefix: string; id: string };
export type IdAllocator = (items: IdAllocationRequest[]) => Promise<IdAllocation[]>;

// Page-lifetime alias table. It is not a persistence owner: every value in it came
// from the backend allocator. It only lets a stale local tmp_* reference resolve to
// the same canonical id after the defining object has already been written.
const canonicalByTemp = new Map<string, string>();

function collectProvisionals(value: unknown, out = new Map<string, string>()): Map<string, string> {
  if (typeof value === "string") {
    if (isProvisionalId(value)) {
      const prefix = provisionalPrefix(value);
      if (prefix) out.set(value, prefix);
    }
    return out;
  }
  if (Array.isArray(value)) {
    for (const item of value) collectProvisionals(item, out);
    return out;
  }
  if (!value || typeof value !== "object") return out;
  for (const [key, child] of Object.entries(value as Record<string, unknown>)) {
    if (isProvisionalId(key)) {
      const prefix = provisionalPrefix(key);
      if (prefix) out.set(key, prefix);
    }
    collectProvisionals(child, out);
  }
  return out;
}

function remapInPlace(value: unknown, mapping: Map<string, string>): void {
  if (Array.isArray(value)) {
    for (let i = 0; i < value.length; i += 1) {
      const item = value[i];
      if (typeof item === "string" && mapping.has(item)) value[i] = mapping.get(item)!;
      else remapInPlace(item, mapping);
    }
    return;
  }
  if (!value || typeof value !== "object") return;
  const obj = value as Record<string, unknown>;
  for (const key of Object.keys(obj)) {
    let activeKey = key;
    if (mapping.has(key)) {
      const nextKey = mapping.get(key)!;
      obj[nextKey] = obj[key];
      delete obj[key];
      activeKey = nextKey;
    }
    const child = obj[activeKey];
    if (typeof child === "string" && mapping.has(child)) obj[activeKey] = mapping.get(child)!;
    else remapInPlace(child, mapping);
  }
}

async function defaultAllocator(items: IdAllocationRequest[]): Promise<IdAllocation[]> {
  const mod = await import("./api");
  return mod.apiAllocateIds(items);
}

/** Return the backend-canonical alias if this tmp id was already allocated on this page. */
export function canonicalId(value: string): string {
  return canonicalByTemp.get(String(value || "")) ?? value;
}

/** Test-only page reset. Product code never manufactures canonical aliases here. */
export function _resetCanonicalIdCache(): void {
  canonicalByTemp.clear();
}

/**
 * Replace every provisional id/reference/key in a graph with a backend-owned id.
 * The frontend may name a draft tmp_*, but it cannot persist that identity.
 */
export async function canonicalizeTempIdsInPlace<T>(value: T, allocate: IdAllocator = defaultAllocator): Promise<T> {
  const refs = collectProvisionals(value);
  if (!refs.size) return value;

  const mapping = new Map<string, string>();
  for (const tempId of refs.keys()) {
    const cached = canonicalByTemp.get(tempId);
    if (cached) mapping.set(tempId, cached);
  }

  const requests = Array.from(refs, ([tempId, prefix]) => ({ tempId, prefix })).filter((r) => !mapping.has(r.tempId));
  if (requests.length) {
    const allocations = await allocate(requests);
    for (const row of allocations || []) {
      const expectedPrefix = refs.get(row?.tempId);
      if (!row || !expectedPrefix || row.prefix !== expectedPrefix || !row.id || isProvisionalId(row.id)) continue;
      canonicalByTemp.set(row.tempId, row.id);
      mapping.set(row.tempId, row.id);
    }
  }

  if (mapping.size !== refs.size) {
    const missing = Array.from(refs.keys()).filter((tempId) => !mapping.has(tempId));
    throw new Error(`ID_OWNER_INCOMPLETE: ${missing.join(",")}`);
  }
  remapInPlace(value, mapping);
  return value;
}
