// V67 (Audit7 V66-08; AMASTER §19 Resetarten getrennt, §54 Produktwirkung sichtbar): one wording for every destructive
// session operation - what is removed, what stays. The server decides what is possible (dependency contract); the question
// only makes the user's decision explicit before the request is sent. No answer / Nein -> nothing is sent.
export type ResetKind = "chat" | "runtime" | "memory" | "uploads" | "full" | "delete" | "restore" | "upload-delete";

const TEXTS: Record<ResetKind, string> = {
  chat: "Chat zurücksetzen: Die Dialogzeilen werden entfernt. Eingaben, Ereignisse, Gedächtnis, Runtime und Uploads bleiben.",
  runtime: "Runtime zurücksetzen: Körper-/Laufzeitwerte und Beziehungen gehen auf den Stamm zurück. Verlauf, Ereignisse und Gedächtnis bleiben.",
  memory: "Gedächtnis zurücksetzen: Alle Erinnerungen der Figuren dieser Session werden gelöscht. Verlauf und Ereignisse bleiben.",
  uploads: "Uploadkontext zurücksetzen: Uploads dieser Session werden entfernt. Uploads, auf die sich gespeicherte Ereignisse stützen, bleiben als Quelle.",
  full: "Session vollständig zurücksetzen: Verlauf, Ereignisse, Zeugenwissen, Gedächtnis, Ziele und Beziehungen werden gelöscht. Name, Avatar und Uploads bleiben. Wer den Stand behalten will, legt vorher einen Snapshot an.",
  delete: "Session löschen: Die Session mit allen ihren Zeilen, Erinnerungen, Ereignissen, Snapshots, Uploads und Diagnose-Logs wird endgültig entfernt. Stamm und andere Sessions bleiben.",
  restore: "Snapshot wiederherstellen: Der aktuelle Stand dieser Session wird durch den Snapshot ersetzt. Der spätere Stand wird nicht mitgesichert.",
  "upload-delete": "Upload löschen: Ist der Upload Quelle gespeicherter Ereignisse, lehnt der Server das Löschen ab und nichts ändert sich.",
};

export function confirmReset(kind: ResetKind, name?: string): boolean {
  if (typeof window === "undefined" || typeof window.confirm !== "function") return false;
  return window.confirm(`${name ? `${name}\n\n` : ""}${TEXTS[kind]}\n\nFortfahren?`);
}

// V68 (Audit8 P0-5/P1-11 "Ablehnung sichtbar und deutsch"; AMASTER §54): the server's refusal of such an operation in plain
// German first, the technical detail after it. The server's code decides (its contract), never words of the message.
const REFUSALS: Record<string, string> = {
  DEPENDENCY_BROKEN:
    "Nichts wurde geändert. Andere gespeicherte Einträge stützen sich noch darauf – zum Beispiel Ereignisse, die diesen Upload als Quelle nennen. Erst wenn nichts mehr darauf verweist, kann es entfernt werden.",
};

export function refusalText(message: string): { title: string; text: string | null; detail: string } {
  const m = /\b([1-5]\d\d) ([A-Z][A-Z0-9_]+)\b/.exec(message || "");
  const status = m ? Number(m[1]) : 0;
  const code = m ? m[2] : "";
  if (code && REFUSALS[code]) return { title: "Abgelehnt", text: REFUSALS[code], detail: message };
  if (status >= 400 && status < 500) return { title: "Abgelehnt, nichts wurde geändert", text: null, detail: message };
  return { title: "Speichern fehlgeschlagen", text: null, detail: message };
}
