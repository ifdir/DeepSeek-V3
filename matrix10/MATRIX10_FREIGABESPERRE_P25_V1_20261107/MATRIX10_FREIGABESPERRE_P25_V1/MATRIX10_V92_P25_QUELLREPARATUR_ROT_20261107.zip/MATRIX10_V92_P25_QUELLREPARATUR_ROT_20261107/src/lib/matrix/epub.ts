const ALLOWED_EXT = new Set([
  ".txt",
  ".md",
  ".epub",
  ".pdf",
  ".png",
  ".jpg",
  ".jpeg",
  ".webp",
  ".json",
  ".html",
  ".htm",
  ".pptx",
  ".ppt",
]);
const MAX_FILE_BYTES = 8 * 1024 * 1024;
const MAX_ZIP_ENTRIES = 800;
const MAX_HTML_CHAPTERS = 200;
const MAX_PDF_PAGES = 200;
const MAX_JOIN_CHARS = 400_000;
const MAX_ZIP_UNCOMPRESSED = 16 * 1024 * 1024;


function extOf(name: string): string {
  const i = name.lastIndexOf(".");
  return i >= 0 ? name.slice(i).toLowerCase() : "";
}

function zipEntryUncompressed(entry: unknown): number {
  const raw = entry as { uncompressedSize?: number; _data?: { uncompressedSize?: number } };
  const n = raw.uncompressedSize ?? raw._data?.uncompressedSize ?? 0;
  return typeof n === "number" ? n : 0;
}

export type EpubZone = "front" | "body" | "back" | "unsicher";
export type TextLayerKind = "text" | "scan" | "empty";

export type EpubPart = {
  index: number;
  zipPath: string;
  anchor: string;
  title: string;
  linear: boolean;
  zone: EpubZone;
  kind: string;
  text: string;
  selected: boolean;
  chars: number;
  layer?: TextLayerKind;
  docId?: string;
};

export type ExtractedSource = {
  title: string;
  text: string;
  dataUrl?: string;
  parts?: EpubPart[];
  omitted?: number;
  language?: string;
  accessMode?: string[];
  accessibilityFeature?: string[];
  accessibilitySummary?: string;
  conformsTo?: string;
};

const SKIP_KINDS = new Set([
  "cover",
  "toc",
  "copyright-page",
  "titlepage",
  "halftitlepage",
  "imprint",
  "contributors",
  "colophon",
  "acknowledgements",
  "acknowledgment",
  "bibliography",
  "index",
  "glossary",
  "loi",
  "lot",
  "loa",
  "errata",
  "footnotes",
]);
const FRONT_KINDS = new Set([
  "frontmatter",
  "cover",
  "titlepage",
  "halftitlepage",
  "imprint",
  "toc",
  "copyright-page",
  "dedication",
  "epigraph",
  "foreword",
  "preface",
  "preamble",
]);
const BODY_KINDS = new Set(["bodymatter", "prologue", "epilogue", "conclusion", "introduction", "chapter", "part", "division"]);
const BACK_KINDS = new Set([
  "backmatter",
  "afterword",
  "appendix",
  "bibliography",
  "colophon",
  "contributors",
  "index",
  "glossary",
  "notes",
  "rearnotes",
  "errata",
  "footnotes",
]);
const KIND_RANK = [
  "prologue",
  "epilogue",
  "bodymatter",
  "chapter",
  "part",
  "cover",
  "toc",
  "copyright-page",
  "titlepage",
  "contributors",
  "afterword",
  "preface",
  "foreword",
  "frontmatter",
  "backmatter",
  "index",
  "appendix",
];

export function defaultPartSelected(part: Pick<EpubPart, "linear" | "zone" | "kind">): boolean {
  if (SKIP_KINDS.has(part.kind)) return false;
  if (part.kind === "preface" || part.kind === "foreword" || part.kind === "afterword") return false;
  if (part.zone === "front") return false;
  if (part.zone === "back" && part.kind !== "epilogue") return false;
  if (!part.linear && part.kind !== "prologue" && part.kind !== "epilogue" && part.kind !== "bodymatter") return false;
  return true;
}

export function joinSelectedParts(parts: EpubPart[], maxChars = MAX_JOIN_CHARS): { text: string; omitted: number } {
  const kept: string[] = [];
  let total = 0;
  let omitted = 0;
  for (const p of parts) {
    if (!p.selected) continue;
    const chunk = p.text.trim();
    if (!chunk) continue;
    const head = (p.title || "").replace(/\s+/g, " ").trim();
    let labeled = chunk;
    if (head) {
      const headRe = new RegExp(`^#{0,3}\\s*${head.replace(/[.*+?^${}()|[\]\\]/g, "\\$&")}\\b\\s*`, "i");
      const body = chunk.replace(headRe, "").trim();
      labeled = `## ${head}\n${body || chunk}`;
    }
    if (kept.length && total + labeled.length > maxChars) {
      omitted += 1;
      continue;
    }
    kept.push(labeled);
    total += labeled.length;
  }
  return { text: kept.join("\n\n"), omitted };
}

export function zoneLabel(zone: EpubZone): string {
  return { front: "Vorspann", body: "Roman", back: "Anhang", unsicher: "Unsicher" }[zone];
}

export function kindLabel(kind: string): string {
  const map: Record<string, string> = {
    cover: "Umschlag",
    toc: "Inhalt",
    titlepage: "Titelblatt",
    "copyright-page": "Impressum",
    prologue: "Prolog",
    epilogue: "Epilog",
    bodymatter: "Körper",
    frontmatter: "Front",
    backmatter: "Anhang",
    preface: "Vorwort",
    foreword: "Geleit",
    afterword: "Nachwort",
    contributors: "Autorin",
  };
  return map[kind] || kind;
}

export function layerLabel(layer?: TextLayerKind): string {
  if (layer === "text") return "Textschicht";
  if (layer === "scan") return "Scan";
  if (layer === "empty") return "Leer";
  return "";
}

export const DOC_ID_SCHEMA = 1;

export function partDocId(sourceKey: string, part: Pick<EpubPart, "index" | "zipPath" | "anchor">, rev?: number): string {
  const key = slugId(sourceKey, 16) || "src";
  const anc = slugId(part.anchor, 24) || "body";
  const head = `doc.src.v${DOC_ID_SCHEMA}.${key}.p${part.index}.${anc}`;
  return rev && rev > 0 ? `${head}.r${rev}` : head;
}

export function partDocHeadId(id: string): string {
  return String(id || "").replace(/\.r\d+$/i, "");
}

export function partDocRevId(headId: string, rev: number): string {
  const head = partDocHeadId(headId);
  return rev > 0 ? `${head}.r${rev}` : head;
}

export type PartDocRef = {
  kind: "src" | "join";
  schema: number;
  sourceKey: string;
  index: number;
  anchor: string;
  rev: number | null;
  worldId?: string;
};

export function sourceKeyFromParts(title: string, parts: Array<Pick<EpubPart, "zipPath" | "anchor">>): string {
  const sig = `${title || ""}\n${parts.map((p) => `${p.zipPath}#${p.anchor}`).join("\n")}`;
  return fnv1aHex(sig);
}

export function parsePartDocId(id: string): PartDocRef | null {
  const raw = String(id || "");
  const src = raw.match(/^doc\.src\.v(\d+)\.([a-z0-9]+)\.p(\d+)\.([a-z0-9]+)(?:\.r(\d+))?$/i);
  if (src) {
    return {
      kind: "src",
      schema: Number(src[1]),
      sourceKey: src[2]!,
      index: Number(src[3]),
      anchor: src[4]!,
      rev: src[5] ? Number(src[5]) : null,
    };
  }
  const join = raw.match(/^doc\.world\.v(\d+)\.([A-Za-z0-9._-]+)\.join(?:\.r(\d+))?$/);
  if (join) {
    return {
      kind: "join",
      schema: Number(join[1]),
      sourceKey: "",
      index: -1,
      anchor: "join",
      rev: join[3] ? Number(join[3]) : null,
      worldId: join[2],
    };
  }
  const up = raw.match(/^doc\.upload\.v(\d+)\.([a-z0-9]+)(?:\.r(\d+))?$/i);
  if (up) {
    return {
      kind: "src",
      schema: Number(up[1]),
      sourceKey: up[2]!,
      index: -1,
      anchor: "upload",
      rev: up[3] ? Number(up[3]) : null,
    };
  }
  return null;
}

export function joinDocId(worldId: string, rev?: number): string {
  const head = `doc.world.v${DOC_ID_SCHEMA}.${slugId(worldId, 48) || "w"}.join`;
  return rev && rev > 0 ? `${head}.r${rev}` : head;
}

export function uploadDocId(name: string, targetKind: string, targetId: string, rev?: number): string {
  const head = `doc.upload.v${DOC_ID_SCHEMA}.${fnv1aHex(`${name}|${targetKind}|${targetId}`)}`;
  return rev && rev > 0 ? `${head}.r${rev}` : head;
}

export function assignPartDocIds(parts: EpubPart[], title: string): EpubPart[] {
  const sourceKey = sourceKeyFromParts(title, parts);
  return parts.map((p) => (p.docId ? p : { ...p, docId: partDocId(sourceKey, p) }));
}

function slugId(raw: string, max: number): string {
  return String(raw || "")
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, "")
    .slice(0, max);
}

function fnv1aHex(s: string): string {
  let h = 0x811c9dc5;
  for (let i = 0; i < s.length; i++) {
    h ^= s.charCodeAt(i);
    h = Math.imul(h, 0x01000193);
  }
  return (h >>> 0).toString(16).padStart(8, "0");
}

/** Buchstaben in der Textschicht = Text; Bild ohne Buchstaben = Scan; sonst leer. */
export function classifyTextLayer(text: string, hasImage: boolean): TextLayerKind {
  if (/[A-Za-zÄÖÜäöüßÀ-ž]/.test(text || "")) return "text";
  if (hasImage) return "scan";
  return "empty";
}

export async function extractTextFromFile(file: File): Promise<ExtractedSource> {
  if (file.size > MAX_FILE_BYTES) {
    throw new Error(`Datei zu groß (${file.size} > ${MAX_FILE_BYTES}).`);
  }
  const name = file.name.toLowerCase();
  const ext = extOf(name);
  const okType =
    ALLOWED_EXT.has(ext) ||
    file.type.includes("epub") ||
    file.type === "text/plain" ||
    file.type === "text/markdown" ||
    file.type === "text/html" ||
    file.type === "application/json" ||
    file.type.startsWith("image/") ||
    file.type === "application/pdf" ||
    file.type.includes("presentation") ||
    file.type.includes("powerpoint");
  if (!okType) {
    throw new Error("Dateityp nicht erlaubt. Erlaubt: txt, md, epub, pdf, json, pptx, bild.");
  }
  if (ext === ".json" || file.type === "application/json") {
    return extractJson(await file.text(), file.name);
  }
  if (ext === ".pptx" || ext === ".ppt" || file.type.includes("presentation") || file.type.includes("powerpoint")) {
    return extractPptx(await file.arrayBuffer(), file.name);
  }
  if (ext === ".pdf" || file.type === "application/pdf") {
    return extractPdf(await file.arrayBuffer(), file.name);
  }
  if (file.type.startsWith("image/") || [".png", ".jpg", ".jpeg", ".webp"].includes(ext)) {
    const dataUrl = await fileToDataUrl(file);
    return { title: file.name.replace(/\.[^.]+$/, ""), text: "", dataUrl };
  }
  if (ext === ".txt" || ext === ".md" || ext === ".html" || ext === ".htm" || file.type === "text/plain" || file.type === "text/markdown" || file.type === "text/html") {
    const text = await file.text();
    return { title: file.name.replace(/\.[^.]+$/, ""), text: ext === ".html" || ext === ".htm" ? stripHtml(text) : text };
  }
  if (ext === ".epub" || file.type.includes("epub") || file.type === "application/zip") {
    return extractEpub(await file.arrayBuffer(), file.name);
  }
  throw new Error("Dateityp nicht erlaubt. Erlaubt: txt, md, epub, pdf, json, pptx, bild.");
}

function extractJson(raw: string, filename: string): { title: string; text: string } {
  let obj: unknown;
  try {
    obj = JSON.parse(raw);
  } catch {
    throw new Error("JSON ungültig — Analyse nicht als Erfolg.");
  }
  const text = flattenJsonText(obj).replace(/\n{3,}/g, "\n\n").trim();
  if (!text) throw new Error("JSON ohne Textfelder. Ein leerer Parse ist keine Weltanalyse.");
  const rec = obj && typeof obj === "object" ? (obj as Record<string, unknown>) : {};
  const title = String(rec.title || rec.name || filename.replace(/\.[^.]+$/, ""));
  return { title, text };
}

function flattenJsonText(v: unknown, depth = 0): string {
  if (depth > 8 || v == null) return "";
  if (typeof v === "string") return v;
  if (typeof v === "number" || typeof v === "boolean") return String(v);
  if (Array.isArray(v)) return v.map((x) => flattenJsonText(x, depth + 1)).filter(Boolean).join("\n");
  if (typeof v === "object") return Object.values(v as Record<string, unknown>).map((x) => flattenJsonText(x, depth + 1)).filter(Boolean).join("\n");
  return "";
}

function fileToDataUrl(file: File): Promise<string> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => resolve(String(reader.result || ""));
    reader.onerror = () => reject(new Error("Bild konnte nicht gelesen werden."));
    reader.readAsDataURL(file);
  });
}

function extractPdfEmbeddedImage(buf: ArrayBuffer): string | undefined {
  const bytes = new Uint8Array(buf);
  const jpegStart = indexOfBytes(bytes, [0xff, 0xd8, 0xff]);
  if (jpegStart >= 0) {
    const jpegEnd = lastIndexOfBytes(bytes, [0xff, 0xd9], jpegStart);
    if (jpegEnd > jpegStart) {
      const slice = bytes.subarray(jpegStart, jpegEnd + 2);
      return `data:image/jpeg;base64,${bytesToBase64(slice)}`;
    }
  }
  const pngStart = indexOfBytes(bytes, [0x89, 0x50, 0x4e, 0x47]);
  if (pngStart >= 0) {
    const pngEnd = indexOfBytes(bytes, [0x49, 0x45, 0x4e, 0x44, 0xae, 0x42, 0x60, 0x82], pngStart);
    if (pngEnd > pngStart) {
      const slice = bytes.subarray(pngStart, pngEnd + 8);
      return `data:image/png;base64,${bytesToBase64(slice)}`;
    }
  }
  return undefined;
}

function indexOfBytes(hay: Uint8Array, needle: number[], from = 0): number {
  outer: for (let i = from; i <= hay.length - needle.length; i++) {
    for (let j = 0; j < needle.length; j++) {
      if (hay[i + j] !== needle[j]) continue outer;
    }
    return i;
  }
  return -1;
}

function lastIndexOfBytes(hay: Uint8Array, needle: number[], from = 0): number {
  let found = -1;
  let idx = from;
  while (idx >= 0) {
    idx = indexOfBytes(hay, needle, found < 0 ? from : found + 1);
    if (idx < 0) break;
    found = idx;
  }
  return found;
}

function bytesToBase64(bytes: Uint8Array): string {
  let bin = "";
  const chunk = 0x8000;
  for (let i = 0; i < bytes.length; i += chunk) {
    bin += String.fromCharCode(...bytes.subarray(i, i + chunk));
  }
  return btoa(bin);
}

function extractPdfStrings(buf: ArrayBuffer): string {
  const raw = new TextDecoder("latin1").decode(buf);
  const out: string[] = [];
  const tj = /\(((?:\\.|[^\\)]){2,})\)\s*Tj/g;
  let m: RegExpExecArray | null;
  while ((m = tj.exec(raw))) {
    out.push(m[1].replace(/\\n/g, "\n").replace(/\\\)/g, ")").replace(/\\\(/g, "("));
  }
  const bt = /BT([\s\S]{0,4000}?)ET/g;
  while ((m = bt.exec(raw))) {
    const inner = m[1];
    const parts = inner.match(/\((?:\\.|[^\\)]){2,}\)/g) || [];
    for (const p of parts) out.push(p.slice(1, -1));
  }
  return out.join(" ").replace(/[ \t]+/g, " ").trim();
}

export function reconstructPdfLines(items: Array<{ str?: string; transform?: number[]; hasEOL?: boolean }>): string {
  const rows = items
    .map((it) => ({
      str: String(it.str || ""),
      x: Number(it.transform?.[4] ?? 0),
      y: Math.round(Number(it.transform?.[5] ?? 0) * 10) / 10,
      eol: Boolean(it.hasEOL),
    }))
    .filter((r) => r.str);
  rows.sort((a, b) => b.y - a.y || a.x - b.x);
  const lines: string[] = [];
  let curY = Infinity;
  let cur: typeof rows = [];
  const flush = () => {
    if (!cur.length) return;
    cur.sort((a, b) => a.x - b.x);
    const line = cur.map((c) => c.str).join(" ").replace(/[ \t]{2,}/g, " ").trim();
    if (line) lines.push(line);
    cur = [];
  };
  for (const r of rows) {
    if (cur.length && Math.abs(curY - r.y) > 4) flush();
    cur.push(r);
    curY = r.y;
    if (r.eol) flush();
  }
  flush();
  return lines.join("\n").trim();
}

async function pageHasImage(
  page: { getOperatorList: () => Promise<{ fnArray?: number[] }> },
  OPS?: Record<string, number>,
): Promise<boolean> {
  try {
    const ops = await page.getOperatorList();
    const fns = ops.fnArray || [];
    const paint = OPS
      ? [OPS.paintImageXObject, OPS.paintJpegXObject, OPS.paintImageMaskXObject, OPS.paintInlineImageXObject, OPS.paintXObject].filter(
          (n) => typeof n === "number",
        )
      : [82, 85, 86, 87, 89, 90];
    return fns.some((fn) => paint.includes(fn));
  } catch {
    return false;
  }
}

async function extractPdf(buf: ArrayBuffer, filename: string): Promise<ExtractedSource> {
  const fallbackTitle = filename.replace(/\.[^.]+$/i, "");
  try {
    return await extractPdfJs(buf, fallbackTitle);
  } catch {
    const text = extractPdfStrings(buf);
    const dataUrl = text.trim() ? undefined : extractPdfEmbeddedImage(buf);
    return { title: fallbackTitle, text, dataUrl };
  }
}

async function extractPdfJs(buf: ArrayBuffer, fallbackTitle: string): Promise<ExtractedSource> {
  const P = Promise as unknown as { try?: (fn: () => unknown) => Promise<unknown> };
  if (typeof P.try !== "function") {
    P.try = (fn) => Promise.resolve().then(fn);
  }
  const pdfjs =
    typeof window === "undefined"
      ? await import("pdfjs-dist/legacy/build/pdf.mjs")
      : await import("pdfjs-dist");
  if (typeof window !== "undefined" && !pdfjs.GlobalWorkerOptions.workerSrc) {
    pdfjs.GlobalWorkerOptions.workerSrc = new URL("pdfjs-dist/build/pdf.worker.min.mjs", import.meta.url).toString();
  }
  const loading = pdfjs.getDocument({
    data: new Uint8Array(buf),
    isEvalSupported: false,
    useSystemFonts: true,
    ...(typeof window === "undefined" ? { disableWorker: true } : {}),
  } as Parameters<typeof pdfjs.getDocument>[0]);
  const pdf = await loading.promise;
  let title = fallbackTitle;
  try {
    const meta = await pdf.getMetadata();
    const info = meta?.info as { Title?: string } | undefined;
    if (info?.Title && String(info.Title).trim()) title = String(info.Title).replace(/\s+/g, " ").trim();
  } catch {
    /* Titel bleibt Dateiname */
  }
  const pageCount = Math.min(pdf.numPages || 0, MAX_PDF_PAGES);
  const parts: EpubPart[] = [];
  for (let n = 1; n <= pageCount; n++) {
    const page = await pdf.getPage(n);
    const content = await page.getTextContent();
    const text = reconstructPdfLines(content.items as Array<{ str?: string; transform?: number[]; hasEOL?: boolean }>);
    const hasImage = await pageHasImage(page, pdfjs.OPS as unknown as Record<string, number>);
    const layer = classifyTextLayer(text, hasImage);
    parts.push({
      index: n - 1,
      zipPath: `page-${n}`,
      anchor: "",
      title: `Seite ${n}`,
      linear: true,
      zone: "unsicher",
      kind: "bodymatter",
      text,
      selected: layer === "text",
      chars: text.length,
      layer,
    });
  }
  const numbered = parts.map((p, i) => ({ ...p, index: i }));
  const joined = joinSelectedParts(numbered);
  let text = joined.text;
  if (!text.trim()) text = numbered.map((p) => p.text).filter(Boolean).join("\n\n");
  const dataUrl = text.trim() ? undefined : extractPdfEmbeddedImage(buf);
  return { title, text, parts: numbered, omitted: joined.omitted || (pdf.numPages > pageCount ? pdf.numPages - pageCount : 0), dataUrl };
}

async function extractPptx(buf: ArrayBuffer, filename: string): Promise<{ title: string; text: string }> {
  const JSZip = (await import("jszip")).default;
  const zip = await JSZip.loadAsync(buf);
  const names = Object.keys(zip.files);
  if (names.length > MAX_ZIP_ENTRIES) throw new Error("Archiv hat zu viele Einträge.");
  if (names.some((n) => n.includes("..") || n.startsWith("/") || n.includes("\\"))) {
    throw new Error("Archiv enthält unzulässige Pfade.");
  }
  const slides = names.filter((n) => /ppt\/slides\/slide\d+\.xml$/i.test(n)).sort();
  const chunks: string[] = [];
  let uncompressed = 0;
  for (const n of slides) {
    const entry = zip.files[n]!;
    uncompressed += zipEntryUncompressed(entry);
    if (uncompressed > MAX_ZIP_UNCOMPRESSED) throw new Error("Archiv überschreitet Entpack-Limit (Zip-Bomb-Schutz).");
    chunks.push(stripHtml(await entry.async("string")));
  }
  const text = chunks.join("\n\n").replace(/\n{3,}/g, "\n\n").trim();
  return { title: filename.replace(/\.[^.]+$/, ""), text };
}

async function extractEpub(buf: ArrayBuffer, filename: string): Promise<ExtractedSource> {
  const JSZip = (await import("jszip")).default;
  const zip = await JSZip.loadAsync(buf);
  const bag = zip as unknown as ZipBag;
  const names = Object.keys(zip.files);
  if (names.length > MAX_ZIP_ENTRIES) {
    throw new Error("Archiv hat zu viele Einträge.");
  }
  if (names.some((n) => n.includes("..") || n.startsWith("/") || n.includes("\\"))) {
    throw new Error("Archiv enthält unzulässige Pfade.");
  }

  const opfPath = await findOpfPath(bag, names);
  let title = filename.replace(/\.epub$/i, "");
  let parts: EpubPart[] = [];
  let a11y: ReturnType<typeof parseOpfA11y> = {
    language: "",
    accessMode: [],
    accessibilityFeature: [],
    accessibilitySummary: "",
    conformsTo: "",
  };

  if (opfPath && bag.files[opfPath]) {
    const opf = await bag.files[opfPath]!.async("string");
    const dc = opf.match(/<dc:title[^>]*>([^<]{2,120})<\/dc:title>/i);
    if (dc?.[1]) title = decodeEntities(dc[1].replace(/\s+/g, " ").trim());
    a11y = parseOpfA11y(opf);
    parts = await partsFromPackage(bag, opfPath, opf);
  }

  if (!parts.length) {
    parts = await partsFromFilenameFallback(bag, names);
  }

  const numbered = parts.map((p, i) => ({ ...p, index: i, chars: p.text.length, selected: defaultPartSelected(p) }));
  const classified = classifyUnmarkedParts(numbered);
  const joined = joinSelectedParts(classified);
  let text = joined.text;
  if (!text.trim()) {
    text = classified.map((p) => p.text).filter(Boolean).join("\n\n");
  }
  const titlePage = classified.find((p) => p.kind === "titlepage" && p.text.trim());
  if (titlePage && titlePage.text.length < 600 && !text.includes(titlePage.text.trim().slice(0, 40))) {
    text = `${titlePage.text.trim()}\n\n${text}`;
  } else if (title && !text.toLowerCase().includes(title.toLowerCase().slice(0, 24))) {
    text = `${title}\n\n${text}`;
  }
  return { title, text, parts: classified, omitted: joined.omitted, ...a11y };
}

type ZipEntry = { async: (t: string) => Promise<string>; uncompressedSize?: number };
type ZipBag = { files: { [path: string]: ZipEntry | undefined } };

async function findOpfPath(zip: ZipBag, names: string[]): Promise<string | undefined> {
  const containerName = names.find((n) => /META-INF\/container\.xml$/i.test(n));
  if (containerName && zip.files[containerName]) {
    const xml = await zip.files[containerName].async("string");
    const m = xml.match(/full-path\s*=\s*["']([^"']+\.opf)["']/i);
    if (m?.[1]) {
      const resolved = normalizeZipPath(m[1]);
      if (resolved && zip.files[resolved]) return resolved;
      const hit = names.find((n) => n.replace(/\\/g, "/").toLowerCase() === resolved?.toLowerCase());
      if (hit) return hit;
    }
  }
  return names.find((n) => /\.opf$/i.test(n));
}

async function partsFromPackage(zip: ZipBag, opfPath: string, opf: string): Promise<EpubPart[]> {
  const opfDir = dirname(opfPath);
  const manifest = new Map<string, { href: string; path: string; props: string }>();
  const itemRe = /<item\b([^>]*)\/?>/gi;
  let im: RegExpExecArray | null;
  while ((im = itemRe.exec(opf))) {
    const a = tagAttrs(im[1] || "");
    const id = a.id;
    const href = a.href;
    if (!id || !href) continue;
    const path = resolveZip(opfDir, href);
    if (!path) continue;
    manifest.set(id, { href, path, props: a.properties || "" });
  }
  const spine: Array<{ id: string; linear: boolean }> = [];
  const refRe = /<itemref\b([^>]*)\/?>/gi;
  let rm: RegExpExecArray | null;
  while ((rm = refRe.exec(opf))) {
    const a = tagAttrs(rm[1] || "");
    if (!a.idref) continue;
    spine.push({ id: a.idref, linear: a.linear ? a.linear.toLowerCase() !== "no" : true });
  }
  const navDocs = await loadNavDocuments(zip, manifest);
  let tocLinks: Array<{ path: string; anchor: string; title: string }> = [];
  let landmarks: Array<{ path: string; anchor: string; types: string[] }> = [];
  const navPaths = new Set(navDocs.map((d) => d.path.toLowerCase()));
  for (const doc of navDocs) {
    if (!tocLinks.length) tocLinks = parseNavLinks(doc.xml, "toc", doc.path);
    if (!landmarks.length) landmarks = parseLandmarkLinks(doc.xml, doc.path);
  }
  const ncxItem = [...manifest.values()].find((x) => /ncx/i.test(x.props) || /\.ncx$/i.test(x.href));
  const ncxPath = ncxItem?.path || [...manifest.values()].find((x) => /\.ncx$/i.test(x.href))?.path;
  if (!tocLinks.length && ncxPath && zip.files[ncxPath]) {
    tocLinks = parseNcxLinks(await zip.files[ncxPath]!.async("string"), ncxPath);
  }
  if (!landmarks.length) landmarks = parseGuideLinks(opf, opfDir);

  const loaded: EpubPart[] = [];
  let uncompressed = 0;
  const spineSlice = spine.slice(0, MAX_HTML_CHAPTERS);
  for (const ref of spineSlice) {
    const item = manifest.get(ref.id);
    if (!item) continue;
    if (navPaths.has(item.path.toLowerCase())) continue;
    const entry = zip.files[item.path] || zipFileCi(zip, item.path);
    if (!entry) continue;
    uncompressed += zipEntryUncompressed(entry);
    if (uncompressed > MAX_ZIP_UNCOMPRESSED) throw new Error("Archiv überschreitet Entpack-Limit (Zip-Bomb-Schutz).");
    const raw = await entry.async("string");
    const fileLinks = tocLinks.filter((l) => l.path.toLowerCase() === item.path.toLowerCase() && l.anchor);
    const slices = sliceByAnchors(raw, fileLinks);
    for (const sl of slices) {
      const mark = matchLandmark(landmarks, item.path, sl.anchor);
      const kind = pickKind(mark);
      const zone = zoneFromKind(kind);
      const title = sl.title || headingTitle(raw) || basename(item.path);
      loaded.push({
        index: 0,
        zipPath: item.path,
        anchor: sl.anchor,
        title,
        linear: ref.linear,
        zone,
        kind,
        text: sl.text,
        selected: true,
        chars: sl.text.length,
      });
    }
  }
  return inferSpineZones(loaded, tocLinks.map((l) => l.path), landmarks);
}

async function partsFromFilenameFallback(zip: ZipBag, names: string[]): Promise<EpubPart[]> {
  let uncompressed = 0;
  const htmlNames = names
    .filter((n) => /\.(xhtml|html|htm)$/i.test(n) && !/bookwire|iTunes|META-INF|nav|toc|cover|ncx/i.test(n))
    .sort()
    .slice(0, MAX_HTML_CHAPTERS);
  const out: EpubPart[] = [];
  for (const n of htmlNames) {
    const entry = zip.files[n];
    if (!entry) continue;
    uncompressed += zipEntryUncompressed(entry);
    if (uncompressed > MAX_ZIP_UNCOMPRESSED) throw new Error("Archiv überschreitet Entpack-Limit (Zip-Bomb-Schutz).");
    const text = stripHtml(await entry.async("string"));
    out.push({
      index: 0,
      zipPath: n,
      anchor: "",
      title: basename(n),
      linear: true,
      zone: "unsicher",
      kind: "",
      text,
      selected: true,
      chars: text.length,
    });
  }
  return out;
}

function zipFileCi(zip: ZipBag, path: string): ZipEntry | undefined {
  const hit = Object.keys(zip.files).find((n) => n.replace(/\\/g, "/").toLowerCase() === path.toLowerCase());
  return hit ? zip.files[hit] : undefined;
}

function tagAttrs(raw: string): Record<string, string> {
  const out: Record<string, string> = {};
  const re = /([:\w.-]+)\s*=\s*["']([^"']*)["']/g;
  let m: RegExpExecArray | null;
  while ((m = re.exec(raw))) out[m[1].toLowerCase()] = m[2];
  return out;
}

async function loadNavDocuments(zip: ZipBag, manifest: Map<string, { href: string; path: string; props: string }>): Promise<Array<{ path: string; xml: string }>> {
  const html = [...manifest.values()].filter((x) => /\.(xhtml|html|htm)$/i.test(x.href) || /html/i.test(x.props));
  const scored = html
    .map((x) => {
      let score = 0;
      if (/\bnav\b/i.test(x.props)) score += 100;
      if (/nav|toc/i.test(x.href)) score += 40;
      return { ...x, score };
    })
    .sort((a, b) => b.score - a.score);
  const out: Array<{ path: string; xml: string }> = [];
  let foundToc = false;
  let foundLand = false;
  for (const item of scored.slice(0, 40)) {
    const entry = zip.files[item.path] || zipFileCi(zip, item.path);
    if (!entry) continue;
    const xml = await entry.async("string");
    const hasToc = /<nav\b[^>]*>/i.test(xml) && (parseNavInner(xml, "toc") !== "" || /epub:type=["'][^"']*\btoc\b|role=["'][^"']*doc-toc/i.test(xml));
    const hasLand = parseNavInner(xml, "landmarks") !== "" || /epub:type=["'][^"']*\blandmarks\b|role=["'][^"']*doc-landmarks/i.test(xml);
    if (!hasToc && !hasLand) continue;
    out.push({ path: item.path, xml });
    if (hasToc) foundToc = true;
    if (hasLand) foundLand = true;
    if (foundToc && foundLand) break;
  }
  return out;
}

function parseNavInner(xml: string, type: string): string {
  const re = new RegExp(`<nav\\b([^>]*)>([\\s\\S]*?)<\\/nav>`, "gi");
  let m: RegExpExecArray | null;
  while ((m = re.exec(xml))) {
    const kinds = navTypeTokens(tagAttrs(m[1] || ""));
    if (kinds.includes(type)) return m[2] || "";
  }
  return "";
}

function navTypeTokens(attrs: Record<string, string>): string[] {
  const raw = `${attrs["epub:type"] || ""} ${attrs.type || ""} ${attrs.role || ""}`.toLowerCase().split(/\s+/);
  const map: Record<string, string> = {
    "doc-toc": "toc",
    "doc-landmarks": "landmarks",
    "doc-pagelist": "page-list",
  };
  return raw.map((t) => map[t] || t).filter(Boolean);
}

function parseHrefList(inner: string, basePath: string): Array<{ path: string; anchor: string; title: string; types: string[] }> {
  const out: Array<{ path: string; anchor: string; title: string; types: string[] }> = [];
  const re = /<a\b([^>]*)>([\s\S]*?)<\/a>/gi;
  let m: RegExpExecArray | null;
  while ((m = re.exec(inner))) {
    const a = tagAttrs(m[1] || "");
    const href = a.href || "";
    if (!href || /^(javascript:|data:|https?:)/i.test(href)) continue;
    const resolved = resolveHref(basePath, href);
    if (!resolved) continue;
    const title = decodeEntities(stripHtml(m[2] || "")).replace(/\s+/g, " ").trim();
    const fromA = `${a["epub:type"] || ""}`.toLowerCase().split(/\s+/).filter(Boolean);
    const fromLi = liTypesBefore(inner, m.index);
    const types = fromA.length ? fromA : fromLi;
    out.push({ path: resolved.path, anchor: resolved.anchor, title, types });
  }
  return out;
}

function liTypesBefore(inner: string, at: number): string[] {
  const before = inner.slice(0, at);
  const matches = [...before.matchAll(/<li\b([^>]*)>/gi)];
  const last = matches[matches.length - 1];
  if (!last) return [];
  return `${tagAttrs(last[1] || "")["epub:type"] || ""}`.toLowerCase().split(/\s+/).filter(Boolean);
}

function parseNcxLinks(xml: string, ncxPath: string): Array<{ path: string; anchor: string; title: string }> {
  const out: Array<{ path: string; anchor: string; title: string }> = [];
  const re =
    /<navPoint\b[^>]*>[\s\S]*?<navLabel>[\s\S]*?<text>([^<]*)<\/text>[\s\S]*?<content\b[^>]*src=["']([^"']+)["']/gi;
  let m: RegExpExecArray | null;
  while ((m = re.exec(xml))) {
    const href = m[2] || "";
    const resolved = resolveHref(ncxPath, href);
    if (!resolved) continue;
    const title = decodeEntities(m[1] || "").replace(/\s+/g, " ").trim();
    out.push({ path: resolved.path, anchor: resolved.anchor, title });
  }
  return out;
}

export function inferSpineZones(
  parts: EpubPart[],
  tocPaths: string[],
  landmarks: Array<{ path: string; anchor: string; types: string[] }>,
): EpubPart[] {
  const toc = new Set(tocPaths.map((p) => p.toLowerCase()));
  const typesByPath = new Map<string, string[]>();
  for (const m of landmarks) {
    const k = m.path.toLowerCase();
    typesByPath.set(k, [...(typesByPath.get(k) || []), ...m.types]);
  }
  const promoRe = /inbook|bookwire|promotion|advert|also[-_]?by|other[-_]?book/i;
  let bodyStart = parts.findIndex((p) => {
    const kind = p.kind || pickKind(typesByPath.get(p.zipPath.toLowerCase()) || []);
    return BODY_KINDS.has(kind);
  });
  let lastToc = -1;
  parts.forEach((p, i) => {
    if (toc.has(p.zipPath.toLowerCase())) lastToc = i;
  });
  let backStart = parts.findIndex((p) => {
    const kind = p.kind || pickKind(typesByPath.get(p.zipPath.toLowerCase()) || []);
    return kind === "backmatter" || kind === "appendix" || kind === "contributors";
  });
  if (backStart < 0 && lastToc >= 0) {
    const after = lastToc + 1;
    if (after < parts.length && parts.slice(after).some((p) => !toc.has(p.zipPath.toLowerCase()))) {
      backStart = after;
      while (backStart < parts.length && toc.has(parts[backStart]!.zipPath.toLowerCase())) backStart += 1;
    }
  }
  return parts.map((p, i) => {
    const types = typesByPath.get(p.zipPath.toLowerCase()) || [];
    let kind = p.kind || pickKind(types);
    let zone = p.zone;
    if (promoRe.test(p.zipPath)) {
      kind = BACK_KINDS.has(kind) ? kind : "backmatter";
      zone = "back";
    } else if (kind && SKIP_KINDS.has(kind)) {
      zone = zoneFromKind(kind);
    } else if (kind && FRONT_KINDS.has(kind) && kind !== "prologue") {
      zone = "front";
    } else if (kind && BACK_KINDS.has(kind) && kind !== "epilogue") {
      zone = "back";
    } else if (bodyStart >= 0 && i < bodyStart) {
      kind = kind || "frontmatter";
      zone = kind === "prologue" ? "body" : "front";
    } else if (backStart >= 0 && i >= backStart && kind !== "epilogue") {
      kind = kind || "backmatter";
      zone = "back";
    } else if (lastToc >= 0 && i > lastToc && !toc.has(p.zipPath.toLowerCase())) {
      kind = kind || "backmatter";
      zone = "back";
    } else if (bodyStart >= 0 && i >= bodyStart) {
      kind = kind || "bodymatter";
      zone = kind === "epilogue" || kind === "prologue" || kind === "bodymatter" || zoneFromKind(kind) === "unsicher" ? "body" : zoneFromKind(kind);
    } else {
      zone = zoneFromKind(kind);
    }
    return { ...p, kind, zone, selected: defaultPartSelected({ linear: p.linear, zone, kind }) };
  });
}

function parseNavLinks(xml: string, type: string, navPath: string): Array<{ path: string; anchor: string; title: string }> {
  return parseHrefList(parseNavInner(xml, type), navPath).map(({ path, anchor, title }) => ({ path, anchor, title }));
}

export function parseLandmarkLinks(xml: string, navPath: string): Array<{ path: string; anchor: string; types: string[] }> {
  return parseHrefList(parseNavInner(xml, "landmarks"), navPath).map(({ path, anchor, types, title }) => ({
    path,
    anchor,
    types: types.length ? types : title ? [] : [],
  }));
}

function parseGuideLinks(opf: string, opfDir: string): Array<{ path: string; anchor: string; types: string[] }> {
  const guide = opf.match(/<guide\b[^>]*>([\s\S]*?)<\/guide>/i);
  if (!guide) return [];
  const out: Array<{ path: string; anchor: string; types: string[] }> = [];
  const re = /<reference\b([^>]*)\/?>/gi;
  let m: RegExpExecArray | null;
  while ((m = re.exec(guide[1] || ""))) {
    const a = tagAttrs(m[1] || "");
    if (!a.href) continue;
    const resolved = resolveHrefFromDir(opfDir, a.href);
    if (!resolved) continue;
    const t = (a.type || "").toLowerCase();
    const mapped = t === "text" || t === "start" ? "bodymatter" : t;
    out.push({ path: resolved.path, anchor: resolved.anchor, types: mapped ? [mapped] : [] });
  }
  return out;
}

function matchLandmark(
  marks: Array<{ path: string; anchor: string; types: string[] }>,
  path: string,
  anchor: string,
): string[] {
  const pl = path.toLowerCase();
  const exact = marks.find((m) => m.path.toLowerCase() === pl && m.anchor && m.anchor === anchor);
  if (exact?.types.length) return exact.types;
  const file = marks.find((m) => m.path.toLowerCase() === pl);
  return file?.types || [];
}

function pickKind(types: string[]): string {
  for (const k of KIND_RANK) {
    if (types.includes(k)) return k;
  }
  return types[0] || "";
}

function zoneFromKind(kind: string): EpubZone {
  if (BODY_KINDS.has(kind)) return "body";
  if (FRONT_KINDS.has(kind)) return "front";
  if (BACK_KINDS.has(kind)) return "back";
  return "unsicher";
}

/** EPUB2 without landmarks: title, author bio and TOC stay front and unselected. */
export function guessPartKind(part: Pick<EpubPart, "title" | "text" | "kind" | "zipPath">, index: number): string {
  if (part.kind) return part.kind;
  if (/inbook|bookwire|promotion|advert|also[-_]?by|other[-_]?book/i.test(part.zipPath || "")) return "backmatter";
  const title = (part.title || "").replace(/\s+/g, " ").trim();
  const tlow = title.toLowerCase();
  const text = (part.text || "").trim();
  const head = text.slice(0, 400).toLowerCase();
  const low = text.toLowerCase();
  if (/titelblatt|title page|copyright|impressum/.test(tlow) || /titelblatt/.test(head)) return "titlepage";
  if (index === 0 && text.length < 500 && !/^\s*(?:prolog|kapitel|chapter)\b/im.test(text)) return "titlepage";
  const kapHits = (text.match(/\b(?:kapitel|chapter)\s+\w+/gi) || []).length;
  if ((/inhalt|inhaltsverzeichnis|^toc$/.test(tlow) || kapHits >= 6) && text.length < 4000 && text.length / Math.max(kapHits, 1) < 450) {
    return "toc";
  }
  if (
    /\bist autor(?:in)?\b|\bis the author\b|wurde geboren/.test(low) &&
    !/^\s*(?:prolog|kapitel|chapter)\b/im.test(text) &&
    text.length < 12000
  ) {
    return "contributors";
  }
  if (/weitere titel|auch von|also by|bestseller-autor|buch\s*\(?1\)?/i.test(low) && !/^\s*(?:prolog|kapitel|chapter)\b/im.test(text) && index >= 8) {
    return "backmatter";
  }
  if (/^prolog\b/i.test(tlow) || /^\s*prolog\b/im.test(text)) return "prologue";
  if (/^kapitel\b/i.test(tlow) || /^\s*kapitel\s+/im.test(text) || /^\s*chapter\s+/im.test(text)) return "chapter";
  return "";
}

export function classifyUnmarkedParts(parts: EpubPart[]): EpubPart[] {
  return parts.map((p, i) => {
    if (p.kind && p.zone && p.zone !== "unsicher") return p;
    const kind = guessPartKind(p, i);
    if (!kind) return p;
    const zone = zoneFromKind(kind);
    const z: EpubZone = zone === "unsicher" ? p.zone || "unsicher" : zone;
    return { ...p, kind, zone: z, selected: defaultPartSelected({ linear: p.linear, zone: z, kind }) };
  });
}

function sliceByAnchors(html: string, links: Array<{ anchor: string; title: string }>): Array<{ anchor: string; title: string; text: string }> {
  const unique: Array<{ anchor: string; title: string; at: number }> = [];
  for (const l of links) {
    if (!l.anchor) continue;
    const at = findIdOffset(html, l.anchor);
    if (at < 0) continue;
    if (unique.some((u) => u.anchor === l.anchor)) continue;
    unique.push({ anchor: l.anchor, title: l.title, at });
  }
  unique.sort((a, b) => a.at - b.at);
  if (!unique.length) {
    return [{ anchor: "", title: headingTitle(html), text: stripHtml(html) }];
  }
  const slices: Array<{ anchor: string; title: string; text: string }> = [];
  for (let i = 0; i < unique.length; i++) {
    const start = unique[i].at;
    const end = i + 1 < unique.length ? unique[i + 1].at : html.length;
    slices.push({
      anchor: unique[i].anchor,
      title: unique[i].title,
      text: stripHtml(html.slice(start, end)),
    });
  }
  if (unique[0].at > 0) {
    const head = stripHtml(html.slice(0, unique[0].at));
    if (head.trim()) {
      const lead = links.find((l) => !l.anchor)?.title || headingTitle(html) || unique[0].title;
      slices.unshift({ anchor: "", title: lead, text: head });
    }
  }
  return slices.filter((s) => s.text.trim());
}

function findIdOffset(html: string, id: string): number {
  const safe = id.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
  const m = html.match(new RegExp(`<(?:[^>]*?)\\sid=["']${safe}["'][^>]*>`, "i"));
  if (!m || m.index == null) return -1;
  return m.index;
}

function headingTitle(html: string): string {
  const m = html.match(/<h[1-3][^>]*>([\s\S]{2,80}?)<\/h[1-3]>/i);
  return m ? decodeEntities(stripHtml(m[1] || "")).replace(/\s+/g, " ").trim() : "";
}

function dirname(p: string): string {
  const n = p.replace(/\\/g, "/");
  const i = n.lastIndexOf("/");
  return i < 0 ? "" : n.slice(0, i);
}

function basename(p: string): string {
  const n = p.replace(/\\/g, "/");
  return n.slice(n.lastIndexOf("/") + 1).replace(/\.(xhtml|html|htm)$/i, "");
}

function normalizeZipPath(p: string): string {
  const parts: string[] = [];
  for (const seg of p.replace(/\\/g, "/").split("/")) {
    if (!seg || seg === ".") continue;
    if (seg === "..") {
      if (!parts.length) return "";
      parts.pop();
      continue;
    }
    parts.push(seg);
  }
  return parts.join("/");
}

function resolveZip(dir: string, href: string): string | null {
  const clean = href.split("?")[0].split("#")[0];
  if (!clean) return dir;
  if (clean.startsWith("/")) return normalizeZipPath(clean.slice(1));
  return normalizeZipPath(dir ? `${dir}/${clean}` : clean) || null;
}

function resolveHref(baseFile: string, href: string): { path: string; anchor: string } | null {
  return resolveHrefFromDir(dirname(baseFile), href) || (href.startsWith("#") ? { path: baseFile, anchor: href.slice(1) } : null);
}

function resolveHrefFromDir(dir: string, href: string): { path: string; anchor: string } | null {
  const hash = href.includes("#") ? href.slice(href.indexOf("#") + 1) : "";
  const pathPart = href.split("#")[0];
  if (!pathPart) return dir ? null : { path: "", anchor: hash };
  const path = resolveZip(dir, pathPart);
  if (!path) return null;
  return { path, anchor: hash };
}

function decodeEntities(s: string): string {
  return (s || "")
    .replace(/&nbsp;/gi, " ")
    .replace(/"/gi, '"')
    .replace(/&#34;/g, '"')
    .replace(/'/gi, "'")
    .replace(/&#39;/g, "'")
    .replace(/</gi, "<")
    .replace(/>/gi, ">")
    .replace(/&#(\d+);/g, (_, n) => String.fromCharCode(Number(n)))
    .replace(/&#x([0-9a-f]+);/gi, (_, n) => String.fromCharCode(parseInt(n, 16)))
    .replace(/&/gi, "&");
}

function stripHtml(html: string): string {
  const withAlt = html.replace(/<(img|image|area)\b([^>]*)\/?>/gi, (_all, _tag, raw: string) => {
    const a = tagAttrs(raw || "");
    const label = a.alt || a["aria-label"] || a.title || "";
    return label ? ` ${decodeEntities(label)} ` : " ";
  });
  return decodeEntities(
    withAlt
      .replace(/<script[\s\S]*?<\/script>/gi, "")
      .replace(/<style[\s\S]*?<\/style>/gi, "")
      .replace(/<a:t[\s\S]*?>/gi, "")
      .replace(/<\/a:t>/gi, "\n")
      .replace(/<br\s*\/?>/gi, "\n")
      .replace(/<\/(p|div|h1|h2|h3|li|tr|figcaption)>/gi, "\n")
      .replace(/<[^>]+>/g, " "),
  )
    .replace(/[ \t]+/g, " ")
    .replace(/\n /g, "\n")
    .trim();
}

export function parseOpfA11y(opf: string): {
  language: string;
  accessMode: string[];
  accessibilityFeature: string[];
  accessibilitySummary: string;
  conformsTo: string;
} {
  const language = dcText(opf, "language");
  const accessMode = metaValues(opf, "schema:accessMode");
  const accessibilityFeature = metaValues(opf, "schema:accessibilityFeature");
  const accessibilitySummary = metaValues(opf, "schema:accessibilitySummary").join(" ").trim();
  const conformsTo = metaValues(opf, "dcterms:conformsTo").filter((v) => /a11y|accessibility/i.test(v)).join(" ");
  return { language, accessMode, accessibilityFeature, accessibilitySummary, conformsTo };
}

function dcText(opf: string, name: string): string {
  const m = opf.match(new RegExp(`<dc:${name}[^>]*>([^<]*)</dc:${name}>`, "i"));
  return decodeEntities((m?.[1] || "").replace(/\s+/g, " ").trim());
}

function metaValues(opf: string, property: string): string[] {
  const out: string[] = [];
  const prop = property.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
  const pair = new RegExp(`<meta\\b([^>]*)>`, "gi");
  let m: RegExpExecArray | null;
  while ((m = pair.exec(opf))) {
    const a = tagAttrs(m[1] || "");
    const key = `${a.property || a.name || ""}`.toLowerCase();
    if (key !== property.toLowerCase()) continue;
    let val = (a.content || "").trim();
    if (!val) {
      const rest = opf.slice(m.index);
      const inner = rest.match(/^<meta\b[^>]*>([^<]*)<\/meta>/i);
      val = (inner?.[1] || "").trim();
    }
    if (val) out.push(decodeEntities(val));
  }
  return out.filter((v, i, a) => a.indexOf(v) === i);
}

