import { apiCreateDocument, apiGetDocument, apiPatchDocument } from "./api";
import { packWorld } from "./normalize";
import type { World, StammCharacter, WorldPack } from "./types";
import { joinDocId, parsePartDocId, partDocHeadId, partDocRevId, type EpubPart } from "./epub";

type DocPayload = Record<string, unknown>;

export type RevisionPlan =
  | { action: "create"; headId: string; rev: 1 }
  | { action: "keep"; headId: string; rev: number }
  | { action: "bump"; headId: string; snapId: string; prevRev: number; nextRev: number };

export function planDocumentRevision(opts: {
  headId: string;
  existing: { text?: unknown; rev?: unknown } | null;
  nextText: string;
}): RevisionPlan {
  const headId = partDocHeadId(opts.headId);
  if (!opts.existing) return { action: "create", headId, rev: 1 };
  const rev = Number(opts.existing.rev || 1) || 1;
  if (String(opts.existing.text || "").trim() === String(opts.nextText || "").trim()) {
    return { action: "keep", headId, rev };
  }
  return {
    action: "bump",
    headId,
    snapId: partDocRevId(headId, rev),
    prevRev: rev,
    nextRev: rev + 1,
  };
}

async function readDoc(id: string): Promise<DocPayload | null> {
  try {
    const got = await apiGetDocument(id);
    if (got.ok === false) return null;
    const doc = (got.document || got) as DocPayload;
    if (!doc || typeof doc !== "object" || (!doc.id && !doc.text && got.ok !== true)) return null;
    return doc;
  } catch {
    return null;
  }
}

async function writeNew(body: DocPayload): Promise<boolean> {
  try {
    await apiCreateDocument(body);
    return true;
  } catch {
    return false;
  }
}

async function writePatch(id: string, body: DocPayload): Promise<boolean> {
  try {
    await apiPatchDocument(id, body);
    return true;
  } catch {
    return false;
  }
}

/** Kopf bleibt, alte Fassung wird .rN. Text gleich → keine neue Revision. */
export async function persistVersionedDocument(head: DocPayload): Promise<string | null> {
  const rawId = String(head.id || "");
  if (!rawId) return null;
  const existing = await readDoc(partDocHeadId(rawId));
  const text = String(head.text || "");
  const plan = planDocumentRevision({ headId: rawId, existing, nextText: text });
  if (plan.action === "create") {
    const ok = await writeNew({ ...head, id: plan.headId, rev: 1, supersededBy: "" });
    return ok ? plan.headId : null;
  }
  if (plan.action === "keep") return plan.headId;
  const snap = { ...existing, id: plan.snapId, rev: plan.prevRev, headId: plan.headId, supersededBy: plan.headId };
  await writeNew(snap);
  const next = { ...head, id: plan.headId, rev: plan.nextRev, previousId: plan.snapId };
  const patched = await writePatch(plan.headId, next);
  if (!patched) await writeNew(next);
  return plan.headId;
}

export async function persistPartDocuments(opts: {
  worldId: string;
  sourceName: string;
  parts: EpubPart[];
}): Promise<string[]> {
  const ids: string[] = [];
  for (const p of opts.parts) {
    if (!p.selected || !p.docId || !String(p.text || "").trim()) continue;
    const ref = parsePartDocId(p.docId);
    const id = await persistVersionedDocument({
      id: p.docId,
      title: p.title || p.zipPath || p.docId,
      name: p.title || p.zipPath || p.docId,
      text: p.text,
      worldId: opts.worldId,
      documentGroup: `world-source:${opts.worldId}`,
      docKind: "src-part",
      sourceKey: ref?.sourceKey || "",
      spineIndex: p.index,
      zipPath: p.zipPath,
      anchor: p.anchor,
      zone: p.zone,
      partKind: p.kind,
      layer: p.layer || "",
      schema: ref?.schema || 1,
      ocrStatus: "ready",
    });
    if (id) ids.push(id);
  }
  return ids;
}

export async function persistJoinDocument(opts: { worldId: string; name: string; text: string }): Promise<string | null> {
  return persistVersionedDocument({
    id: joinDocId(opts.worldId),
    title: opts.name,
    name: opts.name,
    text: opts.text,
    worldId: opts.worldId,
    documentGroup: `world-source:${opts.worldId}`,
    docKind: "src-join",
    schema: 1,
    ocrStatus: "ready",
  });
}

/** WorldPack v1 transfer: export referenced source evidence alongside the world.
 * A missing document aborts export instead of generating an unusable pack.
 */
export async function packWorldWithSources(world: World, characters: StammCharacter[]): Promise<WorldPack> {
  const pack = packWorld(world, characters);
  const sourceDocuments: Array<Record<string, unknown>> = [];
  for (const id of new Set(world.sourcePartIds || [])) {
    const got = await apiGetDocument(id);
    const document = (got.document || got) as Record<string, unknown>;
    if (got.ok === false || document.id !== id || !String(document.text || "").trim()) {
      throw new Error(`Quellbeleg fehlt oder ist leer: ${id}`);
    }
    sourceDocuments.push(document);
  }
  return { ...pack, sourceDocuments };
}
