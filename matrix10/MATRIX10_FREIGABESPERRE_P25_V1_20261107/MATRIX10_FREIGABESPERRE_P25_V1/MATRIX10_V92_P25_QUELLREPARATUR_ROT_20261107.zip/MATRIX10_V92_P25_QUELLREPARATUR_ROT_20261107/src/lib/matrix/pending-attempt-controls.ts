/** Pure UI gate derived from the canonical pending-input GET state.
 * Running with a current server proof must never be retried. An unprovable
 * old attempt may be explicitly retried by the user, with first SQL commit
 * winning. This helper does NOT start work, persist state or perform retries.
 */
export function canExplicitlyRetryPendingAttempt(view: {
  attemptRunning: boolean;
  attemptUnklar?: boolean | null;
}): boolean {
  return !view.attemptRunning || view.attemptUnklar === true;
}
