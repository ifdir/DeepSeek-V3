import type { FateSeed, FateState, MeaningSpace, SceneState, Session, StammCharacter, World } from "./types.ts";
import type { SynapseFire } from "./types.ts";

export function pickFate(opts: {
  world: World;
  session: Session;
  speaker?: StammCharacter;
  fired: SynapseFire[];
  stimulus: string;
}): { seed: FateSeed | null; state: FateState } {
  if (!opts.session.fate.enabled) {
    return { seed: null, state: opts.session.fate };
  }
  const tags = new Set<MeaningSpace>(opts.fired.map((f) => f.space));
  const n = opts.stimulus.toLowerCase();
  let best: { seed: FateSeed; score: number } | null = null;
  for (const seed of opts.world.fateSeeds) {
    let score = 0.15;
    for (const t of seed.tags) if (tags.has(t)) score += 0.22;
    const words = seed.title.toLowerCase().split(/\s+/);
    if (words.some((w) => w.length > 4 && n.includes(w))) score += 0.2;
    if (opts.session.scene.danger > 0.5 && seed.tags.includes("Gewalt")) score += 0.15;
    if (opts.session.turnIndex < 3) score += 0.08;
    if (opts.session.fate.activeSeedId === seed.id) score += 0.12;
    if (!best || score > best.score) best = { seed, score };
  }
  const seed = best && best.score >= 0.28 ? best.seed : null;
  const state: FateState = {
    ...opts.session.fate,
    activeSeedId: seed?.id,
    beat: seed?.beat ?? opts.session.fate.beat,
    pressure: seed ? Math.min(1, opts.session.fate.pressure * 0.7 + 0.35) : opts.session.fate.pressure * 0.92,
    lastShiftTurn: seed && seed.id !== opts.session.fate.activeSeedId ? opts.session.turnIndex : opts.session.fate.lastShiftTurn,
  };
  return { seed, state };
}

export function scenePressureTags(scene: SceneState): MeaningSpace[] {
  const tags: MeaningSpace[] = [];
  if (scene.danger > 0.45) tags.push("Bedrohung", "Gewalt");
  if (scene.tension > 0.5) tags.push("Macht", "Angst");
  if (scene.openMatters.some((m) => /tuer|tür|schloss|tablette|geheim/i.test(m))) {
    tags.push("Verrat", "Schutz");
  }
  return tags;
}
