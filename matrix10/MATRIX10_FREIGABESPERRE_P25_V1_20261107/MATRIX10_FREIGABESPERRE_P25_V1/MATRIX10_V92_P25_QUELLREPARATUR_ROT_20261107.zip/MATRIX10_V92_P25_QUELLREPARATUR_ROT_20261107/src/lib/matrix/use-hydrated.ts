import { useEffect, useState } from "react";
import { ensureSeeded, getMccReaderState, rebindStoredActor, subscribeMccReaderState, useMatrix } from "./store";

/** True only after Flask MCC Reader finished AND Zustand applied it. Seed ≠ Reload-Nachweis. */
export function useHydrated() {
  const [ok, setOk] = useState(false);
  useEffect(() => {
    const apply = () => {
      const reader = getMccReaderState();
      const persistReady = (() => {
        try {
          return Boolean(useMatrix.persist.hasHydrated());
        } catch {
          return false;
        }
      })();
      if (reader.status === "ok" && persistReady) {
        ensureSeeded();
        void rebindStoredActor().catch(() => undefined);
        setOk(true);
        return;
      }
      // Do not flip hydrated back to false — that unmounts the product and
      // can drop the stored actor from the live Zustand slice.
    };
    const unsubReader = subscribeMccReaderState(apply);
    try {
      apply();
      const unsub = useMatrix.persist.onFinishHydration(apply);
      return () => {
        unsub?.();
        unsubReader();
      };
    } catch {
      apply();
      return () => {
        unsubReader();
      };
    }
  }, []);
  return ok;
}

export function useMccReaderError(): string | null {
  const [error, setError] = useState<string | null>(null);
  useEffect(() => {
    const sync = () => {
      const st = getMccReaderState();
      setError(st.status === "error" ? st.error || "MCC-Reader fehlgeschlagen" : null);
    };
    sync();
    return subscribeMccReaderState(sync);
  }, []);
  return error;
}
