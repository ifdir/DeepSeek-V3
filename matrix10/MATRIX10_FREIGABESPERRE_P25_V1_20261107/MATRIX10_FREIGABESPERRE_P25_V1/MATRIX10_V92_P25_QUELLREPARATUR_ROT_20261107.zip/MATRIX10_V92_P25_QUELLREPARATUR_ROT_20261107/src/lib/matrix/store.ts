import { create } from "zustand";
import { persist } from "zustand/middleware";
import {
  apiCommitUpload,
  apiIngestUpload,
  apiCreateCharacter,
  apiCreatePreference,
  apiCreateReview,
  apiCreateSession,
  apiGetSession,
  apiCreateSessionSnapshot,
  apiCreateTrigger,
  apiCreateUpload,
  apiPatchUpload,
  apiCreateUser,
  apiCreateWorld,
  apiImportWorldPack,
  apiCreateDocument,
  apiDeleteCharacter,
  apiDeletePreference,
  apiDeleteSession,
  apiDeleteSnapshot,
  apiDeleteTrigger,
  apiDeleteUpload,
  apiDeleteUser,
  apiDeleteUserLogs,
  apiHardResetUser,
  apiResetUserSessions,
  apiDeleteWorld,
  apiGetMcc,
  apiImportMcc,
  apiKernelReset,
  apiPatchCharacter,
  apiPatchGoal,
  apiPatchPreference,
  apiPatchProposition,
  apiPatchSession,
  apiPatchTrigger,
  apiPatchUser,
  apiPatchWorld,
  apiPostGoal,
  apiPostLog,
  apiPostMemory,
  apiPostProposition,
  apiPutConfig,
  apiPutRelation,
  apiPutSession,
  apiResetSessionChat,
  apiResetSessionFull,
  apiResetSessionMemory,
  apiResetSessionUploads,
  apiResolveReview,
  apiRestoreSnapshot,
  apiCreateGraph,
  apiPatchReview,
  rememberActor,
  readStoredActor,
  clearStoredActor,
  apiListUserDirectory,
} from "./api";
import { makeOutsiderAvatar } from "./seed-gasthaus";
import { createSession as spawnSession, resetMemoryOnly } from "./session-engine";
import { uid } from "./ids";
import { canonicalId, canonicalizeTempIdsInPlace } from "./id-owner";
import { hydrateCharacter, hydrateSession, hydrateWorld, remapPack } from "./normalize";
import { persistJoinDocument } from "./source-docs";
import { FieldWriteTracker } from "./field-writes";
import {
  GASTHAUS_ID,
  type AppConfig,
  type DirectedRel,
  type LogLine,
  type Memory,
  type Preference,
  type Proposition,
  type ReviewItem,
  type Session,
  type SessionGoal,
  type Snapshot,
  type StammCharacter,
  type TriggerRule,
  type UploadAsset,
  type UserProfile,
  type World,
  type WorldPack,
} from "./types";

const DEFAULT_CONFIG: AppConfig = {
  autoChatTurns: 2,
  autoChatDelayMs: 5000,
  contextTurns: 10,
  fateDefault: true,
  narratorDefault: true,
  debug: false,
  model: "gpt-4o-mini",
  temperature: 0.7,
  maxTokens: 700,
  apiKey: "",
  provider: "openai",
  llmEnabled: true,
  scope: "user",
  scopeId: "",
};

function isSelectableWorld(w: World, actor: string): boolean {
  return w.ownerUserId === actor || (w.id === GASTHAUS_ID && w.ownerUserId === "admin");
}

function defaultUser(): UserProfile {
  return {
    id: "admin",
    name: "admin",
    language: "de",
    defaultRole: "teilnehmer",
    lastWorldId: null,
    lastSessionId: null,
    tts: false,
    sttMode: "dictation",
    largeType: false,
    highContrast: false,
    createdAt: new Date().toISOString(),
    avatarsByWorld: {},
    avatarsBySession: {},
    providerConfig: { localOnly: true },
  };
}

const MIGRATE_CLASSES = [
  "users",
  "activeUserId",
  "worlds",
  "characters",
  "sessions",
  "uploads",
  "reviews",
  "snapshots",
  "triggers",
  "logs",
  "preferences",
  "config",
] as const;

const LEGACY_V3 = "matrix10.mcc.v3";
const LEGACY_V4 = "matrix10.mcc.v4";
const BACKUP_KEY = "matrix10.mcc.v3.backup";

let importOnceStarted = false;

function lsGet(key: string): string | null {
  try {
    if (typeof localStorage === "undefined") return null;
    return localStorage.getItem(key);
  } catch {
    return null;
  }
}

function lsSet(key: string, value: string): void {
  try {
    if (typeof localStorage === "undefined") return;
    localStorage.setItem(key, value);
  } catch {
    /* ignore */
  }
}

function lsRemove(key: string): void {
  try {
    if (typeof localStorage === "undefined") return;
    localStorage.removeItem(key);
  } catch {
    /* ignore */
  }
}

function unwrapPersist(raw: unknown): Record<string, unknown> | null {
  if (!raw || typeof raw !== "object") return null;
  const obj = raw as Record<string, unknown>;
  if (obj.state && typeof obj.state === "object") return obj.state as Record<string, unknown>;
  return obj;
}

function countNum(v: unknown): number {
  if (typeof v === "number" && Number.isFinite(v)) return v;
  if (v && typeof v === "object" && !Array.isArray(v) && Object.keys(v as object).length > 0) return 1;
  if (typeof v === "string" && v !== "" && v !== "0") return Number(v) || 0;
  return 0;
}

function missingIdsEmpty(missing: unknown): boolean {
  if (missing == null) return true;
  if (Array.isArray(missing)) return missing.length === 0;
  if (typeof missing !== "object") return false;
  return Object.values(missing as Record<string, unknown>).every(
    (v) => v == null || (Array.isArray(v) && v.length === 0),
  );
}

function importCountsOk(res: {
  ok?: boolean;
  sourceCounts?: Record<string, unknown>;
  targetCounts?: Record<string, unknown>;
  idCompare?: {
    preserved?: boolean;
    missing?: Record<string, string[]> | string[];
    unresolved?: Record<string, string[]> | string[];
    skippedBlocking?: Record<string, string[]> | string[];
    cutoverComplete?: boolean;
  };
  classes?: Record<string, { source?: number; target?: number; action?: string }>;
}): boolean {
  if (!res.ok) return false;
  if (!res.idCompare) return false;
  // missing cutoverComplete field → conservative FALSE (no localStorage delete)
  if (res.idCompare.cutoverComplete !== true) return false;
  if (res.idCompare.preserved !== true) return false;
  if (!missingIdsEmpty(res.idCompare.missing)) return false;
  if (!missingIdsEmpty(res.idCompare.unresolved)) return false;
  for (const cls of MIGRATE_CLASSES) {
    const meta = res.classes?.[cls];
    const src = meta ? Number(meta.source ?? 0) : countNum(res.sourceCounts?.[cls]);
    const tgt = meta ? Number(meta.target ?? 0) : countNum(res.targetCounts?.[cls]);
    if (src > tgt) return false;
  }
  return true;
}

/** One-shot localStorage → POST /api/import/mcc. Removes v3/v4 ONLY after successful
 * import AND idCompare.cutoverComplete === true (missing field → false). Also requires
 * preserved === true, missing empty, unresolved empty. Count compare is additional,
 * never a substitute for ID completeness. Backup key is READ-ONLY and is never used
 * as master. Skipped-blocking (B not in SQLite) must not lsRemove.
 */
export async function importMccOnce(): Promise<{ imported: boolean; error?: string }> {
  if (importOnceStarted) return { imported: false };
  importOnceStarted = true;
  const rawV4 = lsGet(LEGACY_V4);
  const rawV3 = lsGet(LEGACY_V3);
  if (!rawV4 && !rawV3) return { imported: false };
  const raw = rawV4 || rawV3 || "";
  let parsed: unknown;
  try {
    parsed = JSON.parse(raw);
  } catch {
    return { imported: false, error: "legacy JSON parse failed" };
  }
  const state = unwrapPersist(parsed);
  const active = state && typeof state.activeUserId === "string" ? state.activeUserId : "";
  if (active) rememberActor(active);
  try {
    const res = await apiImportMcc(parsed);
    if (!importCountsOk(res)) {
      return { imported: false, error: res.error || res.message || "import count compare failed" };
    }
    const backupSrc = rawV3 || rawV4;
    if (backupSrc) lsSet(BACKUP_KEY, backupSrc);
    lsRemove(LEGACY_V3);
    lsRemove(LEGACY_V4);
    return { imported: true };
  } catch (err) {
    return { imported: false, error: err instanceof Error ? err.message : String(err) };
  }
}

/** Custom persist storage: SQL is master. setItem is a NO-OP (no browser-master write).
 * Zustand PersistStorage.getItem must return { state, version }, not a JSON string.
 * Reader-Fehler darf Hydration nicht als Erfolg markieren (Seed ≠ Reload-Nachweis).
 */
export type MccReaderState = { status: "pending" | "ok" | "error"; error?: string };

let mccReaderState: MccReaderState = { status: "pending" };
const mccReaderListeners = new Set<() => void>();

function setMccReaderState(next: MccReaderState): void {
  mccReaderState = next;
  mccReaderListeners.forEach((fn) => fn());
}

export function getMccReaderState(): MccReaderState {
  return mccReaderState;
}

export function subscribeMccReaderState(fn: () => void): () => void {
  mccReaderListeners.add(fn);
  return () => {
    mccReaderListeners.delete(fn);
  };
}

export const flaskMccStorage = {
  setItem: async (_name: string, _value: unknown): Promise<void> => {
    /* NO-OP: flaskMccStorage.setItem writes no global snapshot */
  },
  getItem: async (_name: string): Promise<{ state: Record<string, unknown>; version: number } | null> => {
    if (typeof window === "undefined") return null;
    await importMccOnce();
    try {
      const state = await fetchOwnerPartial();
      setMccReaderState({ status: "ok" });
      return { version: 0, state };
    } catch (err) {
      setMccReaderState({
        status: "error",
        error: err instanceof Error ? err.message : String(err),
      });
      return null;
    }
  },
  removeItem: async (_name: string): Promise<void> => {
    /* no-op for product master */
  },
};

function emptyOwnerCollections(): Record<string, unknown> {
  return {
    sessions: [],
    uploads: [],
    reviews: [],
    snapshots: [],
    triggers: [],
    logs: [],
    preferences: [],
  };
}

async function fetchOwnerPartial(): Promise<Record<string, unknown>> {
  const stored = readStoredActor();
  if (stored) {
    rememberActor(stored);
    try {
      const mcc = await apiGetMcc(stored);
      const users = Array.isArray(mcc.users) ? (mcc.users as UserProfile[]) : [];
      rememberActor(stored);
      return {
        users,
        activeUserId: stored,
        worlds: ((mcc.worlds as World[]) ?? []).map(hydrateWorld),
        characters: ((mcc.characters as StammCharacter[]) ?? []).map(hydrateCharacter),
        sessions: mcc.sessions ?? [],
        uploads: mcc.uploads ?? [],
        reviews: mcc.reviews ?? [],
        snapshots: mcc.snapshots ?? [],
        triggers: mcc.triggers ?? [],
        logs: mcc.logs ?? [],
        preferences: mcc.preferences ?? [],
        config: mcc.config ?? {},
      };
    } catch (err) {
      throw err instanceof Error ? err : new Error(String(err));
    }
  }
  const dir = await apiListUserDirectory();
  return {
    users: dir.users ?? [],
    activeUserId: "",
    worlds: [],
    characters: [],
    ...emptyOwnerCollections(),
    config: {},
  };
}

/** Re-bind stored actor after reload/navigation if Zustand lost the user row. */
export async function rebindStoredActor(): Promise<void> {
  const stored = readStoredActor();
  if (!stored) return;
  const st = useMatrix.getState();
  if (st.activeUserId === stored && st.users.some((u) => u.id === stored)) return;
  rememberActor(stored);
  const partial = await fetchOwnerPartial();
  useMatrix.setState(partial as Partial<MatrixState>);
}

/** UI-Erfolg nur nach Owner-Write. Fail restores the slice and surfaces PERSIST_FAILED. */
function persistFailed(label: string, err: unknown): void {
  const message = `${label}: ${err instanceof Error ? err.message : String(err)}`;
  try {
    const st = useMatrix.getState();
    const entry: LogLine = {
      id: uid("log"),
      at: new Date().toISOString(),
      level: "error",
      code: "PERSIST_FAILED",
      message,
    };
    useMatrix.setState({ logs: [entry, ...st.logs].slice(0, 400) });
    void canonicalizeTempIdsInPlace(entry)
      .then(() => apiPostLog(entry))
      .catch(() => undefined);
  } catch {
    /* ignore */
  }
}

let persistTail: Promise<void> = Promise.resolve();
let liveSessionGate: Promise<string> | null = null;

/** UI-Erfolg nur nach Owner-Write. Serialized so overlapping keystrokes cannot revert each other. */
function writeOrRevert(label: string, ownerWrite: () => Promise<unknown>, apply: () => void): Promise<boolean> {
  const done = persistTail.then(async () => {
    try {
      await ownerWrite();
      apply();
      return true;
    } catch (err) {
      // No local mutation occurred before ownerWrite completed. Restoring an
      // entire old store snapshot would erase later, independently edited text.
      persistFailed(label, err);
      return false;
    }
  });
  persistTail = done.then(
    () => undefined,
    () => undefined,
  );
  return done;
}

/** Text-/Struktureingaben werden sofort lokal angezeigt; die bestehende Owner-
 * Schreibqueue persistiert weiter strikt seriell. Kein zweiter Wahrheitsstore.
 * Bei Fehlern nur das zuletzt fehlgeschlagene Feld zurueckrollen, nicht einen
 * fremden inzwischen erfolgreich geschriebenen Zustand.
 */
const fieldWrites = new FieldWriteTracker();
function writeEditedFields(
  label: string,
  scope: "world" | "character",
  id: string,
  patch: Record<string, unknown>,
  current: () => Record<string, unknown> | undefined,
  apply: (update: Record<string, unknown>) => void,
  ownerWrite: () => Promise<unknown>,
): Promise<boolean> {
  const before = current();
  if (!before) return Promise.resolve(false);
  const ticket = fieldWrites.begin(scope, id, patch, before);
  apply(patch); // React's controlled value follows the keystroke, not the HTTP ACK.
  const done = persistTail.then(async () => {
    try {
      await ownerWrite();
      ticket.committed();
      return true;
    } catch (err) {
      const revert = ticket.failed();
      if (Object.keys(revert).length) apply(revert);
      persistFailed(label, err);
      return false;
    }
  });
  persistTail = done.then(() => undefined, () => undefined);
  return done;
}

/** Diagnose-only: product owner writes must use writeOrRevert. Logs may fail open. */
function persistWrite(label: string, op: Promise<unknown>, opts?: { skipLog?: boolean }): void {
  void op.catch(async (err) => {
    if (opts?.skipLog) return;
    persistFailed(label, err);
    try {
      const mcc = (await apiGetMcc()) as Record<string, unknown>;
      useMatrix.setState({
        users: (mcc.users as MatrixState["users"]) ?? useMatrix.getState().users,
        worlds: (mcc.worlds as MatrixState["worlds"]) ?? useMatrix.getState().worlds,
        characters: (mcc.characters as MatrixState["characters"]) ?? useMatrix.getState().characters,
        sessions: (mcc.sessions as MatrixState["sessions"]) ?? useMatrix.getState().sessions,
        uploads: (mcc.uploads as MatrixState["uploads"]) ?? useMatrix.getState().uploads,
        reviews: (mcc.reviews as MatrixState["reviews"]) ?? useMatrix.getState().reviews,
        snapshots: (mcc.snapshots as MatrixState["snapshots"]) ?? useMatrix.getState().snapshots,
        triggers: (mcc.triggers as MatrixState["triggers"]) ?? useMatrix.getState().triggers,
        preferences: (mcc.preferences as MatrixState["preferences"]) ?? useMatrix.getState().preferences,
        config: (mcc.config as MatrixState["config"]) ?? useMatrix.getState().config,
      });
    } catch {
      /* PERSIST_FAILED already visible */
    }
  });
}

function sessionEnvelope(s: Session): Record<string, unknown> {
  return {
    id: s.id,
    name: s.name,
    avatarId: s.avatarId,
    alias: s.alias,
    role: s.role,
    speakAs: s.speakAs ?? null,   // V92 Paket 14: the chosen speaker binding (session owner)
    pipeline: s.pipeline,
    autoChat: s.autoChat,
    focus: s.focus,
  };
}

interface MatrixState {
  users: UserProfile[];
  activeUserId: string;
  worlds: World[];
  characters: StammCharacter[];
  sessions: Session[];
  uploads: UploadAsset[];
  reviews: ReviewItem[];
  snapshots: Snapshot[];
  triggers: TriggerRule[];
  logs: LogLine[];
  preferences: Preference[];
  config: AppConfig;
  lastSpiegelJson: string | null;
  compassPreview: { characterId: string; json: string } | null;
  providerOnline: boolean;

  activeUser: () => UserProfile | undefined;
  selectableWorlds: () => World[];
  selectableCharacters: () => StammCharacter[];

  upsertUser: (u: UserProfile) => Promise<boolean>;
  setActiveUser: (id: string) => Promise<void>;
  patchUser: (id: string, patch: Partial<UserProfile>) => void;
  deleteUser: (id: string) => void;

  upsertWorld: (w: World, chars: StammCharacter[]) => Promise<boolean>;
  patchWorld: (id: string, patch: Partial<World>) => Promise<boolean>;
  deleteWorld: (id: string) => void;
  patchCharacter: (id: string, patch: Partial<StammCharacter>) => Promise<boolean>;
  addCharacter: (c: StammCharacter) => Promise<boolean>;
  deleteCharacter: (id: string) => Promise<boolean>;
  importPack: (pack: WorldPack) => Promise<string>;

  startSession: (opts: {
    worldId: string;
    userId?: string;
    avatarName?: string;
    avatarNotes?: string;
    situationId?: string;
    name?: string;
    avatarId?: string | null;
    // V65F (AMASTER §19 "aktive Figuren festlegen"): figures present at the start, chosen in the form.
    presentIds?: string[];
  }) => Promise<string>;
  ensureLiveSession: () => Promise<string>;
  saveSession: (s: Session) => void;
  acceptKernelSession: (s: Session) => void;
  deleteSession: (id: string) => void;
  setActiveSession: (id: string | null) => void;
  renameSession: (id: string, name: string) => void;
  setSessionWorld: (sessionId: string, worldId: string) => void;
  duplicateSession: (id: string) => Promise<string>;
  importSession: (raw: Session, confirmAuthority?: (message: string) => boolean) => Promise<string>;
  patchRelation: (sessionId: string, fromId: string, toId: string, patch: Partial<DirectedRel>) => void;
  addRelation: (sessionId: string, rel: DirectedRel) => void;
  addMemory: (sessionId: string, mem: Omit<Memory, "id">) => void;
  addGoal: (sessionId: string, goal: Omit<SessionGoal, "id">) => void;
  patchGoal: (sessionId: string, goalId: string, patch: Partial<SessionGoal>) => void;
  addProposition: (sessionId: string, p: Omit<Proposition, "id">) => void;
  patchProposition: (sessionId: string, propId: string, patch: Partial<Proposition>) => void;

  addUpload: (u: UploadAsset) => Promise<boolean>;
  patchUpload: (id: string, patch: Partial<UploadAsset>) => void;
  commitUpload: (id: string) => Promise<boolean>;
  deleteUpload: (id: string) => void;

  addReview: (r: ReviewItem) => void;
  patchReview: (id: string, patch: Partial<ReviewItem>) => void;
  resolveReview: (id: string, status: ReviewItem["status"], newValue?: string) => void;

  addSnapshot: (sessionId: string, name?: string) => string;
  restoreSnapshot: (id: string) => void;
  deleteSnapshot: (id: string) => void;

  addTrigger: (t: TriggerRule) => void;
  patchTrigger: (id: string, patch: Partial<TriggerRule>) => void;
  deleteTrigger: (id: string) => void;

  addPreference: (p: Preference) => void;
  patchPreference: (id: string, patch: Partial<Preference>) => void;
  deletePreference: (id: string) => void;

  log: (line: Omit<LogLine, "id" | "at">) => void;
  setConfig: (patch: Partial<AppConfig>) => void;
  applyLoadedConfig: (loaded: Partial<AppConfig>) => void;
  setSpiegel: (json: string | null) => void;
  setCompassPreview: (characterId: string, json: string) => void;
  setProviderOnline: (v: boolean) => void;

  resetSessionFull: (sessionId: string) => void;
  resetSessionChat: (sessionId: string) => void;
  resetSessionRuntime: (sessionId: string) => void;
  resetSessionMemory: (sessionId: string) => void;
  resetSessionUploads: (sessionId: string) => void;
  resetUserSessions: (userId: string) => void;
  hardResetRuntime: (userId?: string) => void;
  kernelReset: (sessionId: string, kind: "chat" | "runtime" | "memory" | "uploads") => void;
}

export const useMatrix = create<MatrixState>()(
  persist(
    (set, get) => ({
      users: [],
      activeUserId: "",
      worlds: [],
      characters: [],
      sessions: [],
      uploads: [],
      reviews: [],
      snapshots: [],
      triggers: [],
      logs: [],
      preferences: [],
      config: DEFAULT_CONFIG,
      lastSpiegelJson: null,
      compassPreview: null,
      providerOnline: false,

      activeUser: () => get().users.find((u) => u.id === get().activeUserId),
      selectableWorlds: () => {
        const actor = get().activeUserId;
        return get().worlds.filter((w) => isSelectableWorld(w, actor));
      },
      selectableCharacters: () => {
        const allowed = new Set(get().selectableWorlds().map((w) => w.id));
        return get().characters.filter((c) => allowed.has(c.worldId));
      },

      upsertUser: (u) => {
        const exists = get().users.some((x) => x.id === u.id);
        return writeOrRevert(
          exists ? "PATCH /api/users" : "POST /api/users",
          async () => {
            if (!exists) await canonicalizeTempIdsInPlace(u);
            return exists ? apiPatchUser(u.id, u) : apiCreateUser(u);
          },
          () => {
            const users = get().users.filter((x) => x.id !== u.id).concat(u);
            set({ users, activeUserId: u.id });
            rememberActor(u.id);
            if (!exists) return;
            void fetchOwnerPartial()
              .then((partial) => set(partial as Partial<MatrixState>))
              .catch((err) => persistFailed("GET /api/mcc", err));
          },
        );
      },
      setActiveUser: (id) => {
        const prev = get().activeUserId;
        rememberActor(id);
        set({ activeUserId: id });
        return fetchOwnerPartial()
          .then((partial) => {
            set(partial as Partial<MatrixState>);
          })
          .catch((err) => {
            if (prev) rememberActor(prev);
            else clearStoredActor();
            persistFailed("GET /api/mcc", err);
          });
      },
      patchUser: (id, patch) => {
        writeOrRevert(
          "PATCH /api/users",
          async () => {
            await canonicalizeTempIdsInPlace(patch);
            await apiPatchUser(id, patch);
            if (patch.providerConfig) {
              await apiPutConfig({
                ...get().config,
                model: patch.providerConfig.model || get().config.model,
                endpoint: patch.providerConfig.endpoint,
                scope: "user",
                scope_id: id,
                scopeId: id,
              });
            }
          },
          () => set({ users: get().users.map((u) => (u.id === id ? { ...u, ...patch } : u)) }),
        );
      },
      deleteUser: (id) => {
        if (id === "admin") return;
        writeOrRevert(
          "DELETE /api/users",
          () => apiDeleteUser(id),
          () => {
            const leaving = get().activeUserId === id;
            if (leaving) clearStoredActor();
            set({
              users: get().users.filter((u) => u.id !== id),
              sessions: get().sessions.filter((s) => s.userId !== id),
              uploads: get().uploads.filter((u) => u.userId !== id),
              activeUserId: leaving ? "" : get().activeUserId,
            });
          },
        );
      },

      upsertWorld: (w, chars) => {
        const exists = get().worlds.some((x) => x.id === w.id);
        const prevChars = get().characters;
        return writeOrRevert(
          exists ? "PATCH /api/worlds" : "POST /api/worlds",
          async () => {
            await canonicalizeTempIdsInPlace({ world: w, characters: chars });
            if (exists) await apiPatchWorld(w.id, w);
            else await apiCreateWorld(w);
            if (w.sourceText) {
              await persistJoinDocument({
                worldId: w.id,
                name: w.sourceName || w.name,
                text: w.sourceText,
              });
            }
            for (const c of chars) {
              if (prevChars.some((x) => x.id === c.id)) await apiPatchCharacter(c.id, c);
              else await apiCreateCharacter(c);
            }
          },
          () => {
            const worlds = get().worlds.filter((x) => x.id !== w.id).concat(hydrateWorld(w));
            const others = get().characters.filter((c) => c.worldId !== w.id);
            set({ worlds, characters: [...others, ...chars.map(hydrateCharacter)] });
          },
        );
      },
      patchWorld: (id, patch) => {
        return writeEditedFields(
          "PATCH /api/worlds",
          "world",
          id,
          patch as Record<string, unknown>,
          () => get().worlds.find((w) => w.id === id) as unknown as Record<string, unknown> | undefined,
          (update) => set({ worlds: get().worlds.map((w) => (w.id === id ? hydrateWorld({ ...w, ...update }) : w)) }),
          async () => {
            await canonicalizeTempIdsInPlace(patch);
            return apiPatchWorld(id, patch);
          },
        );
      },
      deleteWorld: (id) => {
        writeOrRevert(
          "DELETE /api/worlds",
          () => apiDeleteWorld(id),
          () =>
            set({
              worlds: get().worlds.filter((w) => w.id !== id),
              characters: get().characters.filter((c) => c.worldId !== id),
              sessions: get().sessions.filter((s) => s.worldId !== id),
            }),
        );
      },
      patchCharacter: (id, patch) => {
        // Ledger edits remove VALUES from several fields. Await the existing
        // PATCH writer and hydrate its canonical SQL response, not a local
        // shallow {...character, removeLearned} edit.
        const ledgerCommand = patch as Record<string, unknown>;
        if (ledgerCommand.removeLearned || ledgerCommand.removeLearnedAll === true) {
          let readback: StammCharacter | null = null;
          return writeOrRevert(
            "PATCH /api/characters (ledger)",
            async () => {
              const out = await apiPatchCharacter(id, patch) as { character?: StammCharacter };
              if (!out.character) throw new Error("Kein bestätigter Charakterstand vom Server");
              readback = out.character;
            },
            () => set({ characters: get().characters.map((c) => c.id === id && readback ? hydrateCharacter(readback) : c) }),
          );
        }
        return writeEditedFields(
          "PATCH /api/characters",
          "character",
          id,
          patch as Record<string, unknown>,
          () => get().characters.find((c) => c.id === id) as unknown as Record<string, unknown> | undefined,
          (update) => set({ characters: get().characters.map((c) => (c.id === id ? hydrateCharacter({ ...c, ...update }) : c)) }),
          async () => {
            await canonicalizeTempIdsInPlace(patch);
            return apiPatchCharacter(id, patch);
          },
        );
      },
      addCharacter: (c) => {
        return writeOrRevert(
          "POST /api/characters",
          async () => {
            await canonicalizeTempIdsInPlace(c);
            return apiCreateCharacter(c);
          },
          () => {
            const worlds = get().worlds.map((w) =>
              w.id === c.worldId ? { ...w, characterIds: Array.from(new Set([...w.characterIds, c.id])) } : w,
            );
            set({ characters: [...get().characters, hydrateCharacter(c)], worlds });
          },
        );
      },
      deleteCharacter: (id) => {
        // V52: the server updates current session bindings and returns canonical
        // SQL readback. No second deletion algorithm in the browser.
        let readback: Awaited<ReturnType<typeof apiDeleteCharacter>> | null = null;
        return writeOrRevert(
          "DELETE /api/characters",
          async () => { readback = await apiDeleteCharacter(id); },
          () => {
            const canon = readback;
            if (!canon) return;
            const updated = new Map(canon.sessionUpdates.map((s) => [String(s.id), hydrateSession(s as unknown as Session)]));
            set({
              characters: get().characters.filter((c) => c.id !== id),
              worlds: get().worlds.map((w) => w.id === canon.world.id ? hydrateWorld(canon.world as unknown as World) : w),
              sessions: get().sessions.map((s) => updated.get(s.id) ?? s),
              users: canon.user ? get().users.map((u) => u.id === canon.user?.id ? canon.user as unknown as UserProfile : u) : get().users,
            });
          },
        );
      },
      importPack: async (pack) => {
        const { world, characters } = remapPack(pack, get().activeUserId);
        const payload = { ...pack, world, characters };
        // Serial queue + one backend transaction; nothing displayed as saved before SQL commit.
        const done = persistTail.then(async () => {
          await canonicalizeTempIdsInPlace(payload);
          const out = await apiImportWorldPack(payload);
          const importedWorld = hydrateWorld(out.world as unknown as World);
          const importedCharacters = out.characters.map((c) => hydrateCharacter(c as unknown as StammCharacter));
          set({
            worlds: [...get().worlds.filter((w) => w.id !== importedWorld.id), importedWorld],
            characters: [...get().characters.filter((c) => c.worldId !== importedWorld.id), ...importedCharacters],
          });
          get().log({ level: "info", code: "WORLD_IMPORT", message: `Welt ${importedWorld.name} importiert` });
          return importedWorld.id;
        });
        persistTail = done.then(() => undefined, () => undefined);
        try {
          return await done;
        } catch (err) {
          persistFailed("POST /api/world-packs/import", err);
          throw err; // Frontend needs the real owner error, not 'Import abgelehnt'.
        }
      },

      startSession: async ({ worldId, userId, avatarName, avatarNotes, situationId, name, avatarId, presentIds }) => {
        // R4.1: callers can still hold a provisional scalar from the same UI action
        // (e.g. Labor creates a user and immediately starts a session). Resolve those
        // aliases before any owner lookup, actor header, URL path or session seed.
        worldId = canonicalId(worldId);
        userId = userId ? canonicalId(userId) : userId;
        avatarId = avatarId ? canonicalId(avatarId) : avatarId;
        const world = get().selectableWorlds().find((w) => w.id === worldId);
        if (!world) {
          persistFailed("POST /api/sessions", new Error("Welt fehlt"));
          return "";
        }
        const uidUser = userId ?? canonicalId(get().activeUserId);
        if (!uidUser) {
          persistFailed("POST /api/sessions", new Error("Kein aktiver User"));
          return "";
        }
        rememberActor(uidUser);
        const natives = get().characters.filter((c) => c.worldId === worldId && c.isWorldNative);
        const userRow = get().users.find((u) => u.id === uidUser);
        let avatar: StammCharacter | null = null;
        if (avatarId) {
          avatar = get().characters.find((c) => c.id === avatarId && c.worldId === worldId) ?? null;
        } else if (userRow?.avatarsByWorld?.[worldId]) {
          const pref = userRow.avatarsByWorld[worldId];
          if (pref) avatar = get().characters.find((c) => c.id === pref && c.worldId === worldId) ?? null;
        }
        if (!avatar && (avatarName || userRow?.defaultRole === "avatar")) {
          avatar = {
            ...makeOutsiderAvatar(avatarName || userRow?.name || "Avatar", avatarNotes),
            id: uid("av"),
            worldId,
            canBeAvatar: true,
          };
        }
        let session: Session;
        try {
          session = spawnSession({
            world,
            characters: natives,
            avatar,
            situationId,
            name,
            presentIds,
            userId: uidUser,
            pipeline: {
              fate: get().config.fateDefault,
              meta: true,
              narrator: get().config.narratorDefault,
            },
            autoChat: {
              enabled: false,
              turns: get().config.autoChatTurns,
              delayMs: get().config.autoChatDelayMs,
              contextTurns: get().config.contextTurns,
            },
          });
        } catch (err) {
          persistFailed("POST /api/sessions", err);
          return "";
        }
        if (userRow?.defaultRole) session.role = userRow.defaultRole;
        const avatarIsNew = !!(avatar && !get().characters.some((c) => c.id === avatar!.id));
        const ownNative =
          !!(avatar && avatar.ownerUserId && avatar.ownerUserId === uidUser) ||
          !!(avatar && !avatar.ownerUserId && !String(avatar.id).startsWith("char_g7_"));
        const flagNativeAvatar = !!(avatar && !avatarIsNew && avatar.isWorldNative && !avatar.canBeAvatar && ownNative);
        const characters =
          avatarIsNew && avatar
            ? [...get().characters, avatar]
            : flagNativeAvatar && avatar
              ? get().characters.map((c) => (c.id === avatar!.id ? { ...c, canBeAvatar: true } : c))
              : get().characters;
        const avatarsByWorld = avatar
          ? { ...(userRow?.avatarsByWorld ?? {}), [worldId]: avatar.id }
          : userRow?.avatarsByWorld;
        // V25 SES-01/02 (Vertrag §4): Der Client sendet nur Bedienabsicht/Auswahl
        // (Welt, Avatar, Startlage, Anwesende, Name, Rolle, Pipeline, AutoChat,
        // Fate an/aus). Szene, Runtimes, Beziehungen, Fate-Zustand, turnIndex und
        // Eröffnungsturn baut der Server aus Welt + Stämmen. Die lokale Vorschau
        // (spawnSession) dient nur der ID-/Avatar-Vorbereitung; kanonisch ist die
        // zurückgelesene Server-Session.
        let serverSession: Session | null = null;
        const ok = await writeOrRevert(
          "POST /api/sessions",
          async () => {
            await canonicalizeTempIdsInPlace({ avatar, session, avatarsByWorld });
            if (avatarIsNew && avatar) await apiCreateCharacter(avatar);
            if (flagNativeAvatar && avatar) await apiPatchCharacter(avatar.id, { canBeAvatar: true });
            const created = (await apiCreateSession({
              id: session.id,
              worldId,
              name: session.name,
              avatarId: avatar?.id ?? null,
              alias: session.alias,
              role: session.role,
              situationId: situationId ?? null,
              presentIds: session.scene.presentIds.filter((id) => id !== avatar?.id),
              fateEnabled: session.fate.enabled,
              pipeline: session.pipeline,
              autoChat: session.autoChat,
            })) as { session?: Session; warnings?: string[] };
            if (!created?.session?.id) throw new Error("Server hat keine Session zurückgegeben");
            const readBack = (await apiGetSession(created.session.id)) as { session?: Session } | Session;
            const canonical = ((readBack as { session?: Session }).session ?? readBack) as Session;
            serverSession = hydrateSession(canonical);
            await apiPatchUser(uidUser, {
              lastWorldId: worldId,
              lastSessionId: serverSession.id,
              ...(avatar ? { avatarsByWorld } : {}),
            });
          },
          () =>
            set({
              characters,
              sessions: [serverSession ?? session, ...get().sessions.filter((x) => x.id !== (serverSession ?? session).id)],
              users: get().users.map((u) =>
                u.id === uidUser
                  ? { ...u, lastWorldId: worldId, lastSessionId: (serverSession ?? session).id, ...(avatar ? { avatarsByWorld } : {}) }
                  : u,
              ),
            }),
        );
        if (!ok) return "";
        const final = serverSession ?? session;
        get().log({ level: "info", code: "SESSION_START", message: `Session ${final.name} (serverseitig gebaut)`, sessionId: final.id });
        return final.id;
      },
      ensureLiveSession: () => {
        if (liveSessionGate) return liveSessionGate;
        liveSessionGate = (async () => {
          const st = useMatrix.getState();
          let userId = st.activeUserId;
          if (!userId || !st.users.some((u) => u.id === userId)) {
            const existing = st.users[0];
            if (existing) {
              await st.setActiveUser(existing.id);
              userId = existing.id;
            } else {
              const guest: UserProfile = {
                id: uid("user"),
                name: "Gast",
                language: "de",
                defaultRole: "teilnehmer",
                lastWorldId: null,
                lastSessionId: null,
                tts: false,
                sttMode: "dictation",
                largeType: false,
                highContrast: false,
                createdAt: new Date().toISOString(),
              };
              const ok = await st.upsertUser(guest);
              if (!ok) return "";
              userId = guest.id;
            }
          }
          const now = useMatrix.getState();
          const mine = now.sessions.filter((s) => s.userId === userId);
          const last = now.users.find((u) => u.id === userId)?.lastSessionId;
          if (last && mine.some((s) => s.id === last)) return last;
          if (mine[0]) return mine[0].id;
          const worlds = now.selectableWorlds();
          const worldId = worlds.find((w) => w.id === GASTHAUS_ID)?.id || worlds[0]?.id || "";
          if (!worldId) return "";
          return now.startSession({
            worldId,
            userId,
            name: "Gespräch",
          });
        })().finally(() => {
          liveSessionGate = null;
        });
        return liveSessionGate;
      },
      saveSession: (s) => {
        const next = hydrateSession({ ...s, updatedAt: new Date().toISOString() });
        let canonical: Session | null = null;
        writeOrRevert(
          "PUT /api/sessions",
          async () => {
            await canonicalizeTempIdsInPlace(next);
            // V65Y (Gesamtpruefung V65X N01; AMASTER §6.2 Nr. 4, §71.1.3): a settings save sends the envelope only.
            // Turns, memories, relations, propositions and goals of a running session are kernel-owned - the client
            // never pushes a local diff of them into the canonical owners.
            const r = (await apiPutSession(next.id, sessionEnvelope(next))) as { session?: Session };
            if (r.session) canonical = hydrateSession(r.session);
          },
          () => set({ sessions: get().sessions.map((x) => (x.id === s.id ? canonical ?? next : x)) }),
        );
      },
      acceptKernelSession: (s) => {
        const next = hydrateSession(s);
        set({ sessions: get().sessions.map((x) => (x.id === s.id ? next : x)) });
      },
      deleteSession: (id) => {
        const sessions = get().sessions.filter((s) => s.id !== id);
        const uploads = get().uploads.filter((u) => u.sessionId !== id);
        const snapshots = get().snapshots.filter((s) => s.sessionId !== id);
        writeOrRevert(
          "DELETE /api/sessions",
          () => apiDeleteSession(id),
          () => set({ sessions, uploads, snapshots }),
        );
      },
      setActiveSession: (id) => {
        const uidUser = get().activeUserId;
        if (!uidUser) return;
        const cur = get().users.find((u) => u.id === uidUser);
        if (cur && cur.lastSessionId === id) return;
        writeOrRevert(
          "PATCH /api/users",
          () => apiPatchUser(uidUser, { lastSessionId: id }),
          () => set({ users: get().users.map((u) => (u.id === uidUser ? { ...u, lastSessionId: id } : u)) }),
        );
      },
      renameSession: (id, name) => {
        writeOrRevert(
          "PATCH /api/sessions",
          () => apiPatchSession(id, { name }),
          () => set({ sessions: get().sessions.map((s) => (s.id === id ? { ...s, name } : s)) }),
        );
      },
      setSessionWorld: (sessionId, worldId) => {
        const world = get().selectableWorlds().find((w) => w.id === worldId);
        if (!world) {
          get().log({
            level: "error",
            code: "SESSION_WORLD_NOT_SELECTABLE",
            message: `setSessionWorld: world ${worldId} not selectable; server remains source of truth`,
            sessionId,
          });
          return;
        }
        writeOrRevert(
          "PATCH /api/sessions",
          () => apiPatchSession(sessionId, { worldId }),
          () => set({ sessions: get().sessions.map((s) => (s.id === sessionId ? { ...s, worldId } : s)) }),
        );
      },
      duplicateSession: async (id) => {
        const s = get().sessions.find((x) => x.id === id);
        if (!s) return "";
        if (!get().selectableWorlds().some((w) => w.id === s.worldId)) {
          get().log({
            level: "error",
            code: "SESSION_WORLD_NOT_SELECTABLE",
            message: `duplicateSession: world ${s.worldId} not selectable; server remains source of truth`,
            sessionId: id,
          });
          return "";
        }
        // V25 (AMASTERv2 §19 "Session duplizieren, sofern bewusst gewünscht"):
        // Der Server dupliziert seinen kanonischen SQLite-Stand; der Client
        // schickt keinen Sessionblob.
        const newId = uid("ses");
        let copy: Session | null = null;
        const ok = await writeOrRevert(
          "POST /api/sessions",
          async () => {
            const created = (await apiCreateSession({ id: newId, worldId: s.worldId, sourceSessionId: s.id, name: `${s.name} (Kopie)` })) as { session?: Session };
            if (!created?.session?.id) throw new Error("Server hat kein Duplikat zurückgegeben");
            const readBack = (await apiGetSession(created.session.id)) as { session?: Session } | Session;
            copy = hydrateSession((((readBack as { session?: Session }).session ?? readBack) as Session));
          },
          () => {
            if (copy) set({ sessions: [copy, ...get().sessions] });
          },
        );
        if (!ok || !copy) return "";
        return (copy as Session).id;
      },
      importSession: async (raw, confirmAuthority?: (message: string) => boolean) => {
        if (!raw?.worldId || !get().selectableWorlds().some((w) => w.id === raw.worldId)) {
          get().log({
            level: "error",
            code: "SESSION_IMPORT_WORLD",
            message: "Import: Welt nicht wählbar",
          });
          return "";
        }
        // V65Z (SPS-Audit V65Y A08; AMASTERv2 §64 kontrollierter Import, Reparaturvertrag §16): the whole session in ONE
        // request. The server re-keys it and writes envelope and children through the write boundary in one transaction;
        // a refused child refuses the whole import and nothing is stored. Before, the client re-keyed it itself and wrote
        // each child with its own request - a failing child left a half session on the server.
        let imported: Session | null = null;
        const ok = await writeOrRevert(
          "POST /api/sessions",
          async () => {
            const body: Record<string, unknown> = {
              ...structuredClone(raw),
              id: uid("ses"),
              userId: get().activeUserId,
              name: raw.name ? `${raw.name} (Import)` : "Import-Session",
              import: true,
              importedFrom: raw.id, // V66: provenance of the imported rows (stamped by the server, never trusted from the file)
            };
            // the new session id (and any provisional id in the file) comes from the backend allocator (live E2E 31.10.:
            // without it the server answered 400 PROVISIONAL_ID)
            await canonicalizeTempIdsInPlace(body);
            let created: { session?: Session };
            try {
              created = (await apiCreateSession(body)) as { session?: Session };
            } catch (err) {
              // V66 (Audit5 E03; AMASTERv2 §64 kontrollierter Import, §46 God braucht gueltige Authority): God/Regie rows of a
              // file are no authority this server recorded - the server refuses them (409, nothing stored) until the owner
              // accepts them explicitly. The question shows the server's reason; no answer -> nothing is imported.
              const msg = err instanceof Error ? err.message : String(err);
              if (!msg.includes("IMPORT_AUTHORITY_UNACCEPTED") || !confirmAuthority?.(msg)) throw err;
              created = (await apiCreateSession({ ...body, autoritaetAnnehmen: true })) as { session?: Session };
            }
            if (!created?.session?.id) throw new Error("Server hat keinen Import zurückgegeben");
            const readBack = (await apiGetSession(created.session.id)) as unknown as { session?: Session };
            imported = hydrateSession((readBack.session ?? (readBack as unknown as Session)) as Session);
          },
          () => {
            if (imported) set({ sessions: [imported, ...get().sessions] });
          },
        );
        if (!ok || !imported) return "";
        const done = imported as Session;
        get().log({ level: "info", code: "SESSION_IMPORT", message: `${done.name} (kontrollierter Import)`, sessionId: done.id });
        return done.id;
      },
      patchRelation: (sessionId, fromId, toId, patch) => {
        const s = get().sessions.find((x) => x.id === sessionId);
        if (!s) return;
        const next = structuredClone(s) as Session;
        next.relations = next.relations.map((r) => (r.fromId === fromId && r.toId === toId ? { ...r, ...patch } : r));
        const updated = next.relations.find((r) => r.fromId === fromId && r.toId === toId);
        if (!updated) return;
        writeOrRevert(
          "PUT /api/sessions/:id/relations",
          () => apiPutRelation(sessionId, updated),
          () => set({ sessions: get().sessions.map((x) => (x.id === sessionId ? next : x)) }),
        );
      },
      addRelation: (sessionId, rel) => {
        const s = get().sessions.find((x) => x.id === sessionId);
        if (!s) return;
        const next = structuredClone(s) as Session;
        const exists = next.relations.some((r) => r.fromId === rel.fromId && r.toId === rel.toId);
        if (exists) {
          next.relations = next.relations.map((r) => (r.fromId === rel.fromId && r.toId === rel.toId ? { ...r, ...rel } : r));
        } else {
          next.relations = [...next.relations, rel];
        }
        writeOrRevert(
          "PUT /api/sessions/:id/relations",
          async () => {
            await canonicalizeTempIdsInPlace(rel);
            await apiPutRelation(sessionId, rel);
            await apiCreateGraph(sessionId, rel);
          },
          () => set({ sessions: get().sessions.map((x) => (x.id === sessionId ? next : x)) }),
        );
      },
      addMemory: (sessionId, mem) => {
        const s = get().sessions.find((x) => x.id === sessionId);
        if (!s) return;
        const created = { ...mem, id: uid("mem") };
        const next = structuredClone(s) as Session;
        next.memories = [created, ...next.memories];
        writeOrRevert(
          "POST /api/sessions/:id/memories",
          async () => {
            await canonicalizeTempIdsInPlace(created);
            return apiPostMemory(sessionId, created);
          },
          () => set({ sessions: get().sessions.map((x) => (x.id === sessionId ? next : x)) }),
        );
      },
      addGoal: (sessionId, goal) => {
        const s = get().sessions.find((x) => x.id === sessionId);
        if (!s) return;
        const created = { ...goal, id: uid("goal") };
        const next = hydrateSession(structuredClone(s) as Session);
        next.goals = [created, ...next.goals];
        writeOrRevert(
          "POST /api/sessions/:id/goals",
          async () => {
            await canonicalizeTempIdsInPlace(created);
            return apiPostGoal(sessionId, created);
          },
          () => set({ sessions: get().sessions.map((x) => (x.id === sessionId ? next : x)) }),
        );
      },
      patchGoal: (sessionId, goalId, patch) => {
        if (!get().sessions.some((s) => s.id === sessionId && s.goals.some((g) => g.id === goalId))) return;
        let readback: Session | null = null;
        void writeOrRevert(
          "PATCH /api/sessions/:id/goals",
          async () => {
            const out = await apiPatchGoal(sessionId, goalId, patch) as { session?: Session };
            if (!out.session) throw new Error("Zielwechsel ohne SQL-Sitzungsstand");
            readback = hydrateSession(out.session);
          },
          () => { if (readback) set({ sessions: get().sessions.map((s) => s.id === sessionId ? readback! : s) }); },
        );
      },
      addProposition: (sessionId, p) => {
        const s = get().sessions.find((x) => x.id === sessionId);
        if (!s) return;
        const created = { ...p, id: uid("prop") };
        const next = hydrateSession(structuredClone(s) as Session);
        next.propositions = [created, ...next.propositions];
        writeOrRevert(
          "POST /api/sessions/:id/propositions",
          async () => {
            await canonicalizeTempIdsInPlace(created);
            return apiPostProposition(sessionId, created);
          },
          () => set({ sessions: get().sessions.map((x) => (x.id === sessionId ? next : x)) }),
        );
      },
      patchProposition: (sessionId, propId, patch) => {
        const s = get().sessions.find((x) => x.id === sessionId);
        if (!s) return;
        const next = hydrateSession(structuredClone(s) as Session);
        next.propositions = next.propositions.map((p) => (p.id === propId ? { ...p, ...patch } : p));
        const updated = next.propositions.find((p) => p.id === propId);
        if (!updated) return;
        writeOrRevert(
          "PATCH /api/sessions/:id/propositions",
          () => apiPatchProposition(sessionId, propId, patch),
          () => set({ sessions: get().sessions.map((x) => (x.id === sessionId ? next : x)) }),
        );
      },

      addUpload: (u) => {
        return writeOrRevert(
          "POST /api/uploads",
          async () => {
            await canonicalizeTempIdsInPlace(u);
            return apiCreateUpload(u);
          },
          () => set({ uploads: [u, ...get().uploads] }),
        );
      },
      patchUpload: (id, patch) => {
        id = canonicalId(id);
        writeOrRevert(
          "PATCH /api/uploads",
          () => apiPatchUpload(id, patch),
          () => set({ uploads: get().uploads.map((u) => (u.id === id ? { ...u, ...patch } : u)) }),
        );
      },
      commitUpload: (id) => {
        id = canonicalId(id);
        const u = get().uploads.find((x) => x.id === id);
        if (!u) return Promise.resolve(false);
        if (u.status === "ocr_empty" || u.status === "error") {
          persistFailed("POST /api/uploads/ingest", new Error(u.error || "Upload nicht bereit."));
          return Promise.resolve(false);
        }
        if (u.mode === "A" && !u.targetId) {
          persistFailed("POST /api/uploads/ingest", new Error("Mode A ohne Ziel prägt nichts."));
          return Promise.resolve(false);
        }
        if (u.mode === "B" && !u.sessionId) {
          persistFailed("POST /api/uploads/ingest", new Error("MODE_B_NO_SESSION: Mode B Sessionwissen braucht eine ausdrücklich gewählte Session."));
          return Promise.resolve(false);
        }
        const incomingBox: { items: ReviewItem[]; witnesses: number } = { items: [], witnesses: 0 };
        return writeOrRevert(
          "POST /api/uploads/ingest",
          async () => {
            const raw = await apiIngestUpload(id);
            const rec = raw as { reviews?: Array<Record<string, string>>; witnessIds?: string[]; memoryCount?: number };
            incomingBox.witnesses = Array.isArray(rec.witnessIds) ? rec.witnessIds.length : Number(rec.memoryCount || 0);
            incomingBox.items = (rec.reviews || []).filter((r) => Boolean(r.id)).map((r) => ({
              id: String(r.id),
              kind: (r.kind === "stamm" ? "stamm" : r.kind === "spawn" ? "spawn" : "world") as "stamm" | "world" | "spawn",
              sourceSessionId: u.sessionId ?? "",
              characterId: r.characterId,
              worldId: String(r.worldId || u.worldId || ""),
              field: String(r.field || ""),
              oldValue: String(r.oldValue || ""),
              newValue: String(r.newValue || ""),
              reason: String(r.reason || "ingest"),
              status: "open" as const,
              createdAt: new Date().toISOString(),
            }));
            return raw;
          },
          () => {
            set({
              uploads: get().uploads.map((x) =>
                x.id === id
                  ? { ...x, committed: true, status: "committed", error: incomingBox.witnesses ? `${incomingBox.witnesses} Anwesende wissen davon` : x.error }
                  : x,
              ),
              reviews: incomingBox.items.length ? [...incomingBox.items, ...get().reviews] : get().reviews,
            });
            get().log({
              level: "info",
              code: "UPLOAD_INGEST",
              message:
                u.mode === "B"
                  ? `Mode B: ${incomingBox.witnesses} Anwesende haben ${u.name} als Wissen`
                  : `Mode A: ${incomingBox.items.length} Review(s) für ${u.name}`,
              sessionId: u.sessionId,
            });
          },
        );
      },
      deleteUpload: (id) => {
        id = canonicalId(id);
        writeOrRevert(
          "DELETE /api/uploads",
          () => apiDeleteUpload(id),
          () => set({ uploads: get().uploads.filter((u) => u.id !== id) }),
        );
      },

      addReview: (r) => {
        writeOrRevert(
          "POST /api/reviews",
          async () => {
            await canonicalizeTempIdsInPlace(r);
            return apiCreateReview(r);
          },
          () => set({ reviews: [r, ...get().reviews] }),
        );
      },
      patchReview: (id, patch) => {
        writeOrRevert(
          "PATCH /api/reviews",
          () => apiPatchReview(id, patch),
          () => set({ reviews: get().reviews.map((r) => (r.id === id ? { ...r, ...patch } : r)) }),
        );
      },
      resolveReview: (id, status, newValue) => {
        const item = get().reviews.find((r) => r.id === id);
        if (!item) return;
        // V25 REV-01: Nur ein ausdrücklich im selben Bedienschritt übergebener
        // Wert wird mitgesendet. Ohne Wert gilt der im Server gespeicherte
        // (ggf. per PATCH bearbeitete) Wert — kein veralteter UI-Closure-Wert.
        writeOrRevert(
          "POST /api/reviews/resolve",
          () => apiResolveReview(id, status, newValue !== undefined ? { newValue } : {}),
          () => {
            void fetchOwnerPartial()
              .then((partial) => {
                useMatrix.setState({
                  ...(partial as Partial<MatrixState>),
                  reviews: (partial.reviews as MatrixState["reviews"]) ?? get().reviews.map((r) => (r.id === id ? { ...r, status } : r)),
                });
              })
              .catch((err) => persistFailed("POST /api/reviews/resolve read-back", err));
          },
        );
      },

      addSnapshot: (sessionId, name) => {
        const s = get().sessions.find((x) => x.id === sessionId);
        if (!s) return "";
        const label = name || `Stand ${new Date().toLocaleString("de-AT")}`;
        const box: { snap: Snapshot | null } = { snap: null };
        writeOrRevert(
          "POST /api/sessions/snapshots",
          async () => {
            const r = (await apiCreateSessionSnapshot(sessionId, label)) as { snapshot?: Snapshot };
            box.snap = r.snapshot ?? null;
          },
          () => {
            if (!box.snap) return;
            set({ snapshots: [box.snap, ...get().snapshots] });
          },
        );
        return box.snap?.id || "";
      },
      restoreSnapshot: (id) => {
        const snap = get().snapshots.find((s) => s.id === id);
        if (!snap) return;
        const nestedWorldId = snap.session?.worldId;
        if (nestedWorldId && !get().selectableWorlds().some((w) => w.id === nestedWorldId)) {
          get().log({
            level: "error",
            code: "SESSION_WORLD_NOT_SELECTABLE",
            message: `restoreSnapshot: nested world ${nestedWorldId} not selectable; server remains source of truth`,
          });
          return;
        }
        let restored: Session | null = null;
        writeOrRevert(
          "POST /api/snapshots/restore",
          async () => {
            const r = (await apiRestoreSnapshot(id)) as { session?: Session };
            restored = hydrateSession({ ...(r.session as Session), id: snap.sessionId });
          },
          () => {
            if (!restored) return;
            set({ sessions: get().sessions.map((s) => (s.id === snap.sessionId ? restored! : s)) });
          },
        );
      },
      deleteSnapshot: (id) => {
        writeOrRevert(
          "DELETE /api/snapshots",
          () => apiDeleteSnapshot(id),
          () => set({ snapshots: get().snapshots.filter((s) => s.id !== id) }),
        );
      },

      addTrigger: (t) => {
        writeOrRevert(
          "POST /api/triggers",
          async () => {
            await canonicalizeTempIdsInPlace(t);
            return apiCreateTrigger(t);
          },
          () => set({ triggers: [t, ...get().triggers] }),
        );
      },
      patchTrigger: (id, patch) => {
        writeOrRevert(
          "PATCH /api/triggers",
          () => apiPatchTrigger(id, patch),
          () => set({ triggers: get().triggers.map((t) => (t.id === id ? { ...t, ...patch } : t)) }),
        );
      },
      deleteTrigger: (id) => {
        writeOrRevert(
          "DELETE /api/triggers",
          () => apiDeleteTrigger(id),
          () => set({ triggers: get().triggers.filter((t) => t.id !== id) }),
        );
      },

      addPreference: (p) => {
        writeOrRevert(
          "POST /api/preferences",
          async () => {
            await canonicalizeTempIdsInPlace(p);
            return apiCreatePreference(p);
          },
          () => set({ preferences: [p, ...get().preferences] }),
        );
      },
      patchPreference: (id, patch) => {
        writeOrRevert(
          "PATCH /api/preferences",
          () => apiPatchPreference(id, patch),
          () => set({ preferences: get().preferences.map((p) => (p.id === id ? { ...p, ...patch } : p)) }),
        );
      },
      deletePreference: (id) => {
        writeOrRevert(
          "DELETE /api/preferences",
          () => apiDeletePreference(id),
          () => set({ preferences: get().preferences.filter((p) => p.id !== id) }),
        );
      },

      log: (line) => {
        const entry: LogLine = { ...line, id: uid("log"), at: new Date().toISOString() };
        set({ logs: [entry, ...get().logs].slice(0, 400) });
        persistWrite(
          "POST /api/logs",
          canonicalizeTempIdsInPlace(entry).then(() => apiPostLog(entry)),
          { skipLog: true },
        );
      },
      setConfig: (patch) => {
        const config = { ...get().config, ...patch };
        const scope = config.scope || "user";
        const scopeId = config.scopeId || (scope === "user" ? get().activeUserId : "");
        const needsTarget = scope === "world" || scope === "character" || scope === "session" || scope === "runtime";
        if (needsTarget && !scopeId) {
          set({ config });
          return;
        }
        writeOrRevert(
          "PUT /api/config",
          () =>
            apiPutConfig({
              autoChatTurns: config.autoChatTurns,
              autoChatDelayMs: config.autoChatDelayMs,
              contextTurns: config.contextTurns,
              fateDefault: config.fateDefault,
              narratorDefault: config.narratorDefault,
              debug: config.debug,
              model: config.model,
              temperature: config.temperature,
              maxTokens: config.maxTokens,
              provider: config.provider || "openai",
              endpoint: config.endpoint || "",
              llmEnabled: config.llmEnabled !== false,
              scope,
              scope_id: scopeId,
              scopeId,
            }),
          () => set({ config }),
        );
      },
      applyLoadedConfig: (loaded) => {
        set({ config: { ...get().config, ...loaded } });
      },
      setSpiegel: (json) => set({ lastSpiegelJson: json }),
      setCompassPreview: (characterId: string, json: string) => set({ compassPreview: { characterId, json } }),
      setProviderOnline: (v) => set({ providerOnline: v }),

      resetSessionFull: (sessionId) => {
        const s = get().sessions.find((x) => x.id === sessionId);
        if (!s) return;
        const avatarId = s.avatarId;
        let restored: Session | null = null;
        writeOrRevert(
          "POST /api/sessions/reset-full",
          async () => {
            const r = (await apiResetSessionFull(sessionId)) as { session?: Session };
            if (r.session) restored = hydrateSession(r.session);
          },
          () => {
            if (!restored) return;
            set({ sessions: get().sessions.map((x) => (x.id === sessionId ? restored! : x)) });
            get().log({
              level: "warn",
              code: "RESET_SESSION",
              message: `Session ${sessionId} vollständig zurückgesetzt. Id und Avatar ${avatarId ?? "—"} bleiben.`,
            });
          },
        );
      },
      resetSessionChat: (sessionId) => {
        const s = get().sessions.find((x) => x.id === sessionId);
        if (!s) return;
        let restored: Session | null = null;
        writeOrRevert(
          "POST /api/sessions/reset-chat",
          async () => {
            const r = (await apiResetSessionChat(sessionId, { turnIndex: 0, focus: {} })) as { session?: Session };
            if (r.session) restored = hydrateSession(r.session);
          },
          () => {
            if (!restored) return;
            set({ sessions: get().sessions.map((x) => (x.id === sessionId ? restored! : x)) });
            get().log({ level: "warn", code: "RESET_CHAT", message: "Nur Chat/Turns", sessionId });
          },
        );
      },
      resetSessionRuntime: (sessionId) => {
        const s = get().sessions.find((x) => x.id === sessionId);
        if (!s) return;
        let restored: Session | null = null;
        writeOrRevert(
          "POST /api/kernel/reset",
          async () => {
            const r = (await apiKernelReset({ sessionId, kind: "runtime" })) as unknown as { session?: Session };
            if (r.session) restored = hydrateSession(r.session);
          },
          () => {
            if (!restored) return;
            set({ sessions: get().sessions.map((x) => (x.id === sessionId ? restored! : x)) });
            get().log({ level: "warn", code: "RESET_RUNTIME", message: "Nur Runtime/Beziehungen", sessionId });
          },
        );
      },
      resetSessionMemory: (sessionId) => {
        const s = get().sessions.find((x) => x.id === sessionId);
        if (!s) return;
        let restored: Session | null = null;
        writeOrRevert(
          "POST /api/sessions/reset-memory",
          async () => {
            const r = (await apiResetSessionMemory(sessionId)) as { session?: Session };
            restored = hydrateSession(r.session ? r.session : resetMemoryOnly(s));
          },
          () => {
            if (!restored) return;
            set({ sessions: get().sessions.map((x) => (x.id === sessionId ? restored! : x)) });
            get().log({ level: "warn", code: "RESET_MEMORY", message: "Nur Sessionmemory", sessionId });
          },
        );
      },
      resetSessionUploads: (sessionId) => {
        const s = get().sessions.find((x) => x.id === sessionId);
        if (!s) return;
        const avatarId = s.avatarId;
        let restored: Session | null = null;
        let deleted: string[] = [];
        let detached: string[] = [];
        let keptAsSource: string[] = [];
        writeOrRevert(
          "POST /api/sessions/reset-uploads",
          async () => {
            const r = (await apiResetSessionUploads(sessionId)) as {
              session?: Session;
              deleted?: string[];
              keptModeA?: string[];
              keptAsSource?: string[];
              avatarId?: string | null;
            };
            if (r.session) restored = hydrateSession(r.session);
            deleted = r.deleted || [];
            detached = r.keptModeA || [];
            keptAsSource = r.keptAsSource || [];
          },
          () => {
            const gone = new Set(deleted);
            set({
              sessions: restored
                ? get().sessions.map((x) => (x.id === sessionId ? restored! : x))
                : get().sessions,
              // V67 (Audit7 V66-03): only the deleted uploads leave the list; an upload kept as source of stored events stays
              uploads: get()
                .uploads.filter((u) => !gone.has(u.id))
                .map((u) => (detached.includes(u.id) ? { ...u, sessionId: undefined } : u)),
            });
            get().log({
              level: "warn",
              code: "RESET_UPLOADS",
              message: `Nur Uploadkontext. Avatar ${avatarId ?? "—"} bleibt.${keptAsSource.length ? ` ${keptAsSource.length} Upload(s) bleiben als Quelle gespeicherter Ereignisse.` : ""}`,
              sessionId,
            });
          },
        );
      },
      resetUserSessions: (userId) => {
        if (userId !== get().activeUserId) {
          persistFailed("RESET_USER", new Error("Fremduser-Reset ist nicht erlaubt"));
          return;
        }
        const ids = get().sessions.filter((s) => s.userId === userId).map((s) => s.id);
        writeOrRevert(
          "POST /api/users/reset-sessions",
          async () => {
            await apiResetUserSessions(userId);
          },
          () => {
            set({
              sessions: get().sessions.filter((s) => s.userId !== userId),
              uploads: get().uploads.filter((u) => u.userId !== userId || !u.sessionId),
              snapshots: get().snapshots.filter((s) => !ids.includes(s.sessionId)),
            });
            get().log({ level: "warn", code: "RESET_USER", message: `Alle Sessions von ${userId}` });
          },
        );
      },
      hardResetRuntime: (userId) => {
        const actor = get().activeUserId;
        const target = (userId && String(userId).trim()) || actor;
        if (!actor || !target) return;
        if (target !== actor) {
          persistFailed("HARD_RESET", new Error("Fremduser-Reset ist nicht erlaubt"));
          return;
        }
        const sessIds = get().sessions.filter((s) => s.userId === actor).map((s) => s.id);
        const uploadIds = get().uploads.filter((u) => u.userId === actor || (u.sessionId && sessIds.includes(u.sessionId))).map((u) => u.id);
        const snapIds = get().snapshots.filter((s) => sessIds.includes(s.sessionId)).map((s) => s.id);
        const sessSet = new Set(sessIds);
        writeOrRevert(
          "POST /api/users/hard-reset",
          async () => {
            await apiHardResetUser(actor);
          },
          () => {
            set({
              sessions: get().sessions.filter((s) => s.userId !== actor),
              uploads: get().uploads.filter((u) => !uploadIds.includes(u.id)),
              snapshots: get().snapshots.filter((s) => !snapIds.includes(s.id)),
              reviews: get().reviews.filter((r) => !sessSet.has(r.sourceSessionId)),
              logs: get().logs.filter((l) => !l.sessionId || !sessSet.has(l.sessionId)),
              lastSpiegelJson: null,
            });
            get().log({ level: "warn", code: "HARD_RESET", message: `USER HARD RESET gescopet auf ${actor}. Stamm und Welten bleiben.` });
          },
        );
      },
      kernelReset: (sessionId, kind) => {
        const s = get().sessions.find((x) => x.id === sessionId);
        if (!s) return;
        let restored: Session | null = null;
        writeOrRevert(
          "POST /api/kernel/reset",
          async () => {
            const r = (await apiKernelReset({
              sessionId: s.id,
              kind,
            })) as unknown as { session?: Session };
            if (r.session) restored = hydrateSession(r.session);
          },
          () => {
            if (!restored) return;
            set({ sessions: get().sessions.map((x) => (x.id === sessionId ? restored! : x)) });
            get().log({
              level: "warn",
              code: "KERNEL_RESET",
              message: `Kernel-Reset ${kind} für Session ${sessionId}`,
              sessionId,
            });
          },
        );
      },
    }),
    {
      name: "matrix10.mcc.v4",
      storage: flaskMccStorage,
      partialize: (s) => ({
        users: s.users,
        activeUserId: s.activeUserId,
        worlds: s.worlds,
        characters: s.characters,
        sessions: s.sessions,
        uploads: s.uploads,
        reviews: s.reviews,
        snapshots: s.snapshots,
        triggers: s.triggers,
        logs: s.logs.slice(0, 80),
        preferences: s.preferences,
        config: s.config,
      }),
      merge: (persisted, current) => {
        const p = (persisted ?? {}) as Partial<MatrixState>;
        // Only the SQLite/Flask reader is authoritative. No demo-world insertion.
        const worlds = (p.worlds ?? []).map(hydrateWorld);
        const characters = (p.characters ?? []).map(hydrateCharacter);
        return {
          ...current,
          ...p,
          worlds,
          characters,
          users: Array.isArray(p.users) ? p.users : current.users,
          activeUserId:
            (typeof p.activeUserId === "string" && p.activeUserId) || readStoredActor() || "",
          sessions: (p.sessions ?? []).map((s) => {
            try {
              return hydrateSession(s as Session);
            } catch {
              return s as Session;
            }
          }),
          uploads: p.uploads ?? [],
          reviews: p.reviews ?? [],
          snapshots: p.snapshots ?? [],
          triggers: p.triggers ?? [],
          logs: p.logs ?? [],
          preferences: p.preferences ?? [],
          config: {
            ...DEFAULT_CONFIG,
            ...(p.config ?? {}),
            model: p.config?.model || DEFAULT_CONFIG.model,
            provider: p.config?.provider || DEFAULT_CONFIG.provider,
            apiKey: "",
          },
        };
      },
    },
  ),
);

export function ensureSeeded() {
  const s = useMatrix.getState();
  if (!s.config.model) {
    useMatrix.setState({ config: { ...s.config, model: DEFAULT_CONFIG.model } });
  }
}
