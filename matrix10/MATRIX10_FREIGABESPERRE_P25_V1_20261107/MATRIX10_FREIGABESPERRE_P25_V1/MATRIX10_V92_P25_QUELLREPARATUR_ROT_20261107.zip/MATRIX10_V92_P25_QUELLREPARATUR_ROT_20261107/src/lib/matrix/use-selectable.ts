import { useMemo } from "react";
import { useMatrix } from "./store";
import { GASTHAUS_ID } from "./types";

/** Stable selectable worlds — never call selectableWorlds() inside a Zustand selector. */
export function useSelectableWorlds() {
  const worlds = useMatrix((s) => s.worlds);
  const activeUserId = useMatrix((s) => s.activeUserId);
  return useMemo(
    () =>
      worlds.filter(
        (w) => w.ownerUserId === activeUserId || (w.id === GASTHAUS_ID && w.ownerUserId === "admin"),
      ),
    [worlds, activeUserId],
  );
}

/** Stable selectable characters gated by selectable worlds. */
export function useSelectableCharacters() {
  const characters = useMatrix((s) => s.characters);
  const worlds = useSelectableWorlds();
  return useMemo(() => {
    const allowed = new Set(worlds.map((w) => w.id));
    return characters.filter((c) => allowed.has(c.worldId));
  }, [characters, worlds]);
}
