import {
  MEANING_SPACES,
  type Compass,
  type CompassCell,
  type DirectedRel,
  type MeaningSpace,
  type StammCharacter,
  type SynapseFire,
  type SceneState,
  type RuntimeState,
} from "./types.ts";

// B.26 (AMASTERv2): Backend ist Source of Truth. Diese Liste MUSS synchron
// mit matrix_api/kernel.py::_COMPASS_TRIGGERS sein. Das Backend stellt sie
// via /api/compass/triggers bereit — wir versuchen das beim Modul-Boot,
// fallen aber auf diesen Fallback zurück, falls die API nicht erreichbar
// ist (Offline-First).
//
// Letzte Sync-Quelle: kernel.py::_COMPASS_TRIGGERS v18-b26.
export const FALLBACK_TRIGGERS: Record<MeaningSpace, string[]> = {
  Bedrohung: ["bedroh", "gefahr", "angriff", "konfront", "kontroll", "ueberfall", "waffe", "mess", "schlag", "packt", "zieht"],
  Angst: ["angst", "fuercht", "furcht", "panik", "scheu", "schreck", "unsicher", "sorge", "schmerz"],
  Verrat: ["verrat", "luege", "lüge", "betrug", "hintergeh", "untreu", "misstrau", "geheim"],
  Lust: ["lust", "begehr", "verlangen", "anziehung", "intim", "kuss", "nah", "berühr", "beruehr", "schatz", "liebling"],
  Geld: ["geld", "zahl", "kasse", "bezahl", "schuld", "lohn", "preis", "schnaps"],
  Trennung: ["trennung", "verlass", "verlass mich", "ende", "allein", "allein gelassen", "geh weg"],
  Gewalt: ["gewalt", "schlag", "kampf", "wunde", "faust", "zwang", "droh", "haaren", "packt", "fessel"],
  Mord: ["mord", "tot", "toet", "töt", "leiche", "umbring", "gestorben"],
  Eifersucht: ["eifersucht", "neid", "rival", "andere", "besitz"],
  Verlust: ["verlust", "verloren", "trauer", "vermiss", "weggenommen"],
  Abhaengigkeit: ["abhaeng", "abhäng", "job", "arbeit", "dach", "lohn", "rauswerfen"],
  Moral: ["recht", "unrecht", "gewissen", "anstand", "anständig", "ehre", "sollte nicht"],
  Risiko: ["risik", "wagn", "chance", "was wenn", "stehlen", "kasse"],
  Schutz: ["schuetz", "schutz", "verteidig", "sicher", "bewahr", "haus"],
  Macht: ["macht", "kontrolle", "befehl", "herrsch", "autoritaet", "anweisung", "regel"],
};

let TRIGGERS: Record<MeaningSpace, string[]> = FALLBACK_TRIGGERS;
let _triggersVersion = "fallback-v18-b26";

/** B.26: einmaliger Sync mit Backend beim Modul-Boot. Idempotent. */
export async function syncCompassTriggersFromBackend(
  baseUrl = "/api",
): Promise<{ ok: boolean; version: string; source: "backend" | "fallback" }> {
  if (typeof fetch === "undefined") return { ok: false, version: _triggersVersion, source: "fallback" };
  try {
    const r = await fetch(`${baseUrl}/compass/triggers`, { credentials: "include" });
    if (!r.ok) return { ok: false, version: _triggersVersion, source: "fallback" };
    const j = await r.json();
    if (!j || typeof j !== "object" || !j.triggers) {
      return { ok: false, version: _triggersVersion, source: "fallback" };
    }
    const synced: Record<string, string[]> = {};
    for (const space of MEANING_SPACES) {
      const words = j.triggers[space];
      synced[space] = Array.isArray(words) ? words : FALLBACK_TRIGGERS[space] ?? [];
    }
    TRIGGERS = synced as Record<MeaningSpace, string[]>;
    _triggersVersion = String(j.version || "unknown");
    return { ok: true, version: _triggersVersion, source: "backend" };
  } catch {
    return { ok: false, version: _triggersVersion, source: "fallback" };
  }
}

/** B.26: nur für Tests/Diagnose. */
export function _getTriggersVersion(): string {
  return _triggersVersion;
}

export function emptyCompass(): Compass {
  const c = {} as Compass;
  for (const space of MEANING_SPACES) {
    c[space] = {
      space,
      stance: 0,
      threshold: 0.42,
      reaction: "hält inne und prüft, was das mit ihr/ihm macht",
      bodyCue: "Atem wird kürzer",
      drive: "Lage verstehen, bevor gehandelt wird",
    };
  }
  return c;
}

export function fillCompass(partial: Partial<Record<MeaningSpace, Partial<CompassCell>>>): Compass {
  const base = emptyCompass();
  for (const space of MEANING_SPACES) {
    const over = partial[space];
    if (over) base[space] = { ...base[space], ...over, space };
  }
  return base;
}

function hitTrigger(text: string, t: string): boolean {
  // B.26: Substring-Match (1:1 mit kernel.py::fire_compass_lens). Trigger-
  // Wörter sind bereits kurze Stämme ("bedroh", "panik", "schlag"), die
  // nicht versehentlich in unverwandten Wörtern auftauchen. Word-Boundary-
  // Match wäre strenger, würde aber Komposita wie "unbedroht" ausschließen,
  // was für Compass-Heuristiken zu rigide ist.
  const m = norm(t).trim();
  if (!m) return false;
  const n = norm(text);
  return n.includes(m);
}

/** Kompasszellen nur aus Belegsätzen — keine erfundenen Reaktionen. */
export function compassFromPassages(passages: string[]): Partial<Record<MeaningSpace, Partial<CompassCell>>> {
  const out: Partial<Record<MeaningSpace, Partial<CompassCell>>> = {};
  for (const space of MEANING_SPACES) {
    const hit = passages.find((p) => TRIGGERS[space].some((t) => hitTrigger(p, t)));
    if (!hit) continue;
    const line = hit.replace(/\s+/g, " ").trim().slice(0, 160);
    if (space === "Trennung" && /mund verlassen|worte.{0,24}verlassen/i.test(line)) continue;
    out[space] = { stance: 0.55, drive: line, reaction: line };
  }
  return out;
}

function norm(s: string): string {
  return s.toLowerCase().replace(/ä/g, "ae").replace(/ö/g, "oe").replace(/ü/g, "ue").replace(/ß/g, "ss");
}

function lexical(space: MeaningSpace, text: string): number {
  const hits = TRIGGERS[space].filter((t) => hitTrigger(text, t)).length;
  if (!hits) return 0;
  return Math.min(1, 0.28 + hits * 0.22);
}

export function fireSynapses(opts: {
  stamm: StammCharacter;
  runtime: RuntimeState;
  scene: SceneState;
  stimulus: string;
  fateTags?: MeaningSpace[];
  relation?: DirectedRel;
  lived?: string;
}): SynapseFire[] {
  const { stamm, runtime, scene, stimulus, fateTags = [], relation, lived } = opts;
  const fired: SynapseFire[] = [];
  const corpus = [lived, stimulus].filter(Boolean).join("\n");
  for (const space of MEANING_SPACES) {
    const cell = stamm.compass[space];
    let a = lexical(space, corpus);
    a += Math.abs(cell.stance) * 0.12;
    if (fateTags.includes(space)) a += 0.18;
    if (space === "Angst") a += runtime.fear * 0.25;
    if (space === "Lust") a += runtime.lust * 0.2;
    if (space === "Gewalt" || space === "Bedrohung") a += scene.danger * 0.3 + runtime.pain * 0.2;
    if (space === "Macht" || space === "Schutz") a += scene.tension * 0.15;
    if (space === "Abhaengigkeit") a += runtime.pain * 0.12;
    if (relation) {
      if (space === "Lust" && relation.closeness > 0.45) a += relation.closeness * 0.22;
      if (space === "Angst") a += relation.fear * 0.22;
      if (space === "Schutz" && relation.closeness > 0.4) a += 0.14;
      if (space === "Eifersucht" && relation.closeness > 0.4) a += 0.1;
      if (space === "Verrat" && relation.trust < 0.3) a += 0.14;
      if (space === "Gewalt" && relation.hostility > 0.35) a += 0.16;
      if (space === "Abhaengigkeit" && /dienst|druck|besitz/i.test(`${relation.kind ?? ""} ${relation.note}`)) a += 0.12;
    }
    a = Math.max(0, Math.min(1, a));
    if (a >= cell.threshold) fired.push({ space, activation: a, cell });
  }
  fired.sort((x, y) => y.activation - x.activation);
  return fired.slice(0, 5);
}

export function applyFireToRuntime(runtime: RuntimeState, fired: SynapseFire[]): RuntimeState {
  const next = { ...runtime };
  for (const f of fired) {
    const k = f.activation;
    switch (f.space) {
      case "Angst":
      case "Bedrohung":
        next.fear = clamp01(next.fear + k * 0.18);
        next.stress = clamp01(next.stress + k * 0.14);
        break;
      case "Lust":
        next.lust = clamp01(next.lust + k * 0.2);
        break;
      case "Gewalt":
      case "Mord":
        next.anger = clamp01(next.anger + k * 0.16);
        next.fear = clamp01(next.fear + k * 0.1);
        break;
      case "Verrat":
      case "Eifersucht":
        next.trust = clamp01(next.trust - k * 0.14);
        next.anger = clamp01(next.anger + k * 0.1);
        break;
      case "Schutz":
        next.intent = f.cell.drive;
        break;
      case "Macht":
        next.intensity = clamp01(next.intensity + k * 0.12);
        break;
      case "Verlust":
      case "Trennung":
        next.shame = clamp01(next.shame + k * 0.08);
        break;
      default:
        next.intensity = clamp01(next.intensity + k * 0.06);
    }
  }
  if (fired[0]) {
    next.emotion = emotionFromSpace(fired[0].space);
    next.intent = fired[0].cell.drive;
  }
  return next;
}

function emotionFromSpace(space: MeaningSpace): string {
  const map: Record<MeaningSpace, string> = {
    Bedrohung: "alarmiert",
    Angst: "ängstlich",
    Verrat: "misstrauisch",
    Lust: "angezogen",
    Geld: "berechnend",
    Trennung: "verlassen",
    Gewalt: "angespannt",
    Mord: "erstarrt",
    Eifersucht: "eifersüchtig",
    Verlust: "traurig",
    Abhaengigkeit: "bedürftig",
    Moral: "gewissenhaft",
    Risiko: "waghalsig",
    Schutz: "beschützend",
    Macht: "beherrschend",
  };
  return map[space];
}

function clamp01(n: number) {
  return Math.max(0, Math.min(1, n));
}
