import { factsWitnessedBy } from "./event-engine.ts";
import type { Memory, Session, Spiegel, StammCharacter, SynapseFire, World, SpeakerMode, FateSeed } from "./types.ts";

function scoreMemory(m: Memory, stimulus: string, fired: SynapseFire[], turnIndex: number): number {
  if (m.truthStatus === "widersprochen") return -1;
  const n = stimulus.toLowerCase();
  const recency = 1 / (1 + Math.max(0, turnIndex - m.turn));
  let s = m.salience * 0.3 + recency * 0.42;
  const words = m.text.toLowerCase().split(/\W+/).filter((w) => w.length > 4);
  s += Math.min(0.25, words.filter((w) => n.includes(w)).length * 0.06);
  if (fired.some((f) => m.text.toLowerCase().includes(f.space.toLowerCase().slice(0, 4)))) s += 0.08;
  if (m.truthStatus === "unsicher" || m.truthStatus === "behauptet") s *= 0.55;
  if (m.truthStatus === "verdrängt") s *= /angst|verrat|schuld|geheim/i.test(n) ? 0.5 : 0.15;
  if (m.kind === "betroffen" || m.kind === "erlebt") s += 0.12;
  return s;
}

function relevant(list: string[], stimulus: string, limit: number): string[] {
  const n = stimulus.toLowerCase();
  const ranked = [...list].sort((a, b) => {
    const aw = a.toLowerCase().split(/\W+/).filter((w) => w.length > 3 && n.includes(w)).length;
    const bw = b.toLowerCase().split(/\W+/).filter((w) => w.length > 3 && n.includes(w)).length;
    return bw - aw;
  });
  return ranked.slice(0, limit);
}

export function buildSpiegel(opts: {
  world: World;
  session: Session;
  speaker: StammCharacter;
  present: StammCharacter[];
  fired: SynapseFire[];
  stimulus: string;
  mode: SpeakerMode;
  addressedTo?: string;
  topic?: string;
  fateSeed: FateSeed | null;
  query?: { question: string; about?: string; prior?: string };
}): Spiegel {
  const { world, session, speaker, present, fired, stimulus, mode, addressedTo, topic, fateSeed, query } = opts;
  const rt = session.runtimes[speaker.id];
  if (!rt) {
    throw new Error(`Runtime fehlt für ${speaker.name}`);
  }
  const cannot = [
    ...speaker.body.constraints,
    ...rt.constraints,
    rt.mobility < 0.35 ? "kann sich nicht frei bewegen" : "",
    rt.consciousness < 0.5 ? "ist nicht voll bei Bewusstsein" : "",
    rt.pain > 0.7 ? "starke Schmerzen begrenzen jede Handlung" : "",
    rt.restrained ? "ist gefesselt oder festgehalten" : "",
    rt.gagged ? "ist geknebelt und kann nicht frei sprechen" : "",
    !rt.canSpeak ? "kann jetzt nicht sprechen" : "",
    rt.heldBy ? "wird festgehalten" : "",
  ].filter(Boolean);

  const can: string[] = [];
  if (rt.gagged || !rt.canSpeak) can.push("schweigen", "mit dem Blick antworten");
  else if (rt.mobility >= 0.5 && rt.consciousness >= 0.6) can.push("sprechen", "gehen", "gestikulieren");
  else if (rt.consciousness >= 0.4) can.push("sprechen", "sitzen bleiben");
  else can.push("murmeln", "die Augen öffnen");
  if (rt.pain > 0.5) can.push("Schmerz zeigen");

  const nameOf = (id: string) =>
    present.find((p) => p.id === id)?.name ?? Object.keys(session.runtimes).find((k) => k === id) ?? id;

  const relationsHere = session.relations
    .filter((r) => r.fromId === speaker.id && session.scene.presentIds.includes(r.toId))
    .map((r) => ({
      name: present.find((p) => p.id === r.toId)?.name ?? r.toId,
      kind: r.kind,
      trust: r.trust,
      closeness: r.closeness,
      fear: r.fear,
      hostility: r.hostility,
      note: r.note,
    }));

  const mems = session.memories
    .filter((m) => m.characterId === speaker.id)
    .map((m) => ({ m, s: scoreMemory(m, stimulus, fired, session.turnIndex) }))
    .filter((x) => x.s >= 0)
    .sort((a, b) => b.s - a.s)
    .slice(0, 5)
    .map(({ m }) => ({ text: m.text, kind: m.kind, salience: m.salience, truth: m.truthStatus, turn: m.turn }));

  const witnessed = factsWitnessedBy(session, speaker.id, 10);
  const facts = witnessed.map((f) => ({
    actor: nameOf(f.actorId),
    target: f.targetId ? nameOf(f.targetId) : undefined,
    kind: f.kind,
    text: f.text,
    turn: f.turn,
  }));

  const ctx = Math.max(1, Math.min(50, session.autoChat.contextTurns || 10));
  const dialogue = session.turns
    .filter((t) => t.role === "character" || t.role === "avatar" || t.role === "observer")
    .filter((t) => {
      if (t.speakerId === speaker.id) return true;
      return session.facts.some(
        (f) =>
          (f.kind === "speech" || f.kind === "action") &&
          (t.turn == null || f.turn === t.turn) &&
          (!t.speakerId || f.actorId === t.speakerId) &&
          (f.witnessedBy || []).includes(speaker.id),
      );
    })
    .slice(-ctx)
    .map((t) => ({ name: t.speakerName, speech: t.speech, action: t.action }));

  const goals = session.goals.filter((g) => g.ownerId === speaker.id && g.status !== "failed" && g.status !== "revoked").map((g) => g.text).slice(0, 3);

  const knowledge = [
    ...relevant(speaker.knowledge, stimulus, 4),
    ...mems.filter((m) => m.truth === "canon").map((m) => m.text),
  ].slice(0, 6);

  const unknown = [
    "kennt keine fremden Gedanken",
    "kennt nur, was sie selbst erlebt, gehört oder gesehen hat",
    ...world.knowledgeLimits.filter((k) => !/affäre|affare|unterschlag|vorstrafe|geldquelle/i.test(k)).slice(0, 2),
  ];

  const effectiveHearsIds = (session.scene.hearsIds ?? session.scene.presentIds).filter((id) => {
    const rtHere = session.runtimes[id];
    return !rtHere || (rtHere.canHear !== false && (rtHere.consciousness ?? 1) > 0 && (!rtHere.position || rtHere.position === session.scene.placeName));
  });
  const effectiveSeesIds = (session.scene.seesIds ?? session.scene.presentIds).filter((id) => {
    const rtHere = session.runtimes[id];
    return !rtHere || (rtHere.canSee !== false && (rtHere.consciousness ?? 1) > 0 && (!rtHere.position || rtHere.position === session.scene.placeName));
  });
  return {
    speakerId: speaker.id,
    speakerName: speaker.name,
    mode,
    profile: {
      name: speaker.name,
      role: speaker.role,
      speechRegister: speaker.speechRegister,
      typicalPhrases: speaker.typicalPhrases.slice(0, 3),
      taboos: speaker.taboos.slice(0, 3),
      values: speaker.values.slice(0, 3),
      reactionRules: speaker.reactionRules.slice(0, 4),
      relevantCanon: relevant(speaker.canon, stimulus, 3),
      ownSecrets: speaker.secrets.slice(0, 2),
      species: speaker.species || "",
      coreFacts: (speaker.coreFacts || []).slice(0, 4),
      bindingPatterns: (speaker.bindingPatterns || []).slice(0, 3),
      lastingAbilities: (speaker.lastingAbilities || []).slice(0, 3),
      humor: speaker.humor || "",
      favoriteWords: (speaker.favoriteWords || []).slice(0, 4),
      fears: (speaker.fears || []).slice(0, 3),
      likes: (speaker.likes || []).slice(0, 3),
      dislikes: (speaker.dislikes || []).slice(0, 3),
      goals: (speaker.goals || []).slice(0, 3),
      conflictStyle: speaker.conflictStyle || "",
      biography: (speaker.biography || "").slice(0, 240),
      personality: speaker.personality || "",
    },
    fired,
    runtime: rt,
    body: {
      position: rt.position,
      mobility: rt.mobility,
      pain: rt.pain,
      consciousness: rt.consciousness,
      canDo: can,
      cannotDo: cannot,
    },
    scene: {
      place: session.scene.placeName,
      time: session.scene.time,
      present: present.filter((p) => p.id !== speaker.id && session.runtimes[p.id]?.position === session.scene.placeName).map((p) => p.name),
      tension: session.scene.tension,
      danger: session.scene.danger,
      open: session.scene.openMatters.slice(-3),
      hears: effectiveHearsIds.map((id) => present.find((p) => p.id === id)?.name || id),
      sees: effectiveSeesIds.map((id) => present.find((p) => p.id === id)?.name || id),
      items: session.scene.items?.slice(0, 6) || [],
      aftereffects: session.scene.aftereffects?.slice(0, 4) || [],
      questions: session.scene.openQuestions?.slice(0, 4) || [],
      demands: session.scene.openDemands?.slice(0, 4) || [],
      promises: session.scene.openPromises?.slice(0, 4) || [],
    },
    relationsHere,
    memories: mems,
    facts,
    dialogue,
    query,
    goals,
    fate: {
      pressure: session.fate.pressure,
      beat: fateSeed?.beat ?? session.fate.beat,
      mustNot: fateSeed?.mustNot ?? "Kein erfundenes Wissen. Abwesende wissen nichts. Avatar nicht steuern.",
    },
    knowledge,
    unknown,
    userUtterance: stimulus,
    addressedTo,
    topic,
  };
}
