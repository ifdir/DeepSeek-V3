import { finalizeFormulate, synapseSpeech } from "./finalizer";
import type { FormulateResult, Spiegel } from "./types";

function textish(v: unknown): string[] {
  if (v == null || v === "") return [];
  if (typeof v === "string") return v.trim() ? [v.trim()] : [];
  if (typeof v === "number" || typeof v === "boolean") return [String(v)];
  if (Array.isArray(v)) return v.flatMap(textish);
  if (typeof v === "object") {
    const o = v as Record<string, unknown>;
    if (typeof o.text === "string" && o.text.trim()) return [o.text.trim()];
    if (typeof o.beat === "string" && o.beat.trim()) return [o.beat.trim()];
    if (typeof o.note === "string" && o.note.trim()) return [o.note.trim()];
    if (typeof o.name === "string" && o.name.trim()) return [o.name.trim()];
    return Object.values(o).flatMap(textish).slice(0, 4);
  }
  return [];
}

/** Client-Synapse only. Paid/OpenAI and TanStack server functions live in Flask `/api/llm/*`. */
export function localFormulate(spiegel: Spiegel): FormulateResult {
  const utterance = (spiegel.userUtterance || "").trim();
  const cellSpeech = (spiegel.fired?.[0]?.cell.speech || "").trim();
  const dump = (s: string) => s.includes("..") || (utterance.length > 10 && s.toLowerCase().includes(utterance.toLowerCase()) && s.split(". ").length > 3);
  if (cellSpeech && !dump(cellSpeech)) {
    const syn = synapseSpeech(spiegel);
    return { ...finalizeFormulate(spiegel, { ...syn, speech: cellSpeech }), commitsTruth: false };
  }
  const syn = synapseSpeech(spiegel);
  let speech = syn.speech;
  if (!speech || dump(speech)) {
    const bits = [
      ...textish(spiegel.goals).slice(0, 1),
      ...textish(spiegel.memories).slice(0, 1),
      spiegel.profile.typicalPhrases?.[0],
    ]
      .map((s) => s.trim())
      .filter(Boolean);
    speech = bits.slice(0, 2).join(". ") || synapseSpeech(spiegel).speech;
  }
  return {
    ...finalizeFormulate(spiegel, { speech: speech || "…", action: syn.action, source: "synapse" }),
    action: null,
    commitsTruth: false,
  };
}
