// V92 (AMASTER §24.7, Kettenvertrag §5): Teile der Eingabe, die keiner geprüften Komponente zugeordnet werden konnten,
// verschwinden nicht und werden nicht still zu Rede: der Server legt sie als input_component_ambiguity am TurnTruth ab.
// Diese Funktion macht sie dem Menschen sichtbar. Nur Lesen, keine neue Wahrheit.

export type EingabeHinweis = { id: string; text: string };

const GRUND_TEXT: Record<string, string> = {
  rest_ohne_komponente: "Dieser Teil gehört zu keiner Handlung oder Rede und wurde nicht verwendet",
  rede_nicht_im_eingang: "Diese Rede steht nicht so in deiner Eingabe und wurde nicht verwendet",
  rede_ueberlappt_handlung: "Diese Rede überschneidet sich mit einer Handlung und wurde nicht verwendet",
  rede_akteur_ist_nicht_der_sprecher: "Diese Rede gehört einer anderen Figur und wurde nicht verwendet",
  rede_sprecher_fehlt: "Es ist nicht belegt, wer das sagt – es wurde nicht als Rede gespeichert",
  rede_sprecher_unklar: "Der Name passt auf mehrere Figuren – nicht eindeutig, wer das sagt (bitte vollen Namen verwenden)",
  akteur_unklar: "Der Name passt auf mehrere Figuren – nicht eindeutig, wer das tut (bitte vollen Namen verwenden)",
  ziel_unklar: "Der Name passt auf mehrere Figuren – nicht eindeutig, wen die Handlung trifft; ihre Wirkung wurde nicht angewendet",
  ziel_widerspricht_text: "Die Lesung nennt eine andere Zielperson als dein Text – ihre Wirkung wurde nicht angewendet",
  segment_mehrere_saetze: "Mehrere Sätze wurden als eine einzige Handlung gelesen – nicht gespeichert",
  zerlegung_unvollstaendig: "Die Eingabe wurde nicht vollständig zerlegt",
  komponente_ungueltig: "Die Eingabe wurde nicht als gültige Rede oder Handlung gelesen",
  plan_fehlt: "Die Eingabe konnte nicht geprüft werden (keine Lesung verfügbar)",
  vollzug_nicht_geprueft: "Die Handlung konnte nicht geprüft werden, ob sie wirklich geschieht",
  vollzug_beleg_nicht_woertlich: "Die unabhängige Vollzugsprüfung nennt keinen wörtlichen Beleg aus deiner Handlung; es wurde nichts ausgeführt",
  lesung_abgeschnitten: "Die Eingabe wurde nur zum Teil gelesen",
  segment_nicht_in_anweisung: "Dieser Teil steht nicht in deiner Eingabe",
  segment_satz_unvollstaendig: "Dieser Teil ist kein vollständiger Satz",
  ziel_nicht_anwesend_oder_unbekannt: "Die betroffene Person ist nicht anwesend oder unbekannt",
  // V92 Paket 14: a name of unproven extent ("Mara Schmidt" while only Mara Nowak is known, or a noun right after a name)
  ziel_name_unklar: "Der genannte Name ist länger als ein bekannter Name (etwa ein anderer Nachname) – nicht eindeutig, wen die Handlung trifft; ihre Wirkung wurde nicht angewendet",
  akteur_name_unklar: "Ein genannter Name ist unbekannt oder nicht eindeutig – nicht belegt, wer die Handlung ausführt; sie wurde nicht ausgeführt",
  rede_sprecher_name_unklar: "Ein genannter Name ist unbekannt oder nicht eindeutig – nicht belegt, wer das sagt; es wurde nicht als Rede gespeichert",
  rede_adressat_unklar: "Die angesprochene Person ist unbekannt oder nicht eindeutig – die Rede wurde ohne Adressat gespeichert",
  ziel_nicht_im_eingang: "Die betroffene Person steht nicht in deiner Eingabe",
  wirkung_ohne_gebundenes_ziel: "Die Wirkung hat keine eindeutig betroffene Person",
  koerperwirkung_ohne_zielperson: "Die körperliche Wirkung hat keine eindeutig betroffene Person",
  wirkung_unklar: "Die Wirkung der Handlung ist unklar",
  wirkungsziel_nach_klaerung_abweichend: "Die bestätigte Körperwirkung galt einer anderen Person als der endgültig ausgewählten – keine Wirkung angewendet",
  akteur_ist_nicht_der_sprecher: "Diese Handlung gehört einer anderen Figur als der, die du gerade führst, und wurde nicht ausgeführt",
  akteur_nicht_anwesend_oder_unbekannt: "Die handelnde Person ist nicht anwesend oder unbekannt",
  akteur_nicht_belegt: "Die handelnde Person steht nicht in deiner Eingabe",
  segment_bereits_gebunden: "Dieser Teil kam schon als Handlung vor und zählt nicht doppelt",
  segment_nicht_im_eingang: "Dieser Teil steht nicht in deiner Eingabe",
  segment_im_zitat: "Dieser Teil steht in einem Zitat und ist keine Handlung",
  segment_wortgrenze: "Dieser Teil beginnt oder endet mitten in einem Wort",
  handlung_ohne_beschreibung: "Die Handlung hat keine Beschreibung",
  ziel_nicht_belegt: "Die betroffene Person steht nicht in deiner Eingabe",
  rede_ohne_inhalt: "Diese Rede hat keinen Inhalt",
  vom_planer_unklar: "Dieser Teil wurde nicht eindeutig gelesen",
  handlung_nicht_vollzogen: "Die Handlung geschieht nach deinem Wortlaut nicht (verneint, gewünscht, gefragt, bedingt oder angekündigt) und wurde nicht ausgeführt",
  vollzug_nicht_angegeben: "Nicht belegt, dass die Handlung wirklich geschieht – sie wurde nicht ausgeführt",
  avatar_rede_nicht_anordenbar: "Rede des Avatars kann nicht angeordnet werden",
};

function grundText(grund: string): string {
  if (GRUND_TEXT[grund]) return GRUND_TEXT[grund];
  if (grund.startsWith("satzzeit_")) return "Der Satz steht nicht in der Gegenwart und wurde nicht als jetzige Handlung gespeichert";
  if (grund.startsWith("zeit_")) return "Die Handlung geschieht nicht jetzt und wurde nicht als jetzige Handlung gespeichert";
  return `Nicht eindeutig gelesen (${grund || "unbekannt"})`;
}

/** Hinweis zum jüngsten TurnTruth mit nicht zugeordneten Teilen; null, wenn es keinen gibt. */
const EINGABE_ARTEN = new Set(["speech", "user", "puppet", "comment", "observer"]);
export function eingabeHinweis(session: unknown): EingabeHinweis | null {
  const tt0 = (session as { turnTruths?: unknown } | null | undefined)?.turnTruths;
  const list = Array.isArray(tt0) ? (tt0 as Array<Record<string, unknown>>) : [];
  for (let i = list.length - 1; i >= 0; i--) {
    const tt = list[i];
    // V92 Paket 9: nur die LETZTE direkte Eingabe (Avatar/Teilnehmer, Puppet, Kommentar) entscheidet; eine spätere saubere Eingabe
    // zeigt keinen Hinweis einer früheren mehr. Figurenzüge (AutoChat), Regie und God sind keine Eingabe in diesem Sinn.
    if (!EINGABE_ARTEN.has(String(tt?.input_kind ?? tt?.inputKind ?? ""))) continue;
    const amb = Array.isArray(tt?.input_component_ambiguity) ? (tt.input_component_ambiguity as Array<Record<string, unknown>>) : [];
    if (!amb.length) return null;
    const lines = amb.slice(0, 6).map((a) => {
      const grund = String(a?.grund ?? "");
      const seg = String(a?.segment ?? "").trim();
      const why = grundText(grund);
      return seg ? `„${seg}“ – ${why}` : why;
    });
    return { id: String(tt.id ?? i), text: "Nicht alles aus deiner Eingabe wurde als Ereignis gespeichert: " + lines.join("; ") + "." };
  }
  return null;
}

/** Abgelehnte Eingabe (Puppet und Avatar): die Servermeldung ohne technischen Präfix ("POST … 422 CODE:"); sonst null.
 *  Nichts wurde gespeichert, der Eingabetext bleibt im Feld (restoreText). V92 Paket 9: auch für den Avatar-Weg. */
const EINGABE_ABGELEHNT = ["PLAN_INCOMPLETE", "PUPPET_NICHT_AUSFUEHRBAR", "EINGABE_NICHT_AUSFUEHRBAR", "IDENTITAET_KLAEREN", "KLAERUNG_UNGUELTIG"];

/** V92 Paket 16 (Paket-15-Pruefung: "eine sichtbare Klartext-Rückfrage in der vorhandenen Oberfläche muss die korrekte Figur-ID
 *  ermitteln können"): a name the server cannot prove is asked before anything is stored. */
/** V92 Paket 17 (Paket-16-Prüfung A/B): one question per written PLACE of the input (`a`/`b`, excerpt `vor`/`nach`) with the
 *  server's opaque `frage` - the answer names that question, never only the wording. */
export type KlaerungFrage = { frage: string; text: string; a?: number; b?: number; vor?: string; nach?: string;
  kandidaten: Array<{ id: string; name: string; anwesend?: boolean }> };

/** The label of a candidate: its name - when several candidates carry the same name, with "in der Szene"/"nicht in der Szene",
 *  and if that still does not tell them apart, with the end of the figure ID. */
export function klaerungLabel(f: KlaerungFrage, c: { id: string; name: string; anwesend?: boolean }): string {
  const same = f.kandidaten.filter((x) => x.name === c.name);
  if (same.length < 2) return c.name;
  const where = c.anwesend === undefined ? "" : c.anwesend ? " (in der Szene)" : " (nicht in der Szene)";
  const stillSame = same.filter((x) => x.anwesend === c.anwesend).length > 1;
  return `${c.name}${where}${stillSame ? ` · ${c.id.slice(-6)}` : ""}`;
}
export type KlaerungAntwort = { frage: string; id: string | null };

/** The questions of a 422 IDENTITAET_KLAEREN answer (from the error the API layer threw), else null. */
export function identitaetsKlaerung(e: unknown): KlaerungFrage[] | null {
  const body = (e as { body?: { code?: string; klaerung?: unknown } } | null | undefined)?.body;
  if (!body || body.code !== "IDENTITAET_KLAEREN" || !Array.isArray(body.klaerung)) return null;
  const out = (body.klaerung as Array<Record<string, unknown>>)
    .map((q) => ({
      frage: String(q?.frage ?? ""),
      text: String(q?.text ?? ""),
      ...(typeof q?.a === "number" && typeof q?.b === "number" ? { a: q.a as number, b: q.b as number } : {}),
      ...(typeof q?.vor === "string" ? { vor: q.vor as string } : {}),
      ...(typeof q?.nach === "string" ? { nach: q.nach as string } : {}),
      kandidaten: (Array.isArray(q?.kandidaten) ? (q.kandidaten as Array<Record<string, unknown>>) : [])
        .map((c) => ({ id: String(c?.id ?? ""), name: String(c?.name ?? c?.id ?? ""), ...(typeof c?.anwesend === "boolean" ? { anwesend: c.anwesend as boolean } : {}) }))
        .filter((c) => c.id),
    }))
    .filter((q) => q.frage && q.text && q.kandidaten.length);
  return out.length ? out : null;
}
export function planIncompleteMeldung(message: string): string | null {
  for (const code of EINGABE_ABGELEHNT) {
    const i = message.indexOf(code);
    if (i < 0) continue;
    const rest = message.slice(i + code.length).replace(/^:\s*/, "").trim();
    return rest || "Die Eingabe konnte nicht eindeutig gelesen werden. Nichts wurde gespeichert.";
  }
  return null;
}
