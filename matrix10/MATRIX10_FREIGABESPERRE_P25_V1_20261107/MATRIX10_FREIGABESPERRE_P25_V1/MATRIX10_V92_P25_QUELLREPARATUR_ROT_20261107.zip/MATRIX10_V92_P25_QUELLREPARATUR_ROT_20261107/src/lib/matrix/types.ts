export const MEANING_SPACES = [
  "Bedrohung",
  "Angst",
  "Verrat",
  "Lust",
  "Geld",
  "Trennung",
  "Gewalt",
  "Mord",
  "Eifersucht",
  "Verlust",
  "Abhaengigkeit",
  "Moral",
  "Risiko",
  "Schutz",
  "Macht",
] as const;

export type MeaningSpace = (typeof MEANING_SPACES)[number];

export type Authority = "god" | "regie" | "fate" | "character" | "avatar" | "observer" | "narrator";
export type SpeakerMode = "beobachter" | "teilnehmer" | "avatar" | "puppet" | "regie" | "god";
export type GodScope = "auto" | "world" | "session" | "scene" | "character" | "relationship" | "knowledge" | "body" | "time" | "action";
export type UploadMode = "A" | "B";
export type MemoryKind =
  | "getan"
  | "gesagt"
  | "erlebt"
  | "gesehen"
  | "gehoert"
  | "betroffen"
  | "erzaehlt"
  | "vermutet"
  | "verdraengt"
  | "gelesen"
  | "informiert"
  | "upload"
  | "erschlossen"
  | "geglaubt"
  | "behauptet"
  | "bestritten"
  | "unsicher"
  | "vergessen";

export type TruthStatus = "canon" | "unsicher" | "behauptet" | "verdrängt" | "widersprochen";
export type GoalStatus = "open" | "active" | "accepted" | "declined" | "fulfilled" | "failed" | "revoked";
export type Visibility = "public" | "private";
export type PhysicalVerb =
  | "strike"
  | "hold"
  | "bind"
  | "gag"
  | "release"
  | "intimacy"
  | "move"
  | "leave"
  | "enter"
  | "give"
  | "other";

export interface CompassCell {
  space: MeaningSpace;
  stance: number;
  threshold: number;
  reaction: string;
  bodyCue: string;
  drive: string;
  speech?: string;
  avoids?: string;
  escalatesWhen?: string;
  calmsWhen?: string;
}

export type Compass = Record<MeaningSpace, CompassCell>;

export interface PhysicalBaseline {
  mobility: number;
  strength: number;
  pain: number;
  consciousness: number;
  notes: string;
  constraints: string[];
}

export interface StammRelation {
  targetName: string;
  targetId?: string;
  kind: string;
  note: string;
  trust: number;
  closeness: number;
  fear: number;
}

export interface StammCharacter {
  id: string;
  worldId: string;
  name: string;
  aliases: string[];
  /** V25.1: Herkunft je Profilfeld — belegt | abgeleitet | unsicher | abgeleitet-lokal | gelernt (MATRIX10 Nr. 5). */
  fieldProvenance?: Record<string, string>;
  /** V49: Urtriebe aus der Analyse (Selbsterhaltung, Bindung, Rang, Neugier, Fürsorge, Lust, Vergeltung, Sicherheit, Anerkennung, Freiheit) */
  drives?: Array<{ drive: string; strength: number; evidence?: string }>;
  /** V56: Session-Lernherkunft; Stammwirkung erst nach ausdruecklicher Freigabe. */
  learnedItems?: Array<{ id: string; field: string; value: string; source: string; sessionId?: string; turn?: number; at?: string; status?: "pending" | "approved"; scope?: string; approvedBy?: string; approvedAt?: string }>;
  role: string;
  age: string;
  gender: string;
  origin: string;
  occupation: string;
  biography: string;
  canon: string[];
  personality: string;
  values: string[];
  goals: string[];
  fears: string[];
  secrets: string[];
  likes: string[];
  dislikes: string[];
  conflictStyle: string;
  humor: string;
  speechRegister: string;
  typicalPhrases: string[];
  taboos: string[];
  favoriteWords: string[];
  body: PhysicalBaseline;
  knowledge: string[];
  relations: StammRelation[];
  compass: Compass;
  reactionRules: string[];
  isWorldNative: boolean;
  sourceRefs: string[];
  status: "entwurf" | "bereit" | "archiv";
  appearance: string;
  dialect: string;
  visibility: Visibility;
  typicalPlace: string;
  worldNotes: string;
  species?: string;
  coreFacts?: string[];
  bindingPatterns?: string[];
  lastingAbilities?: string[];
  sourceReleaseStatus?: "draft" | "reviewed" | "released" | "blocked";
  canBeAvatar?: boolean;
  ownerUserId?: string;
}

export interface Place {
  id: string;
  name: string;
  description: string;
  connections: string[];
  rules: string[];
  tags: string[];
  parentId?: string;
}

export interface WorldRule {
  id: string;
  kind: "physisch" | "sozial" | "rechtlich" | "kulturell" | "haus" | "magie";
  text: string;
}

export interface Faction {
  id: string;
  name: string;
  description: string;
  members: string[];
}

export interface WorldTimelineEvent {
  id: string;
  when: string;
  text: string;
  actors: string[];
}

export interface SpawnCandidate {
  /** Stable identity inside world.spawnCandidates. Name is display only. */
  id: string;
  name: string;
  role: string;
  origin: string;
  biography: string;
  source: string;
  worldRef?: string;
  goals?: string[];
  fears?: string[];
  secrets?: string[];
  values?: string[];
  conflicts?: string[];
  relations?: string[];
  stammRelations?: StammRelation[];
  knowledge?: string[];
  speechProfile?: string;
  personality?: string;
  appearance?: string;
  typicalPhrases?: string[];
  taboos?: string[];
  compass?: Compass;
  bodyNotes?: string;
  traits?: string[];
  uncertainties?: string[];
  derivedFields?: string[];
  directFields?: string[];
  canBeAvatar?: boolean;
  /** V25.1 CHAR-01: vollständige Profilfelder reisen vom Entwurf bis in den Stamm. */
  age?: string;
  gender?: string;
  occupation?: string;
  dialect?: string;
  humor?: string;
  conflictStyle?: string;
  typicalPlace?: string;
  worldNotes?: string;
  likes?: string[];
  dislikes?: string[];
  favoriteWords?: string[];
  reactionRules?: string[];
  bindingPatterns?: string[];
  lastingAbilities?: string[];
  fieldProvenance?: Record<string, string>;
}

export interface FateSeed {
  id: string;
  title: string;
  pressure: string;
  tags: MeaningSpace[];
  beat: string;
  mustNot: string;
}

export interface StartSituation {
  id: string;
  title: string;
  placeId: string;
  time: string;
  presentNames: string[];
  opening: string;
}

export interface StoryBeat {
  id: string;
  title: string;
  text: string;
}

export interface World {
  id: string;
  name: string;
  short: string;
  long: string;
  genre: string;
  tone: string;
  /** V49 universeller Extraktor: Textsorte/Genre/Epoche/Perspektive/Stil aus der Figurenkarte */
  textMeta?: Record<string, string>;
  /** V49: Anzahl belegter Facetten-Einträge je Feld */
  facetsSummary?: Record<string, number>;
  /** V49: Feldprovenienz der Welt (belegt | abgeleitet) */
  worldProvenance?: Record<string, string>;
  rulesDetail?: Array<Record<string, unknown>>;
  conflictsDetail?: Array<Record<string, unknown>>;
  secretsDetail?: Array<Record<string, unknown>>;
  itemsDetail?: Array<Record<string, unknown>>;
  socialOrder?: Array<Record<string, unknown>>;
  physicalRules?: string[];
  socialRules?: string[];
  language?: string[];
  culture?: string[];
  worldKnowledge?: string[];
  narratorName?: string;
  epoch: string;
  geography: string;
  places: Place[];
  rules: WorldRule[];
  factions: Faction[];
  timeline: WorldTimelineEvent[];
  conflicts: string[];
  items: string[];
  secrets: string[];
  history: string[];
  beings: string[];
  knowledgeLimits: string[];
  worldGoals: string[];
  startSituations: StartSituation[];
  fateSeeds: FateSeed[];
  sourceName?: string;
  sourceText?: string;
  sourcePartIds?: string[];
  characterIds: string[];
  fateEnabled: boolean;
  explicitOnly?: boolean;
  ownerUserId: string;
  atmosphere: string;
  purpose: string;
  visibility: Visibility;
  typicalScenes: string[];
  storyBeats: StoryBeat[];
  canon?: string;
  assets?: Array<{ id: string; name: string; kind: string; ref?: string }>;
  spawnTemplates?: Array<{ id: string; name: string; notes?: string }>;
  sourceRefs?: string[];
  spawnCandidates?: SpawnCandidate[];
  secretKnowledge?: string[];
  knowledgeBounds?: string[];
  startScenes?: string[];
  storyGoals?: string[];
  fateBeats?: string[];
  figureRelations?: unknown[];
  subplaces?: unknown[];
  placeRelations?: unknown[];
}

export interface RuntimeState {
  characterId: string;
  emotion: string;
  intensity: number;
  fear: number;
  trust: number;
  lust: number;
  pain: number;
  shame: number;
  anger: number;
  fatigue: number;
  stress: number;
  intent: string;
  mobility: number;
  consciousness: number;
  position: string;
  constraints: string[];
  canSpeak: boolean;
  restrained: boolean;
  gagged: boolean;
  heldBy?: string;
  holding?: string;
  canHear?: boolean;
  canSee?: boolean;
  canMove?: boolean;
  breathing?: number;
  balance?: number;
  reach?: number;
  handsFree?: boolean;
}

export interface DirectedRel {
  fromId: string;
  toId: string;
  trust: number;
  closeness: number;
  fear: number;
  hostility: number;
  note: string;
  kind?: string;
}

export interface Memory {
  id: string;
  characterId: string;
  kind: MemoryKind;
  text: string;
  salience: number;
  turn: number;
  witnesses: string[];
  layer: "stamm" | "session" | "world";
  truthStatus: TruthStatus;
  source?: string;
  factId?: string;
}

export interface SceneFact {
  id: string;
  turn: number;
  actorId: string;
  targetId?: string;
  kind: "speech" | "action" | "god" | "regie" | "scene" | "narrator" | "upload" | "physical";
  verb?: PhysicalVerb;
  text: string;
  authority: Authority;
  witnessedBy: string[];
  placeId?: string;
  userId?: string;
  worldId?: string;
  sessionId?: string;
  sourceTurnId?: string;
  sourceType?: string;
  eventKind?: string;
  speechAct?: string;
  payload?: Record<string, unknown>;
  validated?: boolean;
  status?: string;
  provenance?: string;
  propositionId?: string;
  goalId?: string;
  respondsToFactId?: string;
  rejectionReason?: string;
}

export interface GodFact {
  id: string;
  scope: GodScope;
  targetId?: string;
  text: string;
  turn: number;
  applied: boolean;
}

export interface SceneState {
  placeId: string;
  placeName: string;
  time: string;
  presentIds: string[];
  tension: number;
  danger: number;
  openMatters: string[];
  notes: string;
  phase: string;
  hearsIds?: string[];
  seesIds?: string[];
  hearsExplicit?: boolean;
  seesExplicit?: boolean;
  actors?: string[];
  goals?: string[];
  witnesses?: string[];
  ongoingActions?: string[];
  bodyPositions?: Record<string, string>;
  openQuestions?: string[];
  openDemands?: string[];
  openPromises?: string[];
  conflicts?: string[];
  bounds?: string[];
  items?: string[];
  aftereffects?: string[];
  foreground?: string[];
  nextScene?: string;
}

export interface FateState {
  enabled: boolean;
  pressure: number;
  activeSeedId?: string;
  beat: string;
  lastShiftTurn: number;
  mustNot?: string;
}

export interface ChatLine {
  id: string;
  turn: number;
  speakerId: string;
  speakerName: string;
  role: Authority;
  speech: string;
  action?: string;
  firedSpaces: MeaningSpace[];
  source?: "llm" | "synapse" | "engine";
  /** V37: validierte Synapsen dieses Turns (lexikalisch und/oder LLM-Vorschlag) und ihre Wirkung */
  synapses?: Array<{ space: string; activation: number; source?: string }>;
  synapseEffect?: { runtimeDelta?: Record<string, { from: unknown; to: unknown }>; relationDelta?: Array<{ toName?: string; before?: Record<string, unknown>; after?: Record<string, unknown> }> };
  recallCount?: number | null;
  /** V42: von der Figur bemerkter Widerspruch (kanonisch, contradiction-Fact) */
  contradiction?: { factId?: string; items?: Array<{ art?: string; aussage?: string; bekannt?: string; quelle?: string; sicherheit?: number }> };
}

export interface PipelineFlags {
  fate: boolean;
  meta: boolean;
  narrator: boolean;
}

export interface SessionGoal {
  id: string;
  ownerId: string;
  text: string;
  status: GoalStatus;
}

export interface Proposition {
  id: string;
  text: string;
  status: GoalStatus | "contradicted";
  actors: string[];
  turn: number;
}

export interface TurnFocus {
  addressedId?: string;
  topicId?: string;
  lastSpeakerId?: string;
  lastActorId?: string;
  lastTargetId?: string;
  lastQuestion?: string;
  lastFactId?: string;
  lastGoalId?: string;
  uploadId?: string;
}

export interface SessionTime {
  world: string;
  world_id: string;
  session: number;
  session_id: string;
  scene?: string;
  turn: number;
  real?: string | null;
  source_turn_id?: string;
  window?: string;
  relative?: string;
  ambiguous?: boolean;
  resolved_date?: string;
  tense: "past" | "present" | "future" | "unbound";
  commit_allowed?: boolean;
}

export interface ConjunctiveFrame {
  id: string;
  kind: string;
  status: string;
  who: string;
  whom?: string;
  what: string;
  when?: { label?: string; precision?: string; start?: string | null; end?: string | null; weekday?: string | null; time?: string | null };
  history?: Array<{ turn: number; by: string; event: string }>;
  witnesses?: string[];
  updatedTurn?: number;
}

export interface Session {
  /** V39 Konjunktives Gedächtnis: kanonische Vereinbarungen/Zustände (zeugengebunden), kernel-owned */
  frames?: ConjunctiveFrame[];
  /** V44 Szenen-Zustandsmaschine (kernel-owned) */
  sceneState?: { status?: string; escalation?: number; actorIds?: string[]; targetIds?: string[]; nextBeatOwner?: string; lastPhysicalBeat?: { by?: string; target?: string; text?: string; turn?: number } | null; lastEmotionalBeat?: { by?: string; emotion?: string; intensity?: number; turn?: number } | null; openBeats?: Array<{ id: string; kind: string; text: string; by: string; owner: string; status: string; turn?: number }>; openEmotions?: Record<string, string[]> };
  id: string;
  worldId: string;
  userId: string;
  name: string;
  createdAt: string;
  updatedAt: string;
  avatarId: string | null;
  alias: string;
  role: SpeakerMode;
  /** V92 Paket 14 (Entscheidung 4, AMASTER §27.2): the speaker binding chosen in "Spreche als" - stored by the session owner,
   *  read back after a reload ("avatar" | "operator" | "observer" | "regie" | "gott" | "char:<id>"); none = choose again. */
  speakAs?: string | null;
  scene: SceneState;
  runtimes: Record<string, RuntimeState>;
  relations: DirectedRel[];
  memories: Memory[];
  facts: SceneFact[];
  godFacts: GodFact[];
  fate: FateState;
  turns: ChatLine[];
  turnIndex: number;
  pipeline: PipelineFlags;
  autoChat: { enabled: boolean; turns: number; delayMs: number; contextTurns: number };
  goals: SessionGoal[];
  propositions: Proposition[];
  focus: TurnFocus;
  witnessKnowledge?: { character_id?: string; characterId?: string; fact_id?: string; access: string; turn: number; source_turn_id?: string }[];
  currentState?: Record<string, unknown> | null;
  /** B.22: Server liefert strukturierten Time-Bind (kernel.bind_time).
   *  Vorher Type-Mismatch: war nirgends typisiert, landete als Dict im JSON. */
  time?: SessionTime;
}

export interface SynapseFire {
  space: MeaningSpace;
  activation: number;
  cell: CompassCell;
}

export interface ProfileSlice {
  name: string;
  role: string;
  speechRegister: string;
  typicalPhrases: string[];
  taboos: string[];
  values: string[];
  reactionRules: string[];
  relevantCanon: string[];
  ownSecrets: string[];
  species?: string;
  coreFacts?: string[];
  bindingPatterns?: string[];
  lastingAbilities?: string[];
  humor?: string;
  favoriteWords?: string[];
  fears?: string[];
  likes?: string[];
  dislikes?: string[];
  goals?: string[];
  conflictStyle?: string;
  biography?: string;
  personality?: string;
}

export interface SpiegelFact {
  actor: string;
  target?: string;
  kind: string;
  text: string;
  turn: number;
}

export interface Spiegel {
  speakerId: string;
  speakerName: string;
  mode: SpeakerMode;
  profile: ProfileSlice;
  fired: SynapseFire[];
  runtime: RuntimeState;
  body: {
    position: string;
    mobility: number;
    pain: number;
    consciousness: number;
    canDo: string[];
    cannotDo: string[];
  };
  scene: {
    place: string;
    time: string;
    present: string[];
    tension: number;
    danger: number;
    open: string[];
    hears?: string[];
    sees?: string[];
    items?: string[];
    aftereffects?: string[];
    questions?: string[];
    demands?: string[];
    promises?: string[];
  };
  relationsHere: { name: string; kind?: string; trust: number; closeness: number; fear: number; hostility: number; note: string }[];
  memories: { text: string; kind: MemoryKind; salience: number; truth: TruthStatus; turn: number }[];
  facts: SpiegelFact[];
  dialogue: { name: string; speech: string; action?: string }[];
  query?: { question: string; about?: string; prior?: string };
  goals: string[];
  fate: { pressure: number; beat: string; mustNot: string };
  knowledge: string[];
  unknown: string[];
  userUtterance: string;
  addressedTo?: string;
  topic?: string;
  worldRules?: string[];
  currentState?: Record<string, unknown> | string | null;
  triggerHints?: string[];
  cues?: string[];
}

export interface FormulateResult {
  speech: string;
  action: string | null;
  source: "llm" | "synapse";
  commitsTruth?: boolean;
  proposals?: Record<string, unknown>;
}

export interface WorldDraft {
  world: Partial<World> & Pick<World, "name" | "short" | "long" | "genre">;
  characters: Array<Partial<StammCharacter> & Pick<StammCharacter, "name">>;
  recognize?: "local" | "llm";
  keywords?: string[];
  /** V25: "llm" = konfigurierter Provider, "local-fallback" = Heuristik ohne KI (Vertrag §7). */
  source?: "llm" | "local-fallback" | string;
  provenance?: Record<string, string>;
  llmError?: string;
}

export interface UserProfile {
  id: string;
  name: string;
  language: string;
  defaultRole: SpeakerMode;
  lastWorldId: string | null;
  lastSessionId: string | null;
  tts: boolean;
  sttMode: "dictation" | "autosend";
  largeType: boolean;
  highContrast: boolean;
  createdAt: string;
  avatarsByWorld?: Record<string, string>;
  avatarsBySession?: Record<string, string>;
  providerConfig?: { endpoint?: string; model?: string; localOnly?: boolean };
}

export interface UploadAsset {
  id: string;
  name: string;
  mime: string;
  text: string;
  mode: UploadMode;
  targetKind: "world" | "character" | "session" | "scene" | "reference";
  targetId: string;
  worldId?: string;
  sessionId?: string;
  characterId?: string;
  note: string;
  committed: boolean;
  status: "pending" | "ready" | "committed" | "error" | "ocr_empty";
  error?: string;
  createdAt: string;
  userId: string;
  documentGroup?: string;
  preview?: string;
}

export interface ReviewItem {
  id: string;
  kind: "stamm" | "world" | "spawn";
  sourceSessionId: string;
  characterId?: string;
  worldId: string;
  field: string;
  oldValue: string;
  newValue: string;
  reason: string;
  status: "open" | "accepted" | "rejected" | "session-only";
  createdAt: string;
}

export interface TriggerRule {
  id: string;
  name: string;
  active: boolean;
  worldId: string;
  sessionId?: string;
  targetIds: string[];
  match: string;
  effectType: "scene" | "world_event" | "behavior_constraint" | "hint";
  effectText: string;
}

export interface Snapshot {
  id: string;
  sessionId: string;
  name: string;
  createdAt: string;
  session: Session;
  /** V66 (Audit6 N05): the server's own capture (stamp + content hash); without it the snapshot is archive only */
  erfasst?: { durch: string; weg?: string; am?: string; inhaltSha256?: string };
}

export interface Preference {
  id: string;
  characterId: string;
  target: string;
  valence: "pos" | "neg";
  category: string;
  intensity: number;
  text: string;
}

export interface LogLine {
  id: string;
  at: string;
  level: "info" | "warn" | "error";
  code: string;
  message: string;
  sessionId?: string;
  turn?: number;
}

export interface AppConfig {
  autoChatTurns: number;
  autoChatDelayMs: number;
  contextTurns: number;
  fateDefault: boolean;
  narratorDefault: boolean;
  debug: boolean;
  model: string;
  temperature: number;
  maxTokens: number;
  apiKey: string;
  provider?: "xai" | "openai" | "synapse" | "custom";
  endpoint?: string;
  llmEnabled?: boolean;
  keyPresent?: boolean;
  keySource?: "config" | "env" | "none" | string;
  apiKeyPresent?: boolean;
  apiKeyMasked?: string;
  scope?: "global" | "user" | "world" | "character" | "session" | "runtime";
  scopeId?: string;
}

export interface WorldPack {
  kind: "matrix10-world-pack";
  version: 1;
  world: World;
  characters: StammCharacter[];
  /** Complete source evidence required to reconstruct sourcePartIds in another installation. */
  sourceDocuments?: Array<Record<string, unknown>>;
  exportedAt: string;
}

export const BUILD_ID = "MATRIX10_CHATHERE_V91_KETTENREPARATUR_20261103";
export const GASTHAUS_ID = "world_gasthaus_7kreis";
