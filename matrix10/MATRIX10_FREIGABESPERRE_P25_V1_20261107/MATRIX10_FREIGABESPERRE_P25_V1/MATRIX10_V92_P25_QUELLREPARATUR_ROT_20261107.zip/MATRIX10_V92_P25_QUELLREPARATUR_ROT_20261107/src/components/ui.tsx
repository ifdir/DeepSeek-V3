import { cloneElement, isValidElement, useId, type ReactElement, type ReactNode } from "react";
import { cn } from "@/lib/cn";
import type { ButtonHTMLAttributes, InputHTMLAttributes, LabelHTMLAttributes, SelectHTMLAttributes, TextareaHTMLAttributes } from "react";

export function Button({
  variant = "primary",
  className,
  ...props
}: ButtonHTMLAttributes<HTMLButtonElement> & { variant?: "primary" | "ghost" | "danger" | "line" | "ok" }) {
  const v = {
    primary: "bg-accent text-accent-fg hover:opacity-90",
    ghost: "bg-transparent text-fg hover:bg-subtle",
    danger: "border border-danger/50 bg-elevated text-danger hover:bg-subtle",
    line: "border border-border bg-elevated text-fg hover:bg-subtle",
    ok: "border border-ok/40 bg-elevated text-ok hover:bg-subtle",
  }[variant];
  return (
    <button
      className={cn(
        "inline-flex min-h-11 items-center justify-center gap-2 rounded-[12px] px-4 text-sm font-medium transition-opacity duration-150 disabled:opacity-40",
        v,
        className,
      )}
      {...props}
    />
  );
}

export function Input({ className, ...props }: InputHTMLAttributes<HTMLInputElement>) {
  return (
    <input
      className={cn(
        "min-h-11 w-full rounded-[12px] border border-border bg-bg px-3 text-sm text-fg placeholder:text-faint outline-none focus:border-accent",
        className,
      )}
      {...props}
    />
  );
}

export function Textarea({ className, ...props }: TextareaHTMLAttributes<HTMLTextAreaElement>) {
  return (
    <textarea
      className={cn(
        "w-full rounded-[12px] border border-border bg-bg px-3 py-2 text-sm text-fg placeholder:text-faint outline-none focus:border-accent",
        className,
      )}
      {...props}
    />
  );
}

export function Select({ className, ...props }: SelectHTMLAttributes<HTMLSelectElement>) {
  return (
    <select
      className={cn(
        "min-h-11 w-full rounded-[12px] border border-border bg-bg px-3 text-sm text-fg outline-none focus:border-accent",
        className,
      )}
      {...props}
    />
  );
}

export function Label({ children, className, ...props }: LabelHTMLAttributes<HTMLLabelElement>) {
  return (
    <label className={cn("mb-1 block text-xs font-medium uppercase tracking-wide text-muted", className)} {...props}>
      {children}
    </label>
  );
}

export function Field({ label, children }: { label: string; children: ReactNode }) {
  const autoId = useId();
  const existing = isValidElement(children) ? (children as ReactElement<{ id?: string }>).props.id : undefined;
  const inputId = existing ?? autoId;
  const child = isValidElement(children)
    ? cloneElement(children as ReactElement<{ id?: string }>, { id: inputId })
    : children;
  return (
    <div className="min-w-0">
      <Label htmlFor={inputId}>{label}</Label>
      {child}
    </div>
  );
}

export function Chip({ children, hot, tone }: { children: React.ReactNode; hot?: boolean; tone?: "ok" | "danger" | "warn" }) {
  return (
    <span
      className={cn(
        "inline-flex items-center rounded-full px-2 py-0.5 text-[11px] font-medium tabular-nums",
        hot ? "bg-accent text-accent-fg" : "bg-subtle text-muted",
        tone === "ok" && "bg-ok/15 text-ok",
        tone === "danger" && "bg-danger/15 text-danger",
        tone === "warn" && "bg-warn/15 text-warn",
      )}
    >
      {children}
    </span>
  );
}

export function Switch({
  checked,
  onChange,
  label,
}: {
  checked: boolean;
  onChange: (v: boolean) => void;
  label: string;
}) {
  return (
    <button
      type="button"
      role="switch"
      aria-checked={checked}
      onClick={() => onChange(!checked)}
      className="flex min-h-11 items-center gap-2 text-sm"
    >
      <span className={cn("relative h-6 w-10 rounded-full border border-border", checked ? "bg-accent" : "bg-subtle")}>
        <span className={cn("absolute top-0.5 size-5 rounded-full bg-fg transition-transform duration-150", checked ? "translate-x-4" : "translate-x-0.5")} />
      </span>
      <span className="text-muted">{label}</span>
    </button>
  );
}

export function Lines({
  value,
  onChange,
  rows = 3,
  placeholder,
}: {
  value: string[];
  onChange: (v: string[]) => void;
  rows?: number;
  placeholder?: string;
}) {
  return (
    <Textarea
      rows={rows}
      placeholder={placeholder}
      value={value.join("\n")}
      onChange={(e) => onChange(e.target.value.split("\n"))}
      onBlur={(e) => onChange(e.target.value.split("\n").map((s) => s.trim()).filter(Boolean))}
    />
  );
}

