@echo off
cd /d "%~dp0"
where py >nul 2>nul
if not errorlevel 1 (
  py -3 PRUEFUNG_STARTEN.py
) else (
  python PRUEFUNG_STARTEN.py
)
echo.
echo Testlauf abgeschlossen. Fenster bleibt zur Ergebniskontrolle offen.
pause
