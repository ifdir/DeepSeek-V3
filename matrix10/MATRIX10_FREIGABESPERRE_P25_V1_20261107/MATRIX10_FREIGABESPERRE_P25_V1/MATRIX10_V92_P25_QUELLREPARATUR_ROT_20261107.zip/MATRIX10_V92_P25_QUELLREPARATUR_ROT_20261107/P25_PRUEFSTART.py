#!/usr/bin/env python3
"""P25: reproducible source check, never runs product or customer DB.
MANDATORY EXIT 2 (ROT) until complete Flask, frontend build and live acceptance.
"""
from __future__ import annotations
import hashlib
import json
import importlib.util
import os
import shutil
import subprocess
import sys
from pathlib import Path
ROOT = Path(__file__).resolve().parent
LOG = ROOT / 'P25_PRUEFLOG_WINDOWS.txt'
ENV = os.environ.copy()
ENV['PYTHONPATH'] = os.pathsep.join([str(ROOT), str(ROOT / 'tests'), ENV.get('PYTHONPATH', '')])
LINES = []

def say(msg):
    print(msg, flush=True)
    LINES.append(msg)

def sha_code():
    return {str(p.relative_to(ROOT)): hashlib.sha256(p.read_bytes()).hexdigest()
            for pat in ('matrix_api/**/*.py','src/**/*.ts','src/**/*.tsx','tests/**/*.py')
            for p in ROOT.glob(pat) if p.is_file()}

def run(label, args, timeout=160):
    say('\n=== ' + label + ' ===')
    try:
        p = subprocess.run(args, cwd=ROOT, env=ENV, text=True,
                           stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
                           errors='replace', timeout=timeout)
        output = p.stdout or '(keine Ausgabe)'
        # Preserve full detail on the test record while keeping the console readable.
        summary = output.splitlines()
        chosen = summary[-16:] if len(summary) > 16 else summary
        say('\n'.join(chosen))
        say('EXIT=' + str(p.returncode))
        return p.returncode
    except (OSError, subprocess.TimeoutExpired) as e:
        say('NICHT PRUEFBAR: ' + repr(e))
        return 3

say('MATRIX10 V92 P25 – QUELLCODE/VERTRAGSPRUEFUNG – KEIN PRODUKTSTART')
say('Kundendatenbank wird nicht verwendet; SQLite-Tests nutzen temp-Dateien.')
say('Python=' + sys.version.split()[0])
before = sha_code()
# The manifest hashes immutable package entries, excluding the dynamic run log.
manifestfile = ROOT / 'P25_MANIFEST.json'
if manifestfile.is_file():
    try:
        manifest = json.loads(manifestfile.read_text(encoding='utf-8'))
        mismatches = [rel for rel, expected in (manifest.get('sha256_files') or {}).items()
                      if not (ROOT / rel).is_file() or
                      hashlib.sha256((ROOT / rel).read_bytes()).hexdigest() != expected]
        say('MANIFEST_QUELLDATEIEN=' + ('PASS' if not mismatches else 'FEHLER: ' + ', '.join(mismatches[:12])))
    except (ValueError, OSError, KeyError) as ex:
        say('MANIFEST_LESUNG_FEHLER=' + repr(ex))
else:
    say('MANIFEST_FEHLT: KEIN Vollpaketnachweis')
run('VERSION.txt / Backend-Frontend-Build-Kennung, kein Build',
    [sys.executable, 'scripts/P24_BUILD_IDENTITAET.py'])
run('P25 R1, R2 und R3 – echte Assertions einschließlich getrenntem SQLite-Reader',
    [sys.executable, '-m', 'unittest', '-q', 'test_v92_p25_r1_r2_r3'])
run('P24 bestehende Binder-/Negativtests – nicht veraendert',
    [sys.executable, '-m', 'unittest', '-q', 'test_v92_p24_kette'])
run('Weitere bestehende Negativ-/Komponententests',
    [sys.executable, '-m', 'unittest', '-q', 'test_v84_kausal_chain', 'test_v92_negativgrenzen'])
# The P23 test writes a random-id test receipt. Use it only for the Node
# fixture test; restore the original packaged fixture afterwards, so this
# Prüfstart never alters the delivered source corpus or its test evidence.
fixture = ROOT / 'P23_PRUEFBELEGE' / 'P23_SQLITE_B_READBACK.json'
fixture_before = fixture.read_bytes() if fixture.is_file() else None
node = shutil.which('node')
try:
    run('SQLite-Kette: Prepare und Figuren-Commit (B)',
        [sys.executable, 'scripts/P23_SQLITE_READBACK_FIXTURE.py'])
    if node:
        run('P24 Frontend-Ruecklese- und UI-Gegenproben (kein Browser)',
            [node,'--experimental-strip-types','scripts/P24_COMMIT_READBACK_AND_UI_GATE.mjs'])
finally:
    if fixture_before is None:
        fixture.unlink(missing_ok=True)
    else:
        fixture.write_bytes(fixture_before)
if node:
    run('P22 Timeout/Abort-Kontrakte',
        [node,'P22_TIMEOUT_ABBRUCH_GEGENPROBEN.cjs','src/lib/matrix/api.ts'])
    run('TypeScript Transpile, nur Syntax', [node,'P22_TYPESCRIPT_SYNTAX.cjs',str(ROOT)])
else:
    say('Node fehlt: JS-Gegenproben NICHT PRUEFBAR')
if importlib.util.find_spec('flask'):
    run('R1: die 3 zuvor neu gebrochenen ECHTEN Puppet-Routentests',
        [sys.executable,'-m','unittest','-q',
         'test_v92_puppet_vertrag.PuppetRouteChain.test_denied_act_with_real_speech_stores_only_the_speech',
         'test_v92_puppet_vertrag.PuppetRouteChain.test_p10_partial_and_multiple_markers_over_the_route',
         'test_v92_puppet_vertrag.PuppetRouteChain.test_p12_two_acts_in_one_component_are_both_read_and_stored'])
    run('R2: zwei Adressaten echte Puppet-Route + SQLite + negative Kontrollfaelle',
        [sys.executable,'scripts/P25_ROUTE_R2_EMPFAENGER_GEGENPROBEN.py',str(ROOT),'P25'])
    run('P24 Anrede-/Fremdsprecher-Routen, weiterhin',
        [sys.executable,'scripts/P24_ROUTE_ANREDE_GEGENPROBEN.py'])
else:
    say('FLASK NICHT INSTALLIERT: ECHTE ROUTEN NICHT PRUEFBAR; NICHT BESTANDEN.')
run('VOLLSTAENDIGE bestehende Python-Suite, incl. historischer Fehlschlaege',
    [sys.executable, '-m','unittest','discover','-s','tests','-q'],timeout=240)
say('CODE_HASHES_UNVERAENDERT=' + str(before==sha_code()))
say('VERSION_HASH=' + hashlib.sha256((ROOT/'VERSION.txt').read_bytes()).hexdigest())
say('FRONTEND_DIST=' + ('JA' if (ROOT/'frontend_dist/index.html').is_file() else 'NEIN'))
say('ECHTES_MODELL_BROWSER_LIVE_ABGENOMMEN=NEIN')
say('GESAMTSTATUS=ROT / KEINE PRODUKTFREIGABE')
LOG.write_text('\n'.join(LINES)+'\n',encoding='utf-8')
say('Protokoll: '+str(LOG))
raise SystemExit(2)
