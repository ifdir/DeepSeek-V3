@echo off
setlocal
cd /d "%~dp0"
echo MATRIX10 V92 P24 - UNABHAENGIGE QUELLENPRUEFUNG - KEIN PRODUKTSTART
echo Die Originaldatenbank wird nicht fuer diese Pruefung genutzt.
where py >nul 2>nul
if not errorlevel 1 (
  py -3 P24_PRUEFSTART.py
) else (
  python P24_PRUEFSTART.py
)
echo.
echo Ergebnis: ROT. Keine Freigabe, bevor Live-Modell, Browser und Kettenvertrag bestehen.
echo Bericht: P24_PRUEFLOG_WINDOWS.txt
pause
endlocal
