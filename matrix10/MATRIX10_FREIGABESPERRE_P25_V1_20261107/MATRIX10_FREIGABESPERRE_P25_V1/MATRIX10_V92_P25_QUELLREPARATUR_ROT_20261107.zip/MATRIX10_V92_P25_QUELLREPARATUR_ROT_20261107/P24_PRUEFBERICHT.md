# Matrix10 V92 – P24-Quellreparatur und unabhängige Nachprüfung

**Stand:** 07.11.2026 · **Status: ROT** · keine Produktfreigabe · keine Originaldatenbank geändert

## 1. Eingefrorene Basis

- **Ausgangspunkt:** `MATRIX10_V92_P23_QUELLREPARATUR_ROT_20261107.zip`.
- **P23 SHA-256:** `4d7113084eb74fa5f13e0b371f174c23d84048d06c1a40a2dce61fdf827e32eb`.
- **Vergleichsbasis für die unveränderte BUILD_ID:** P22 (`MATRIX10_V92_P22_QUELLREPARATUR_ROT_20261106.zip`; SHA-256 `f21a46d3fc2f921ad44c668c10ec5eba52241cdde8f88156f69b0b6281814b43`).
- Die `VERSION.txt` in P24 ist **byte-identisch zur P22-Datei**, SHA-256 `188ac609498ded0f88758626661d49aed44c37125cf123f59f81fd331e72fe15`.
- Originaldatenbank ist nicht im Arbeitsstand und wurde nicht geöffnet; ein eigener Originaldatenbank-Hash konnte daher nicht neu erhoben werden.
- Pflichten aus `2_7master.txt`, `MATRIX10_SPS_MASTER.md` und Reparatur-Kettenvertrag §6 bleiben unverändert. Keine Umdeutung bestehender Testanforderungen.

## 2. Erste falsche Stelle und ausgeführte Quellreparatur

### N1: Build-Kennung (neuer P23-Fehler)

**Vorher:** P23 setzte in `VERSION.txt` eine neue `BUILD_ID`, während `src/lib/matrix/types.ts` und `src/routes/__root.tsx` die bisherige Kennung verwendeten. Das widerspricht dem Build- und Versionsvertrag und führt zum dokumentierten Build-Abbruch.

**P24:** `VERSION.txt` aus P22 **exakt wiederhergestellt**. Die statische Identitätsprüfung (`scripts/P24_BUILD_IDENTITAET.py`) besteht. **Ein echter Vite-/Frontend-Build wurde in dieser Umgebung nicht durchgeführt** und wird nicht als bestanden behauptet.

### C: Anrede als fremde Sprecheransage fehlgebunden

**P23-Fehlernaht:** `kernel.py` in `speaker_reading_needed` / `bind_input_components`. Ein einziger Name im Planerfeld `einleitung` wurde als Sprecher interpretiert, selbst wenn die separate Sprecherlesung Johann als Sprecher und Herrn Pfeiffer als Adressaten identifizierte. Ein Patch nur am Artpfad war daher wirkungslos.

**P24-Änderungen:**

1. `llm_contract.py`, `SPRECHER_CHECK_RULES`: ausdrücklich getrennte semantische Rollen `anrede`, `sprecheransage`, `unklar` und ein wörtlicher `ansageBeleg`. **Keine Wortliste als Entscheidungsgrundlage.**
2. `app.py`, `_check_component_vollzug`: durchgereichte Lesung samt Rolle und wörtlichem Beleg, ohne Quelle/ID zu übernehmen.
3. `kernel.py`, `_announcement_address_ids` und `bind_input_components`: nur eindeutige, quellgebundene Adressaten werden von Sprecherkandidaten getrennt; mehrdeutige Namen oder unbewiesene Lesungen bleiben ungebunden. Die vorangestellte Anrede bleibt vollständig in der tatsächlich gesprochenen Zeile.
4. `kernel.py`, `apply_component_kind_readings`: falsche Planer-Sprecher-ID bei **nachweisbarer Einleitung** wird nicht sofort zu einer nicht ausführbaren Rede. Bis zur unabhängigen Sprecher-/Adressatenlesung bleibt ihre Rolle ausdrücklich **offen**. Fehlt der Nachweis, wird keine fremde Rede als eigene anerkannt.

**Gezielt bestanden (Kernel, kein Live-Modell):** „Gustav, setz dich.“, „Herr Pfeiffer, setzen Sie sich.“, „Ja, Gustav, setz dich.“ und negative Fälle „Mara sagt: …“, falscher/fehlender Rollenbeleg, doppelte Namen. Der Originalwortlaut einschließlich Anrede wird geprüft. **Ob der echte Modell-Provider die neuen Rollen über alle Fälle zuverlässig liefert, ist weiterhin ungeprüft.**

### C-S: Stille Teilkürzung

Bei Puppet-Turns blockiert `app.py` in der Writer-Transaktion das Speichern, wenn `input_binding_outcome` eine fehlende/abgelehnte Teilkomponente meldet (`PUPPET_TEILABLEHNUNG`, 422). Der abgelehnte Rest wird der Oberfläche im Fehlertext mitgeteilt. Dadurch darf „Mara, schön dich zu sehen. Gustav, setz dich.“ nicht nur mit dem ersten Satz ohne Hinweis als erfolgreich gelten.

**Grenze:** Dieser P24-Schutz ist gezielt im Puppet-Schreibweg umgesetzt; eine vollständige Prüfung aller übrigen Eingabemodi erfolgte nicht.

### N2: Ungeklärter Antwortversuch ohne Ausgang

**P23-Fehlernaht:** Das Backend sperrte bei `attemptRunning` auch `attemptUnklar`; Frontend sperrte Wiederaufnahme sowohl am sichtbaren Knopf als auch im Click-Handler. „Abschließen“ war bereits gesperrt. Bei verlorenem Lebensnachweis war die Sitzung dauerhaft blockiert.

**P24:** Backend lässt die **ausdrücklich angeforderte** Wiederaufnahme bei `attemptUnklar` zu; ein nachweislich laufender Versuch bleibt 409 gesperrt. Der sichtbare Knopf und sein Handler benutzen dieselbe prüfbare reine TS-Funktion `canExplicitlyRetryPendingAttempt`; bei Unklarheit erklärt die Oberfläche den möglichen alten Prozess und das „first-commit-wins“-Verhalten. Es gibt **keinen automatischen Zweitversuch**. „Abschließen“ bleibt bis zum nachgewiesenen Abschluss gesperrt.

**Grenze:** Dieser Fall ist im Kernel/Frontend-Entscheider geprüft; die **echten HTTP-Routen** wurden hier nicht ausgeführt.

### N3: Prüfstart stürzt ab

`P23_PRUEFSTART.py` importiert jetzt `importlib.util` ausdrücklich. `P24_PRUEFSTART.py` und `P24_PRUEFSTART_WINDOWS.bat` enthalten einen vollständigen Prüfstart mit Anzeige und Protokoll. Der Prüfer startet weder das Produkt noch eine Nutzerdatenbank; der kontrollierte Exitcode **2 bedeutet ROT**, nicht Programmabsturz.

## 3. Eigene Gegenproben

| Prüfung | Ergebnis | Reichweite |
|---|---|---|
| `tests/test_v92_p24_kette.py` | **9/9 PASS** | Kernel: positive/negative Anrede, Titel/Name, Mehrdeutigkeit, Teilkürzung, ungeklärter Versuch |
| Bestehende P20–P24-Testauswahl | **82 ausgeführt, 1 FAIL** | Der originale P22-Test sucht die nicht mehr zulässige Bedingung `puppet_actor_id_not_bound_to_present_cast` als bloßen Quelltext. **Unverändert belassen**; Vertragsentscheidung offen |
| `scripts/P23_SQLITE_READBACK_FIXTURE.py` | **PASS** | Zwei Phasen, Facts aus getrennten SQLite-Verbindungen |
| `scripts/P24_COMMIT_READBACK_AND_UI_GATE.mjs` | **22 PASS** | Echte TS-Rücklesefunktion + UI-Entscheider, negative und positive Fälle; keine Browserabnahme |
| P22 Timeout-/Abort-Isolationsprüfung | **PASS** | JavaScript-Timeout-Mechanik; kein HTTP-/Browser-Timeout |
| TypeScript-Transpile | **PASS** | Syntax, **kein** Typecheck des Gesamtprojekts und **kein** Frontend-Build |
| Build-ID statisch | **PASS** | `VERSION.txt`, `types.ts` und Root-Metatag konsistent |
| Vollständige Python-Suite | **435 ausgeführt, 8 FAIL, 84 ERROR** | **ROT**, Flask-/Bundle-abhängige Tests hier teilweise nicht ausführbar |
| Neue echte Flask-Routenproben (Anrede und Liveness) | **nicht ausführbar** | Skripte mit echten Assertions beigelegt; Flask in dieser Umgebung nicht vorhanden |
| Echter Provider, realer Browser, Folgeturn, vollständige AMASTER-Abnahme | **nicht durchgeführt** | **ROT** |

Der P24-Prüfstart wurde wirklich ausgeführt, endete **kontrolliert mit Exitcode 2** und meldete, dass die Quellhashes während der Prüfung unverändert blieben. Das vollständige lokale Prüfprotokoll wird im Paket als `P24_PRUEFLOG_WINDOWS.txt` mitgeliefert.

**Testqualität:** Die bekannten schwachen P23-Tests wurden nicht als neue Beweise verkauft oder verändert. Neue P24-Tests prüfen konkrete Resultate mittels Assertions. Die beigepackten realen Routenprüfungen sind mangels Flask **noch kein bestandenes Testresultat**.

## 4. Vorhandene funktionierende P23-Strecken nicht unterstellen

Der vorgelegte externe P23-Livebericht bestätigt A (abwesende Puppet-Figur und leere Szene), B (Commit-Rücklesen), Prepare-Timeout und die Sperre gegen gleichzeitige Versuche. P24 verändert diese Ketten außer der bewusst korrigierten Wiederaufnahme und der Anrede nicht gezielt. **Sie wurden hier nicht erneut als gesamte Livekette mit echtem Provider und Browser abgenommen.**

## 5. Unverändert offene Systemprobleme und Abnahme

- G-5: God-Befehlswortlaut als bereits ausgeführte Tat.
- E-1: Einwilligung als dauerhafter Zustand; insbesondere Ablehnungen.
- S-1: Alte Sessions.
- R-1: Regie „setzt sich“ als Ortswechsel.
- `god_extract`-Wortliste und die acht ungeklärten Alt-Vertragstests.
- P22/P23-Meldung D („Mara sagt ...“), weitere Format-/Rollen-Fälle.
- Tatsächlicher Frontend-Build, HTTP-Routen- und Browser-Szenarien, echter Modellaufruf, SQLite-Commit aus der Route, Rücklesen, Figuren-Gedächtnis und Folgeturn.
- Bei mehrfach angesprochenen Figuren muss der komplette Satz erhalten bleiben oder die gesamte Eingabe sichtbar abgelehnt werden, niemals still verschwinden.
- Der alte P22-Quelltexttest ist eine bekannte Vertragsfrage, nicht still geändert, übersprungen oder als „Erwartungsfehler“ freigegeben.

### Freigabeentscheidung

**ROT.** P24 ist nur eine kontrollierbare Quellarbeitskopie, keine neue betriebsfertige Matrix10-Version. Die Auslieferung enthält kein neues `frontend_dist`, keine behaupteten Live-Ergebnisse und keinen Zugriff auf die Kundendatenbank. Der Kettenvertrag bleibt bis zur echten Frischpaket-Gesamtabnahme unvollständig.
