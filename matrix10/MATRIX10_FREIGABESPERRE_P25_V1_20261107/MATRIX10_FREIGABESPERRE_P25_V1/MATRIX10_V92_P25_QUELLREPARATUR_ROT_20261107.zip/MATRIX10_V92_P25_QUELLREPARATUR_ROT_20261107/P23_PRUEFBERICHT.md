# Matrix10 V92 – P23 Quellreparatur und unabhängige Zwischenabnahme

**Stand:** 7. November 2026  
**Gesamtstatus:** **ROT – KEINE Produktfreigabe.** P23 ist eine geänderte **Quellarbeitskopie**, kein neu gebautes und im Browser abgenommenes Matrix10-Produkt. Die vollständige Ausführungskette nach AMASTER/SPS/Kettenvertrag ist nicht geschlossen.

## 1. Eingefrorene Ausgangsbasis

- **P22-ZIP:** `MATRIX10_V92_P22_QUELLREPARATUR_ROT_20261106.zip`
- **SHA-256:** `f21a46d3fc2f921ad44c668c10ec5eba52241cdde8f88156f69b0b6281814b43`
- **Originaldateien:** 230; Archiv-CRC geprüft.
- **Änderungen am Original-ZIP:** keine.
- **Original-Nutzer-SQLite:** nicht beigelegt, nicht angefasst. Alle SQL-Testläufe nutzen neue temporäre Datenbanken.
- **Vorgaben:** `2_7master.txt`, `MATRIX10_SPS_MASTER.md` und `VERBINDLICHER_REPARATUR_KETTENVERTRAG.txt` sind im P23-Quellenpaket enthalten. Die zu P23 betroffenen Code- und Vertragspfade wurden geprüft; dies ist keine erneute vollständige semantische Abnahme aller Kapitel.

## 2. Erste falsche Naht und konkrete Reparatur

### A – autorisierte, aber abwesende Puppet

Vorher: `app.py` gab dem semantischen Leser nur die aktuelle Szene-Presence. P22 verlangte in `_check_component_vollzug` die Puppet-ID in dieser Liste. Die Route fügte die Figur erst später beim Commit hinzu; bei komplett leerer Liste entfiel die Artprüfung sogar vollständig.

P23: `_puppet_speaker` bindet die vom Nutzer gewählte **kanonische Welt-ID**. `kernel.puppet_kind_cast` bildet für die **Lesung** nur die anwesenden Figuren plus die autorisierte Puppet ab. `_check_component_vollzug` validiert jetzt auch bei leerer Szene zwingend gegen diesen autorisierten Cast. Der Writer bindet die Figur-ID erneut unter SQLite-Schreibsperre und darf erst bei gültigem Ergebnis den Presence-Commit durchführen. Die vorherige versteckte `allowAbsent`-Ausnahme wurde entfernt.

**Nachweis:** echte Assertions für abwesende/autorisiert, leere Szene, nichtautorisierte ID, namensgleiche andere Figur, Presence- und Rede-Fact nach SQL-Speicherung, SQL-Rollback bei Ablehnung. **Grenze:** Keine reale Flask-/Browser-/Provider-Puppet-Route in diesem Lauf; der End-to-End-Fall ist **nicht abgenommen**.

### B – falsche Erfolgsmeldung nach Commit-Timeout

Vorher: `facts.some(f => f.sourceTurnId === commitSourceTurnId)` identifizierte bereits Johanns beim Prepare gespeicherten Eingabe-Fact als vermeintliche Antwort der Figur.

P23: `responseReadbackStatus` in `src/lib/matrix/response-readback.ts` prüft die kanonische GET-Session auf **abgeschlossene Eingabe**, passenden `TurnTruth`-Antwortsprecher, validierten Antwort-Fact mit Figuren-ID und Quell-ID sowie die dazugehörige `character`-Turn-Zeile. Ein vorhandener Eingabe-Fact genügt nicht. Bei nicht nachgewiesenem Ausgang wird **„ungewiss“** angezeigt; kein automatischer Commit-Retry.

**Nachweis:** reale `kernel.commit_turn`-Phasen input → SQLite → getrennte GET-Verbindung → response → SQLite → getrennte GET-Verbindung. Die tatsächlichen SQL-Session-Snapshots fließen als Fixture in 19 Node-Fälle mit **echten Assertions**, darunter „nur Eingabe“ = ungewiss und gültige Figurenantwort = gespeichert. Negative Fälle umfassen falsche ID, fehlenden Turn, fehlende TurnTruth, fehlende Validierung und noch offene Eingabe. **Grenze:** Die Timeout-Auslösung mit realem HTTP und der sichtbare Browser fehlen; E2E weiter ROT.

### C – Anrede „Gustav“ / „Herr Pfeiffer“

`kernel.py` erkennt den positionsgebundenen Vokativ aus der **Originaleingabe**, auch wenn der Planer im Satzsegment das Namenspräfix entfernt. Die Bindung verlangt eine eindeutige Figuren-ID, eine passende Quellposition und ein belegtes Anredesegment. Fremdbericht „Mara sagt: ...“ bleibt abgewiesen. Zwei positive und ein negativer Fall bestehen im Kern mit Assertions; echte LLM-Planner-/Flask-Route nicht abgenommen.

### Prepare-Timeout und Wiederaufnahme

Die Oberfläche liest nach einem ungewissen Prepare-Timeout die kanonische Session zurück, zeigt offene Eingaben und hat einen bedienbaren Knopf **„Status neu prüfen“**. Die Session-Rücklesung aktualisiert auch die Timeline. Ein ungeklärt laufender Antwortversuch (`attemptRunning`) sperrt erneute Antwort-POSTs sowohl im UI als auch serverseitig. Bei bestätigtem Stillstand bleibt die explizite Wiederaufnahme möglich. Keine automatische Zweitsendung.

## 3. Ausgeführte Gegenproben

| Prüfung | Gemessen | Status |
|---|---:|---|
| P20/P21/P22/P23 Python-Regressionen | 73 bestanden | **PASS für geprüfte Fälle** |
| Davon zusätzliche P23-Python-Tests mit Assertions | 12 bestanden | **PASS** |
| Frische SQLite-Input-/Response-Kette, GET über getrennte Verbindung | positiv und negativ | **PASS für Fixture** |
| Node-Antwort-Rücklesung inkl. echter SQLite-Fixture | 19 Fälle inkl. ID-Negativcheck bestanden | **PASS** |
| P22-Timeout/Abort-Node-Kernprobe | 5 bestanden | **PASS** |
| Frontend-Syntax/isolierter Typcheck | bestanden | **PASS für Syntax, nicht Browser** |
| Vollständige Python-Offlinesuite | 426, 8 FAIL, 83 ERROR | **ROT** |
| Flask-API mit SQLite, echte Modell-Provider | hier nicht installiert/ausgeführt | **NICHT ABGENOMMEN** |
| Vite-Build, Browser, echte Frontend-Hydration/Bedienung | kein `frontend_dist`, Buildabhängigkeiten fehlen | **NICHT ABGENOMMEN** |
| AMASTER/SPS vollständiger Folgeturn, Witness-/Recall-/Körper-/Isolationstest | nicht vollständig ausgeführt | **NICHT ABGENOMMEN** |

**Wichtige Testergebnis-Einordnung:** 8 FAIL + 83 ERROR sind der Stand dieses P23-Laufs. Ein früherer Lauf zeigte 7 FAIL + 84 ERROR; die Gesamtzahl der nicht bestandenen oder nicht ausführbaren Prüfungen bleibt 91. Die Verschiebung betrifft die Einordnung fehlender `frontend_dist`-Dateien. Ein bestehender Kernfehler zur Klassifikation `zaertlich` vs. `ohne_koerperwirkung` ist weiterhin darunter. Die große Gruppe der HTTP-Routentests kann wegen fehlendem Flask nicht starten. Dies ist keine Freigabe, auch wenn die gezielten Tests erfolgreich sind.

## 4. Unabgeschlossene Vertragsachsen

- **G-5:** God-Befehl wird weiter im Befehlswortlaut als vollzogene Tat gespeichert.
- **E-1:** Ablehnung/Einwilligung noch keine verlässliche dauerhafte Grenze.
- **S-1:** alte Sessions weiterhin gesperrt.
- **R-1:** Regie verwechselt „setzt sich“ mit Ortswechsel.
- `god_extract`-Wortliste, 7 vorbestehende Vertragstests, Sprecherdiagnose D, vollständige Prepare-/Commit-Live-Timeoutkette.
- Kein kompletter Nachweis Route → Writer → echte SQL-Rücklesung → Folgeturn → Witness/Memory/Körper/Recall → sichtbares Frontend am exakt ausgelieferten Build.

## 5. Frischpaket und Prüfanleitung

- Windows: Archiv in neuen Ordner entpacken und **`P23_PRUEFSTART_WINDOWS.bat`** doppelklicken. CMD bleibt offen; Ergebnisse landen in `P23_PRUEFLOG_WINDOWS.txt`.
- Das Startskript führt **nur Prüfungen**, nicht den Produktserver oder die Nutzer-SQLite aus. Ein beabsichtigter Exitcode 2 signalisiert Gesamtstatus ROT, auch wenn einzelne Quelltests PASS sind.
- Änderungen: `P23_AENDERUNGEN_GEGGEN_P22.diff` (vollständiges lesbares Source-Diff). Hashes und geänderte Dateien: `P23_MANIFEST.json`.
- Die Auslieferungs-ZIP wird nach dem Erstellen frisch entpackt und die selben Source-/SQLite-/Frontendbedingungen überprüft. **Diese Frischprüfung kann keinen fehlenden Browser-/Provider-Beweis ersetzen.**

## 6. Freigabeentscheidung

**P23 = ROT (Quellenreparatur, keine Produktversion).** Die Quellreparatur schließt die gezielt geprüften A-/B-/C-Fehler im isolierten Kern und in der SQL-Rückleseprobe. Der ursprüngliche End-to-End-Kettenvertrag §6.8 bleibt mangels gebautem Frontend, Flask und vollständigem Folgenachweis unerfüllt. **Keine Produktfreigabe und keine Behauptung einer neuen funktionstüchtigen Matrix10-Version.**
