/*
 * Regression contract for the AutoChat / Puppet / figure-commit logic.
 * V92 reconciliation: since frontend_dist is now compiled from the TSX sources
 * (npm run build:dist), minified identifiers change with every build. This test
 * therefore executes the REAL functions and gates out of
 * src/routes/chat.$sessionId.tsx (TypeScript-transpiled, run in a VM) and
 * additionally proves that the shipped bundle contains the same behaviour
 * markers. Not a browser / provider / SQLite acceptance.
 */
const assert = require('node:assert/strict');
const fs = require('node:fs');
const vm = require('node:vm');
const path = require('node:path');
const root = path.resolve(__dirname, '..');
const ts = require(path.join(root, 'node_modules', 'typescript'));
const tsx = fs.readFileSync(path.join(root, 'src/routes/chat.$sessionId.tsx'), 'utf8');

const js = (code) => ts.transpileModule(code, {compilerOptions: {target: ts.ScriptTarget.ES2020, module: ts.ModuleKind.None}}).outputText;
function slice(first, last, {inclusive = false} = {}) {
  const start = tsx.indexOf(first);
  assert(start > -1, `TSX anchor lost: ${first}`);
  const end = tsx.indexOf(last, start + first.length);
  assert(end > start, `TSX end anchor lost: ${last}`);
  return tsx.slice(start, end + (inclusive ? last.length : 0));
}
function functionSource(name) {
  const start = tsx.indexOf(`  function ${name}(`);
  assert(start > -1, `function lost: ${name}`);
  const end = tsx.indexOf('\n  }\n', start);
  assert(end > start);
  return tsx.slice(start, end + 5);
}

// ---- bundle presence (shipped JS carries the same behaviour markers) ----
function verifyBundle() {
  const html = fs.readFileSync(path.join(root, 'frontend_dist/index.html'), 'utf8');
  const assets = fs.readdirSync(path.join(root, 'frontend_dist/assets')).filter((f) => f.endsWith('.js'));
  const all = assets.map((f) => fs.readFileSync(path.join(root, 'frontend_dist/assets', f), 'utf8')).join('\n');
  for (const marker of ['figure_turn_not_committed', 'AUTOCHAT_STOP', 'Keine Rede oder Handlung vollzogen', 'TURN_WITHOUT_LINE']) {
    assert(all.includes(marker), `bundle misses behaviour marker: ${marker}`);
  }
  assert(/assets\/index-[A-Za-z0-9_-]+\.js/.test(html), 'index.html references no hashed entry bundle');
  console.log('Bundle: behaviour markers present in shipped JS.');
}

// ---- AutoChat: real cancelAutoChain + queueAuto from the TSX ----
function autoHarness({success = false, gateStop = false, noSpeaker = false, deferredGate = false, deferredCommit = false} = {}) {
  const code = js(functionSource('cancelAutoChain') + functionSource('queueAuto'));
  const timers = new Map(), events = [];
  let nextId = 0, resolveGate, resolveCommit;
  const session = {id: 's1', turnIndex: 4, role: 'teilnehmer', autoChat: {enabled: true}, turns: [{speech: 'Hallo'}]};
  const c = {
    autoChainEpoch: {current: 0}, autoTimer: {current: null},
    window: {setTimeout: (fn) => { const id = ++nextId; timers.set(id, fn); return id; }, clearTimeout: (id) => timers.delete(id)},
    useMatrix: {getState: () => ({sessions: [session]})},
    log: (d) => events.push(['log', d.code, d.message]),
    sessionId: 's1', session, world: {}, natives: [{id: 'mara'}], setSpeakerPick: () => {}, followAs: () => 'user',
    kernelAutochatGate: async () => {
      events.push(['gate']);
      if (deferredGate) return await new Promise((r) => { resolveGate = r; });
      return {stop: gateStop, speakerId: noSpeaker ? null : 'mara'};
    },
    runFigure: async () => {
      events.push(['turn']);
      if (deferredCommit) return await new Promise((r) => { resolveCommit = r; });
      return success;
    },
  };
  vm.createContext(c); vm.runInContext(code, c, {timeout: 1500});
  async function next() { const entry = timers.entries().next().value; if (!entry) return false; timers.delete(entry[0]); await entry[1](); return true; }
  async function drain() { let count = 0; while (timers.size) { assert(count++ < 8, 'recursive AutoChat runaway'); await next(); } }
  return {c, timers, events, next, drain,
    resolveGate: () => resolveGate?.({stop: false, speakerId: 'mara'}), resolveCommit: () => resolveCommit?.(true),
    get hasGateResolver() { return typeof resolveGate === 'function'; }, get hasCommitResolver() { return typeof resolveCommit === 'function'; }};
}
const turns = (x) => x.events.filter((e) => e[0] === 'turn').length;
async function verifyAuto() {
  let x = autoHarness(); x.c.queueAuto(3, 0, 0); await x.drain(); assert.equal(turns(x), 1); assert(x.events.some((e) => e[2] === 'figure_turn_not_committed'));
  x = autoHarness({success: true}); x.c.queueAuto(3, 0, 0); await x.drain(); assert.equal(turns(x), 3);
  x = autoHarness({gateStop: true}); x.c.queueAuto(3, 0, 0); await x.drain(); assert.equal(turns(x), 0);
  x = autoHarness({noSpeaker: true}); x.c.queueAuto(3, 0, 0); await x.drain(); assert.equal(turns(x), 0);
  x = autoHarness({success: true}); x.c.queueAuto(3, 0, 0); x.c.cancelAutoChain(); await x.drain(); assert.equal(turns(x), 0);
  x = autoHarness({deferredGate: true}); x.c.queueAuto(3, 0, 0); const p1 = x.next(); await Promise.resolve(); await Promise.resolve(); assert(x.hasGateResolver);
  x.c.cancelAutoChain(); x.resolveGate(); await p1; await x.drain(); assert.equal(turns(x), 0);
  x = autoHarness({deferredCommit: true}); x.c.queueAuto(3, 0, 0); const p2 = x.next(); for (let i = 0; i < 5; i++) await Promise.resolve(); assert(x.hasCommitResolver);
  x.c.cancelAutoChain(); x.resolveCommit(); await p2; await x.drain(); assert.equal(turns(x), 1);
  console.log('AutoChat: 7 executable stop/continue cases pass.');
}

// ---- entry paths: a failed figure turn never schedules a follow-up ----
function entryCode(which) {
  if (which === 'user') {
    const body = slice('const committed = await runFigure(speaker, msg, msg', '\n  }\n');
    return 'async function invoke(){' + body + '}';
  }
  const body = slice('const responseCommitted = await runFigure(responder', 'live.autoChat.delayMs);', {inclusive: true});
  return 'async function invoke(){' + body + '}';
}
async function verifyEntry() {
  for (const which of ['user', 'puppet']) for (const success of [false, true]) {
    const events = [];
    const live = {id: 's1', turnIndex: 3, alias: 'user', autoChat: {enabled: true, turns: 2, delayMs: 1}};
    const c = {
      runFigure: async () => { events.push('attempt'); return success; }, queueAuto: () => events.push('scheduled'),
      restoreText: () => events.push('restore'), useMatrix: {getState: () => ({sessions: [live]})}, sessionId: 's1',
      speaker: {id: 'mara'}, responder: {id: 'mara'}, msg: 'Hallo', speakerAs: 'user', live, avatar: null, user: null,
      followAs: () => 'user', explicit: false, puppetNext: live, log: () => {},
      klaerungen: undefined,   // V92 Paket 16: send(msg, klaerungen) passes the operator's answers through
    };
    vm.createContext(c); vm.runInContext(js(entryCode(which)), c, {timeout: 1500}); await c.invoke();
    assert.equal(events.includes('scheduled'), success, `${which}: bad continuation for success=${success}`);
    assert.equal(events.includes('restore'), which === 'user' && !success, `${which}: restoreText branch wrong`);
  }
  console.log('Input and Puppet-response: 4 success/failure branches pass.');
}

// ---- Puppet commit gate ----
function puppetGate(rows, previousTurns = []) {
  const snippet = slice('const puppetCommitted = next.turns.some(', 'puppetNext = puppetCommitted');
  const c = {next: {turnIndex: 4, turns: rows}, live: {turns: previousTurns}, fig: {id: 'mara'}};
  vm.createContext(c);
  vm.runInContext('function gate(){' + js(snippet) + 'return puppetCommitted;}', c, {timeout: 1500});
  return !!c.gate();
}
function verifyPuppet() {
  const cases = [
    [[{turn: 4, speakerId: 'mara', speech: '—', action: null}], false, 'placeholder'],
    [[{turn: 4, speakerId: 'mara', speech: 'Hallo', action: null}], true, 'spoken'],
    [[{turn: 4, speakerId: 'mara', speech: '—', action: '*tritt ein*'}], true, 'action'],
    [[{turn: 4, speakerId: 'mara', speech: '', action: null}], false, 'rejected'],
    [[{turn: 4, speakerId: 'johann', speech: 'Hallo', action: null}], false, 'other actor'],
    [[{turn: 3, speakerId: 'mara', speech: 'Hallo', action: null}], false, 'historical'],
    [[{id: 'old-line', turn: 4, speakerId: 'mara', speech: 'Hallo', action: null}], false, 'already committed line', [{id: 'old-line'}]],
  ];
  for (const [rows, expected, label, previous] of cases) assert.equal(puppetGate(rows, previous || []), expected, `puppet ${label}`);
  console.log('Puppet root: 7 scope/commit/old-row branches pass.');
}

// ---- figure line commit gate ----
function figureLineGate(rows, previousTurns = []) {
  const snippet = slice('const lastLine = committed.turns.at(-1);', '));\n', {inclusive: true});
  const c = {committed: {turnIndex: 4, turns: rows}, commitSpeaker: {id: 'mara'}, live: {turns: previousTurns}};
  vm.createContext(c);
  vm.runInContext('function gate(){' + js(snippet) + 'return figureExecuted;}', c, {timeout: 1500});
  return !!c.gate();
}
function verifyFigureLine() {
  const scenarios = [
    {rows: [], previous: [], expected: false, label: 'no line'},
    {rows: [{id: 'fresh', turn: 4, speakerId: 'mara', speech: '—', action: null}], expected: false, label: 'placeholder'},
    {rows: [{id: 'fresh', turn: 4, speakerId: 'johann', speech: 'Hallo', action: null}], expected: false, label: 'other speaker'},
    {rows: [{id: 'fresh', turn: 3, speakerId: 'mara', speech: 'Hallo', action: null}], expected: false, label: 'other turn'},
    {rows: [{id: 'previous', turn: 4, speakerId: 'mara', speech: 'Hallo', action: null}], previous: [{id: 'previous'}], expected: false, label: 'old committed row'},
    {rows: [{id: 'fresh', turn: 4, speakerId: 'mara', speech: 'Hallo', action: null}], expected: true, label: 'valid new speech'},
    {rows: [{id: 'fresh', turn: 4, speakerId: 'mara', speech: '', action: 'geht zur Tür'}], expected: true, label: 'valid action-only'},
  ];
  for (const sc of scenarios) assert.equal(figureLineGate(sc.rows, sc.previous || []), sc.expected, `figure ${sc.label}`);
  console.log('Figure source-of-truth: 7 new/old/invalid commit branches pass.');
}
// V92 Paket 9: der Eingabehinweis gehört nur zur LETZTEN direkten Eingabe; abgelehnte Eingaben zeigen die Servermeldung ohne Präfix.
function verifyEingabeHinweis() {
  const src = fs.readFileSync(path.join(root, 'src/lib/matrix/eingabe-hinweis.ts'), 'utf8').replace(/^export /gm, '');
  const ctx = {}; vm.createContext(ctx);
  vm.runInContext(js(src) + '\nthis.eingabeHinweis = eingabeHinweis; this.planIncompleteMeldung = planIncompleteMeldung;', ctx);
  const alt = {id: 't1', input_kind: 'speech', input_component_ambiguity: [{grund: 'rest_ohne_komponente', segment: 'x'}]};
  const neu = {id: 't2', input_kind: 'speech', input_component_ambiguity: []};
  const figur = {id: 't3', input_kind: 'autochat'};
  assert.equal(ctx.eingabeHinweis({turnTruths: [alt, neu]}), null, 'a later clean input shows no older hint');
  assert.equal(ctx.eingabeHinweis({turnTruths: [alt, figur]}).id, 't1', 'a figure turn after the input keeps the hint of the input');
  assert.equal(ctx.eingabeHinweis({turnTruths: [neu, {...alt, id: 't4', input_kind: 'puppet'}]}).id, 't4');
  assert.equal(ctx.planIncompleteMeldung('POST /api/kernel/prepare 422 EINGABE_NICHT_AUSFUEHRBAR: Eingabe: Nichts davon.'), 'Eingabe: Nichts davon.');
  assert.equal(ctx.planIncompleteMeldung('POST /api/kernel/puppet 422 PUPPET_NICHT_AUSFUEHRBAR: Puppet: Nichts.'), 'Puppet: Nichts.');
  assert.equal(ctx.planIncompleteMeldung('POST /api/kernel/prepare 409 INPUT_PENDING: wartet'), null);
  console.log('Eingabehinweis: 6 branches pass.');
}

(async () => { verifyBundle(); await verifyAuto(); await verifyEntry(); verifyPuppet(); verifyFigureLine(); verifyEingabeHinweis(); console.log('PASS: TSX-source executable regression gate (31 branches + bundle markers).'); })().catch((err) => { console.error(err); process.exitCode = 1; });
