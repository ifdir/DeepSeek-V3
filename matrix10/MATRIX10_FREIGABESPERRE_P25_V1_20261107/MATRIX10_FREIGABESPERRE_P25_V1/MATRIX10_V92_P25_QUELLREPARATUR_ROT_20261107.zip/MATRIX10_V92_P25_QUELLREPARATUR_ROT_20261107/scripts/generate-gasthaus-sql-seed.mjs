/** Build-time only: mirror the existing authored UI Gasthaus templates into
 * first-run server seed data. Node is NOT required to run Matrix10.
 * Usage: node --experimental-strip-types scripts/generate-gasthaus-sql-seed.mjs
 */
import { createHash } from 'node:crypto';
import { readFileSync, writeFileSync } from 'node:fs';
import { fileURLToPath } from 'node:url';
import { resolve, dirname } from 'node:path';
import { GASTHAUS_CHARS, GASTHAUS_WORLD } from '../src/lib/matrix/seed-gasthaus.ts';

const root = resolve(dirname(fileURLToPath(import.meta.url)), '..');
const files = ['src/lib/matrix/seed-gasthaus.ts','src/lib/matrix/compass.ts','src/lib/matrix/types.ts'];
const sources = Object.fromEntries(files.map(p => [p, createHash('sha256').update(readFileSync(resolve(root,p))).digest('hex')]));
const object = {schema:1, sourceHashes:sources, world:GASTHAUS_WORLD, characters:GASTHAUS_CHARS};
if (GASTHAUS_CHARS.length !== 5 || GASTHAUS_CHARS.some(ch => !ch.id || !ch.compass || !ch.personality)) {
  throw Error('authored seed incomplete; refuse incomplete output');
}
const output=resolve(root,'matrix_api/gasthaus_seed.json');
writeFileSync(output,JSON.stringify(object,null,2)+'\n','utf8');
console.log('GENERATED',output, GASTHAUS_CHARS.length, 'complete profiles');
