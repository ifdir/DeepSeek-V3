"""P25/R2: C5 über die echte Puppet-Route: zwei Anreden in einer Eingabe, beide Teile vom Planer erkannt, Sprecherlesung korrekt
(Johann spricht, ansageRolle anrede). Geprüft: Status, gespeicherter Wortlaut, an wen die Rede gerichtet ist."""
import io, json, os, sys, tempfile, urllib.request
from contextlib import closing
from pathlib import Path
from unittest.mock import patch
ROOT = Path(sys.argv[1]).resolve(); LABEL = sys.argv[2]
sys.path[:0] = [str(ROOT), str(ROOT / "tests")]
os.environ.pop("PYTEST_CURRENT_TEST", None); os.environ.pop("MATRIX_SKIP_SEED", None)
_t = tempfile.TemporaryDirectory(); DBP = str(Path(_t.name) / "t.sqlite"); os.environ["MATRIX_DB"] = DBP; os.environ["MATRIX_LIVE_LOG"] = str(Path(_t.name) / "l")
from matrix_api.db import connect, init_schema
from matrix_api.seed_builtin import seed_if_missing
from matrix_api.repos import create_session, get_session
class R(io.BytesIO):
    def __enter__(self): return self
    def __exit__(self, *a): return False
def plan(comps): return {"event_kind": "request", "speech_act": "request", "durability": "utterance", "summary": "x", "subject": "Johann", "predicate": "x", "object": "",
                         "temporal": {"text": None, "precision": "unknown"}, "refers_to": None, "cue_terms": [], "grenze": None, "verweis": None, "komponenten": comps}
def comp(seg, intro): return {"typ": "rede", "segment": seg, "akteur": "Johann Bruckner", "einleitung": intro, "ziel": None, "zeit": "jetzt", "wirkung": None, "bezug": None}
def prov(comps):
    def f(req, timeout=None):
        b = json.loads(req.data.decode()); s = b["messages"][0]["content"]
        try: u = json.loads(b["messages"][1]["content"])
        except Exception: u = {}
        if "Konjunktives Gedächtnis" in s: c = plan(comps)
        elif "Rede oder eigene Handlung einer gesteuerten Figur" in s: c = {"art": "rede", "beleg": u.get("segment") or "", "wirkung": None}
        elif "Sprecher prüfen" in s:
            a = str(u.get("ansage") or ""); n = a.rstrip(", ").split(",")[-1].strip()
            c = {"sprecher": "Johann Bruckner", "adressat": n or None, "beleg": u.get("worte") or None, "ansageRolle": "anrede", "ansageBeleg": a.strip()}
        elif "Namensumfang" in s:
            c = {"grenzen": [{"a": k["a"], "b": k["b"], "wortfolge": k["wortfolge"], "wortklassen": ["name"] * len(k.get("woerter") or []), "status": "eindeutig", "rolle": "anrede"} for k in u.get("kandidaten") or []]}
        else: c = {}
        return R(json.dumps({"choices": [{"message": {"content": json.dumps(c, ensure_ascii=False)}, "finish_reason": "stop"}]}).encode())
    return f
with closing(connect(DBP)) as c:
    init_schema(c); seed_if_missing(c); c.execute("INSERT OR IGNORE INTO users(id,json) VALUES('admin','{\"id\":\"admin\"}')")
    c.execute("INSERT INTO config(scope,scope_id,json) VALUES(?,?,?)", ("user", "admin", json.dumps({"scope": "user", "scope_id": "admin", "provider": "openai", "model": "t", "apiKey": "sk-TESTONLY", "endpoint": "http://127.0.0.1:9/v1/chat/completions"})))
    ch = {json.loads(r[1])["name"]: json.loads(r[1]) for r in c.execute("select id,json from characters")}
    J = ch["Johann Bruckner"]; M = next(v for k, v in ch.items() if "Mara" in k); G = next(v for k, v in ch.items() if "Gustav" in k)
    W = c.execute("select id from worlds limit 1").fetchone()[0]
    for sid in ("c5", "c5t", "g1"): create_session(c, {"id": sid, "worldId": W, "name": "v", "presentIds": [J["id"], M["id"], G["id"]]}, "admin")
    c.commit()
from matrix_api import app as appmod
CL = appmod.create_app(DBP).test_client()
NAMES = {J["id"]: "Johann", M["id"]: "Mara", G["id"]: "Gustav", None: None, "": None}
def run(case, sid, text, comps, target=None):
    with closing(connect(DBP)) as c: s0 = get_session(c, "admin", sid)
    body = {"session": s0, "sessionId": sid, "actorUserId": "admin", "figure": {"id": J["id"], "name": J["name"]}, "text": text}
    if target: body["targetId"] = target
    with patch.object(urllib.request, "urlopen", prov(comps)):
        r = CL.post("/api/kernel/puppet", headers={"X-Matrix-Actor": "admin"}, json=body)
    j = r.get_json(silent=True) or {}
    with closing(connect(DBP)) as c: s1 = get_session(c, "admin", sid)
    sp = [f for f in s1["facts"] if f not in s0["facts"] and f.get("kind") == "speech"]
    tu = [t for t in s1.get("turns") or [] if t not in (s0.get("turns") or [])]
    print(json.dumps({"paket": LABEL, "fall": case, "ui_ziel": NAMES.get(target), "status": r.status_code, "code": j.get("code"), "meldung": (j.get("message") or "")[:120],
                      "rede": [(f.get("text"), NAMES.get(f.get("targetId"), f.get("targetId"))) for f in sp],
                      "turn_ziel": [NAMES.get(t.get("targetId"), t.get("targetId")) for t in tu],
                      "hoerer_ids": [sorted(NAMES.get(x, x) for x in (f.get("audience") or f.get("hearerIds") or [])) for f in sp]}, ensure_ascii=False))
    # P25: fail on the exact former false positive. P24 returned 200 and
    # misdirected the entire combined speech Fact to Mara.
    if case.startswith("C5_"):
        assert r.status_code == 422 and j.get("code") == "PUPPET_TEILABLEHNUNG", (case, r.status_code, j)
        assert not sp and not tu, (case, sp, tu)
        assert s1["facts"] == s0["facts"] and s1["turns"] == s0["turns"], (case, "partial SQL write")
        assert s1.get("turnTruths") == s0.get("turnTruths"), (case, "turn truth changed")
        assert s1.get("scene", {}).get("presentIds") == s0.get("scene", {}).get("presentIds"), (case, "presence changed")
    else:
        assert r.status_code == 200, (case, r.status_code, j)
        assert len(sp) == 1 and sp[0].get("targetId") == G["id"], (case, sp)
        assert sp[0].get("text") == text, (case, sp)
T = "Mara, schön dich zu sehen. Gustav, setz dich."
run("C5_zwei_Anreden", "c5", T, [comp("schön dich zu sehen.", "Mara,"), comp("setz dich.", "Gustav,")])
run("C5_zwei_Anreden_UI_Ziel_Mara", "c5t", T, [comp("schön dich zu sehen.", "Mara,"), comp("setz dich.", "Gustav,")], target=M["id"])
run("G1_Gustav_UI_Ziel_Mara", "g1", "Gustav, setz dich.", [comp("setz dich.", "Gustav,")], target=M["id"])

print("P25 R2 echte Route / kanonische SQLite: 3 Faelle bestanden")
