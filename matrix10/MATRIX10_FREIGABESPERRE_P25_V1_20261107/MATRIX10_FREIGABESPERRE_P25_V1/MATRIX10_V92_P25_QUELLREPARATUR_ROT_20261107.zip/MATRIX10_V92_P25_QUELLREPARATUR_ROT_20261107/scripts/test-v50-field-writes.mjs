import fs from 'node:fs';
import assert from 'node:assert/strict';
import ts from 'typescript';

const src = fs.readFileSync(new URL('../src/lib/matrix/field-writes.ts', import.meta.url), 'utf8');
const compiled = ts.transpileModule(src, {
  fileName: 'field-writes.ts',
  compilerOptions: { target: ts.ScriptTarget.ES2022, module: ts.ModuleKind.ES2022 },
  reportDiagnostics: true,
});
assert.equal((compiled.diagnostics || []).filter(x => x.category === ts.DiagnosticCategory.Error).length, 0);
const { FieldWriteTracker } = await import('data:text/javascript;base64,'+Buffer.from(compiled.outputText).toString('base64'));

let tracker = new FieldWriteTracker();
let first = tracker.begin('world', 'world_test', { name: 'AB' }, { name: 'A' });
let second = tracker.begin('world', 'world_test', { name: 'ABC' }, { name: 'AB' });
assert.deepEqual(first.failed(), {}, 'older write must not overwrite newer typing');
assert.deepEqual(second.failed(), { name: 'A' }, 'double failure rolls back to last confirmed value');

tracker = new FieldWriteTracker();
first = tracker.begin('world', 'world_test', { name: 'AB' }, { name: 'A' });
second = tracker.begin('world', 'world_test', { name: 'ABC' }, { name: 'AB' });
first.committed();
assert.deepEqual(second.failed(), { name: 'AB' }, 'later failure rolls back to earlier successful value');

tracker = new FieldWriteTracker();
first = tracker.begin('world', 'world_test', { name: 'AB', genre: 'Thriller' }, { name: 'A', genre: 'Drama' });
second = tracker.begin('world', 'world_test', { name: 'ABC' }, { name: 'AB', genre: 'Thriller' });
assert.deepEqual(first.failed(), { genre: 'Drama' }, 'older failed fields revert only when no newer intent exists');
second.committed();

tracker = new FieldWriteTracker();
first = tracker.begin('world', 'w1', { name: 'W1 new' }, { name: 'W1' });
second = tracker.begin('character', 'c1', { name: 'C1 new' }, { name: 'C1' });
assert.deepEqual(first.failed(), { name: 'W1' });
assert.deepEqual(second.failed(), { name: 'C1' }, 'entity fields stay isolated');
console.log('PASS four field-write scenarios: rapid failure, sequential ACK, independent fields, isolated owners');
