#!/usr/bin/env node
/**
 * V25 PKG-05: frontend_dist reproduzierbar aus dem mitgelieferten Quellstand bauen.
 *
 *   npm ci && npm run build:dist
 *
 * Schritte: vite build (TanStack Start + Nitro, Preset vercel) → SPA-Huelle rendern
 * (V65U: nur Root-Route, TSS_SHELL; START.py liefert sie fuer jede Route als index.html) →
 * frontend_dist/ aus Assets + Shell zusammensetzen → .build-info.json mit
 * SHA-256 des src-Baums schreiben, damit Quelle↔Build prüfbar bleibt.
 */
import { createHash } from "node:crypto";
import { cpSync, existsSync, mkdirSync, readdirSync, readFileSync, rmSync, statSync, writeFileSync } from "node:fs";
import { dirname, join, relative } from "node:path";
import { spawnSync } from "node:child_process";
import { fileURLToPath, pathToFileURL } from "node:url";

const ROOT = dirname(dirname(fileURLToPath(import.meta.url)));
const OUT = join(ROOT, ".vercel", "output");
const DIST = join(ROOT, "frontend_dist");

function sha256(buf) {
  return createHash("sha256").update(buf).digest("hex");
}

function walk(dir, acc = []) {
  for (const name of readdirSync(dir)) {
    const p = join(dir, name);
    const st = statSync(p);
    if (st.isDirectory()) walk(p, acc);
    else acc.push(p);
  }
  return acc;
}

function treeHash(dir) {
  const files = walk(dir).sort();
  const h = createHash("sha256");
  for (const f of files) {
    h.update(relative(ROOT, f));
    h.update("\0");
    h.update(readFileSync(f));
    h.update("\0");
  }
  return { hash: h.digest("hex"), files: files.length };
}

const build = spawnSync(process.execPath, [join(ROOT, "scripts", "with-app-env.mjs"), "vite", "build"], { cwd: ROOT, stdio: "inherit" });
if (build.status !== 0) {
  console.error("[build:dist] vite build fehlgeschlagen");
  process.exit(build.status ?? 1);
}

// Rolldown-Chunkzyklus im SSR-Bundle (var-Helper vor Initialisierung): nur für das
// Shell-Rendering relevant, Client-Bundle ist nicht betroffen. Getter-Objekt ist
// semantisch identisch mit __exportAll({ getRouter: () => getRouter }).
const ssrDir = join(OUT, "functions", "__server.func", "_ssr");
if (existsSync(ssrDir)) {
  for (const f of readdirSync(ssrDir)) {
    const p = join(ssrDir, f);
    if (!f.endsWith(".mjs")) continue;
    const src = readFileSync(p, "utf8");
    const patched = src.replace(/__exportAll\(\{ getRouter: \(\) => getRouter \}\)/g, "{ get getRouter() { return getRouter; } }");
    if (patched !== src) writeFileSync(p, patched);
  }
}

// V65U (Codegutachten v1 T7, React #418): START.py liefert index.html fuer JEDE Route (/chat/…, /welt/…). Die bisher
// fuer "/" vollstaendig vorgerenderte Seite passte nur zu "/"; auf jeder anderen Route traf hydrateRoot(document) auf
// fremdes Markup (#418). Gerendert wird deshalb die SPA-Huelle von TanStack Start (TSS_SHELL, wie spa.enabled): nur die
// Root-Route, keine Routeninhalte; der Client rendert die Route selbst. Gleiche Assets, keine Aenderung an START.py.
process.env.TSS_SHELL = "true";
const handlerPath = join(OUT, "functions", "__server.func", "index.mjs");
const mod = await import(pathToFileURL(handlerPath).href);
const res = await mod.default.fetch(new Request("http://127.0.0.1:8080/", { headers: { host: "127.0.0.1:8080", accept: "text/html" } }), { waitUntil() {} });
if (res.status !== 200) {
  console.error(`[build:dist] SSR-Shell für / lieferte ${res.status}`);
  process.exit(1);
}
const html = await res.text();

rmSync(DIST, { recursive: true, force: true });
mkdirSync(DIST, { recursive: true });
cpSync(join(OUT, "static"), DIST, { recursive: true });
writeFileSync(join(DIST, "index.html"), html);

const missing = [...new Set(html.match(/\/assets\/[A-Za-z0-9._-]+/g) || [])].filter((ref) => !existsSync(join(DIST, ref)));
if (missing.length) {
  console.error("[build:dist] index.html referenziert fehlende Assets:", missing);
  process.exit(1);
}
const src = treeHash(join(ROOT, "src"));
// V92 (Build-Vertrag, Freigabe 04.11.2026): die Oberflaeche wird aus den TSX-Quellen gebaut; Build-Identitaet,
// Quellhash, Lockfile und SHA-256 jeder ausgelieferten Datei stehen in .build-info.json und werden von den Tests geprueft.
const versionTxt = readFileSync(join(ROOT, "VERSION.txt"), "utf8");
const buildId = (versionTxt.split(/\r?\n/).find((l) => l.startsWith("BUILD_ID=")) || "").split("=")[1]?.trim();
if (!buildId) { console.error("[build:dist] BUILD_ID in VERSION.txt fehlt"); process.exit(1); }
if (!html.includes(`name="matrix-build" content="${buildId}"`)) {
  console.error("[build:dist] index.html traegt nicht die Build-ID aus VERSION.txt (src/lib/matrix/types.ts BUILD_ID pruefen)");
  process.exit(1);
}
const assetFiles = walk(DIST).filter((f) => !f.endsWith(".build-info.json")).map((f) => relative(DIST, f)).sort();
const fileSha256 = Object.fromEntries(assetFiles.map((f) => [f, sha256(readFileSync(join(DIST, f)))]));
const info = {
  builtAt: new Date().toISOString(),
  buildId,
  frontendCompiledAnew: true,
  builtFromSource: true,
  sourceTreeSha256: src.hash,
  sourceFiles: src.files,
  lockfileSha256: sha256(readFileSync(join(ROOT, "package-lock.json"))),
  packageJsonSha256: sha256(readFileSync(join(ROOT, "package.json"))),
  indexHtmlSha256: sha256(html),
  assets: walk(join(DIST, "assets")).map((f) => relative(DIST, f)).sort(),
  fileSha256,
  // Stabiler Fingerprint ohne Zeitstempel: gleiche Quellen + Abhaengigkeiten => gleicher Wert (Reproduzierbarkeit)
  // index.html traegt einen Zeitstempel (u:<ms>) der SSR-Huelle; er wird fuer den Fingerprint auf u:0 normiert.
  indexHtmlNormalizedSha256: sha256(html.replace(/u:\d{10,}/g, "u:0")),
  reproducibleFingerprint: sha256(JSON.stringify({ ...fileSha256, "index.html": sha256(html.replace(/u:\d{10,}/g, "u:0")) })),
};
writeFileSync(join(DIST, ".build-info.json"), JSON.stringify(info, null, 2));
console.log(`[build:dist] frontend_dist erzeugt: ${info.assets.length} Assets, src-Hash ${src.hash.slice(0, 16)}…, Fingerprint ${info.reproducibleFingerprint.slice(0, 16)}…`);
