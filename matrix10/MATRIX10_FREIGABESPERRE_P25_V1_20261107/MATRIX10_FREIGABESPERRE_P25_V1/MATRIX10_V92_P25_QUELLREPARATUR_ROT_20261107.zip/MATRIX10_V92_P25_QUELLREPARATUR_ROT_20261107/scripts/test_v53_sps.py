"""V53 acceptance of REAL SQLite repository writers on an isolated DB clone.

The isolated test runtime has no Flask, so a tiny *test-only import shim*
permits importing the actual repo/isolation functions. No fake SQL write path.
Use in the project root: python scripts/test_v53_sps.py
"""
from __future__ import annotations
import hashlib, json, shutil, sys, tempfile, types
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
try:
    import flask
except ImportError:
    flask = types.ModuleType('flask')
    flask.jsonify = lambda d: d
    flask.request = None
    sys.modules['flask'] = flask

from matrix_api import repos, kernel
from matrix_api.db import connect, init_schema

MASTER = ROOT / 'data/matrix10.sqlite'

def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()
def counters(conn):
    return {name: conn.execute(f'SELECT COUNT(*) FROM {name}').fetchone()[0]
            for name in ('turns', 'scene_facts', 'memories', 'witness_knowledge', 'relationships', 'goals', 'god_facts')}

def get_char(conn, id):
    row=conn.execute('SELECT json FROM characters WHERE id=?', (id,)).fetchone()
    return json.loads(row[0]) if row else None


def run():
    assert MASTER.is_file(), MASTER
    before = sha(MASTER)
    with tempfile.TemporaryDirectory(prefix='m10v53_') as td:
        db=Path(td)/'copy.sqlite';shutil.copy2(MASTER,db)
        conn=connect(db);init_schema(conn);conn.commit()
        # Test 1: existing multi-session deletion, no loss of durable evidence.
        cid='char_b97b63012cf47621a91f404d'  # fixture identity, never production branch
        assert get_char(conn,cid)['name']=='Kvle'
        prev=counters(conn)
        from matrix_api.repos import WriterError
        try:
            repos.delete_character(conn,cid,'unbeteiligter_user')
        except WriterError as error:
            assert error.status == 403, (error.status, error)
        else:
            raise AssertionError('Foreign owner was allowed to delete')
        # Foreign session is NEVER edited implicitly when owner deletes stem.
        foreign_sid=conn.execute("SELECT id FROM sessions WHERE world_id=? LIMIT 1",(get_char(conn,cid)['worldId'],)).fetchone()[0]
        conn.execute('SAVEPOINT foreign_session')
        conn.execute('UPDATE sessions SET user_id=? WHERE id=?',('other_user',foreign_sid))
        try:
            repos.delete_character(conn,cid,'admin')
        except WriterError as error:
            assert error.status == 409 and error.error == 'CHARACTER_FOREIGN_SESSION', (error.status,error.error)
        else:
            raise AssertionError('Foreign session protection was bypassed')
        conn.execute('ROLLBACK TO foreign_session')
        conn.execute('RELEASE foreign_session')
        print('PASS FB01 ISOLATION: foreign owner 403, foreign active session 409, transaction unchanged')
        conn.execute('BEGIN IMMEDIATE')
        res=repos.delete_character(conn,cid,'admin')
        conn.commit()
        assert res['ok'] and res['deleted']==cid and res['historyPreserved']
        assert len(res['detachedSessions'])>=1
        assert res['sessionUpdates'] and res['world'] and res['user']
        assert get_char(conn,cid) is None
        for sid in res['detachedSessions']:
            row=conn.execute('SELECT json FROM sessions WHERE id=?',(sid,)).fetchone()
            d=json.loads(row[0]);scene=d.get('scene') or {}
            assert cid not in scene.get('presentIds',[])
            assert cid not in scene.get('hearsIds',[])
            assert cid not in scene.get('seesIds',[])
            assert cid not in (d.get('runtimes') or {})
            assert d.get('avatarId')!=cid
        assert counters(conn)==prev, (prev,counters(conn))
        assert conn.execute('PRAGMA integrity_check').fetchone()[0]=='ok'
        print('PASS FB01: one-session character deletion, all 7 SQL child tables preserved, server readback')

        # Test 2: old learned values removed only when explicitly requested.
        other='char_abe72ed52e7e895f3d3b34e1'
        old=get_char(conn,other);old_items=list(old['learnedItems']); assert old_items
        old_facts=counters(conn)
        result=repos.patch_character(conn,other,{'removeLearnedAll':True},'admin')
        conn.commit()
        new=result['character']
        assert not new.get('learnedItems'), len(new.get('learnedItems') or [])
        assert counters(conn)==old_facts
        assert 'removeLearnedAll' not in new
        if first := next((v for v in old_items if v['field']=='typicalPhrases'),None):
            assert first['value'] not in new.get('typicalPhrases',[])
        assert get_char(conn,other)['learnedItems']==[]
        print(f'PASS FB03: explicit ledger cleanup {len(old_items)} old entries, historical SQL untouched')

        # V58 / AMASTER 7/35: profile goals are not a gated chain.
        world_id=old.get('worldId')
        row=conn.execute('SELECT json FROM worlds WHERE id=?',(world_id,)).fetchone()
        world=json.loads(row[0])
        fresh=kernel.build_new_session(world,[old],session_id='ses_v58_sps_test',user_id='admin')
        definitions=repos.get_character(conn,other,'admin')['goals']
        # 'old' still contains pre-cleanup entries; compare with the same canonical reader.
        from matrix_api.learning import canonical_stem
        definitions=canonical_stem(old)['goals']
        steps=[g for g in fresh['goals'] if g.get('ownerId')==other]
        assert len(steps)==len(definitions)
        assert all(g['status']=='open' and 'nextGoalId' not in g for g in steps)
        assert [g['sourceDefinition'] for g in steps]==definitions
        assert fresh['runtimes'][other]['intent']==''
        sid=res['detachedSessions'][0]
        stored=[json.loads(row[0]) for row in conn.execute('SELECT json FROM goals WHERE session_id=?',(sid,))]
        goal=next(g for g in stored if g.get('ownerId')==other and g.get('status') not in ('fulfilled','completed'))
        before_click=counters(conn)
        try:
            repos.patch_session_goal(conn,sid,goal['id'],{'status':'fulfilled'},'admin')
        except WriterError as error:
            assert error.status==409 and error.error=='GOAL_EVIDENCE_REQUIRED'
        else:
            raise AssertionError('Status click manufactured goal fulfilment')
        assert counters(conn)==before_click
        assert json.loads(conn.execute('SELECT json FROM goals WHERE id=?',(goal['id'],)).fetchone()[0])==goal
        print('PASS FB04: all authored goals preserved, no phase chain, no click-created fulfilment')
        conn.close()
    assert sha(MASTER)==before, 'USER DB CHANGED'
    print('PASS DB: original bytewise SHA-256 unchanged')

if __name__=='__main__':run()
