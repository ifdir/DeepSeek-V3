#!/bin/sh
# MATRIX10 Flask/SQLite API. ROOT is the repo containing this script's parent, not a hardcoded /workspace.
set -eu

ROOT=$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)
export PYTHONPATH="$ROOT"
export MATRIX_DB="${MATRIX_DB:-$ROOT/data/matrix10.sqlite}"
PYTHON3="${PYTHON3:-python3}"
if ! "$PYTHON3" -c "import flask" >/dev/null 2>&1; then
  if [ -x /data/data/com.termux/files/usr/bin/python3 ] \
    && /data/data/com.termux/files/usr/bin/python3 -c "import flask" >/dev/null 2>&1; then
    PYTHON3=/data/data/com.termux/files/usr/bin/python3
  fi
fi
# Preview binds 0.0.0.0:8080. API stays loopback so the preview never hits Flask GET / 404.
export MATRIX_API_HOST=127.0.0.1
export MATRIX_API_PORT="${MATRIX_API_PORT:-5050}"

APP_ENV="$ROOT/.grok/app-env.json"
if [ -f "$APP_ENV" ]; then
  AUTH_FLAG=$(python3 -c 'import json,sys; print(json.load(open(sys.argv[1])).get("VITE_AUTH_ENABLED",""))' "$APP_ENV" 2>/dev/null || true)
  if [ -n "${AUTH_FLAG:-}" ]; then
    export VITE_AUTH_ENABLED="$AUTH_FLAG"
  fi
fi

cd "$ROOT"
mkdir -p data

PROBE_HOST="$MATRIX_API_HOST"
if [ "$PROBE_HOST" = "0.0.0.0" ] || [ "$PROBE_HOST" = "::" ]; then
  PROBE_HOST="127.0.0.1"
fi
HEALTH_URL="http://${PROBE_HOST}:${MATRIX_API_PORT}/api/health"

if curl -sf -o /dev/null --max-time 1 "$HEALTH_URL"; then
  exit 0
fi

if "$PYTHON3" -c "
import socket, sys
host, port = sys.argv[1], int(sys.argv[2])
s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
try:
    s.bind((host, port))
    raise SystemExit(1)
except OSError:
    raise SystemExit(0)
finally:
    s.close()
" "$PROBE_HOST" "$MATRIX_API_PORT"; then
  echo "PORT ${MATRIX_API_PORT} already in use. Set PORT=... or stop the other process." >&2
  echo "error: ${PROBE_HOST}:${MATRIX_API_PORT} is occupied by a process that is not matrix10 /api/health" >&2
  echo "error: stop that process or set MATRIX_API_PORT to a free port" >&2
  exit 1
fi

exec "$PYTHON3" -m matrix_api.app
