import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import { runInNewContext } from 'node:vm';
import { fileURLToPath } from 'node:url';
import { dirname, join } from 'node:path';

// Validates the exact delivered bundle's compiled kernelPresence function,
// not a duplicate test implementation. A browser + Flask run is separate.
const root = join(dirname(fileURLToPath(import.meta.url)), '..');
const path = join(root, 'frontend_dist', 'assets', 'index-5-VzmJtc-V51P.js');
const compiled = readFileSync(path, 'utf8');
const begin = compiled.indexOf('let q51=Promise.resolve();function Cg(');
const end = compiled.indexOf('async function wg(', begin);
assert.ok(begin > 0 && end > begin, 'delivered Cg implementation present');
const piece = compiled.slice(begin, end);
assert.ok(piece.includes('sessionId:e.session.id'), 'no full browser-owned session write');
assert.ok(!piece.includes('xg('), 'no 5 extra live-trace requests');
assert.ok(compiled.includes('onClick:()=>p51Toggle(e.id)'), 'delivered button wired');
assert.ok(compiled.includes('"aria-pressed":t'), 'on/off state accessible');
assert.ok(compiled.includes('"aria-busy":n,disabled:n'), 'double tap blocked during pending write');

const requests = [];
const httpCalls = [];
let releaseFirst;
const firstCanFinish = new Promise(resolve => (releaseFirst = resolve));
const canonical = { id: 'ses_test', turnIndex: 0, facts: [], scene: { presentIds: ['alpha', 'beta'] } };
const harness = {
  dg: p => p + '_trace',
  Ue: async body => {
    requests.push({ ...body });
    httpCalls.push(`POST:${body.characterId}`);
    if (requests.length === 1) await firstCanFinish;
    const present = canonical.scene.presentIds;
    canonical.scene.presentIds = present.includes(body.characterId)
      ? present.filter(c => c !== body.characterId) : [...present, body.characterId];
    return { session: structuredClone(canonical) };
  },
  mg: async _sid => {
    httpCalls.push(`GET:${_sid}`);
    return { ok: true, session: structuredClone(canonical) };
  },
  ug: (_prev, stored) => stored,
  hg: (writePath, stored, _merged, read, traceId) => ({
    writePath, storeTurn: stored.turnIndex, readOk: read.ok, traceId,
  }),
  Promise,
};
const presence = runInNewContext(piece + '\nCg', harness);
const click1 = presence({ session: { id: 'ses_test', userId: 'actor' }, characterId: 'alpha' });
const click2 = presence({ session: { id: 'ses_test', userId: 'actor' }, characterId: 'beta' });
await new Promise(resolve => setImmediate(resolve));
assert.equal(requests.length, 1, 'second request waits for first');
assert.equal(requests[0].sessionId, 'ses_test');
assert.equal(requests[0].session, undefined, 'no browser snapshot submitted');
assert.equal(requests[0].trace_id, 'kps_trace');
releaseFirst();
const result1 = await click1;
const result2 = await click2;
assert.equal(requests.length, 2);
assert.deepEqual(httpCalls, ["POST:alpha", "GET:ses_test", "POST:beta", "GET:ses_test"]);
assert.deepEqual(Array.from(result1.session.scene.presentIds), ['beta']);
assert.deepEqual(Array.from(result2.session.scene.presentIds), []);
assert.equal(result1.trace.readOk, true);
assert.equal(result2.trace.readOk, true);
console.log('V51 delivered presence queue: PASS (serial, 2 HTTP requests per tap, canonical GET, UI hooked)');
