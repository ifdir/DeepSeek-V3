/**
 * PRoot/Termux: Android's linker refuses dlopen of .node addons from /root.
 * Copy each addon into a permitted /data path, then load from there.
 * No-op on non-android platforms.
 */
"use strict";

const fs = require("fs");
const path = require("path");
const Module = require("module");

if (process.platform !== "android") {
  module.exports = {};
} else {
  const DEST =
    process.env.MATRIX_ANDROID_NATIVE_DIR || "/data/data/com.termux/files/usr/tmp/native";

  function ensureDest() {
    fs.mkdirSync(DEST, { recursive: true });
  }

  const orig = Module._extensions[".node"];
  Module._extensions[".node"] = function androidNodeAddon(module, filename) {
    try {
      ensureDest();
      const dest = path.join(DEST, path.basename(filename));
      const src = fs.statSync(filename);
      let copy = true;
      try {
        const dst = fs.statSync(dest);
        if (dst.size === src.size && dst.mtimeMs >= src.mtimeMs) copy = false;
      } catch {
        copy = true;
      }
      if (copy) fs.copyFileSync(filename, dest);
      return orig.call(this, module, dest);
    } catch {
      return orig.call(this, module, filename);
    }
  };

  module.exports = { DEST };
}
