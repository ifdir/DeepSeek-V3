"""Doppelsende-Sperre über die echten Routen /api/kernel/prepare (Wiederaufnahme) und /api/kernel/commit (closePending).
Antwortversuche werden über den kanonischen Schreiber repos.mark_pending_attempt gesetzt (wie /api/llm/formulate)."""
import json, sys, unittest, urllib.request
from contextlib import closing
from pathlib import Path
from unittest.mock import patch
ROOT = Path(__file__).resolve().parents[1]; LABEL = "P24"
sys.path.insert(0, str(ROOT)); sys.path.insert(0, str(ROOT / "tests"))
import test_v92_avatar_route as AV  # noqa: E402
from test_v92_puppet_vertrag import FakeProvider, plan  # noqa: E402
from matrix_api.db import connect  # noqa: E402
from matrix_api.repos import mark_pending_attempt  # noqa: E402
from matrix_api import app as appmod  # noqa: E402
TEXT = "Mara, wie geht es dir?"
def out(**k): print(json.dumps({"paket": LABEL, **k}, ensure_ascii=False))
class L(AV.AvatarRouteChain):
    def resume(self):
        s = self.session(); pid = s["pendingInputTurnId"]
        truth = {"userId": "admin", "operatorId": "admin", "worldId": s["worldId"], "sessionId": "ses_av", "role": "teilnehmer",
                 "speakerId": self.M["id"], "responseSpeakerId": self.M["id"], "avatarId": self.J["id"], "inputActorId": self.J["id"],
                 "speakAs": "avatar", "targetId": self.M["id"], "authority": "teilnehmer", "presentIds": s["scene"]["presentIds"],
                 "inputKind": "speech", "text": TEXT, "userName": self.J["name"]}
        with patch.object(urllib.request, "urlopen", FakeProvider([plan("smalltalk", "chat", [AV.rede(TEXT)])] * 2)):
            return self.client.post("/api/kernel/prepare", headers={"X-Matrix-Actor": "admin"}, json={
                "session": s, "actorUserId": "admin", "trace_id": "kpr_lock", "truth": truth, "resumePending": {"turnTruthId": pid},
                "speaker": {"id": self.M["id"], "name": self.M["name"]},
                "present": [{"id": self.J["id"], "name": self.J["name"]}, {"id": self.M["id"], "name": self.M["name"]}]})
    def close(self):
        s = self.session()
        return self.client.post("/api/kernel/commit", headers={"X-Matrix-Actor": "admin"}, json={
            "session": s, "actorUserId": "admin", "trace_id": "kc_close", "closePending": {"turnTruthId": s["pendingInputTurnId"]}})
    def mark(self, **att):
        s = self.session()
        with closing(connect(self.dbp)) as c:
            mark_pending_attempt(c, "admin", "ses_av", s["pendingInputTurnId"], att); c.commit()
    def runTest(self):
        r = self.prepare(FakeProvider([plan("smalltalk", "chat", [AV.rede(TEXT)])] * 2), TEXT)
        assert r.status_code == 200, r.get_data(as_text=True)[:200]
        n_tt = len(self.session()["turnTruths"])
        # T1 laufender Versuch DIESES Prozesses
        self.mark(state="laeuft", id="att1", boot=appmod.SERVER_BOOT_ID, lebensnachweis=appmod.BOOT_PROOF, since="t")
        r1 = self.resume()
        self.assertEqual((r1.status_code, (r1.get_json() or {}).get("code")), (409,"PENDING_RESPONSE_ATTEMPT_ACTIVE"))
        out(fall="T1_laeuft_eigener_prozess_wiederaufnahme", status=r1.status_code, code=(r1.get_json(silent=True) or {}).get("code"))
        # T2 derselbe Versuch beendet (formuliert, nicht gespeichert)
        self.mark(state="formuliert", id="att1", boot=appmod.SERVER_BOOT_ID, lebensnachweis=appmod.BOOT_PROOF, at="t")
        r2 = self.resume()
        self.assertEqual(r2.status_code,200,r2.get_data(as_text=True)[:300])
        self.assertEqual(len(self.session()["turnTruths"]),n_tt,"retry must not create a new input")
        out(fall="T2_formuliert_wiederaufnahme", status=r2.status_code, code=(r2.get_json(silent=True) or {}).get("code"),
            neue_turntruths=len(self.session()["turnTruths"]) - n_tt)
        # T3 ungeklärter Versuch eines anderen Prozesses ohne Lebensnachweis
        self.mark(state="laeuft", id="att2", boot="anderer_prozess", since="t")
        r3 = self.resume(); r4 = self.close()
        self.assertEqual(r3.status_code,200,r3.get_data(as_text=True)[:300])
        self.assertEqual((r4.status_code,(r4.get_json() or {}).get("code")),(409,"ATTEMPT_UNCLEAR"))
        self.assertEqual(len(self.session()["turnTruths"]),n_tt,"unclear retry must reuse old input")
        j3 = r3.get_json(silent=True) or {}; j4 = r4.get_json(silent=True) or {}
        out(fall="T3_unklar_wiederaufnahme", status=r3.status_code, code=j3.get("code"), meldung=(j3.get("message") or "")[:120])
        out(fall="T3_unklar_abschliessen", status=r4.status_code, code=j4.get("code"), meldung=(j4.get("message") or "")[:160])
result=unittest.TextTestRunner(verbosity=1).run(L())
raise SystemExit(0 if result.wasSuccessful() else 2)
