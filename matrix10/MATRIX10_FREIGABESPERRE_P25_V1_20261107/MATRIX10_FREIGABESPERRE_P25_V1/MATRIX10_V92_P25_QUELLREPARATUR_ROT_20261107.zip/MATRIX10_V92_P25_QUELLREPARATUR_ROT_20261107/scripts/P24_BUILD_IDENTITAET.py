#!/usr/bin/env python3
"""Do not modify VERSION.txt; verify the shipped legacy build identity in source."""
from pathlib import Path
import re
ROOT=Path(__file__).resolve().parents[1]
version=(ROOT/'VERSION.txt').read_text('utf-8')
m=re.search(r'^BUILD_ID=([^\r\n]+)$',version,re.M)
assert m,'Missing BUILD_ID in VERSION.txt'
value=m.group(1).strip()
types=(ROOT/'src/lib/matrix/types.ts').read_text('utf-8')
root_route=(ROOT/'src/routes/__root.tsx').read_text('utf-8')
assert value in types,(value,'types.ts does not match VERSION')
assert 'name: "matrix-build", content: BUILD_ID' in root_route,'Root route must emit BUILD_ID marker'
print('PASS VERSION.txt unveraendert zur P22-Basis, types.ts und Root-Metatag konsistent (kein Build):',value)
