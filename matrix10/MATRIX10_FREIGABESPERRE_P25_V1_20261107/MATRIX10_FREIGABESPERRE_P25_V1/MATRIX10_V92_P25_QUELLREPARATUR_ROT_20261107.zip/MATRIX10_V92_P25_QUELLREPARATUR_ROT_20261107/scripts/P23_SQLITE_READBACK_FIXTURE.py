#!/usr/bin/env python3
"""P23: persist actual kernel input+response states into a FRESH TEST SQLite DB,
read them on independent connections, and export a read-only UI verification
fixture. No user DB and no HTTP/Flask/provider claim.
"""
from __future__ import annotations
import json,sys,tempfile
from contextlib import closing
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
sys.path[:0]=[str(ROOT),str(ROOT/'tests')]
import test_v84_kausal_chain as K  # repo import shim, not Flask runtime
from matrix_api import kernel
from matrix_api.db import connect,init_schema
from matrix_api.repos import create_session,get_session,save_session
from matrix_api.seed_builtin import seed_if_missing

s,_,_=K.scene('Johann sagt Hallo Mara.')
J,M=K.JOHANN,K.MARA
T=kernel.bind_turn_truth(user_id='admin',world_id=s['worldId'],session_id=s['id'],role='teilnehmer',
    speaker_id=M['id'],avatar_id=J['id'],target_id=M['id'],authority='teilnehmer',
    present_ids=s['scene']['presentIds'],hears_ids=s['scene']['hearsIds'],
    input_kind='speech',text='Hallo Mara.',input_actor_id=J['id'])
prepared=kernel.commit_turn(s,truth=T,speaker=M,present=K.NATIVES,result={'speech':'','action':None},fired=[],phase='input')
assert T['id']==prepared['pendingInputTurnId']
with tempfile.TemporaryDirectory(prefix='p23_b_sqlite_') as temp:
    dbp=Path(temp)/'p23_b.sqlite'
    with closing(connect(dbp)) as c:
        init_schema(c);seed_if_missing(c)
        create_session(c,{'id':s['id'],'worldId':s['worldId'],'name':'P23 Rücklese-Gegenprobe',
                          'presentIds':s['scene']['presentIds']},'admin')
        save_session(c,'admin',prepared);c.commit()
    with closing(connect(dbp)) as c:
        before=get_session(c,'admin',s['id'])
    assert before['pendingInputTurnId']==T['id']
    assert [f for f in before['facts'] if f.get('sourceTurnId')==T['id'] and f.get('actorId')==J['id']]
    assert not [f for f in before['facts'] if f.get('sourceTurnId')==T['id'] and f.get('actorId')==M['id']]
    response=kernel.commit_turn(before,truth=T,speaker=M,present=K.NATIVES,result={'speech':'Guten Tag.','action':None},fired=[],phase='response')
    assert response['pendingInputTurnId'] is None
    with closing(connect(dbp)) as c:
        save_session(c,'admin',response);c.commit()
    with closing(connect(dbp)) as c:
        after=get_session(c,'admin',s['id'])
        assert c.execute('pragma quick_check').fetchone()[0]=='ok'
    assert after['pendingInputTurnId'] is None
    assert [f for f in after['facts'] if f.get('sourceTurnId')==T['id'] and f.get('actorId')==M['id'] and f.get('kind')=='speech' and f.get('validated')]
    result={'sourceTurnId':T['id'],'inputActorId':J['id'],'figureId':M['id'],
            'prepare_SQL':before,'commit_SQL':after}
    out=ROOT/'P23_PRUEFBELEGE'/'P23_SQLITE_B_READBACK.json'
    out.parent.mkdir(exist_ok=True)
    out.write_text(json.dumps(result,ensure_ascii=False,sort_keys=True,indent=2),encoding='utf-8')
    print(json.dumps({'sqlite_test':'PASS','input_facts':len([f for f in before['facts'] if f.get('sourceTurnId')==T['id']]),
                      'response_facts':len([f for f in after['facts'] if f.get('sourceTurnId')==T['id']]),
                      'sourceTurnId':T['id'],'output':str(out.relative_to(ROOT))},ensure_ascii=False))
