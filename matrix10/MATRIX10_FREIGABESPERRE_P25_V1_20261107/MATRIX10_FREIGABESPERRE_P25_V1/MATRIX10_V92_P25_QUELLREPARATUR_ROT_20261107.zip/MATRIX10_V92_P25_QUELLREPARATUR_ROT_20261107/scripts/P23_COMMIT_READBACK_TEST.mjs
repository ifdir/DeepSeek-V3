/** P23: executable affirmative and adversarial evidence for the browser's
 * post-timeout GET readback. Uses the same canonical structure as SQL Session.
 * Run: node --experimental-strip-types scripts/P23_COMMIT_READBACK_TEST.mjs
 * Does not claim to run the browser, HTTP route or provider.
 */
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import { responseReadbackStatus } from '../src/lib/matrix/response-readback.ts';
const sqlite = JSON.parse(readFileSync(new URL('../P23_PRUEFBELEGE/P23_SQLITE_B_READBACK.json', import.meta.url),'utf8'));

const SID = 'tt_test_source', M = 'char_mara', J = 'char_johann';
const input = {kind:'speech', actorId:J, sourceTurnId:SID, turn:1, validated:true, text:'Mara, wie geht es dir?'};
const reply = {kind:'speech', actorId:M, sourceTurnId:SID, turn:1, validated:true, text:'Gut, danke.'};
const row = {id:'ln_answer',role:'character',speakerId:M, turn:1, speech:'Gut, danke.'};
const truth = {id:SID, speaker_id:M, input_actor_id:J};
const before = () => ({
  pendingInputTurnId:SID, turnTruths:[truth], facts:[input],
  turns:[{id:'ln_input',role:'teilnehmer',speakerId:J,turn:1,speech:input.text}],
});
const after = () => ({...before(), pendingInputTurnId:null,facts:[input,reply],turns:[...before().turns,row]});
const cases = [
  ['Eingabe-Fact aus Prepare allein', before(), 'ungewiss'],
  ['Eingabe abgeschlossen aber ohne Figurenantwort', {...before(),pendingInputTurnId:null}, 'ungewiss'],
  ['fremder Fact trotz gleicher Zug-ID', {...after(),facts:[input,{...reply,actorId:'char_clara'}]}, 'ungewiss'],
  ['richtiger Akteur, falsche Zug-ID', {...after(),facts:[input,{...reply,sourceTurnId:'other'}]}, 'ungewiss'],
  ['Antwort-Fact ohne charakter-Zeile', {...after(),turns:before().turns}, 'ungewiss'],
  ['Charakter-Zeile ohne Fact', {...after(),facts:[input]}, 'ungewiss'],
  ['nicht validierter Fact', {...after(),facts:[input,{...reply,validated:false}]}, 'ungewiss'],
  ['abgelehnter Fact', {...after(),facts:[input,{...reply,rejectionReason:'capability'}]}, 'ungewiss'],
  ['anderer Turnindex', {...after(),turns:[...before().turns,{...row,turn:2}]}, 'ungewiss'],
  ['falscher Quell-Sprecher', {...after(),turnTruths:[{...truth,speaker_id:'char_clara'}]}, 'ungewiss'],
  ['fehlender TurnTruth', {...after(),turnTruths:[]}, 'ungewiss'],
  ['gekürzter GET ohne pendingInputTurnId', (({pendingInputTurnId,...s})=>s)(after()), 'ungewiss'],
  ['laufender Commit mit schon geschriebenem Reply-Fact', {...after(),pendingInputTurnId:SID}, 'ungewiss'],
  ['gültige Antwort (Speech)', after(), 'antwort_gespeichert'],
  ['gültige Antwort (Action)', {...after(),facts:[input,{...reply,kind:'action',text:'Mara winkt.'}], turns:[...before().turns,{...row,speech:'',action:'Mara winkt.'}]}, 'antwort_gespeichert'],
  ['gleichnamige falsche Figur trotz gleicher ID? ID muss abweichen', {...after(),facts:[input,{...reply,actorId:'other_mara'}]}, 'ungewiss'],
];
cases.push(['ECHTE SQLite-Rücklesung nach Prepare (Eingabe allein)',sqlite.prepare_SQL,'ungewiss']);
cases.push(['ECHTE SQLite-Rücklesung nach Figuren-Commit',sqlite.commit_SQL,'antwort_gespeichert']);
for(const [title,s,expected] of cases){
  assert.equal(responseReadbackStatus(s,title.startsWith('ECHTE')?sqlite.sourceTurnId:SID,title.startsWith('ECHTE')?sqlite.figureId:M),expected,title);
  console.log(`${expected==='antwort_gespeichert'?'PASS+':'PASS-'} ${title}`);
}
assert.equal(responseReadbackStatus(after(), SID,'char_clara'),'ungewiss','ID binding');
const route=readFileSync(new URL('../src/routes/chat.$sessionId.tsx',import.meta.url),'utf8');
assert.match(route,/responseReadbackStatus\(canonical, commitSourceTurnId, commitFigureId/);
assert.doesNotMatch(route,/facts\.some\(\s*\(?f\)?\s*=>\s*(?:String\()?f\.sourceTurnId\s*===\s*commitSourceTurnId/);
assert.match(route,/KERNEL_PREPARE_STATUS_UNGEWISS/);
assert.match(route,/setPendingView\(canonical\.pendingInput/);
assert.match(route,/natives\.find\(\(c: StammCharacter\) => c\.id === view\.speakerId\)/);
assert.match(route,/disabled=\{pendingView\.attemptRunning \|\| writeLocked\}/);
assert.match(route,/data-v65u="status-pruefen"/);
console.log(`TOTAL ${cases.length+1} + Route Guards PASS`);
