#!/usr/bin/env python3
"""P24 *real Flask route* contract test with independent SQLite readback.

Runs with an ephemeral DB and a deterministic provider (no user DB/API key).
NOT a real-model/browser test. Must fail on a false positive or partial commit.
"""
from __future__ import annotations
import io
import json
import os
import sys
import tempfile
import urllib.request
from contextlib import closing
from pathlib import Path
from unittest.mock import patch

ROOT = Path(__file__).resolve().parents[1]
sys.path[:0] = [str(ROOT), str(ROOT / 'tests')]
from matrix_api.db import connect, init_schema
from matrix_api.seed_builtin import seed_if_missing
from matrix_api.repos import create_session, get_session

class Response(io.BytesIO):
    def __enter__(self): return self
    def __exit__(self, *args): return False

def plan(comps):
    return {"event_kind": "request", "speech_act": "request", "durability": "utterance",
            "summary": "Probe", "subject": "Johann Bruckner", "predicate": "sprechen", "object": "",
            "temporal": {"text": None, "precision": "unknown"}, "refers_to": None,
            "cue_terms": [], "grenze": None, "verweis": None, "komponenten": comps}

def component(text, actor="Johann Bruckner", intro=None):
    return {"typ": "rede", "segment": text, "akteur": actor, "einleitung": intro,
            "ziel": None, "zeit": "jetzt", "wirkung": None, "bezug": None}

CASES = [
    {"id":"Gustav", "text":"Gustav, setz dich.", "parts":[component("setz dich.","Johann Bruckner","Gustav,")], "accept":True},
    {"id":"Herr_Pfeiffer", "text":"Herr Pfeiffer, setzen Sie sich.", "parts":[component("setzen Sie sich.","Johann Bruckner","Herr Pfeiffer,")], "accept":True},
    {"id":"Ja_Gustav", "text":"Ja, Gustav, setz dich.", "parts":[component("setz dich.","Gustav Pfeiffer","Ja, Gustav,")], "accept":True},
    {"id":"Teilablehnung", "text":"Mara, schön dich zu sehen. Gustav, setz dich.",
     "parts":[component("Mara, schön dich zu sehen.")], "accept":False, "code":"PUPPET_TEILABLEHNUNG"},
    {"id":"Mara_sagt", "text":"Mara sagt: Ich bin müde.",
     "parts":[component("Ich bin müde.","Mara Nowak","Mara sagt:")], "accept":False},
    {"id":"Gustav_sagt", "text":"Gustav sagt: Hallo.",
     "parts":[component("Hallo.","Gustav Pfeiffer","Gustav sagt:")], "accept":False},
]

# Returns a controlled semantic read, not just matching a class name.
def provider_for(test):
    def response(req, timeout=None):
        body = json.loads(req.data.decode('utf-8'))
        system = body['messages'][0]['content']
        user = json.loads(body['messages'][1]['content'])
        if 'Konjunktives Gedächtnis' in system:
            content = plan(test['parts'])
        elif 'Rede oder eigene Handlung einer gesteuerten Figur' in system:
            content = {"art":"rede", "beleg":user.get('segment') or "", "wirkung":None}
        elif 'Sprecher prüfen' in system:
            announcement = str(user.get('ansage') or '')
            if test['id'] in ('Mara_sagt','Gustav_sagt'):
                target = 'Mara Nowak' if test['id']=='Mara_sagt' else 'Gustav Pfeiffer'
                content = {"sprecher":target,"adressat":None,"beleg":None,
                           "ansageRolle":"sprecheransage","ansageBeleg":announcement}
            else:
                name = 'Herr Pfeiffer' if test['id']=='Herr_Pfeiffer' else 'Gustav'
                content = {"sprecher":"Johann Bruckner", "adressat":name,
                           "beleg":user.get('worte') or None, "ansageRolle":"anrede",
                           "ansageBeleg":name + ','}
        elif 'Namensumfang' in system:
            spans = []
            for candidate in user.get('kandidaten') or []:
                words = candidate.get('woerter') or []
                title = 'Herr Pfeiffer' in (candidate.get('wortfolge') or '')
                spans.append({"a":candidate['a'],"b":candidate['b'],"wortfolge":candidate['wortfolge'],
                              "wortklassen":(['titel','name'] if title else ['name'] * len(words)),
                              "status":"eindeutig","rolle":"anrede" if test['accept'] else 'nennung'})
            content = {"grenzen":spans}
        else:
            content = {}
        return Response(json.dumps({"choices":[{"message":{"content":json.dumps(content,ensure_ascii=False)},
                                                 "finish_reason":"stop"}]}).encode('utf-8'))
    return response


def main():
    with tempfile.TemporaryDirectory(prefix='p24_route_') as tmp:
        db = str(Path(tmp)/'fresh.sqlite')
        with patch.dict(os.environ, {"MATRIX_DB":db,"MATRIX_LIVE_LOG":str(Path(tmp)/'live.log')}):
            with closing(connect(db)) as conn:
                init_schema(conn)
                seed_if_missing(conn)
                conn.execute("INSERT OR IGNORE INTO users(id,json) VALUES('admin','{\"id\":\"admin\"}')")
                conn.execute("INSERT INTO config(scope,scope_id,json) VALUES(?,?,?)",
                    ('user','admin',json.dumps({'scope':'user','scope_id':'admin','provider':'openai',
                    'model':'t','apiKey':'sk-TESTONLY','endpoint':'http://127.0.0.1:9/v1/chat/completions'})))
                chars = {json.loads(r[1])['name']:json.loads(r[1]) for r in conn.execute('select id,json from characters')}
                johann = chars['Johann Bruckner']
                others = [next(v for k,v in chars.items() if needle in k) for needle in ('Mara','Gustav')]
                wid = conn.execute('select id from worlds limit 1').fetchone()[0]
                for case in CASES:
                    create_session(conn,{'id':'p24_'+case['id'],'worldId':wid,'name':'Probe',
                                         'presentIds':[johann['id'],*[(c['id']) for c in others]]},'admin')
                conn.commit()
            from matrix_api import app as appmod
            client=appmod.create_app(db).test_client()
            for case in CASES:
                sid='p24_'+case['id']
                with closing(connect(db)) as conn: before=get_session(conn,'admin',sid)
                with patch.object(urllib.request,'urlopen',provider_for(case)):
                    r=client.post('/api/kernel/puppet',headers={'X-Matrix-Actor':'admin'},json={
                        'session':before,'sessionId':sid,'actorUserId':'admin',
                        'figure':{'id':johann['id'],'name':johann['name']},'text':case['text']})
                body=r.get_json(silent=True) or {}
                with closing(connect(db)) as conn:
                    after=get_session(conn,'admin',sid)
                    assert conn.execute('PRAGMA quick_check').fetchone()[0]=='ok'
                fresh=[f for f in after.get('facts',[]) if f not in before.get('facts',[])]
                if case['accept']:
                    assert r.status_code==200, (case['id'],r.status_code,body)
                    own=[str(f.get('text') or '') for f in fresh if f.get('actorId')==johann['id'] and f.get('kind')=='speech']
                    assert case['text'] in own, (case['id'],'entire source must survive',own)
                    assert not [f for f in fresh if f.get('actorId')!=johann['id']], (case['id'],fresh)
                else:
                    assert r.status_code==422, (case['id'],r.status_code,body)
                    if case.get('code'):
                        assert body.get('code')==case['code'], (case['id'],body)
                    assert after.get('facts')==before.get('facts'), (case['id'],'SQLite facts changed')
                    assert after.get('turns')==before.get('turns'), (case['id'],'SQLite turns changed')
                    assert after.get('scene',{}).get('presentIds')==before.get('scene',{}).get('presentIds')
                print(json.dumps({'fall':case['id'],'status':r.status_code,'code':body.get('code'),
                                  'neue_facts':len(fresh),'pruefung':'PASS'},ensure_ascii=False))
    print('P24 ROUTE GEGENPROBEN: 6 PASS')

if __name__ == '__main__':
    main()
