#!/usr/bin/env python3
"""P24 source/contract review only. Never launch a product or touch a customer DB.
The mandatory exit code is 2 (RED) until full route+browser+model contract acceptance.
"""
from __future__ import annotations
import hashlib
import importlib.util
import os
import shutil
import subprocess
import sys
from pathlib import Path
ROOT=Path(__file__).resolve().parent
LOG=ROOT/'P24_PRUEFLOG_WINDOWS.txt'
LINES=[]
ENV=os.environ.copy()
ENV['PYTHONPATH']=os.pathsep.join([str(ROOT),str(ROOT/'tests'),ENV.get('PYTHONPATH','')])

def say(message):
    print(message,flush=True)
    LINES.append(message)

def source_hashes():
    return {str(p.relative_to(ROOT)):hashlib.sha256(p.read_bytes()).hexdigest()
            for pat in ('matrix_api/**/*.py','src/**/*.ts','src/**/*.tsx','tests/**/*.py')
            for p in ROOT.glob(pat) if p.is_file()}

def run(name,cmd,timeout=210):
    say('\n=== '+name+' ===')
    try:
        res=subprocess.run(cmd,cwd=ROOT,env=ENV,capture_output=True,text=True,errors='replace',timeout=timeout)
        output=((res.stdout or '')+'\n'+(res.stderr or '')).splitlines()
        say('\n'.join(output[-18:]) if output else '(keine Ausgabe)')
        say('EXIT='+str(res.returncode))
        return res.returncode
    except (OSError,subprocess.TimeoutExpired) as exc:
        say('NICHT PRUEFBAR: '+str(exc))
        return 3

say('MATRIX10 V92 P24 - PRUEFSTART (QUELLCODE, KEIN PRODUKTSTART)')
say('Original-DB wird nicht geoeffnet. Nur temporaere Test-DBs.')
say('Python '+sys.version.splitlines()[0])
before=source_hashes()
run('VERSION unveraendert und Build-Kennung stimmig',[sys.executable,str(ROOT/'scripts/P24_BUILD_IDENTITAET.py')])
run('P24 neue Binder-/Negativtests',[sys.executable,'-m','unittest','-q','test_v92_p24_kette'])
run('Ketten-Regressionen einschliesslich UNVERAENDERTEM alten P22-Test',
    [sys.executable,'-m','unittest','discover','-s','tests','-p','test_v92_p2*.py','-q'])
run('SQLite: Prepare- und Commit-Facts wirklich in getrennter SQL-Verbindung',
    [sys.executable,str(ROOT/'scripts/P23_SQLITE_READBACK_FIXTURE.py')])
node=shutil.which('node')
if node:
    run('P24 positive und negative Frontend-Ruecklesung + UI-Gate',
        [node,'--experimental-strip-types',str(ROOT/'scripts/P24_COMMIT_READBACK_AND_UI_GATE.mjs')])
    run('P22 Timeout/Abort-Gegenproben',[node,str(ROOT/'P22_TIMEOUT_ABBRUCH_GEGENPROBEN.cjs'),
        str(ROOT/'src/lib/matrix/api.ts')])
    run('TypeScript-Transpile nur Syntax (KEIN Frontend-Build)',
        [node,str(ROOT/'P22_TYPESCRIPT_SYNTAX.cjs'),str(ROOT)])
else:
    say('Node fehlt: JS-/TypeScript-Belege NICHT PRUEFBAR')
if importlib.util.find_spec('flask'):
    run('P24 ECHTE Puppet-Route, eigene SQLite und fakemodell',[sys.executable,
        str(ROOT/'scripts/P24_ROUTE_ANREDE_GEGENPROBEN.py')])
    run('P24 ECHTE Prepare-Route: liveness/unclear deadlock',[sys.executable,
        str(ROOT/'scripts/P24_ROUTE_ATTEMPT_GEGENPROBEN.py')])
else:
    say('Flask fehlt: Routen-/HTTP-Gegenproben NICHT PRUEFBAR. KEIN PASS.')
run('VOLLSTAENDIGE Python-Suite (Fehler duerfen NICHT kaschiert werden)',
    [sys.executable,'-m','unittest','discover','-s','tests','-q'])
say('QUELLCODE_WAEHREND_PRUEFUNG_UNVERAENDERT='+str(before==source_hashes()))
say('FLASK_INSTALLIERT='+str(importlib.util.find_spec('flask') is not None))
say('FRONTEND_DIST_VORHANDEN='+str((ROOT/'frontend_dist/index.html').is_file()))
say('BROWSER_LIVE_MIT_ECHTEM_PROVIDER_ABGENOMMEN=NEIN')
say('GESAMT: ROT. KEINE PRODUKTFREIGABE.')
LOG.write_text('\n'.join(LINES)+'\n',encoding='utf-8')
say('Ergebnisdatei: '+str(LOG))
raise SystemExit(2)
