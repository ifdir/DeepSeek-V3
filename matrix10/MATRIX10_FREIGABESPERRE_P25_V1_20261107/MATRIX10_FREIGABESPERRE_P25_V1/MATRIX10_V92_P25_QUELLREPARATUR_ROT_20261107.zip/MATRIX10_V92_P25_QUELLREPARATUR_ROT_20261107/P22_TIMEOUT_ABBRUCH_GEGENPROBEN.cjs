'use strict';
// Isolated test of the actual P22 boundedKernelJson source, not a rewritten
// approximation. No network, browser or user database required.
const fs=require('fs');
const vm=require('vm');
const assert=require('assert');
let ts;
try { ts=require('typescript'); } catch {
  try { const path=require('path'), cp=require('child_process');
        ts=require(path.join(cp.execFileSync('npm',['root','-g'],{encoding:'utf8'}).trim(),'typescript'));
  } catch { console.error('NICHT_PRUEFBAR: TypeScript-Compiler (npm) fehlt');process.exit(3); }
}
const p=process.argv[2];
if(!p) throw Error('usage: node file.cjs <P22/src/lib/matrix/api.ts>');
const source=fs.readFileSync(p,'utf8');
const sf=ts.createSourceFile(p,source,ts.ScriptTarget.Latest,true,ts.ScriptKind.TS);
const decl=sf.statements.find(n=>ts.isFunctionDeclaration(n)&&n.name?.text==='boundedKernelJson');
assert(decl, 'boundedKernelJson missing');
const body=decl.getText(sf);
const cjs=ts.transpileModule(body+'\nmodule.exports=boundedKernelJson;',{
  compilerOptions:{module:ts.ModuleKind.CommonJS,target:ts.ScriptTarget.ES2022}}).outputText;
async function check(){
 let calls=0;
 const box={
   module:{exports:null},AbortController,setTimeout,clearTimeout,Math,
   apiJson: async function (_p,init){calls++;return {ok:true,signalPresent:!!init.signal}},
 };
 vm.runInNewContext(cjs,box);
 const bounded=box.module.exports;
 let v=await bounded('/api/kernel/prepare',{method:'POST'},100,'KERNEL_PREPARE_STATUS_UNGEWISS');
 assert(v.ok&&v.signalPresent);assert.equal(calls,1);
 console.log('PASS | normal response and AbortController supplied');
 box.apiJson=async function (_p,init){return new Promise((resolve,reject)=>{
   init.signal.addEventListener('abort',()=>reject(Object.assign(new Error('aborted'),{name:'AbortError'})),{once:true});
 });};
 try {await bounded('/api/kernel/commit',{method:'POST'},20,'KERNEL_COMMIT_STATUS_UNGEWISS');throw Error('must timeout');}
 catch(e){assert.equal(e.code,'KERNEL_COMMIT_STATUS_UNGEWISS');assert.equal(e.statusUnknown,true);
   assert(e.message.includes('nicht ungeprüft'));}
 console.log('PASS | timed-out POST has unknown outcome, never reported as failure/rollback');
 box.apiJson=async()=>{throw Error('HTTP 422: identity clarification')};
 try {await bounded('/api/kernel/prepare',{method:'POST'},100,'KERNEL_PREPARE_STATUS_UNGEWISS');throw Error('must fail')}
 catch(e){assert(String(e.message).includes('422'));assert(!e.statusUnknown)}
 console.log('PASS | normal server rejection propagated, not replaced with timeout');
 // Real abort must escape JSON parsing, not be converted to {}.
 assert(source.includes('if (init?.signal?.aborted) throw error;'));
 console.log('PASS | aborted JSON body not swallowed');
 // Ensure no automatic mutating retry in the timeout recovery source.
 const page=fs.readFileSync(p.replace('src/lib/matrix/api.ts','src/routes/chat.$sessionId.tsx'),'utf8');
 assert(page.includes('KERNEL_COMMIT_STATUS_UNGEWISS')&&page.includes('apiGetSession(live.id, { timeoutMs: 12000 })'));
 assert(page.includes('commitSourceTurnId')&&page.includes('acceptKernelSession(canonical)'));
 console.log('PASS | UI checks canonical SQL and displays uncertainty (source-level only)');
}
check().catch(e=>{console.error(e);process.exitCode=2});
