#!/usr/bin/env python3
"""Matrix10 V92 Paket 19: eigene Gegenproben zum Koerpervertrag (unabhaengige Pruefung Paket 18, 06.11.2026).

Aufruf:  python MATRIX10_V92_PAKET19_KOERPER_GEGENPROBEN.py <frisch entpackter Projektroot>

Vertrag (AMASTER §43/§43.1, §46.1/§46.2, §24.2/§24.7; Pruefung P18 §6 Punkte 2-6):
- jede Koerperaenderung (Figur, Puppet, Avatar, God, Regie): getypte Lesung + woertlicher Beleg + je Feld eine zweite, unabhaengige
  Bestaetigungslesung an genau dieser Stelle (art "tatsaechlich", inhalt "gleich", eigener woertlicher Anker) -> EIN Writer
  (write_body_change -> apply_body_directive). Ein Zitat allein schreibt nichts. God/Regie nur fuer die gebundene Figur.
- Schlaf ist ein eigener Zustand (schlaeft). Unter Bewusstsein 0.5 keine Rede; einzige eigene Handlung: das bestaetigte Aufwachen aus
  dem Schlaf (nicht aus Bewusstlosigkeit); was sonst im Zug steht, bleibt gesperrt (Zustand zu Zugbeginn).
- Regie liest keine Woerter mehr (_regie_body_words entfernt).
Teil A  Pruefer-Skript P18 in Originalform (nur Zitat) und mit vollstaendigem Vertrag.
Teil S  Schlaf/Capability.   Teil G  God.   Teil Q  Regie.   Teil D  SQLite + BrainContext + Folgezug (Temp-DB).
Teil R  echte Routen (Puppet, Avatar/Figur, God, Regie) nur mit Flask, sonst NICHT_PRUEFBAR.
GRENZE = dokumentierte Grenze (beide unabhaengigen Lesungen falsch), keine Vertragsverletzung.
Kein Provider (kontrollierte Lesungen), keine Nutzerdatenbank. Exitcode 0 = keine Vertragsverletzung, 2 = Verletzung.
"""
import importlib.util
import sys
import tempfile
from contextlib import closing
from pathlib import Path
from unittest.mock import patch

if len(sys.argv) != 2:
    raise SystemExit("Aufruf: python MATRIX10_V92_PAKET19_KOERPER_GEGENPROBEN.py <projektroot>")
root = Path(sys.argv[1]).resolve()
HAS_FLASK = importlib.util.find_spec("flask") is not None
sys.path[:0] = [str(root), str(root / "tests")]
import test_v84_kausal_chain as K84  # noqa: E402  (Szene + Flask-Fallback nur fuer Kernel/SQLite)
from matrix_api import kernel  # noqa: E402
from matrix_api.db import connect, init_schema, GASTHAUS_ID  # noqa: E402
from matrix_api.seed_builtin import seed_if_missing  # noqa: E402
from matrix_api.repos import create_session, save_session, get_session  # noqa: E402

MARA, JOHANN, NATIVES = K84.MARA, K84.JOHANN, K84.NATIVES
res = {"PASS": 0, "CONTRACT_VIOLATION": 0, "GRENZE": 0, "NICHT_PRUEFBAR": 0}
NEW = hasattr(kernel, "body_change_candidate") and hasattr(kernel, "write_body_change")


def out(kind, label, detail=""):
    res[kind] += 1
    print(f"{kind} | {label} | {str(detail)[:380]}", flush=True)


def check(label, ok, detail=""):
    out("PASS" if ok else "CONTRACT_VIOLATION", label, detail)


def best(reading, text, *, art="tatsaechlich", inhalt="gleich", authority="character", fid=None):
    """The reading plus the confirmation readings the route attaches (one per field, at the quote the kernel derives)."""
    r = dict(reading)
    if fid is not None:
        r["figurId"] = str(fid)
    if not NEW:
        return r
    c = kernel.body_change_candidate(r, text, authority=authority)
    if c is None:
        return r
    ch, bl = c
    r["bestaetigung"] = {"stelle": bl, "felder": {k: {"wert": v, "art": art, "inhalt": inhalt, "beleg": bl} for k, v in ch.items()}}
    return r


def state(start=None):
    s, _, _ = K84.scene("Pruefung Paket 19")
    s["runtimes"][MARA["id"]].update(start or {"consciousness": 1.0, "canSpeak": True, "pain": 0.25, "canSee": True})
    s["runtimes"].setdefault(JOHANN["id"], {}).update({"pain": 0.0, "consciousness": 1.0, "canSpeak": True})
    return s


def commit(s, action, reading=None, speech="", proposals=None):
    t = kernel.bind_turn_truth(user_id="admin", world_id=s["worldId"], session_id=s["id"], role="teilnehmer", speaker_id=MARA["id"],
                               avatar_id=None, target_id=JOHANN["id"], authority="character", present_ids=s["scene"]["presentIds"],
                               hears_ids=s["scene"]["hearsIds"], input_kind="autochat", text="", input_actor_id=JOHANN["id"])
    n = len(s["facts"])
    o = kernel.commit_turn(s, truth=t, speaker=MARA, present=NATIVES, result={"speech": speech, "action": action},
                           proposals=proposals, koerper_lesung=reading)
    return o, [f for f in o["facts"][n:] if isinstance(f, dict)]


def god(text, reading, start=None):
    o = kernel.apply_god(state(start), text, "body", MARA["id"], natives=NATIVES, body_state=reading)
    return o, o["runtimes"][MARA["id"]]


def mrt(o):
    return o["runtimes"][MARA["id"]]


def kinds(ff, k):
    return [f for f in ff if f.get("kind") == k]


def grund(ff):
    return [((f.get("effect") or {}).get("koerperPruefung") or {}).get("grund") for f in kinds(ff, "action")]


SLEEP_TXT = "Mara schläft auf dem Stuhl ein."
SLEEP = {"haltung": "sitzend", "schlaf": "einschlafen", "zeit": "jetzt", "beleg": "schläft auf dem Stuhl ein"}
WAKE_TXT = "Mara wacht auf."
WAKE = {"schlaf": "aufwachen", "zeit": "jetzt", "beleg": "wacht auf"}


def asleep():
    o, _ = commit(state(), SLEEP_TXT, best(SLEEP, SLEEP_TXT))
    return o


if not NEW:
    check("A0_PAKET_HAT_DEN_P19_VERTRAG", False, "body_change_candidate/write_body_change fehlen")
    print(f"RESULT: {res['PASS']} passed; {res['CONTRACT_VIOLATION']} contract violations")
    raise SystemExit(2)

# ---------------- Teil A: Pruefer-Skript Paket 18 - Originalform (nur Zitat) und vollstaendiger Vertrag
o, ff = commit(state(), "Mara keucht vor Schmerzen.", None)
check("A1_P1_SCHMERZAUSDRUCK_AENDERT_NICHTS", mrt(o).get("pain") == 0.25 and not kinds(ff, "body_state"), mrt(o).get("pain"))
P2_TXT, P2 = "Mara setzt sich auf die Bank.", {"haltung": "sitzend", "zeit": "jetzt", "beleg": "setzt sich auf die Bank"}
o, ff = commit(state(), P2_TXT, P2)
check("A2_P2_NUR_ZITAT_SCHREIBT_NICHTS", mrt(o).get("posture") is None and grund(ff) == ["bestaetigung_fehlt"], (mrt(o).get("posture"), grund(ff)))
o, ff = commit(state(), P2_TXT, best(P2, P2_TXT))
check("A3_P2_VOLLSTAENDIG_LAGE_WIRKT", mrt(o).get("posture") == "sitzend" and len(kinds(ff, "body_state")) == 1, mrt(o).get("posture"))
P3_TXT = "Mara hat starke Schmerzen."
o, rt = god(P3_TXT, {"schmerz": "stark", "beleg": "starke Schmerzen"})
check("A4_P3_GOTT_NUR_ZITAT_SCHREIBT_NICHTS", rt.get("pain") == 0.25, rt.get("pain"))
o, rt = god(P3_TXT, best({"schmerz": "stark", "beleg": "starke Schmerzen"}, P3_TXT, authority="god", fid=MARA["id"]))
check("A5_P3_GOTT_VOLLSTAENDIG_SETZT", rt.get("pain") == 0.8, rt.get("pain"))
s = asleep()
check("A6_EINSCHLAFEN_VOLLSTAENDIG", (mrt(s).get("consciousness"), mrt(s).get("schlaeft"), mrt(s).get("canSpeak")) == (0.4, True, False),
      {k: mrt(s).get(k) for k in ("consciousness", "schlaeft", "canSpeak", "posture")})
o, ff = commit(s, WAKE_TXT, best(WAKE, WAKE_TXT))
check("A7_N1_AUFWACHEN_DURCH_FIGUR", mrt(o).get("consciousness") == 1.0 and kinds(ff, "body_state"), {"consciousness": mrt(o).get("consciousness")})
o, ff = commit(s, None, None, "Hallo, ich bin noch im Schlaf.")
check("A8_N2_NORMALE_REDE_IM_SCHLAF_GESPERRT", not [f for f in kinds(ff, "speech") if f.get("validated")], [f["text"] for f in kinds(ff, "speech")])
for name, txt, reading, key, bad in (("N3", "Mara schläft nicht ein.", {"schlaf": "einschlafen", "zeit": "jetzt", "beleg": "schläft nicht ein"}, "consciousness", 0.4),
                                     ("N4", "Mara steht nicht auf.", {"haltung": "stehend", "zeit": "jetzt", "beleg": "steht nicht auf"}, "posture", "stehend")):
    o, ff = commit(state(), txt, reading)
    check(f"A9_{name}_FALSCHE_LESUNG_NUR_ZITAT", mrt(o).get(key) != bad and not kinds(ff, "body_state"), grund(ff))
    o, ff = commit(state(), txt, best(reading, txt, art="verneint"))
    check(f"A9_{name}_FALSCHE_LESUNG_ZWEITE_LESUNG_VERNEINT", mrt(o).get(key) != bad and grund(ff) == ["bestaetigung_verneint"], grund(ff))
    o, ff = commit(state(), txt, best(reading, txt, art="tatsaechlich"))
    out("GRENZE" if mrt(o).get(key) == bad else "PASS", f"A9_{name}_BEIDE_LESUNGEN_FALSCH",
        "beide unabhaengigen Lesungen falsch -> geschrieben (ohne Wortliste nicht abfangbar; gemessene Haeufigkeit im Bericht)")
o, rt = god("Mara ist nicht verletzt.", {"schmerz": "stark", "figurId": MARA["id"]})
check("A10_N5_GOTT_OHNE_BELEG", rt.get("pain") == 0.25 and [f for f in o["facts"] if f.get("kind") == "god"][-1]["payload"]["koerperPruefung"]["grund"] == "beleg_fehlt",
      rt.get("pain"))
N6_TXT = "Mara hat keine Schmerzen."
o, rt = god(N6_TXT, {"schmerz": "stark", "beleg": "keine Schmerzen"})
check("A11_N6_GOTT_NEGATION_NUR_ZITAT", rt.get("pain") == 0.25, rt.get("pain"))
o, rt = god(N6_TXT, best({"schmerz": "stark", "beleg": "keine Schmerzen"}, N6_TXT, art="verneint", authority="god", fid=MARA["id"]))
check("A12_N6_GOTT_NEGATION_ZWEITE_LESUNG", rt.get("pain") == 0.25, rt.get("pain"))
_orig = kernel.apply_body_directive
with patch.object(kernel, "apply_body_directive", side_effect=_orig) as spy:
    o, rt = god(P3_TXT, best({"schmerz": "stark", "beleg": "starke Schmerzen"}, P3_TXT, authority="god", fid=MARA["id"]))
check("A13_N7_GOTT_SCHREIBT_UEBER_DEN_EINEN_WRITER", spy.call_count == 1 and rt.get("pain") == 0.8, {"calls": spy.call_count, "pain": rt.get("pain")})
with patch.object(kernel, "apply_body_directive", side_effect=RuntimeError("Writer gesperrt")) as spy:
    o, rt = god(P3_TXT, best({"schmerz": "stark", "beleg": "starke Schmerzen"}, P3_TXT, authority="god", fid=MARA["id"]))
gf = [f for f in o["facts"] if f.get("kind") == "god"][-1]
check("A14_N7_WRITER_GESPERRT_KEIN_ZWEITER_WEG", spy.call_count == 1 and rt.get("pain") == 0.25 and not [f for f in o["facts"] if f.get("kind") == "body_state"]
      and "RuntimeError" in str(gf["payload"].get("koerperFehler")), {"calls": spy.call_count, "pain": rt.get("pain"), "fehler": gf["payload"].get("koerperFehler")})
check("A15_KEIN_DIREKTER_KOERPERSCHREIBER_IN_APPLY_GOD", "cur.update(" not in Path(kernel.__file__).read_text(encoding="utf-8")
      and not hasattr(kernel, "god_body_values"), "")

# ---------------- Teil S: Schlaf / Capability
s = asleep()
for name, txt, reading in (("S1_IM_SCHLAF_AUFSTEHEN_GESPERRT", "Mara steht auf.", {"haltung": "stehend", "zeit": "jetzt", "beleg": "steht auf"}),
                           ("S2_AUFWACHEN_UND_SCHLAG_GESPERRT", "Mara wacht auf und schlägt Johann.", WAKE)):
    o, ff = commit(s, txt, best(reading, txt), proposals={"wirkung": {"art": "gewalt", "ziel": JOHANN["name"]}})
    check(name, mrt(o).get("consciousness") == 0.4 and o["runtimes"][JOHANN["id"]].get("pain") == 0.0,
          {"cons": mrt(o).get("consciousness"), "johann_pain": o["runtimes"][JOHANN["id"]].get("pain")})
o, ff = commit(state({"consciousness": 0.2, "canSpeak": False, "pain": 0.25}), WAKE_TXT, best(WAKE, WAKE_TXT))
check("S3_BEWUSSTLOS_WECKT_SICH_NICHT_SELBST", mrt(o).get("consciousness") == 0.2, mrt(o).get("consciousness"))
o, ff = commit(state({"consciousness": 0.2, "canSpeak": True, "pain": 0.25}), None, None, "Ich rede trotzdem.")
check("S4_BEWUSSTLOS_ALTSTAND_CANSPEAK_TRUE_KEINE_REDE", not kinds(ff, "speech"), [f.get("text") for f in kinds(ff, "speech")])
acts = [{"text": "Mara wacht auf", "targetId": None, "effectKind": None, "effectValid": False, "koerperPruefung": best(WAKE, "Mara wacht auf")},
        {"text": "Mara schlägt Johann", "targetId": JOHANN["id"], "effectKind": "strike", "effectValid": True}]
o = kernel.commit_puppet(s, MARA, "Was ist los?", actions=acts, target_id=JOHANN["id"])
new = o["facts"][len(s["facts"]):]
check("S5_PUPPET_ZUSTAND_ZU_ZUGBEGINN", [(f["text"], f.get("validated")) for f in kinds(new, "action")] == [("Mara wacht auf", True), ("Mara schlägt Johann", False)]
      and not kinds(new, "speech") and o["runtimes"][JOHANN["id"]].get("pain") == 0.0 and mrt(o).get("consciousness") == 1.0,
      [(f["text"], f.get("validated"), f.get("rejection_reason")) for f in kinds(new, "action")])
o = kernel.apply_regie(s, {}, f'{MARA["name"].split()[0]}, sage: "Ich bin wach."', actor_id=MARA["id"], present=NATIVES)
new = o["facts"][len(s["facts"]):]
check("S6_REGIE_REDEANORDNUNG_IM_SCHLAF_KEINE_REDE", not kinds(new, "speech"), [f.get("text") for f in kinds(new, "speech")])
t = kernel.bind_turn_truth(user_id="admin", world_id=s["worldId"], session_id=s["id"], role="teilnehmer", speaker_id=MARA["id"], avatar_id=None,
                           target_id=JOHANN["id"], authority="character", present_ids=s["scene"]["presentIds"], hears_ids=s["scene"]["hearsIds"],
                           input_kind="autochat", text="", input_actor_id=JOHANN["id"])
sp = kernel.bind_formulation_spiegel(s, t, speaker=MARA, present=NATIVES)
from matrix_api import llm_contract  # noqa: E402
brief = llm_contract.render_persona_brief(sp, "Wach auf!", JOHANN["name"], "")
check("S7_BRAINCONTEXT_SAGT_SCHLAF_NUR_AUFWACHEN", sp["body"]["canDo"] == ["aufwachen"] and sp["body"]["canSpeak"] is False and "du schläfst" in brief,
      {"canDo": sp["body"]["canDo"], "canSpeak": sp["body"]["canSpeak"]})
o, ff = commit(s, WAKE_TXT, best(WAKE, WAKE_TXT))
o2, ff2 = commit(o, None, None, "Guten Morgen.")
check("S8_FOLGEZUG_NACH_AUFWACHEN_SPRICHT", [f["text"] for f in kinds(ff2, "speech")] == ["Guten Morgen."], [f["text"] for f in kinds(ff2, "speech")])
check("S9_KEINE_PAUSCHALE_FREIGABE_UNTER_05", kernel.act_capability({"consciousness": 0.4, "schlaeft": True}, "Mara geht zur Tür.", None, None)[0] == "capability"
      and kernel.act_capability({"consciousness": 0.4}, "Mara wacht auf.", {"schlaf": "aufwachen"}, {"beleg": "wacht auf"})[0] == "capability", "")

# ---------------- Teil G: God - Beleg Pflicht, gebundene Figur, Inventar
o, rt = god(P3_TXT, best({"schmerz": "stark", "beleg": "starke Schmerzen"}, P3_TXT, authority="god", fid=JOHANN["id"]))
check("G1_GOTT_LESUNG_FUER_ANDERE_FIGUR", rt.get("pain") == 0.25, rt.get("pain"))
for name, txt, reading, expect, start in (
        ("G2_SCHMERZ_KEIN", "Mara hat keine Schmerzen mehr.", {"schmerz": "kein", "beleg": "keine Schmerzen mehr"}, {"pain": 0.0}, None),
        ("G3_BEWUSSTLOS", "Mara ist bewusstlos.", {"bewusstsein": "bewusstlos", "beleg": "ist bewusstlos"}, {"consciousness": 0.2, "canSpeak": False, "posture": "liegend"}, None),
        ("G4_GEFESSELT", "Mara ist gefesselt.", {"gefesselt": True, "beleg": "ist gefesselt"}, {"restrained": True, "mobility": 0.2}, None),
        ("G5_GEKNEBELT", "Mara ist geknebelt.", {"geknebelt": True, "beleg": "ist geknebelt"}, {"gagged": True, "canSpeak": False}, None),
        ("G6_HEILUNG", "Maras Verletzungen heilen.", {"heilung": True, "beleg": "Verletzungen heilen"}, {"injuries": [], "pain": 0.0},
         {"pain": 0.7, "consciousness": 1.0, "injuries": [{"part": "Arm (links)", "kind": "gebrochen", "since": 1, "cause": "f"}]}),
        ("G7_WIEDER_WACH_SPRICHT", "Mara ist wieder wach.", {"bewusstsein": "wach", "beleg": "ist wieder wach"}, {"consciousness": 1.0, "canSpeak": True},
         {"consciousness": 0.2, "canSpeak": False, "pain": 0.25})):
    o, rt = god(txt, best(reading, txt, authority="god", fid=MARA["id"]), start=start)
    body = [f for f in o["facts"] if f.get("kind") == "body_state"]
    check(name, {k: rt.get(k) for k in expect} == expect and len(body) == 1 and body[0]["witnessedBy"] == [MARA["id"]],
          {k: rt.get(k) for k in expect})

# ---------------- Teil Q: Regie - Wortlesung entfernt, derselbe Vertrag, gebundener Akteur


def regie(text, reading=None, akteur=None, start=None):
    seg = text.rstrip(".")
    comp = {"typ": "handlung", "akteur": akteur or MARA["name"], "ziel": None, "segment": seg, "beschreibung": seg, "wirkung": "ohne_koerperwirkung"}
    if reading is not None:
        comp["koerperPruefung"] = reading
    o = kernel.apply_regie(state(start), {}, text, actor_id=MARA["id"], present=NATIVES, components={"komponenten": [comp], "unklar": []})
    return o, mrt(o), [f for f in o["facts"] if f.get("kind") == "body_state"]


check("Q0_REGIE_WORTLESUNG_ENTFERNT", not hasattr(kernel, "_regie_body_words") and not [n for n in dir(kernel) if n.startswith("_BODY_") and n.endswith("_RE")], "")
for txt, wrong, art in (("Mara wird nicht bewusstlos.", {"bewusstsein": "bewusstlos", "beleg": "wird nicht bewusstlos"}, "verneint"),
                        ("Mara ist nicht blind.", {"sehen": "verliert", "beleg": "ist nicht blind"}, "verneint"),
                        ("Mara keucht vor Schmerzen.", {"schmerz": "mittel", "beleg": "keucht vor Schmerzen"}, "ausdruck")):
    tag = txt[5:28].strip().replace(" ", "_")
    for variant, reading in (("OHNE_LESUNG", None), ("NUR_ZITAT", {**wrong, "figurId": MARA["id"]}),
                             ("ZWEITE_LESUNG", best(wrong, txt.rstrip("."), art=art, authority="regie", fid=MARA["id"]))):
        o, rt, body = regie(txt, reading)
        check(f"Q1_{tag}_{variant}", (rt.get("consciousness"), rt.get("canSee"), rt.get("pain")) == (1.0, True, 0.25) and not body,
              {k: rt.get(k) for k in ("consciousness", "canSee", "pain")})
for name, txt, reading, expect, start in (
        ("Q2_REGIE_SETZT_SICH", "Mara setzt sich auf die Bank.", {"haltung": "sitzend", "beleg": "setzt sich auf die Bank"}, {"posture": "sitzend"}, None),
        ("Q3_REGIE_OHNMACHT", "Mara wird ohnmächtig.", {"bewusstsein": "bewusstlos", "beleg": "wird ohnmächtig"}, {"consciousness": 0.2, "canSpeak": False}, None),
        ("Q4_REGIE_VERLETZUNG", "Mara bricht sich den rechten Arm.", {"verletzung": {"art": "gebrochen", "glied": "Arm", "seite": "rechts", "schwer": True},
                                                                       "beleg": "bricht sich den rechten Arm"}, {"pain": 0.7}, None),
        ("Q5_REGIE_WECKT_AUS_OHNMACHT", "Mara kommt wieder zu sich.", {"bewusstsein": "wach", "beleg": "kommt wieder zu sich"}, {"consciousness": 1.0, "canSpeak": True},
         {"consciousness": 0.2, "canSpeak": False, "posture": "liegend"})):
    o, rt, body = regie(txt, best(reading, txt.rstrip("."), authority="regie", fid=MARA["id"]), start=start)
    check(name, {k: rt.get(k) for k in expect} == expect and len(body) == 1, {k: rt.get(k) for k in expect})
o, rt, body = regie("Mara setzt sich.", best({"haltung": "sitzend", "beleg": "setzt sich"}, "Mara setzt sich", authority="regie", fid=JOHANN["id"]))
check("Q6_REGIE_LESUNG_FUER_ANDERE_FIGUR", rt.get("posture") is None and not body, rt.get("posture"))
o, rt, body = regie("Johann setzt sich.", best({"haltung": "sitzend", "beleg": "setzt sich"}, "Johann setzt sich", authority="regie", fid=MARA["id"]), akteur=JOHANN["name"])
check("Q7_REGIE_ANDERER_AKTEUR", o["runtimes"][JOHANN["id"]].get("posture") is None and rt.get("posture") is None and not body, "")

comp = {"typ": "handlung", "akteur": MARA["name"], "ziel": None, "segment": "Mara wird ohnmächtig", "beschreibung": "Mara wird ohnmächtig", "wirkung": None,
        "koerperPruefung": best({"bewusstsein": "bewusstlos", "beleg": "wird ohnmächtig"}, "Mara wird ohnmächtig", authority="regie", fid=MARA["id"])}
o = kernel.apply_regie(state(), {}, "Mara wird ohnmächtig.", actor_id=MARA["id"], present=NATIVES, components={"komponenten": [comp], "unklar": []})
check("Q8_REGIE_EIGENER_OUTCOME_OHNE_WIRKUNGSKLASSE", mrt(o).get("consciousness") == 0.2 and [f.get("validated") for f in kinds(o["facts"], "action")] == [True],
      mrt(o).get("consciousness"))
comp.pop("koerperPruefung")
o = kernel.apply_regie(state(), {}, "Mara wird ohnmächtig.", actor_id=MARA["id"], present=NATIVES, components={"komponenten": [comp], "unklar": []})
check("Q9_REGIE_OHNE_LESUNG_BLEIBT_WIRKUNG_UNKLAR", mrt(o).get("consciousness") == 1.0
      and [f.get("rejection_reason") for f in kinds(o["facts"], "action")] == ["wirkung_unklar"], mrt(o).get("consciousness"))

# ---------------- Teil D: SQLite (Temp-DB), neue Verbindung, BrainContext, Folgezug
s = asleep()
with tempfile.TemporaryDirectory(prefix="matrix10_p19_") as tmp:
    dbfile = Path(tmp) / "nur_pruefung.sqlite"
    with closing(connect(dbfile)) as c:
        init_schema(c)
        seed_if_missing(c)
        c.commit()
        create_session(c, {"id": s["id"], "worldId": GASTHAUS_ID, "name": "Nur Pruefung", "presentIds": [MARA["id"], JOHANN["id"]]}, "admin")
        save_session(c, "admin", s)
        c.commit()
    with closing(connect(dbfile)) as c:
        read = get_session(c, "admin", s["id"])
        quick = c.execute("PRAGMA quick_check").fetchone()[0]
    rr = (read.get("runtimes") or {}).get(MARA["id"]) or {}
    brt = kernel.brain_context(read, MARA["id"]).get("runtime") or {}
    check("D1_SQLITE_SCHLAF_UND_BODYFACT", quick == "ok" and (rr.get("schlaeft"), rr.get("consciousness"), rr.get("canSpeak")) == (True, 0.4, False)
          and [f for f in read.get("facts") or [] if f.get("kind") == "body_state"], {k: rr.get(k) for k in ("schlaeft", "consciousness", "canSpeak")})
    check("D2_BRAINCONTEXT_LIEST_SCHLAF", (brt.get("schlaeft"), brt.get("consciousness")) == (True, 0.4), {k: brt.get(k) for k in ("schlaeft", "consciousness")})
    o, ff = commit(read, WAKE_TXT, best(WAKE, WAKE_TXT))
    o2, ff2 = commit(o, None, None, "Ich bin wieder da.")
    check("D3_FOLGEZUG_AUS_SQLITE", mrt(o).get("consciousness") == 1.0 and [f["text"] for f in kinds(ff2, "speech")] == ["Ich bin wieder da."], "")

# ---------------- Teil R: echte Routen
ROUTE = ["R1_PUPPET_BESTAETIGUNG_VERNEINT_UND_AUFWACHEN", "R2_GOD_ROUTE_KOERPER", "R3_REGIE_ROUTE_KOERPER", "R4_PUPPET_LAGE_SQLITE_NEUSTART",
         "R5_AVATAR_UND_FIGUR_HTTP", "R6_AVATAR_SCHLAEFT_REDE_UND_HANDLUNG_422_AUFWACHEN_200"]
if not HAS_FLASK:
    for n in ROUTE:
        out("NICHT_PRUEFBAR", n, "Flask fehlt in dieser Umgebung - HTTP-Kette nicht ausfuehrbar")
else:
    def _teil_r():
        import unittest
        import test_v92_p19_koerper as T19
        import test_v92_p18_koerper as T18
        plan_ = [("R1_PUPPET_BESTAETIGUNG_VERNEINT_UND_AUFWACHEN", T19.P19Routes("test_puppet_confirmation_decides_and_a_sleeping_puppet_wakes")),
                 ("R2_GOD_ROUTE_KOERPER", T19.P19Routes("test_god_route_body_scope")),
                 ("R3_REGIE_ROUTE_KOERPER", T19.P19Routes("test_regie_route_reads_and_confirms_each_ordered_act")),
                 ("R4_PUPPET_LAGE_SQLITE_NEUSTART", T18.P18PuppetRoute("test_position_only_from_the_server_reading_over_http_sqlite_restart")),
                 ("R5_AVATAR_UND_FIGUR_HTTP", T18.P18AvatarAndFigure("test_avatar_position_and_figure_reply_with_forged_and_real_readings")),
                 ("R6_AVATAR_SCHLAEFT_REDE_UND_HANDLUNG_422_AUFWACHEN_200", T19.P19AvatarSleep("test_sleeping_avatar"))]
        for name, case in plan_:
            r = unittest.TestResult()
            case.run(r)
            bad = [str(e)[-300:] for _t, e in r.failures + r.errors]
            check(name, not bad and r.testsRun == 1, bad)
    try:
        _teil_r()
    except Exception as exc:
        check("R_KETTE_ABGEBROCHEN", False, f"{type(exc).__name__}: {exc}")

print(f"RESULT: {res['PASS']} passed; {res['CONTRACT_VIOLATION']} contract violations; {res['GRENZE']} Grenze (beide Lesungen falsch); "
      f"{res['NICHT_PRUEFBAR']} nicht pruefbar (Flask: {'ja' if HAS_FLASK else 'nein'})")
raise SystemExit(2 if res["CONTRACT_VIOLATION"] else 0)
