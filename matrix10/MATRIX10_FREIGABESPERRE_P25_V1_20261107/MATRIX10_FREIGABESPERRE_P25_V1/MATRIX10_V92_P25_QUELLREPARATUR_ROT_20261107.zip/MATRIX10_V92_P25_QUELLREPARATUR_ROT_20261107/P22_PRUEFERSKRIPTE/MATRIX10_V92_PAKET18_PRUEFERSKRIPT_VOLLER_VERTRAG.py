#!/usr/bin/env python3
"""Matrix10 V92 Paket 18: unabhaengige Koerper/Capability/Gott-Gegenproben.
ABGELEITETE FASSUNG (Paket 19, Entwickler): Pruefbedingungen, Texte, Lesungen und check()-Aufrufe sind unveraendert. Einzige
Aenderung: jede Lesung traegt zusaetzlich die zweite, unabhaengige Bestaetigungslesung, die Punkt 3 der Pruefung verlangt
(`voll(...)`). Bei korrekten Lesungen antwortet sie "tatsaechlich/gleich"; bei den absichtlich FALSCHEN Lesungen N3/N4/N6 so, wie eine
korrekte zweite Lesung antworten wuerde ("verneint"). God-Lesungen tragen die gebundene Figur (figurId). Das Original liegt daneben.
Aufruf: python MATRIX10_V92_PAKET18_UNABHAENGIGE_GEGENPROBEN.py <frisch entpackter Projektroot>
Keine Netzabfragen, keine Nutzer-DB, keine Aenderung des Produktcodes. Exit 2 bei Vertragsverletzungen.
Synthetische Lesungen sind kontrollierte FEHLANTWORTEN des Modells; sie zeigen fehlende
serverseitige Sperren, nicht die Haeufigkeit realer Modellfehler.
"""
import sys
from pathlib import Path
from unittest.mock import patch

if len(sys.argv) != 2:
    raise SystemExit('Aufruf: python MATRIX10_V92_PAKET18_UNABHAENGIGE_GEGENPROBEN.py <projektroot>')
root=Path(sys.argv[1]).resolve()
sys.path[:0]=[str(root),str(root/'tests')]
from matrix_api import kernel
from test_v84_kausal_chain import scene, MARA, JOHANN, NATIVES

results=[]
def voll(reading, text, art='tatsaechlich', god=False):
    """the reading plus the second, independent confirmation reading per field (Paket-19 contract)"""
    if reading is None:
        return None
    r=dict(reading)
    if god:
        r['figurId']=MARA['id']
    c=kernel.body_change_candidate(r, text, authority='god' if god else 'character')
    if c is None:
        return r
    ch,bl=c
    r['bestaetigung']={'stelle':bl,'felder':{k:{'wert':v,'art':art,'inhalt':'gleich','beleg':bl} for k,v in ch.items()}}
    return r
def check(name,ok,actual,kind='check'):
    ok=bool(ok)
    results.append((name,ok))
    print(('PASS' if ok else 'CONTRACT_VIOLATION')+' | '+name+' | '+str(actual)[:350],flush=True)

def original():
    s,_,_=scene('Pruefung eigene Lage')
    s['runtimes'][MARA['id']].update({'consciousness':1.0,'canSpeak':True,'pain':0.25})
    return s

def commit(s,action,reading=None,speech=''):
    t=kernel.bind_turn_truth(user_id='admin',world_id=s['worldId'],session_id=s['id'],role='teilnehmer',speaker_id=MARA['id'],avatar_id=None,
        target_id=JOHANN['id'],authority='character',present_ids=s['scene']['presentIds'],hears_ids=s['scene']['hearsIds'],
        input_kind='autochat',text='',input_actor_id=JOHANN['id'])
    n=len(s['facts'])
    out=kernel.commit_turn(s,truth=t,speaker=MARA,present=NATIVES,result={'speech':speech,'action':action},koerper_lesung=voll(reading,action or '',art=ART.get(action,'tatsaechlich')))
    return out,[f for f in out['facts'][n:] if isinstance(f,dict)]

ART={'Mara schläft nicht ein.':'verneint','Mara steht nicht auf.':'verneint','Mara hat keine Schmerzen.':'verneint'}
def god(text,reading):
    s=original();out=kernel.apply_god(s,text,'body',MARA['id'],natives=NATIVES,body_state=voll(reading,text,art=ART.get(text,'tatsaechlich'),god=True))
    return out,out['runtimes'][MARA['id']]

# Positive controls for the shipped repair
s=original();out,facts=commit(s,'Mara keucht vor Schmerzen.',None)
rt=out['runtimes'][MARA['id']]
check('P1_SCHMERZAUSDRUCK_AENDERT_NICHTS',rt.get('pain')==0.25 and not any(f['kind']=='body_state' for f in facts),(rt.get('pain'),[f['kind'] for f in facts]))
s=original();out,facts=commit(s,'Mara setzt sich auf die Bank.',{'haltung':'sitzend','zeit':'jetzt','beleg':'setzt sich auf die Bank'})
check('P2_GETYPTE_LAGE_WIRKT',out['runtimes'][MARA['id']].get('posture')=='sitzend' and any(f['kind']=='body_state' for f in facts),out['runtimes'][MARA['id']].get('posture'))
out,rt=god('Mara hat starke Schmerzen.',{'schmerz':'stark','beleg':'starke Schmerzen'})
check('P3_GOTT_TYPISCHER_BELEG_WIRKT',rt.get('pain')==0.8,rt.get('pain'))

# A: the new sleep/wake ability is impossible over the normal figure-commit
s=original()
s,facts=commit(s,'Mara schläft auf dem Stuhl ein.',{'haltung':'sitzend','schlaf':'einschlafen','zeit':'jetzt','beleg':'schläft auf dem Stuhl ein'})
assert s['runtimes'][MARA['id']]['consciousness']==0.4, 'prerequisite sleep not set'
woke,ff=commit(s,'Mara wacht auf.',{'schlaf':'aufwachen','zeit':'jetzt','beleg':'wacht auf'})
rt=woke['runtimes'][MARA['id']]
check('N1_AUFWECKEN_DURCH_FIGUR',rt.get('consciousness')==1.0 and any(f['kind']=='body_state' for f in ff),{'consciousness':rt.get('consciousness'),'newFacts':[(f['kind'],f.get('validated')) for f in ff]})
# same sleeping state incorrectly permits ordinary speech
spoke,ff=commit(s,None,None,'Hallo, ich bin noch im Schlaf.')
check('N2_NORMALE_REDE_IM_SCHLAF_GESPERRT',not [f for f in ff if f['kind']=='speech' and f.get('validated')],{'consciousness':s['runtimes'][MARA['id']].get('consciousness'),'speechFacts':[(f['kind'],f['text']) for f in ff if f['kind']=='speech']})

# B: model reading with LITERAL evidence, but semantically contradictory (negative occurrence)
for name,action,reading,key,forbidden in (
    ('N3_NEGIERTE_EINSCHLAFLESUNG','Mara schläft nicht ein.',{'schlaf':'einschlafen','zeit':'jetzt','beleg':'schläft nicht ein'},'consciousness',0.4),
    ('N4_NEGIERTE_AUFSTEHLESUNG','Mara steht nicht auf.',{'haltung':'stehend','zeit':'jetzt','beleg':'steht nicht auf'},'posture','stehend'),
):
    s=original();out,facts=commit(s,action,reading)
    rt=out['runtimes'][MARA['id']]
    check(name,rt.get(key)!=forbidden and not any(f['kind']=='body_state' for f in facts),{'state':rt.get(key),'audits':[(f.get('effect') or {}).get('koerperPruefung') for f in facts if f['kind']=='action']})

# C: God has two validation gaps and writes directly rather than through the claimed ONE writer
out,rt=god('Mara ist nicht verletzt.',{'schmerz':'stark'})
check('N5_GOTT_OHNE_WOERTLICHEN_BELEG_UNBELEGT',rt.get('pain')==0.25,{'pain':rt.get('pain'),'godFacts':[(f['kind'],f.get('validated')) for f in out['facts'] if f['kind'] in ('god','body_state')]})
out,rt=god('Mara hat keine Schmerzen.',{'schmerz':'stark','beleg':'keine Schmerzen'})
check('N6_GOTT_NEGATION_ALS_STARKER_SCHMERZ',rt.get('pain')==0.25,{'pain':rt.get('pain'),'proposed':'schmerz stark with quote keine Schmerzen'})
# if the canonical writer is disabled, a fully separate body write is impossible under the one-writer contract
with patch.object(kernel,'apply_body_directive',side_effect=RuntimeError('Body writer unexpectedly invoked')) as spy:
    out,rt=god('Mara hat starke Schmerzen.',{'schmerz':'stark','beleg':'starke Schmerzen'})
    used=spy.call_count
check('N7_GOTT_UMGEHT_DEN_BENANNTEN_KOERPER_WRITER',used>0 or rt.get('pain')==0.25,{'writerCalls':used,'painWithoutWriter':rt.get('pain')})

print('RESULT: %d PASS, %d CONTRACT_VIOLATION, %d conditions'%(sum(ok for _,ok in results),sum(not ok for _,ok in results),len(results)))
raise SystemExit(2 if any(not ok for _,ok in results) else 0)
