#!/usr/bin/env python3
"""P23 stand-alone source-check launcher; no real world/user DB modified.
Every live/product gate remains ROT until externally verified.
"""
from __future__ import annotations
import hashlib,importlib.util,os,shutil,subprocess,sys
from pathlib import Path
ROOT=Path(__file__).resolve().parent
LOG=ROOT/'P23_PRUEFLOG_WINDOWS.txt'
LINES=[]
def say(s):
    print(s,flush=True);LINES.append(s)
def run(title,cmd,timeout=180):
    say('\n=== '+title+' ===')
    try:
        r=subprocess.run(cmd,cwd=ROOT,capture_output=True,text=True,errors='replace',timeout=timeout,env=ENV)
        output=(r.stdout or '')+'\n'+(r.stderr or '')
        lines=output.strip().splitlines()
        say('\n'.join(lines[-16:]) if lines else '(keine Ausgabe)')
        say('EXIT='+str(r.returncode))
        return r.returncode
    except (OSError,subprocess.TimeoutExpired) as exc:
        say('NICHT PRUEFBAR: '+str(exc))
        return 3
ENV=os.environ.copy()
ENV['PYTHONPATH']=os.pathsep.join([str(ROOT),str(ROOT/'tests'),ENV.get('PYTHONPATH','')])
say('MATRIX10 V92 P23 QUELLPRUEFUNG (ROT; KEIN PRODUKTSTART)')
say('Python: '+sys.version.splitlines()[0])
say('P23 Produktions-Start NICHT ausfuehren: kein neu gebautes frontend_dist.')
say('WARNUNG: Nur eigene tmp SQLite-Datenbanken, keine Nutzerdaten.')
source=lambda:{str(p.relative_to(ROOT)):hashlib.sha256(p.read_bytes()).hexdigest() for pat in ('matrix_api/**/*.py','src/**/*.ts','src/**/*.tsx') for p in ROOT.glob(pat) if p.is_file()}
before=source()
run('P20/P21/P22/P23 Regressionen',[sys.executable,'-m','unittest','discover','-s','tests','-p','test_v92_p2*.py','-q'])
run('P23 frische SQLite-Daten und zwei Phasen',[sys.executable,str(ROOT/'scripts/P23_SQLITE_READBACK_FIXTURE.py')])
node=shutil.which('node')
if node:
    run('P23 echtes SQLite-GET -> Frontend-Bedingung, Negativ und Positiv',
        [node,'--experimental-strip-types',str(ROOT/'scripts/P23_COMMIT_READBACK_TEST.mjs')])
    run('P22 HTTP-Timeout Abort Isolation',[node,str(ROOT/'P22_TIMEOUT_ABBRUCH_GEGENPROBEN.cjs'),str(ROOT/'src/lib/matrix/api.ts')])
    run('TS Syntax Quellpruefung (KEIN Browserbuild)',[node,str(ROOT/'P22_TYPESCRIPT_SYNTAX.cjs'),str(ROOT)])
else:say('NODE FEHLT: JS-Ketten-Pruefung NICHT BESTANDEN / NICHT PRUEFBAR')
run('Vollstaendige vorhandene Offline-Suite',[sys.executable,'-m','unittest','discover','-s','tests','-q'])
say('QUELLCODE_UNVERAENDERT='+str(before==source()))
say('FRONTEND_DIST_NEU_GEBAUT='+str((ROOT/'frontend_dist/index.html').exists()))
say('FLASK_IN_DIESEM_PYTHON='+str(importlib.util.find_spec('flask') is not None))
say('GESAMTSTATUS: ROT. Keine Browser-/HTTP-/Provider-/vollstaendige AMASTER-Abnahme.')
LOG.write_text('\n'.join(LINES)+'\n',encoding='utf-8')
say('PRUEFLOG: '+str(LOG))
raise SystemExit(2)
