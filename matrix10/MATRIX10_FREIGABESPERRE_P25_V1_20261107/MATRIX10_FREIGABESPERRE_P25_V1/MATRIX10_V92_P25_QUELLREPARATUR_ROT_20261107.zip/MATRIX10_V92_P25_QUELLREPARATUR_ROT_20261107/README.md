# Matrix10 V92 – P25-Quellarbeitskopie (ROT)

**Keine Produktversion, keine Startfreigabe.** P25 ist die eindeutige Nummer
für dieses neue *Quellen*-Paket, während `VERSION.txt` bewusst bytegleich mit
P22/P24 bleibt (`MATRIX10_CHATHERE_V91_KETTENREPARATUR_20261103`).

## Unter Windows prüfen

Archiv in einen **neuen leeren Ordner** entpacken. Ein Doppelklick auf
`P25_PRUEFSTART_WINDOWS.bat` führt die überprüfbaren Quellen- und Vertragstests aus.
Das CMD-Fenster bleibt geöffnet und schreibt `P25_PRUEFLOG_WINDOWS.txt`.
Der Prüfstart endet absichtlich mit **Exitcode 2 / ROT**: Er ist kein
Produktstart. `START.bat` für ein vollständig abgenommenes Produkt wird nicht
als vorhanden ausgegeben.

## Reparierte Naht R1–R3 gegenüber P24

- **R1:** Im gemeinsamen Binder zählt ein unmittelbares, in der Originaleingabe
  eindeutig an die *geführte Figur-ID* gebundenes Subjekt zur gleichen
  Handlungslesung, auch wenn der Planer es aus `segment` ausgelassen hat.
  Keine Wortstamm- oder unbelegte Namensgleichheit. Eine unabhängige, vollständige
  Nicht-Vollzug-Lesung bleibt als Hinweis; sie darf eine separat gelesene Rede
  nicht unterdrücken. Ohne vollständige Lesung bleibt die Ablehnung aktiv.
- **R2:** Zwei unterschiedliche, unabhängig nachgewiesene Adressaten in einer
  Rede-Commit-Gruppe dürfen nicht mehr still auf den ersten `targetId` fallen.
  Da der jetzige Writer nur einen Adressaten pro Rede-Fact kann, wird der
  **gesamte Puppet-Turn sichtbar mit 422** abgelehnt. Kein stiller Teilcommit.
  Auch der gemeinsame Avatar-Binder gibt bei nachgewiesenem Konflikt keinen
  falsch adressierten Rede-Fact als vollzogene Rede zurück. Eine spätere
  architekturgerechte Aufteilung braucht eigene Facts/Targets je Komponente.
- **R3:** Die genau auf Abnahmesätze zugeschnittenen Beispiele sind aus der
  Sprecheranweisung entfernt; die allgemeine Rollenunterscheidung bleibt.

## Prüfgrenzen

Es gibt zusätzliche **ausführbare** Tests und eine kanonische
SQLite-Writer-Rücklesung über eine andere Verbindung. Die Prüfung der
R2-Fehlzuordnung über die **echte Flask-Route** ist als separates Script
`P25_ROUTE_R2_EMPFAENGER_GEGENPROBEN.py` enthalten.

Hier fehlen Flask, vollständige npm-Abhängigkeiten und ein echtes Modell.
**Routentests, Frontend-Build, Live-Browser und vollständige Abnahme sind daher
nicht erfolgt.** Die alte P22-Quelltextassertion und andere Altfehler bleiben
unverändert. Vergleiche `P25_PRUEFBERICHT.md` und das Diff zum Original-P24.

**Originaldatenbank unverändert.** Keine Produktfreigabe bei ROT.
