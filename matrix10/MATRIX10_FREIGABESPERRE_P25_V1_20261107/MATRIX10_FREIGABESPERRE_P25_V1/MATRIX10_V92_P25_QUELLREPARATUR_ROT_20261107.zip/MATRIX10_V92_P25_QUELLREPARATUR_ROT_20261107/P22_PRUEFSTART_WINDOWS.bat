@echo off
setlocal
cd /d "%~dp0"
echo MATRIX10 P22 - Quellpruefung, KEIN PRODUKTSTART
where py >nul 2>nul
if not errorlevel 1 (
  py -3 P22_PRUEFSTART.py
) else (
  python P22_PRUEFSTART.py
)
echo.
echo Die Gesamtfreigabe ist ROT. Prueflog: P22_PRUEFLOG_WINDOWS.txt
pause
endlocal
