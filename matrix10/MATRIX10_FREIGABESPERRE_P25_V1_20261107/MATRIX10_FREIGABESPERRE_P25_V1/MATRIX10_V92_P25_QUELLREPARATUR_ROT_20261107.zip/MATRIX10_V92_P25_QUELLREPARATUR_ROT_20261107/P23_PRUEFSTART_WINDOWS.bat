@echo off
setlocal
cd /d "%~dp0"
echo MATRIX10 V92 P23 - QUELLENPRUEFUNG, KEIN PRODUKTSTART
echo Keine Benutzer-Datenbank wird fuer diese Pruefung verwendet.
where py >nul 2>nul
if not errorlevel 1 (
    py -3 P23_PRUEFSTART.py
) else (
    python P23_PRUEFSTART.py
)
echo.
echo GESAMT ROT bis zur vollstaendigen Vertragsabnahme.
echo Ergebnisdatei: P23_PRUEFLOG_WINDOWS.txt
pause
endlocal
