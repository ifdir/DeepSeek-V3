const fs=require('fs');
let ts;
try { ts=require('typescript'); } catch {
  try { const path=require('path'), cp=require('child_process');
        ts=require(path.join(cp.execFileSync('npm',['root','-g'],{encoding:'utf8'}).trim(),'typescript'));
  } catch { console.error('NICHT_PRUEFBAR: TypeScript-Compiler (npm) fehlt');process.exit(3); }
}
const path=require('path');
const root=process.argv[2] || __dirname;
let failed=false;
for(const rel of ['src/lib/matrix/api.ts','src/lib/matrix/kernel-bridge.ts','src/routes/chat.$sessionId.tsx']){
 const p=path.join(root,rel),s=fs.readFileSync(p,'utf8');
 const x=ts.transpileModule(s,{fileName:p,reportDiagnostics:true,compilerOptions:{jsx:ts.JsxEmit.ReactJSX,target:ts.ScriptTarget.ES2022,module:ts.ModuleKind.ESNext}});
 const err=x.diagnostics.filter(d=>d.category===ts.DiagnosticCategory.Error);
 console.log(`${rel}: ${err.length?err.map(d=>ts.flattenDiagnosticMessageText(d.messageText,' ')).join('; '):'TRANSPILE_OK'}`);if(err.length)failed=true;
}
process.exit(failed?2:0);
