"""V85 source-to-seed + SQLite + reader regression. Never touches a user DB."""
import hashlib
import json
import os
from pathlib import Path
import tempfile
from contextlib import closing
import unittest
from test_v84_kausal_chain import scene, proposed, proofs
from matrix_api.db import connect, init_schema, GASTHAUS_ID
from matrix_api.seed_builtin import seed_if_missing
from matrix_api.repos import get_session, create_session, save_session
from matrix_api import kernel

ROOT = Path(__file__).resolve().parents[1]

class SeedAndPersistence(unittest.TestCase):
    def test_authored_source_and_backend_seed_are_identical_version(self):
        data=json.loads((ROOT/'matrix_api/gasthaus_seed.json').read_text(encoding='utf-8'))
        for relative, expected in data['sourceHashes'].items():
            self.assertEqual(hashlib.sha256((ROOT/relative).read_bytes()).hexdigest(),expected)
        self.assertEqual(len(data['characters']), 5)
        for c in data['characters']:
            self.assertTrue(c['personality'], c['name'])
            self.assertGreaterEqual(len(c['compass']),5,c['name'])
            self.assertTrue(c['goals'],c['name'])
        self.assertEqual(data['world']['id'],GASTHAUS_ID)

    def test_first_run_loads_full_gasthaus_profile_and_does_not_clobber_edits(self):
        with tempfile.TemporaryDirectory() as tmp:
            path=Path(tmp)/'new.sqlite'
            old=os.environ.pop('MATRIX_SKIP_SEED',None)
            try:
                with closing(connect(path)) as db:
                    init_schema(db)
                    seed_if_missing(db)  # temp DB test fixture; independent of test runner
                    db.commit()
                    r=db.execute("select json from characters where id='char_g7_mara'").fetchone()
                    self.assertIsNotNone(r)
                    char=json.loads(r[0]); self.assertEqual(char['personality'], 'Loyal wo sicher, trotzig unter Druck, körperlich-direkt.')
                    self.assertIn('Angst',char['compass'])
                    self.assertIn('Lust',char['compass'])
                    self.assertTrue(char['relations'])
                    self.assertEqual(char['ownerUserId'],'admin')
                    world=json.loads(db.execute('select json from worlds where id=?',(GASTHAUS_ID,)).fetchone()[0])
                    self.assertGreaterEqual(len(world['places']),5)
                    char['personality']='Vom Nutzer bewusst bearbeitet'
                    db.execute("UPDATE characters SET json=? WHERE id='char_g7_mara'",(json.dumps(char),))
                    db.commit()
                    seed_if_missing(db)
                    db.commit()
                    self.assertEqual(json.loads(db.execute("select json from characters where id='char_g7_mara'").fetchone()[0])['personality'],char['personality'])
                    self.assertEqual(db.execute('PRAGMA quick_check').fetchone()[0],'ok')
            finally:
                if old is not None:os.environ['MATRIX_SKIP_SEED']=old

    def test_incomplete_then_valid_review_roundtrips_db_and_reader_isolates_sessions(self):
        s,p,e=scene('Danke fuer deine Hilfe')
        row=proposed(state=0,trust=.1,closeness=.1,feeling='')
        row['_kausalpruefung']=proofs(row,e,fields=['beziehung.0.trust'])
        old=os.environ.pop('MATRIX_SKIP_SEED',None)
        try:
            with tempfile.TemporaryDirectory() as tmp:
                path=Path(tmp)/'state.sqlite'
                with closing(connect(path)) as db:
                    init_schema(db)
                    seed_if_missing(db)  # temp DB test fixture; independent of test runner
                    full=[json.loads(db.execute('select json from characters where id=?',(id,)).fetchone()[0])
                          for id in ('char_g7_mara','char_g7_johann')]
                    create_session(db,{'id':s['id'],'worldId':s['worldId'],'name':'V85-Test','presentIds':s['scene']['presentIds']},'admin')
                    create_session(db,{'id':'unrelated','worldId':s['worldId'],'name':'Isolation','presentIds':s['scene']['presentIds']},'admin')
                    save_session(db,'admin',s)
                    db.commit()
                    other_initial=get_session(db,'admin','unrelated')
                with closing(connect(path)) as db:
                    saved=get_session(db,'admin',s['id'])
                    pending=kernel.pending_appraisals(saved,full)
                    self.assertEqual(len(pending),1)
                    self.assertEqual(len(pending[0]['events']),1)
                    partial,diagnostics=kernel.apply_appraisals(saved,pending,{'bewertungen':[row]},natives=full)
                    self.assertNotIn(e['id'],partial['runtimes']['char_g7_mara'].get('appraisedFactIds',[]))
                    p_rel=next(r for r in partial['relations'] if r['fromId']=='char_g7_mara' and r['toId']=='char_g7_johann')
                    self.assertAlmostEqual(p_rel['trust'],.46)
                    self.assertAlmostEqual(p_rel['closeness'],.2)
                    save_session(db,'admin',partial)
                    db.commit()
                with closing(connect(path)) as db:
                    saved=get_session(db,'admin',s['id'])
                    pending=kernel.pending_appraisals(saved,full)
                    self.assertEqual(len(pending),1)
                    row2=proposed(state=0,trust=.1,closeness=.1,feeling='')
                    row2['_kausalpruefung']=proofs(row2,e)
                    repaired,diag=kernel.apply_appraisals(saved,pending,{'bewertungen':[row2]},natives=full)
                    save_session(db,'admin',repaired)
                    db.commit()
                with closing(connect(path)) as db:
                    persisted=get_session(db,'admin',s['id'])
                    other=get_session(db,'admin','unrelated')
                    rel=next(r for r in persisted['relations'] if r['fromId']=='char_g7_mara' and r['toId']=='char_g7_johann')
                    self.assertAlmostEqual(rel['trust'],.46)
                    self.assertAlmostEqual(rel['closeness'],.28)
                    self.assertIn(e['id'],persisted['runtimes']['char_g7_mara']['appraisedFactIds'])
                    self.assertEqual(kernel.pending_appraisals(persisted,full),[])
                    brain=kernel.brain_context(persisted,'char_g7_mara')
                    self.assertEqual(brain['runtime']['characterId'],'char_g7_mara')
                    self.assertIn(e['id'],brain['runtime']['appraisedFactIds'])
                    witness_rel=next(r for r in brain['relations'] if r['fromId']=='char_g7_mara' and r['toId']=='char_g7_johann')
                    self.assertAlmostEqual(witness_rel['trust'],.46)
                    self.assertAlmostEqual(witness_rel['closeness'],.28)
                    unrelated_brain=kernel.brain_context(other,'char_g7_mara')
                    self.assertFalse([r for r in unrelated_brain['relations'] if r.get('trust')==.46 and r.get('closeness')==.28])
                    self.assertEqual(other.get('relations'),other_initial.get('relations'))
                    self.assertEqual(other.get('facts'),other_initial.get('facts'))
                    self.assertEqual(db.execute('PRAGMA quick_check').fetchone()[0],'ok')
        finally:
            if old is not None:os.environ['MATRIX_SKIP_SEED']=old

if __name__=='__main__':unittest.main()
