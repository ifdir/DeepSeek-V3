"""V82: the specific fixed overlay must be absent; storage remains in UI."""
from __future__ import annotations
import json
import re
from pathlib import Path
import unittest

ROOT = Path(__file__).resolve().parents[1]
FRONTEND = ROOT/'frontend_dist'
BUILD_ID='MATRIX10_CHATHERE_V91_KETTENREPARATUR_20261103'

class V85OverlayRegression(unittest.TestCase):
    def test_floating_button_not_in_served_frontend_html(self):
        html = (FRONTEND/'index.html').read_text(encoding='utf-8')
        self.assertNotIn('matrix10-storage-check',html)
        self.assertNotIn('Sessions löschen / Speicher',html)
        self.assertNotIn('position:fixed;right:12px;bottom:12px;z-index:1001',html)
        self.assertIn('content="'+BUILD_ID+'"',html)

    def test_storage_link_still_in_normal_navigation_and_working_page(self):
        src = (ROOT/'src'/'components'/'shell.tsx').read_text(encoding='utf-8')
        shell_files=sorted((FRONTEND/'assets').glob('shell-*.js')); self.assertEqual(len(shell_files),1,shell_files)
        compiled=shell_files[0].read_text(encoding='utf-8')
        self.assertIn('href="/__matrix_speicher"',src)
        self.assertIn('Löschen / Speicher',src)
        self.assertIn('href:`/__matrix_speicher`',compiled)
        self.assertIn('Löschen / Speicher',compiled)
        self.assertNotIn('matrix10-storage-check',compiled)
        self.assertTrue((ROOT/'matrix_speicher_v91.html').exists())

    def test_new_assets_exist_and_are_referenced(self):
        html=(FRONTEND/'index.html').read_text(encoding='utf-8')
        self.assertIn('content="'+BUILD_ID+'"',html)
        self.assertNotIn('index-V81-ProjektDatenbank.js',html)
        refs=set(re.findall(r'/assets/([A-Za-z0-9._-]+\.(?:js|css))',html))
        self.assertTrue(any(r.startswith('index-') for r in refs),refs)
        for r in refs: self.assertTrue((FRONTEND/'assets'/r).exists(),r)
        for f in (FRONTEND/'assets').glob('*.js'):
            text=f.read_text(encoding='utf-8')
            self.assertNotIn('-V81.js',text,f.name)
            self.assertNotIn('-V85.js',text,f.name)
        manifest=json.loads((FRONTEND/'.build-info.json').read_text(encoding='utf-8'))
        self.assertEqual(manifest['buildId'],BUILD_ID)
        self.assertIs(manifest['frontendCompiledAnew'],True)

    def test_no_database_in_software_release(self):
        self.assertFalse(list(ROOT.rglob('*.sqlite')))
        self.assertFalse(list(ROOT.rglob('*.sqlite-wal')))
        self.assertFalse(list(ROOT.rglob('*.sqlite-shm')))

if __name__=='__main__':
    unittest.main()
