"""V92 Paket 14 (Paket-13-Pruefung 05.11.2026): eine verkuerzte Modelllesung oder eine nur teilweise Rede-Einleitung darf einen
ausdruecklich laengeren fremden Namen nie ueberschreiben; die vier Fachentscheidungen.

Verbindliche Bedingung: die Validierungsgrenze beruecksichtigt die GESAMTE relevante Zeichenfolge (Name im Text in voller
Laenge, ganzer ansagender Satzteil) und den eindeutig belegten Sprecher/Taeter/Ziel; bei ungeklaertem Umfang fail-closed statt
eines falschen kanonischen Facts. Kein zweiter Owner, keine Wortliste.
Entscheidungen: (1) "sagt zu X" bindet den Rede-Adressaten nur bei eindeutig gepruefter Identitaet; unbekannt -> keiner, nie die
UI-Auswahl. (2) Anwesende nur bei unmittelbarer Szenen-Interaktion bevorzugt, volle Namen behalten Vorrang. (3) die validierte
Einleitung ist kein Redetext. (4) "Spreche als" wird ueber den Session-Owner gespeichert und gelesen (Frontend: chat.$sessionId.tsx).
"""
import copy
import json
import unittest
import urllib.request
from contextlib import closing
from unittest.mock import patch

import test_v84_kausal_chain  # noqa: F401  (offline Flask shim wie die übrigen Tests)
from matrix_api import kernel
from matrix_api.db import connect
from matrix_api.repos import create_session, get_session
import test_v92_negativgrenzen as _NG
import test_v92_puppet_vertrag as _PV
import test_v92_avatar_route as _AV
from test_v92_negativgrenzen import hc, rc, JA
from test_v92_puppet_vertrag import FakeProvider, plan, comp
from test_v92_avatar_route import act, rede


def pain(s, fid):
    return float(((s.get("runtimes") or {}).get(fid) or {}).get("pain") or 0)


def reading(ziel=None, taeter="figur"):
    return {**JA, "taeter": taeter, **({"ziel": ziel} if ziel is not None else {})}


def speech(seg, einl=None, akteur="Johann Bruckner", sprecher=None, adressat=None):
    c = rc(seg, akteur=akteur, einleitung=einl)
    if sprecher is not None or adressat is not None:
        c["sprecherPruefung"] = {"sprecher": sprecher or "figur", "beleg": None, "adressat": adressat}
    return c


class P14Binder(unittest.TestCase):
    setUp = _NG.Negativgrenzen.setUp
    bind = _NG.Negativgrenzen.bind
    commit = _NG.Negativgrenzen.commit
    grunds = _NG.Negativgrenzen.grunds

    def _schmidt(self, present=True):
        s = copy.deepcopy(self.M); s["id"] = "char_test_mara_schmidt"; s["name"] = "Mara Schmidt"; s["aliases"] = []
        self.chars = self.chars + [s]
        if present:
            self.present = self.present + [s["id"]]
        return s

    def _nothing_for_mara(self, r, key):
        s = self.commit(r)
        self.assertFalse([f for f in s.get("facts", []) if f.get("targetId") == self.M["id"] and f.get("kind") in ("action", "physical")], key)
        self.assertEqual(pain(s, self.M["id"]), 0.0, key)
        return s

    # ---- Bedingung: verkuerzte Ziel-Zweitlesung (Paket-13-Pruefung N1) ----
    def test_shortened_target_reading_never_binds_the_present_first_name(self):
        for taeter in ("figur", "Johann", "Johann Bruckner"):
            for ziel in ("Mara Nowak", "Mara", None):
                r = self.bind("Johann schubst Mara Schmidt.", [hc("Johann schubst Mara Schmidt", wirkung="gewalt", pruefung=reading("Mara", taeter), ziel=ziel)])
                self._nothing_for_mara(r, (taeter, ziel))
                self.assertTrue(set(self.grunds(r)) & {"ziel_name_unklar", "akteur_name_unklar"}, (taeter, ziel, self.grunds(r)))
        # the opening "Johann" is the doer: the act stays (no target), visibly unclear
        r = self.bind("Johann schubst Mara Schmidt.", [hc("Johann schubst Mara Schmidt", wirkung="gewalt", pruefung=reading("Mara", "Johann"), ziel="Mara Nowak")])
        self.assertEqual([(a["targetId"], a["effectValid"]) for a in r["actions"]], [(None, False)]); self.assertIn("ziel_name_unklar", self.grunds(r))

    def test_full_name_of_the_cast_always_wins_over_a_shorter_reading(self):
        self._schmidt()
        r = self.bind("Johann schubst Mara Schmidt.", [hc("Johann schubst Mara Schmidt", wirkung="gewalt", pruefung=reading("Mara"), ziel="Mara Nowak")])
        # the planner claims Nowak, the text names Mara Schmidt in full: never Nowak (the claim contradicts the text)
        self.assertNotIn(self.M["id"], [a["targetId"] for a in r["actions"]])
        r = self.bind("Johann schubst Mara Schmidt.", [hc("Johann schubst Mara Schmidt", wirkung="gewalt", pruefung=reading("Mara"), ziel="Mara Schmidt")])
        self.assertEqual([a["targetId"] for a in r["actions"]], ["char_test_mara_schmidt"])

    # ---- Taeter: unbekannter/verkuerzter Name im eigenen Wortlaut ----
    def test_unknown_doer_is_never_the_puppets_act(self):
        for taeter, ziel in (("figur", None), ("Johann", None), ("figur", "Johann Weber"), ("Johann Bruckner", None)):
            r = self.bind("Johann Weber winkt.", [hc("Johann Weber winkt", wirkung="ohne_koerperwirkung", pruefung=reading(ziel, taeter), ziel=None)])
            self.assertEqual(r["actions"], [], (taeter, ziel)); self.assertIn("akteur_name_unklar", self.grunds(r))
        r = self.bind("Mara Schmidt schubst Johann.", [hc("Mara Schmidt schubst Johann", wirkung="gewalt", pruefung=reading("Johann"), ziel="Johann Bruckner")])
        self.assertEqual(r["actions"], [])

    def test_shortened_act_segment_never_hides_the_named_doer(self):
        # the planner leaves the subject out of the segment (live 05.11.: "reicht Mara Wasser.", "schubst Mara Schmidt."); the clause
        # is read as a whole - a foreign or unknown subject right before the segment is never the puppet's act
        for raw, seg, taeter in (("Johann Weber winkt.", "winkt", "Johann"), ("Johann Weber winkt.", "winkt", "figur"),
                                 ("Johann Weber schubst Mara.", "schubst Mara", "Johann"), ("Mara Schmidt schubst Johann.", "schubst Johann", "figur")):
            r = self.bind(raw, [hc(seg, wirkung="gewalt", pruefung=reading(None, taeter), ziel="Mara Nowak")])
            self.assertEqual(r["actions"], [], (raw, taeter)); self.assertIn("akteur_name_unklar", self.grunds(r))
            self._nothing_for_mara(r, raw)
        r = self.bind("Mara schubst Johann.", [hc("schubst Johann", wirkung="gewalt", pruefung=reading("Johann", "figur"), ziel="Johann Bruckner")])
        self.assertEqual(r["actions"], []); self.assertIn("akteur_ist_nicht_der_sprecher", self.grunds(r))
        # the figure itself as the (left out) subject: the act stays
        r = self.bind("Johann küsst Mara.", [hc("küsst Mara", wirkung="zaertlich", pruefung=reading("Mara", "Johann"), ziel="Mara Nowak")])
        self.assertEqual([a["targetId"] for a in r["actions"]], [self.M["id"]])
        r = self.bind("Johann reicht Mara Wasser.", [hc("reicht Mara Wasser", wirkung="ohne_koerperwirkung", pruefung=reading("Mara", "Johann"), ziel="Mara Nowak")])
        self.assertEqual([a["targetId"] for a in r["actions"]], [None]); self.assertIn("ziel_name_unklar", self.grunds(r))
        # a vocative is no subject
        r = self._avatar_bind("Mara, ich küsse dich.", [hc("Mara, ich küsse dich", akteur="ich", wirkung="zaertlich", pruefung=reading(None, "ich"), ziel=None)])
        self.assertEqual([a["targetId"] for a in r["actions"]], [self.M["id"]])

    # ---- Bedingung: verkuerzte Rede-Einleitung (Paket-13-Pruefung N2/N3) ----
    def test_shortened_announcement_never_hides_the_named_speaker(self):
        for sprecher in ("Johann", "figur", "Johann Bruckner", None):
            for einl in ("sagt:", "Johann Weber sagt:", None):
                r = self.bind("Johann Weber sagt: Hallo.", [speech("Hallo.", einl, sprecher=sprecher)])
                self.assertEqual(r["speech"], "", (sprecher, einl)); self.assertTrue(r.get("nichts_ausfuehrbar"), (sprecher, einl))
                self.assertEqual([f for f in self.commit(r).get("facts", []) if f.get("kind") == "speech"], [])
        r = self.bind("Mara sagt zu Johann: Lass mich in Ruhe!", [speech("Lass mich in Ruhe!", "sagt zu Johann:", sprecher="Mara")])
        self.assertEqual(r["speech"], ""); self.assertIn("rede_akteur_ist_nicht_der_sprecher", self.grunds(r))
        # without an announcement mark at all: the adjacent words before the speech are its clause
        r = self.bind("Johann Weber sagt Hallo.", [speech("Hallo.", None, sprecher="figur")])
        self.assertEqual(r["speech"], "")

    def test_own_speech_with_full_announcement_still_works(self):
        r = self.bind("Johann sagt zu Mara: Komm her.", [speech("Komm her.", "Johann sagt zu Mara:", sprecher="Johann")])
        self.assertEqual(r["speech"], "Komm her."); self.assertEqual(self.grunds(r), [])
        r = self.bind("Johann sagt: Hallo.", [speech("Hallo.", "sagt:", sprecher="Johann")])          # name before "sagt:" = the figure
        self.assertEqual(r["speech"], "Hallo.")

    def test_missing_reading_with_an_unknown_name_is_fail_closed(self):
        r = self.bind("Mara Schmidt sagt: Komm her.", [speech("Komm her.", "sagt:")])
        self.assertEqual(r["speech"], ""); self.assertIn("rede_sprecher_name_unklar", self.grunds(r))
        r = self.bind("Ein Gast sagt zu Mara Schmidt: Komm her.", [speech("Komm her.", "sagt zu Mara Schmidt:")])
        self.assertEqual(r["speech"], ""); self.assertIn("rede_sprecher_name_unklar", self.grunds(r))
        # the clause itself proves the speaker (it opens with the figure's name / with "ich"): the unknown name is the addressee
        r = self.bind("Johann sagt zu Mara Schmidt: Komm her.", [speech("Komm her.", "sagt zu Mara Schmidt:")])
        self.assertEqual((r["speech"], r.get("speechTarget")), ("Komm her.", None)); self.assertIn("rede_adressat_unklar", self.grunds(r))
        r = self._avatar_bind("Ich sage zu Mara Schmidt: Hallo.", [speech("Hallo.", "Ich sage zu", akteur="ich")])   # live 05.11.: einleitung cut
        self.assertEqual((r["speech"], r.get("speechTarget")), ("Hallo.", None))
        r = self.bind("Johann schubst Mara Schmidt.", [hc("Johann schubst Mara Schmidt", wirkung="gewalt", pruefung=None)])
        self.assertEqual(r["actions"], []); self._nothing_for_mara(r, "ohne Lesung")

    # ---- Entscheidung 1: Rede-Adressat aus "sagt zu X" ----
    def _avatar_bind(self, raw, comps):
        return kernel.bind_input_components(raw, comps, actor_id=self.J["id"], actor_names=["Johann Bruckner"], figures=self.chars,
                                            present_ids=self.present, default_target=self.M["id"], text_tense=None, addressee_id=self.M["id"])

    def test_named_addressee_outranks_the_selected_recipient_only_when_proven(self):
        sch = self._schmidt()
        r = self.bind("Johann sagt zu Mara Schmidt: Komm her.", [speech("Komm her.", "Johann sagt zu Mara Schmidt:", sprecher="Johann", adressat="Mara Schmidt")])
        self.assertEqual((r["speech"], r.get("speechTargetSet"), r.get("speechTarget")), ("Komm her.", True, sch["id"]))
        s = self.commit(r)
        # commit_puppet with the decided addressee (as the route passes it)
        self.assertTrue(r.get("speechTargetSet"))
        r = self.bind("Johann sagt zu Mara: Komm her.", [speech("Komm her.", "Johann sagt zu Mara:", sprecher="Johann", adressat="Mara")])
        self.assertEqual((r["speech"], r.get("speechTarget")), ("Komm her.", None))  # "Mara" fits two present figures: no addressee
        self.assertIn("rede_adressat_unklar", self.grunds(r))
        # Schmidt absent / unknown: the speech stays, addressed to nobody (never to the selected Mara Nowak)
        self.chars = [self.J, self.M]; self.present = [self.J["id"], self.M["id"]]
        for ad in ("Mara Schmidt", "Mara", None):
            r = self.bind("Johann sagt zu Mara Schmidt: Komm her.", [speech("Komm her.", "Johann sagt zu Mara Schmidt:", sprecher="Johann", adressat=ad)])
            self.assertEqual((r["speech"], r.get("speechTargetSet"), r.get("speechTarget")), ("Komm her.", True, None), ad)
            self.assertIn("rede_adressat_unklar", self.grunds(r))
        r = self._avatar_bind("Ich sage zu Peter: Hallo.", [speech("Hallo.", "Ich sage zu Peter:", akteur="ich", sprecher="figur", adressat="Peter")])
        self.assertEqual((r["speech"], r.get("speechTarget")), ("Hallo.", None))
        # a present named addressee
        r = self._avatar_bind("Ich sage zu Mara: Hallo.", [speech("Hallo.", "Ich sage zu Mara:", akteur="ich", sprecher="figur", adressat="Mara")])
        self.assertEqual((r["speech"], r.get("speechTarget")), ("Hallo.", self.M["id"]))
        # no addressee named: no decision, the route keeps the selected recipient
        r = self.bind("Johann sagt: Hallo.", [speech("Hallo.", "Johann sagt:", sprecher="Johann")])
        self.assertFalse(r.get("speechTargetSet"))

    # ---- Entscheidung 2: Vorrang Anwesender nur in der Szene, volle Namen behalten Vorrang ----
    def test_direct_address_prefers_the_one_present_figure_but_never_bends_a_full_name(self):
        sch = self._schmidt(present=False)
        sess = {"scene": {"presentIds": [self.J["id"], self.M["id"]]}, "facts": [], "propositions": [], "goals": []}
        d = kernel.resolve_target_detail(sess, self.chars, "Mara, komm her.", ui_target_id=None, input_actor_id=self.J["id"])
        self.assertEqual((d["target_id"], d["reason"]), (self.M["id"], "explicit_address_present"))
        d = kernel.resolve_target_detail(sess, self.chars, "Mara Schmidt, komm her.", ui_target_id=self.M["id"], input_actor_id=self.J["id"])
        self.assertEqual(d["target_id"], sch["id"])                                    # the full name keeps its own figure
        d = kernel.resolve_target_detail(sess, [self.J, self.M], "Mara Schmidt, komm her.", ui_target_id=self.M["id"], input_actor_id=self.J["id"])
        self.assertEqual((d["target_id"], d["reason"]), (None, "explicit_address_unknown"))   # unknown: never the selected Mara Nowak
        sess["scene"]["presentIds"].append(sch["id"])
        d = kernel.resolve_target_detail(sess, self.chars, "Mara, komm her.", ui_target_id=None, input_actor_id=self.J["id"])
        self.assertEqual((d["target_id"], d["ambiguous"]), (None, True))             # both present: unclear
        # referents (memory/recall) keep no scene preference: a name two figures carry binds nobody
        self.assertEqual(kernel.bind_referents("Ich habe Mara gesehen.", self.chars), [])

    # ---- Entscheidung 3: die validierte Einleitung ist kein Redetext ----
    def test_validated_announcement_inside_the_speech_segment_is_no_spoken_word(self):
        r = self.bind("Johann sagt: Hallo Mara.", [speech("Johann sagt: Hallo Mara.", "Johann sagt:")])
        self.assertEqual(r["speech"], "Hallo Mara."); self.assertEqual(self.grunds(r), [])
        r = self._avatar_bind("*Ich lächle* und sage: Schön, euch zu sehen.",
                              [hc("*Ich lächle*", akteur="ich", wirkung="ohne_koerperwirkung", pruefung=JA, ziel=None),
                               speech("und sage: Schön, euch zu sehen.", "sage:", akteur="ich", sprecher="figur")])
        self.assertEqual(r["speech"], "Schön, euch zu sehen.")
        # never words of a real utterance without an announcement mark
        r = self._avatar_bind("Ich sage dir die Wahrheit.", [speech("Ich sage dir die Wahrheit.", "Ich sage dir", akteur="ich")])
        self.assertEqual(r["speech"], "Ich sage dir die Wahrheit.")
        # an announcement inside that names another figure is still checked
        r = self.bind("Mara sagt: Hallo.", [speech("Mara sagt: Hallo.", "Mara sagt:")])
        self.assertEqual(r["speech"], ""); self.assertIn("rede_akteur_ist_nicht_der_sprecher", self.grunds(r))


class P14PuppetRoute(unittest.TestCase):
    setUp = _PV.PuppetRouteChain.setUp
    session = _PV.PuppetRouteChain.session
    puppet = _PV.PuppetRouteChain.puppet
    snapshot = _PV.PuppetRouteChain.snapshot
    _nothing_committed = _PV.PuppetRouteChain._nothing_committed
    _act_comp = _PV.PuppetRouteChain._act_comp

    def test_shortened_readings_commit_nothing_wrong_over_the_route(self):
        s0 = self.session()
        ok_effect = lambda p: {"bestaetigt": True, "zeit": "jetzt", "ziel": p.get("ziel"), "beleg": "schubst"}
        c = dict(self._act_comp("Johann schubst Mara Schmidt"), ziel="Mara Nowak", wirkung="gewalt")
        prov = FakeProvider([plan("action", "act", [c])], wirkung=ok_effect,
                            vollzug=lambda p: {"geschieht": True, "art": "tatsaechlich", "beleg": None, "taeter": "figur", "ziel": "Mara"})
        r = self.puppet(prov, "Johann schubst Mara Schmidt.")
        self.assertIn(r.status_code, (200, 422), r.get_data(as_text=True)[:300])
        s = self.session()                                                    # new connection = reader after a restart
        self.assertFalse([f for f in s["facts"] if f.get("targetId") == self.M["id"] and f.get("kind") in ("action", "physical")])
        self.assertEqual(pain(s, self.M["id"]), pain(s0, self.M["id"]))
        self.assertFalse([m for m in s.get("memories") or [] if m.get("characterId") == self.M["id"] and m.get("kind") == "erlebt"])
        rd = dict(comp("rede", "Hallo."), einleitung="sagt:")
        # V92 Paket 16: the shortened reading "Johann" proves nothing - the operator is asked first (nothing stored); "nobody of the
        # cast" -> a foreign speech, nothing stored
        prov = FakeProvider([plan("smalltalk", "chat", [rd])] * 2, sprecher=lambda p: {"sprecher": "Johann", "beleg": None})
        r = self._nothing_committed(prov, "Johann Weber sagt: Hallo.", None, code="IDENTITAET_KLAEREN")
        self.assertEqual([(q["text"], [c["id"] for c in q["kandidaten"]]) for q in r.get_json()["klaerung"]], [("Johann Weber", [self.J["id"]])])
        self._nothing_committed(prov, "Johann Weber sagt: Hallo.", None, klaerungen=[{"text": "Johann Weber", "id": None}])
        rd = dict(comp("rede", "Lass mich in Ruhe!"), einleitung="sagt zu Johann:")
        self._nothing_committed(FakeProvider([plan("smalltalk", "chat", [rd])], sprecher=lambda p: {"sprecher": "Mara", "beleg": None}),
                                "Mara sagt zu Johann: Lass mich in Ruhe!", None)

    def test_named_addressee_is_the_speech_target_and_follow_up_after_restart(self):
        with closing(connect(self.dbp)) as c:
            jrow = c.execute("select world_id, owner_user_id, json from characters where id=?", (self.M["id"],)).fetchone()
            w = dict(json.loads(jrow[2])); w["id"] = "char_test_mara_schmidt"; w["name"] = "Mara Schmidt"; w["aliases"] = []
            c.execute("INSERT INTO characters(id, world_id, owner_user_id, json) VALUES(?,?,?,?)", (w["id"], jrow[0], jrow[1], json.dumps(w, ensure_ascii=False)))
            create_session(c, {"id": "ses_ad", "worldId": jrow[0], "name": "AD", "presentIds": [self.J["id"], self.M["id"], w["id"]]}, "admin"); c.commit()

        def run(text, rd, sprecher):
            with closing(connect(self.dbp)) as c: before = get_session(c, "admin", "ses_ad")
            prov = FakeProvider([plan("smalltalk", "chat", [rd])], sprecher=sprecher)
            with patch.object(urllib.request, "urlopen", prov):
                r = self.client.post("/api/kernel/puppet", headers={"X-Matrix-Actor": "admin"}, json={
                    "session": before, "sessionId": "ses_ad", "actorUserId": "admin", "figure": {"id": self.J["id"], "name": self.J["name"]},
                    "text": text, "targetId": self.M["id"]})
            with closing(connect(self.dbp)) as c: return r, get_session(c, "admin", "ses_ad")
        r, s = run("Johann sagt zu Mara Schmidt: „Komm her.“", dict(comp("rede", "Komm her."), einleitung="Johann sagt zu Mara Schmidt:"),
                   lambda p: {"sprecher": "Johann", "beleg": None, "adressat": "Mara Schmidt"})
        self.assertEqual(r.status_code, 200, r.get_data(as_text=True)[:300])
        f = [x for x in s["facts"] if x.get("kind") == "speech" and x.get("actorId") == self.J["id"]][-1]
        self.assertEqual((f["text"], f.get("targetId")), ("Komm her.", "char_test_mara_schmidt"))
        r, s = run("Johann sagt: „Alles gut?“", dict(comp("rede", "Alles gut?"), einleitung="Johann sagt:"),
                   lambda p: {"sprecher": "Johann", "beleg": None, "adressat": None})
        self.assertEqual(r.status_code, 200, r.get_data(as_text=True)[:300])
        f = [x for x in s["facts"] if x.get("kind") == "speech" and x.get("actorId") == self.J["id"]][-1]
        self.assertEqual(f.get("targetId"), self.M["id"])                       # nothing named: the selected recipient


class P14AvatarAndSession(unittest.TestCase):
    setUp = _AV.AvatarRouteChain.setUp
    session = _AV.AvatarRouteChain.session
    prepare = _AV.AvatarRouteChain.prepare
    mine = _AV.AvatarRouteChain.mine

    def test_avatar_speech_to_an_unknown_named_person_has_no_addressee(self):
        rd = dict(rede("Hallo.", akteur="ich"), einleitung="Ich sage zu Mara Schmidt:")
        prov = FakeProvider([plan("smalltalk", "chat", [rd])] * 2, sprecher=lambda p: {"sprecher": "figur", "beleg": None, "adressat": "Mara Schmidt"})
        # V92 Paket 16: "Mara Schmidt" holds the cast name "Mara" - the operator is asked first (nothing stored); "nobody" -> no addressee
        r = self.prepare(prov, "Ich sage zu Mara Schmidt: Hallo.")
        self.assertEqual((r.status_code, (r.get_json() or {}).get("code")), (422, "IDENTITAET_KLAEREN"), r.get_data(as_text=True)[:300])
        self.assertFalse([x for x in self.session()["facts"] if x.get("kind") == "speech" and x.get("actorId") == self.J["id"]])
        r = self.prepare(prov, "Ich sage zu Mara Schmidt: Hallo.", [{"text": "Mara Schmidt", "id": None}])
        self.assertEqual(r.status_code, 200, r.get_data(as_text=True)[:300])
        f = [x for x in self.session()["facts"] if x.get("kind") == "speech" and x.get("actorId") == self.J["id"]][-1]
        self.assertEqual((f["text"], f.get("targetId")), ("Hallo.", None))

    def test_absent_world_figure_and_cut_announcement_live_shape(self):
        # Browser-Lauf 05.11. (Paket 14 vorher): Mara Schmidt existiert in der Welt, ist aber nicht anwesend; die Lesung kuerzte die
        # Einleitung auf "Ich sage zu". The route must decide with the SAME (present) figures as the binder - the speech is the
        # avatar's, addressed to nobody; Mara Nowak is never the addressee.
        with closing(connect(self.dbp)) as c:
            jrow = c.execute("select world_id, owner_user_id, json from characters where id=?", (self.M["id"],)).fetchone()
            w = dict(json.loads(jrow[2])); w["id"] = "char_test_mara_schmidt"; w["name"] = "Mara Schmidt"; w["aliases"] = []
            c.execute("INSERT INTO characters(id, world_id, owner_user_id, json) VALUES(?,?,?,?)", (w["id"], jrow[0], jrow[1], json.dumps(w, ensure_ascii=False))); c.commit()
        rd = dict(rede("Hallo.", akteur="Johann Bruckner"), einleitung="Ich sage zu")
        prov = FakeProvider([plan("smalltalk", "chat", [rd])] * 2, sprecher=lambda p: {"sprecher": "figur", "beleg": None, "adressat": "Mara Schmidt"})
        # V92 Paket 16: "Mara Schmidt" holds the cast name "Mara" - the operator is asked first (nothing stored); "nobody" -> no addressee
        r = self.prepare(prov, "Ich sage zu Mara Schmidt: Hallo.")
        self.assertEqual((r.status_code, (r.get_json() or {}).get("code")), (422, "IDENTITAET_KLAEREN"), r.get_data(as_text=True)[:300])
        self.assertFalse([x for x in self.session()["facts"] if x.get("kind") == "speech" and x.get("actorId") == self.J["id"]])
        r = self.prepare(prov, "Ich sage zu Mara Schmidt: Hallo.", [{"text": "Mara Schmidt", "id": None}])
        self.assertEqual(r.status_code, 200, r.get_data(as_text=True)[:300])
        f = [x for x in self.session()["facts"] if x.get("kind") == "speech" and x.get("actorId") == self.J["id"]][-1]
        self.assertEqual((f["text"], f.get("targetId")), ("Hallo.", None))

    def test_speaker_binding_is_stored_by_the_session_owner_and_read_back(self):
        put = lambda body: self.client.put("/api/sessions/ses_av", headers={"X-Matrix-Actor": "admin"}, json=body)
        for v in ("avatar", "operator", f"char:{self.M['id']}"):
            r = put({"speakAs": v}); self.assertEqual(r.status_code, 200, r.get_data(as_text=True)[:200])
            self.assertEqual(self.session().get("speakAs"), v)                  # new connection = read back after a reload
        for bad in ("bedienperson", "char:char_gibt_es_nicht"):
            r = put({"speakAs": bad}); self.assertGreaterEqual(r.status_code, 400, bad)
            self.assertEqual(self.session().get("speakAs"), f"char:{self.M['id']}", bad)
        r = put({"speakAs": ""}); self.assertEqual(r.status_code, 200)
        self.assertIsNone(self.session().get("speakAs"))

    def test_frontend_reads_the_binding_from_the_session_and_locks_without_it(self):
        from pathlib import Path
        src = (Path(__file__).resolve().parents[1] / "src" / "routes" / "chat.$sessionId.tsx").read_text(encoding="utf-8")
        self.assertIn("const speakerAs = boundSpeakAs(session, natives);", src)
        self.assertIn("const writeLocked = busy || !speakerAs;", src)
        self.assertNotIn('useState(session?.avatarId ? "avatar" : "operator")', src)
        self.assertIn('data-v92="sprecher-waehlen"', src)
        store = (Path(__file__).resolve().parents[1] / "src" / "lib" / "matrix" / "store.ts").read_text(encoding="utf-8")
        self.assertIn("speakAs: s.speakAs ?? null", store)


if __name__ == "__main__":
    unittest.main()
