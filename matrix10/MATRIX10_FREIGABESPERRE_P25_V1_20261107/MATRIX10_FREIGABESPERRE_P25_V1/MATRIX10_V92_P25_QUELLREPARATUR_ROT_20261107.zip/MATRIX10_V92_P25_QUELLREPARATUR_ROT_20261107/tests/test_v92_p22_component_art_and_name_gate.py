"""P22: original-token name gate and Puppet speech/action kind gate.
Read-only controlled semantic proposals; no provider or user database.
"""
import unittest
from matrix_api import kernel


class P22NameGate(unittest.TestCase):
    def setUp(self):
        self.figures = [{"id": "j", "name": "Johann Bruckner"}, {"id": "m", "name": "Mara Nowak"}, {"id": "g", "name": "Gustav Pfeiffer"}]

    def reading(self, raw, **extra):
        spot = kernel.name_boundary_candidates(raw, self.figures)
        self.assertTrue(spot, raw)
        return {"grenzen": [{**spot[0], "status": "eindeutig", **extra}]}

    def test_legacy_free_name_never_authorizes_body_effect(self):
        raw = "Johann schubst Anna Mara Nowak."
        # Both planner and the old name reader wrongly shortened the full name.
        old = self.reading(raw, name="Mara Nowak", beleg="Anna Mara Nowak", rolle="nennung")
        cast = kernel.with_name_boundary_reading(raw, self.figures, old)
        names = kernel.name_occurrences(raw, cast)
        self.assertFalse(any(o.get("state") == "ok" and o.get("ids") == {"m"} for o in names if o.get("a", 0) > 0), names)

    def test_new_source_token_format_keeps_valid_vocatives(self):
        raw = "Hallo Mara, wie geht es dir?"
        cast = kernel.with_name_boundary_reading(raw, self.figures,
            self.reading(raw, wortklassen=["gruss", "name"], rolle="anrede"))
        target = kernel.resolve_target_detail({"scene": {"presentIds": ["j", "m"]}, "avatarId": "j"},
            cast, raw, ui_target_id="g", input_actor_id="j")
        self.assertEqual(target["target_id"], "m", target)

    def test_new_source_token_format_does_not_clip_unknown_full_name(self):
        raw = "Johann schubst Anna Mara Nowak."
        cast = kernel.with_name_boundary_reading(raw, self.figures,
            self.reading(raw, wortklassen=["name", "name", "name"], rolle="nennung"))
        names = kernel.name_occurrences(raw, cast)
        self.assertFalse(any(o.get("state") == "ok" and o.get("ids") == {"m"} for o in names if o.get("a", 0) > 0), names)

    def test_narrated_action_requires_separate_art_and_vollzug_check(self):
        raw = "Johann gibt Mara Nowak Brot."
        comps = [{"typ": "rede", "segment": "Johann gibt Mara Nowak Brot", "akteur": "Johann Bruckner", "ziel": "Mara Nowak"}]
        self.assertEqual(kernel.component_kind_candidate_indices(raw, comps, self.figures, "j"), [0])
        out = kernel.apply_component_kind_readings(raw, comps, {0: {"art": "handlung", "beleg": "Johann gibt Mara Nowak Brot", "wirkung": "ohne_koerperwirkung"}},
            figures=self.figures, actor_id="j", actor_name="Johann Bruckner")
        self.assertEqual((out[0]["typ"], out[0]["wirkung"]), ("handlung", "ohne_koerperwirkung"))
        self.assertTrue(out[0]["geschieht"])  # classified act is a proposal only
        self.assertNotIn("vollzugPruefung", out[0])  # the route must still obtain its own independent check
        self.assertEqual(comps[0]["typ"], "rede")  # never mutate the first reading

    def test_foreign_narrated_actor_never_promoted(self):
        raw = "Mara gibt Johann Brot."
        comps = [{"typ": "rede", "segment": "Mara gibt Johann Brot", "akteur": "Mara Nowak"}]
        out = kernel.apply_component_kind_readings(raw, comps, {0: {"art": "handlung", "beleg": "Mara gibt Johann Brot", "wirkung": "ohne_koerperwirkung"}},
            figures=self.figures, actor_id="j", actor_name="Johann Bruckner")
        self.assertEqual(out[0]["typ"], "unklar")

    def test_plan_reroutes_foreign_actor_only_when_source_is_vocative(self):
        raw = "Herr Pfeiffer, setzen Sie sich."
        proposal = [{"typ": "rede", "segment": "Herr Pfeiffer, setzen Sie sich", "akteur": "Gustav Pfeiffer"}]
        cast = kernel.with_name_boundary_reading(raw, self.figures,
            self.reading(raw, wortklassen=["titel", "name"], rolle="anrede"))
        out = kernel.apply_component_kind_readings(raw, proposal, {0: {"art": "rede", "beleg": "Herr Pfeiffer, setzen Sie sich"}},
            figures=cast, actor_id="j", actor_name="Johann Bruckner")
        self.assertEqual((out[0]["typ"], out[0]["akteur"]), ("rede", "Johann Bruckner"))

    def test_no_semantic_speech_proof_no_foreign_actor_override(self):
        raw = "Mara sagt: Hallo."
        comps = [{"typ": "rede", "segment": "Mara sagt: Hallo", "akteur": "Mara Nowak"}]
        out = kernel.apply_component_kind_readings(raw, comps, {0: {"art": "rede", "beleg": "Mara sagt: Hallo"}},
            figures=self.figures, actor_id="j", actor_name="Johann Bruckner")
        self.assertEqual(out[0]["typ"], "unklar")

    def test_missing_or_nonliteral_secondary_check_blocks_suspicious_speech(self):
        raw = "Johann gibt Mara Nowak Brot."
        comps = [{"typ": "rede", "segment": "Johann gibt Mara Nowak Brot", "akteur": "Johann Bruckner"}]
        for reading in (None, {"art": "handlung", "wirkung": "ohne_koerperwirkung", "beleg": "schenkt ihr Schuhe"}):
            with self.subTest(reading=reading):
                out = kernel.apply_component_kind_readings(raw, comps, {0: reading}, figures=self.figures,
                                                            actor_id="j", actor_name="Johann Bruckner")
                self.assertEqual(out[0]["typ"], "unklar")

    def test_normal_speech_not_delayed_by_another_model_call(self):
        comps = [{"typ": "rede", "segment": "Hallo Mara, wie geht es dir?", "akteur": "Johann Bruckner"}]
        self.assertEqual(kernel.component_kind_candidate_indices("Hallo Mara, wie geht es dir?", comps, self.figures, "j"), [])


    def _narrated_plan(self, reading, vollzug=None):
        # The cast is the one P21 actually projects AFTER the name-token check.
        import test_v92_p17_klaerung as T
        fixture=T.P17Kernel();fixture.setUp();f=fixture.f
        raw="Johann gibt Mara Nowak Brot."
        name_spot=kernel.name_boundary_candidates(raw,f.chars)[0]
        cast=kernel.with_name_boundary_reading(raw,f.chars,{"grenzen":[{
            **name_spot,"wortklassen":["name","name","anderes"],"rolle":"nennung","status":"eindeutig"}]})
        initial=[{"typ":"rede","segment":raw[:-1],"akteur":f.J["name"],"ziel":f.M["name"]}]
        changed=kernel.apply_component_kind_readings(raw,initial,{0:reading}, figures=cast,
                            actor_id=f.J["id"],actor_name=f.J["name"])
        if vollzug is not None:
            changed=kernel.apply_component_vollzug(changed,{0:vollzug})
        return f,raw,cast,changed

    def test_reclassified_action_is_executed_only_with_independent_vollzug(self):
        reread={"art":"handlung","beleg":"Johann gibt Mara Nowak Brot","wirkung":"ohne_koerperwirkung"}
        f,raw,cast,proposal=self._narrated_plan(reread)
        self.assertEqual(proposal[0]["typ"],"handlung")
        self.assertEqual(proposal[0].get("geschieht"),True)
        # The second kind reading is not sufficient to write a single event.
        unverified=kernel.bind_puppet_input(raw,{"komponenten":proposal},f.J,cast,f.present,addressee_id=f.M["id"])
        self.assertFalse([a for a in unverified["actions"] if not a.get("targetBindingInvalid")])
        self.assertFalse([x for x in f.commit(unverified)["facts"] if x.get("kind")=="action"])
        independent={"geschieht":True,"art":"tatsaechlich","beleg":"Johann gibt Mara Nowak Brot",
                    "taeter":f.J["name"],"ziel":f.M["name"]}
        _,_,_,components=self._narrated_plan(reread, independent)
        bound=kernel.bind_puppet_input(raw,{"komponenten":components},f.J,cast,f.present,addressee_id=f.M["id"])
        self.assertEqual((bound["speech"],len(bound["actions"]),bound["actions"][0]["targetId"]),
                         ("",1,f.M["id"]),bound)
        saved=f.commit(bound)
        actions=[x for x in saved["facts"] if x.get("kind")=="action" and x.get("validated")]
        self.assertEqual([(a.get("actorId"),a.get("targetId")) for a in actions],[(f.J["id"],f.M["id"])])
        self.assertFalse([x for x in saved["facts"] if x.get("kind")=="speech"])

    def test_reclassified_action_survives_sqlite_and_brain_reader(self):
        import tempfile
        import json
        from contextlib import closing
        from pathlib import Path
        from matrix_api.db import connect,init_schema,GASTHAUS_ID
        from matrix_api.seed_builtin import seed_if_missing
        from matrix_api.repos import create_session,save_session,get_session
        import test_v92_p17_klaerung as T
        f,raw,cast,components=self._narrated_plan(
            {"art":"handlung","beleg":"Johann gibt Mara Nowak Brot","wirkung":"ohne_koerperwirkung"},
            {"geschieht":True,"art":"tatsaechlich","beleg":"Johann gibt Mara Nowak Brot",
             "taeter":"Johann Bruckner","ziel":"Mara Nowak"})
        b=kernel.bind_puppet_input(raw,{"komponenten":components},f.J,cast,f.present,addressee_id=f.M["id"])
        saved=f.commit(b)
        self.assertTrue([v for v in saved.get("memories") or [] if v.get("characterId")==f.M["id"]])
        with tempfile.TemporaryDirectory(prefix="p22_puppet_") as tmp:
            dest=Path(tmp)/"fresh.sqlite"
            with closing(connect(dest)) as c:
                init_schema(c);seed_if_missing(c)
                origin=c.execute("select world_id,owner_user_id,json from characters where id=?",(f.M["id"],)).fetchone()
                duplicate=json.loads(origin[2]);duplicate.update({"id":T.S,"name":"Mara Schmidt","aliases":[]})
                c.execute("insert into characters(id,world_id,owner_user_id,json) values(?,?,?,?)",
                           (T.S,origin[0],origin[1],json.dumps(duplicate,ensure_ascii=False)))
                create_session(c,{"id":saved["id"],"worldId":GASTHAUS_ID,"name":"P22 test","presentIds":f.present},"admin")
                save_session(c,"admin",saved);c.commit()
            with closing(connect(dest)) as c:
                again=get_session(c,"admin",saved["id"])
                self.assertEqual(c.execute("pragma quick_check").fetchone()[0],"ok")
            facts=[v for v in again["facts"] if v.get("kind")=="action" and v.get("validated")]
            self.assertEqual(len(facts),1)
            self.assertEqual(facts[0].get("targetId"),f.M["id"])
            self.assertFalse([v for v in again["facts"] if v.get("kind")=="speech"])
            self.assertTrue([v for v in again.get("memories") or [] if v.get("characterId")==f.M["id"]])
            context=kernel.brain_context(again,f.M["id"])
            self.assertIsInstance(context,dict)
            self.assertFalse(context.get("writable",True))

    def test_wrong_or_missing_blind_vollzug_never_creates_action(self):
        candidate={"art":"handlung","beleg":"Johann gibt Mara Nowak Brot","wirkung":"ohne_koerperwirkung"}
        for check in (None, {"geschieht":False,"art":"verneint","taeter":"Johann Bruckner","ziel":"Mara Nowak"},
                      {"geschieht":True,"art":"tatsaechlich","taeter":"Johann Bruckner","ziel":"Mara Nowak","beleg":"bad"}):
            with self.subTest(check=check):
                f,raw,cast,components=self._narrated_plan(candidate,check)
                b=kernel.bind_puppet_input(raw,{"komponenten":components},f.J,cast,f.present,addressee_id=f.M["id"])
                self.assertFalse([a for a in b["actions"] if not a.get("targetBindingInvalid")],b)
                self.assertFalse([v for v in f.commit(b)["facts"] if v.get("kind")=="action"])

    def test_puppet_route_passes_authenticated_actor_id_not_name_lookup(self):
        # Source-contract guard because full Flask routes cannot run here.
        from pathlib import Path
        src=(Path(__file__).resolve().parents[1]/"matrix_api/app.py").read_text(encoding="utf-8")
        self.assertIn('actor_id=str(speaker_r.get("id") or "")',src)
        self.assertIn('puppet_actor_id_not_bound_to_present_cast',src)
        self.assertNotIn('actor_id = next((str(f.get("id") or "") for f in _figs',src)

if __name__ == "__main__":
    unittest.main()
