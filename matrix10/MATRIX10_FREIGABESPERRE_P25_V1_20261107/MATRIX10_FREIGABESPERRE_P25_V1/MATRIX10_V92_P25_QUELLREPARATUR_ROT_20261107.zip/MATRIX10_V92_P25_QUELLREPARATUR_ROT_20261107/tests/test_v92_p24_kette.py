"""P24 failure-oriented binder/SQLite/state contracts. Does NOT claim browser/LLM execution."""
from __future__ import annotations
import unittest
from matrix_api import kernel

J = {'id': 'j', 'name': 'Johann Bruckner'}
G = {'id': 'g', 'name': 'Gustav Pfeiffer'}
M = {'id': 'm', 'name': 'Mara Nowak'}
CAST = [J, G, M]


def speech(seg, intro='', actor='Johann Bruckner', speaker='Johann Bruckner', addressee=None,
           role='anrede', role_beleg=None):
    comp = {'typ': 'rede', 'segment': seg, 'akteur': actor}
    if intro:
        comp['einleitung'] = intro
        comp['sprecherPruefung'] = {'sprecher': speaker, 'adressat': addressee,
            'beleg': seg, 'ansageRolle': role, 'ansageBeleg': role_beleg or intro}
    return comp


def bound(raw, comps, figures=CAST):
    return kernel.bind_puppet_input(raw, {'komponenten': comps}, J, figures,
                                   [c['id'] for c in figures], addressee_id=M['id'])


class P24CausalTests(unittest.TestCase):
    def test_gustav_vocative_with_misread_speaker_keeps_entire_spoken_sentence(self):
        raw = 'Gustav, setz dich.'
        b = bound(raw, [speech('setz dich.', 'Gustav,', speaker='Gustav', addressee='Gustav')])
        self.assertEqual(b['speech'], raw, b)
        self.assertEqual(b.get('speechTarget'), G['id'], b)
        self.assertFalse(b.get('ambiguous'), b)

    def test_title_vocative_does_not_turn_into_unknown_person(self):
        from test_v92_p22_component_art_and_name_gate import P22NameGate
        t=P22NameGate(); t.setUp()
        raw='Herr Pfeiffer, setzen Sie sich.'
        reading=t.reading(raw,wortklassen=['titel','name'],rolle='anrede')
        figures=kernel.with_name_boundary_reading(raw,t.figures,reading)
        b=bound(raw,[speech('setzen Sie sich.', 'Herr Pfeiffer,', addressee='Herr Pfeiffer')],figures)
        self.assertEqual(b['speech'],raw,b)
        self.assertEqual(b.get('speechTarget'),'g',b)
        self.assertFalse(b.get('ambiguous'),b)

    def test_address_after_introductory_word_keeps_original_full_text(self):
        raw='Ja, Gustav, setz dich.'
        b=bound(raw,[speech('setz dich.','Ja, Gustav,',speaker='Gustav',addressee='Gustav',role_beleg='Gustav,')])
        self.assertEqual(b['speech'],raw,b)
        self.assertEqual(b.get('speechTarget'),'g',b)

    def test_no_semantic_role_or_literal_evidence_never_overrides_foreign_speech(self):
        raw='Mara sagt: Ich bin müde.'
        for role,beleg in [('sprecheransage','Mara sagt:'),('unklar','Mara sagt:'),('anrede','nicht im Text')]:
            with self.subTest(role=role,beleg=beleg):
                b=bound(raw,[speech('Ich bin müde.','Mara sagt:',speaker='Mara Nowak',addressee=None,role=role,role_beleg=beleg)])
                self.assertEqual(b['speech'],'',b)
                self.assertTrue(b.get('incomplete') or b.get('nichts_ausfuehrbar'),b)

    def test_unverified_comma_is_not_enough_to_promote_address(self):
        raw='Gustav, setz dich.'
        c=speech('setz dich.','Gustav,',speaker='Gustav',addressee=None,role='unklar')
        c['sprecherPruefung']['ansageBeleg']=None
        b=bound(raw,[c])
        self.assertEqual(b['speech'],'',b)

    def test_same_name_two_characters_never_promotes_to_ambiguous_address(self):
        cloned={**G,'id':'g2'}
        raw='Gustav, setz dich.'
        b=bound(raw,[speech('setz dich.','Gustav,',speaker='Gustav',addressee='Gustav')],CAST+[cloned])
        self.assertEqual(b['speech'],'',b)

    def test_missing_later_sentence_is_blocked_as_partial_rejection(self):
        raw='Mara, schön dich zu sehen. Gustav, setz dich.'
        b=bound(raw,[{'typ':'rede','segment':'Mara, schön dich zu sehen.','akteur':J['name']}])
        self.assertTrue(b.get('partial_rejection'),b)
        self.assertTrue(any(a.get('grund')=='rest_ohne_komponente' for a in b['ambiguous']),b)

    def test_two_proven_speech_components_both_persist_in_speech_binding(self):
        raw='Mara, schön dich zu sehen. Gustav, setz dich.'
        b=bound(raw,[{'typ':'rede','segment':'Mara, schön dich zu sehen.','akteur':J['name']},
                     speech('setz dich.','Gustav,',speaker='Gustav',addressee='Gustav')])
        self.assertIn('Mara, schön dich zu sehen.',b['speech'],b)
        self.assertIn('Gustav, setz dich.',b['speech'],b)
        self.assertFalse(b.get('partial_rejection'),b)

    def test_unproven_old_process_is_not_proven_to_be_running(self):
        s={'pendingInputTurnId':'tid','turnTruths':[{'id':'tid','text':'Hallo'}],
           'pendingInputAttempt':{'turnTruthId':'tid','attempts':[{'state':'laeuft','boot':'dead_or_unknown'}]}}
        view=kernel.pending_input_view(s,boot_id='current',alive=lambda attempt:None)
        self.assertTrue(view['attemptRunning'])
        self.assertTrue(view['attemptUnklar'])
        self.assertRaisesRegex(RuntimeError,'unclear',kernel.close_pending_input,s,'tid',boot_id='current',alive=lambda attempt:None)

if __name__ == '__main__':
    unittest.main()
