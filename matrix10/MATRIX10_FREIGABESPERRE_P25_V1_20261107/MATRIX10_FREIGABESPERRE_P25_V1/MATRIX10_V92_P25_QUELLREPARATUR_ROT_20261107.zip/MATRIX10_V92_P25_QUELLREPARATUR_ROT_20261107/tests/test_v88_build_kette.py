"""V88 regression: test real shipped browser bundle IDs, not just HTML metadata."""
from __future__ import annotations
import json
from pathlib import Path
import re
import unittest

ROOT = Path(__file__).resolve().parents[1]
DIST = ROOT / "frontend_dist"
ASSETS = DIST / "assets"
BUILD_ID = next(line.partition("=")[2].strip() for line in
                (ROOT/"VERSION.txt").read_text(encoding="utf-8").splitlines()
                if line.startswith("BUILD_ID="))

class ShippedBrowserBuildContract(unittest.TestCase):
    def test_browser_api_shell_routes_send_and_check_server_current_build(self):
        # V92: aus den TSX-Quellen gebaut; Chunks tragen Hash-Namen statt "-V91"
        def one(prefix):
            hits=[p for p in ASSETS.glob(prefix+"-*.js") if re.fullmatch(re.escape(prefix)+r"-[A-Za-z0-9_-]{8}\.js",p.name)]
            self.assertEqual(len(hits),1,(prefix,hits)); return hits[0]
        files={n:one(n) for n in ("api","shell","routes")}
        for name,path in files.items():
            content=path.read_text(encoding="utf-8")
            self.assertIn(BUILD_ID,content,path.name)
            self.assertNotIn("MATRIX10_CHATHERE_V86_VOLLSTAENDIGE_BASIS_20261102",content,path.name)
        self.assertIn("X-Matrix-Client-Build",files["api"].read_text(encoding="utf-8"))
        self.assertIn("/api/health",files["shell"].read_text(encoding="utf-8"))

    def test_html_metadata_source_and_server_are_consistent(self):
        html=(DIST/"index.html").read_text(encoding="utf-8")
        self.assertIn('name="matrix-build" content="'+BUILD_ID+'"',html)
        self.assertIn('export const BUILD_ID = "'+BUILD_ID+'"',
                      (ROOT/"src/lib/matrix/types.ts").read_text(encoding="utf-8"))
        self.assertEqual(json.loads((DIST/".build-info.json").read_text(encoding="utf-8"))['buildId'], BUILD_ID)

    def test_versioned_asset_graph_resolves_and_not_old_build(self):
        paths=[p for p in ASSETS.glob("*.js")]
        self.assertGreaterEqual(len(paths),38)
        content=[(DIST/"index.html").read_text(encoding="utf-8")]+[p.read_text(encoding="utf-8") for p in paths]
        for raw in content:
            self.assertNotIn("MATRIX10_CHATHERE_V86_VOLLSTAENDIGE_BASIS_20261102",raw)
            self.assertNotIn("-V85.js",raw)
            self.assertNotIn("-V91.js",raw)       # kein altes, nachetikettiertes V80/V91-Bundle
            self.assertNotIn("index-V85-VollstaendigeBasis.js",raw)
            for asset in re.findall(r'(?:/assets/|\./)([A-Za-z0-9._-]+\.js)',raw):
                self.assertTrue((ASSETS/asset).exists(),asset)
        info=json.loads((DIST/".build-info.json").read_text(encoding="utf-8"))
        listed=info['assets']
        self.assertEqual(len(listed),len(set(listed)))
        for f in listed: self.assertTrue((DIST/f).is_file(),f)
        self.assertEqual(sorted(listed),sorted(str(p.relative_to(DIST)).replace("\\","/") for p in ASSETS.rglob("*") if p.is_file()))

    def test_build_is_from_source_and_checksums_match_delivered_files(self):
        """V92 Build-Vertrag: Quellhash, Lockfile, SHA-256 je Datei und Fingerprint stimmen mit dem Ausgelieferten ueberein."""
        import hashlib
        info=json.loads((DIST/".build-info.json").read_text(encoding="utf-8"))
        self.assertIs(info["frontendCompiledAnew"],True); self.assertIs(info["builtFromSource"],True)
        self.assertEqual(info["buildId"],BUILD_ID)
        # src-Baum (gleiche Formel wie scripts/build-frontend-dist.mjs treeHash)
        files=sorted(p for p in (ROOT/"src").rglob("*") if p.is_file())
        h=hashlib.sha256()
        for f in files:
            h.update(str(f.relative_to(ROOT)).replace("\\","/").encode()); h.update(b"\0"); h.update(f.read_bytes()); h.update(b"\0")
        self.assertEqual(h.hexdigest(),info["sourceTreeSha256"],"src/ wurde nach dem Build geaendert: Dist neu bauen")
        self.assertEqual(hashlib.sha256((ROOT/"package-lock.json").read_bytes()).hexdigest(),info["lockfileSha256"])
        shas=info["fileSha256"]
        for rel,expected in shas.items():
            self.assertEqual(hashlib.sha256((DIST/rel).read_bytes()).hexdigest(),expected,rel)
        delivered={str(p.relative_to(DIST)).replace("\\","/") for p in DIST.rglob("*") if p.is_file() and p.name!=".build-info.json"}
        self.assertEqual(delivered,set(shas))
        html=(DIST/"index.html").read_text(encoding="utf-8")
        norm=hashlib.sha256(re.sub(r"u:\d{10,}","u:0",html).encode()).hexdigest()
        self.assertEqual(norm,info["indexHtmlNormalizedSha256"])
        fp=hashlib.sha256(json.dumps({**shas,"index.html":norm},separators=(",",":"),ensure_ascii=False).encode()).hexdigest()
        self.assertEqual(fp,info["reproducibleFingerprint"])

    def test_checksum_contract_detects_a_tampered_or_old_bundle(self):
        import hashlib, tempfile, shutil
        info=json.loads((DIST/".build-info.json").read_text(encoding="utf-8"))
        with tempfile.TemporaryDirectory() as tmp:
            copy=Path(tmp)/"d"; shutil.copytree(DIST,copy)
            victim=next(copy.glob("assets/api-*.js"))
            victim.write_text(victim.read_text(encoding="utf-8")+"\n//manipuliert",encoding="utf-8")
            rel=str(victim.relative_to(copy)).replace("\\","/")
            self.assertNotEqual(hashlib.sha256(victim.read_bytes()).hexdigest(),info["fileSha256"][rel])
            (copy/"assets"/"api-V91old.js").write_text("x",encoding="utf-8")
            delivered={str(p.relative_to(copy)).replace("\\","/") for p in copy.rglob("*") if p.is_file() and p.name!=".build-info.json"}
            self.assertNotEqual(delivered,set(info["fileSha256"]))

    def test_delivered_ui_contains_new_controls_and_backend_shares_build_identity(self):
        bundle="\n".join(p.read_text(encoding="utf-8") for p in ASSETS.glob("*.js"))
        for needle in ("eingabe-hinweis","Nicht alles aus deiner Eingabe wurde als Ereignis gespeichert","PLAN_INCOMPLETE",
                       "Angewiesene Figur (wer handelt;","Löschen / Speicher"):
            self.assertIn(needle,bundle,needle)
        html=(DIST/"index.html").read_text(encoding="utf-8")
        self.assertIn('name="matrix-build" content="'+BUILD_ID+'"',html)
        import sys; sys.path.insert(0,str(ROOT))
        src=(ROOT/"matrix_api"/"app.py").read_text(encoding="utf-8")
        self.assertIn('line.startswith("BUILD_ID=")',src)       # Backend liest dieselbe VERSION.txt
        self.assertIn("BUILD_ID",(ROOT/"START.py").read_text(encoding="utf-8"))   # UI-Server liest dieselbe VERSION.txt

    def test_entrypoints_share_v88_and_sqlite_is_not_bundled(self):
        start=(ROOT/"START.py").read_text(encoding="utf-8")
        self.assertIn('matrix_speicher_v91.html',start)
        self.assertTrue((ROOT/"matrix_speicher_v91.html").is_file())
        self.assertIn('START_WINDOWS_V91.bat',(ROOT/"START.bat").read_text(encoding="utf-8"))
        self.assertIn('START_WINDOWS_V91.py',(ROOT/"START_WINDOWS_V91.bat").read_text(encoding="utf-8"))
        for ending in ("*.sqlite", "*.sqlite-wal", "*.sqlite-shm"):
            self.assertFalse(list(ROOT.rglob(ending)),ending)

if __name__ == "__main__": unittest.main()
