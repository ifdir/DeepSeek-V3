"""INDEPENDENT RED COUNTERPROBE -- intentionally not counted as green acceptance.
Run: python -m unittest discover -s tests -p 'audit*.py' -q
Demand is contract §10: a vague model rationale without profile-grounded
causal support must not become a canonical directed relationship update.
No hardcoded 'Mara always refuses' behavior is required by this check.
"""
import json
from pathlib import Path
import unittest
from test_v84_kausal_chain import scene, proposed, proofs
from matrix_api import kernel

ROOT = Path(__file__).resolve().parents[1]

class OpenCausalValidity(unittest.TestCase):
    def test_a_generic_model_affirmation_does_not_prove_a_trust_change(self):
        source = json.loads((ROOT/'matrix_api/gasthaus_seed.json').read_text(encoding='utf-8'))
        chars = [c for c in source['characters'] if c['id'] in ('char_g7_mara','char_g7_johann')]
        scene_state,pending,event = scene('Ich klatsch dir auf deinen arsch')
        row = proposed(state=.2,trust=.1,closeness=.1,feeling='Begeisterung')
        row['_kausalpruefung'] = proofs(row,event)
        # Deliberately substitute the *original V85 review* (merely a generic
        # model affirmation, no quote from canonical disposition). Legitimate
        # approvals in test_v84_kausal_chain now carry verifiable evidence.
        for check in row['_kausalpruefung']['pruefungen']:
            check.pop('dispositionsBeleg', None)
            check['begruendung'] = 'Das Ereignis wird relativ zum Figurenprofil interpretiert.'
        out,log = kernel.apply_appraisals(scene_state,pending,{'bewertungen':[row]},natives=chars)
        # Test expected by the causal effect contract, NOT presently satisfied:
        # The generic text 'Das Ereignis wird relativ zum Figurenprofil
        # interpretiert' states no actual profile/relationship reason.
        self.assertAlmostEqual(out['relations'][0]['trust'], 0.4, msg=
            'RED: unsubstantiated model verdict elevated Mara trust')

if __name__=='__main__':unittest.main()
