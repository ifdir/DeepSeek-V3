"""V92 Paket 17 (unabhaengige Pruefung Paket 16, 06.11.2026): die Antwort auf eine Identitaets-Rueckfrage gilt nur fuer die Frage,
die DIESER Server fuer GENAU diese Eingabe gestellt hat, und nur fuer die eine geschriebene Stelle, fuer die sie gestellt wurde.

Vertragsverletzung A: eine nicht angebotene, ungefragte, veraenderte, veraltete oder fremde Antwort wurde uebernommen
("Frau Nowak" = Mara Schmidt -> Koerperwirkung an Mara Schmidt). Vertragsverletzung B: derselbe Name an zwei Stellen ergab eine
Frage, und eine Antwort band beide Handlungen. Echte Kernel-Leser, echte Routen /api/kernel/puppet und /api/kernel/prepare,
SQLite-Ruecklesung ueber eine neue Verbindung, Neustart (neue App-Instanz), Folgezug, Frontend-Quellvertrag. Keine Nutzer-DB.
"""
import base64
import copy
import json
import unittest
import urllib.request
from contextlib import closing
from pathlib import Path
from unittest.mock import patch

import test_v84_kausal_chain  # noqa: F401  (offline Flask shim wie die übrigen Tests)
from matrix_api import kernel
from matrix_api.db import connect
from matrix_api.repos import create_session, get_session
import test_v92_puppet_vertrag as _PV
import test_v92_avatar_route as _AV
import test_v92_negativgrenzen as _NG
from test_v92_puppet_vertrag import FakeProvider, plan
from test_v92_avatar_route import act

ROOT = Path(__file__).resolve().parents[1]
S = "char_test_mara_schmidt"


def pain(s, fid):
    return float(((s.get("runtimes") or {}).get(fid) or {}).get("pain") or 0)


def _ok_effect(p):
    return {"bestaetigt": True, "zeit": "jetzt", "ziel": p.get("ziel"), "beleg": "schubst"}


class P17Kernel(unittest.TestCase):
    """Kernel: Antwort nur fuer angebotene Figur und nur fuer ihre Stelle."""

    def setUp(self):
        f = _NG.Negativgrenzen(); f.setUp()
        sch = copy.deepcopy(f.M); sch["name"], sch["id"], sch["aliases"] = "Mara Schmidt", S, []
        f.chars.append(sch); f.present.append(S)
        self.f = f

    def act(self, text, target, effect):
        return {"typ": "handlung", "segment": text, "akteur": "Johann Bruckner", "ziel": target, "zeit": "jetzt", "wirkung": effect,
                "geschieht": True, "vollzugPruefung": {"geschieht": True, "art": "tatsaechlich", "beleg": None,
                                                       "taeter": "Johann Bruckner", "ziel": target}}

    def run_(self, raw, comps, answers=()):
        f = self.f
        proj = kernel.with_klaerungen(f.chars, list(answers), raw)
        b = kernel.bind_puppet_input(raw, {"komponenten": comps}, f.J, proj, f.present, addressee_id=f.M["id"])
        q = kernel.identity_questions(b.get("ambiguous"), None, list(answers), proj, present_ids=f.present)
        out = f.commit(b)
        facts = [(x.get("kind"), x.get("targetId")) for x in out.get("facts", []) if x.get("kind") in ("action", "physical") and x.get("validated", True)]
        return b, q, facts

    def test_an_answer_the_place_does_not_offer_binds_nothing_and_the_question_stays(self):
        raw, comps = "Johann schubst Frau Nowak.", [self.act("Johann schubst Frau Nowak", "Frau Nowak", "gewalt")]
        for answer in ({"text": "Frau Nowak", "id": S}, {"text": "Frau Nowak", "a": 15, "b": 25, "id": S},
                       {"text": "Frau Nowak", "a": 15, "b": 25, "id": self.f.J["id"]}):
            b, q, facts = self.run_(raw, comps, [answer])
            self.assertEqual([(x["text"], x["a"], x["b"], [c["id"] for c in x["kandidaten"]]) for x in q], [("Frau Nowak", 15, 25, [self.f.M["id"]])], answer)
            self.assertFalse([t for k, t in facts if t], answer)
        b, q, facts = self.run_(raw, comps, [{"text": "Frau Nowak", "a": 15, "b": 25, "id": self.f.M["id"]}])
        self.assertEqual((q, facts), ([], [("action", self.f.M["id"]), ("physical", self.f.M["id"])]))

    def test_the_same_name_at_two_places_is_two_questions_and_two_independent_answers(self):
        M = self.f.M["id"]
        raw = "Johann schubst Mara. Johann umarmt Mara."
        comps = [self.act("Johann schubst Mara", "Mara", "gewalt"), self.act("Johann umarmt Mara", "Mara", "zaertlich")]
        b, q, facts = self.run_(raw, comps)
        self.assertEqual([(x["text"], x["a"], x["b"]) for x in q], [("Mara", 15, 19), ("Mara", 35, 39)])
        # the wording alone names no place: nothing bound, both questions stay
        b, q, facts = self.run_(raw, comps, [{"text": "Mara", "id": M}])
        self.assertEqual(([a["targetId"] for a in b["actions"]], len(q)), ([None, None], 2))
        # each place on its own - Nowak at the first, Schmidt at the second
        b, q, facts = self.run_(raw, comps, [{"text": "Mara", "a": 15, "b": 19, "id": M}, {"text": "Mara", "a": 35, "b": 39, "id": S}])
        self.assertEqual(([a["targetId"] for a in b["actions"]], q), ([M, S], []))
        self.assertEqual(facts, [("action", M), ("physical", M), ("action", S)])
        # one place answered: only that place is bound, the other is asked
        b, q, facts = self.run_(raw, comps, [{"text": "Mara", "a": 35, "b": 39, "id": M}])
        self.assertEqual(([a["targetId"] for a in b["actions"]], [(x["a"], x["b"]) for x in q]), ([None, M], [(15, 19)]))
        # a place that is not exactly the written name (offset inside the word) binds nothing
        b, q, facts = self.run_(raw, comps, [{"text": "Mara", "a": 16, "b": 19, "id": M}])
        self.assertEqual(([a["targetId"] for a in b["actions"]], len(q)), ([None, None], 2))

    def test_other_roles_answer_at_their_place(self):
        J, M = self.f.J["id"], self.f.M["id"]
        # doer named by the planner (Paket 16 asked only for the blind reading's doer): asked, the answer binds by its place
        raw = "Anna Johann Bruckner schubst Mara Nowak."
        c = [dict(self.act("Anna Johann Bruckner schubst Mara Nowak", "Mara Nowak", "gewalt"), akteur="Anna Johann Bruckner")]
        c[0]["vollzugPruefung"]["taeter"] = "Anna Johann Bruckner"
        b, q, facts = self.run_(raw, c)
        self.assertEqual(([a["grund"] for a in b["ambiguous"]], [(x["text"], x["a"], x["b"]) for x in q]),
                         (["akteur_ist_nicht_der_sprecher"], [("Anna Johann Bruckner", 0, 20)]))
        b, q, facts = self.run_(raw, c, [{"text": "Anna Johann Bruckner", "a": 0, "b": 20, "id": J}])
        self.assertEqual(([a["targetId"] for a in b["actions"]], q), ([M], []))
        b, q, facts = self.run_(raw, c, [{"text": "Anna Johann Bruckner", "a": 0, "b": 20, "id": None}])
        self.assertEqual((b["actions"], q), ([], []))
        # speaker at two places: each answer decides its own speech
        raw = "Anna Johann Bruckner sagt: Hallo. Anna Johann Bruckner sagt: Tschüss."
        r = lambda seg: {"typ": "rede", "segment": seg, "akteur": "Johann Bruckner", "einleitung": "Anna Johann Bruckner sagt:",
                         "sprecherPruefung": {"sprecher": "Anna Johann Bruckner", "adressat": None, "beleg": None}}
        b, q, facts = self.run_(raw, [r("Hallo."), r("Tschüss.")])
        self.assertEqual([(x["a"], x["b"]) for x in q], [(0, 20), (34, 54)])
        b, q, facts = self.run_(raw, [r("Hallo."), r("Tschüss.")], [{"text": "Anna Johann Bruckner", "a": 0, "b": 20, "id": J},
                                                                     {"text": "Anna Johann Bruckner", "a": 34, "b": 54, "id": None}])
        self.assertEqual((b["speech"], q), ("Hallo.", []))
        # a direct address answered for Mara Schmidt: she is the addressee, not the selected recipient Mara Nowak
        sess = {"scene": {"presentIds": self.f.present}, "facts": [], "propositions": [], "goals": []}
        t = "Hallo Mara, wie geht es dir?"
        d = kernel.resolve_target_detail(sess, self.f.chars, t, ui_target_id=M, input_actor_id=J)
        self.assertEqual((d["target_id"], d["klaerung"]["a"], d["klaerung"]["b"]), (None, 0, 10))
        proj = kernel.with_klaerungen(self.f.chars, [{"text": "Hallo Mara", "a": 0, "b": 10, "id": S}], t)
        d = kernel.resolve_target_detail(sess, proj, t, ui_target_id=M, input_actor_id=J)
        self.assertEqual((d["target_id"], d["reason"]), (S, "explicit_address_clarified"))
        # two vocatives "Mara": the first answered, the second is asked on its own
        t = "Mara, komm her. Mara, setz dich."
        proj = kernel.with_klaerungen(self.f.chars, [{"text": "Mara", "a": 0, "b": 4, "id": S}], t)
        d = kernel.resolve_target_detail(sess, proj, t, ui_target_id=M, input_actor_id=J)
        self.assertEqual((d["target_id"], d["klaerung"]["a"], d["klaerung"]["b"]), (None, 16, 20))
        proj = kernel.with_klaerungen(self.f.chars, [{"text": "Mara", "a": 0, "b": 4, "id": S}, {"text": "Mara", "a": 16, "b": 20, "id": S}], t)
        self.assertEqual(kernel.resolve_target_detail(sess, proj, t, ui_target_id=M, input_actor_id=J)["target_id"], S)

    def test_place_klaerungen_rules(self):
        J, M = self.f.J, self.f.M
        raw = "Johann schubst Mara. Johann umarmt Mara."
        placed = lambda answers: {c["id"]: c.get("klaerung") for c in kernel.with_klaerungen(self.f.chars, answers, raw) if c.get("klaerung") is not None}
        self.assertEqual(placed([{"text": "Mara", "id": M["id"]}]), {M["id"]: []}, "two places: no place without offsets")
        self.assertEqual(placed([{"text": "Mara", "a": 15, "b": 19, "id": M["id"]}]),
                         {M["id"]: [{"text": "Mara", "a": 15, "b": 19, "eindeutig": False}]})
        self.assertEqual(placed([{"text": "Mara", "a": 15, "b": 19, "id": J["id"]}]), {J["id"]: []}, "Johann is no candidate of 'Mara'")
        self.assertEqual(placed([{"text": "Mara", "a": 15, "b": 19, "id": M["id"]}, {"text": "Mara", "a": 15, "b": 19, "id": S}]),
                         {M["id"]: [], S: []}, "one place claimed for two figures binds nobody")
        # a non-unique answer is never used by the place-free name reader
        proj = kernel.with_klaerungen(self.f.chars, [{"text": "Mara", "a": 15, "b": 19, "id": M["id"]}], raw)
        self.assertEqual(kernel.figure_ids_for_name("Mara", proj), {M["id"], S})


class P17PuppetRoute(unittest.TestCase):
    """Echte Route /api/kernel/puppet: Rueckfrage -> Antwort nur auf die ausgestellte Frage."""
    setUp0 = _PV.PuppetRouteChain.setUp
    snapshot = _PV.PuppetRouteChain.snapshot
    _act_comp = _PV.PuppetRouteChain._act_comp

    def setUp(self):
        self.setUp0()
        with closing(connect(self.dbp)) as c:
            jrow = c.execute("select world_id, owner_user_id, json from characters where id=?", (self.M["id"],)).fetchone()
            w = dict(json.loads(jrow[2])); w["id"] = S; w["name"] = "Mara Schmidt"; w["aliases"] = []
            c.execute("INSERT INTO characters(id, world_id, owner_user_id, json) VALUES(?,?,?,?)", (w["id"], jrow[0], jrow[1], json.dumps(w, ensure_ascii=False)))
            create_session(c, {"id": "ses_mm", "worldId": jrow[0], "name": "MM", "presentIds": [self.J["id"], self.M["id"], S]}, "admin")
            create_session(c, {"id": "ses_m2", "worldId": jrow[0], "name": "M2", "presentIds": [self.J["id"], self.M["id"], S]}, "admin"); c.commit()

    def sess(self, sid="ses_mm"):
        with closing(connect(self.dbp)) as c:
            return get_session(c, "admin", sid)

    def post(self, prov, text, klaerungen=None, sid="ses_mm", fig=None, client=None):
        fig = fig or self.J
        with patch.object(urllib.request, "urlopen", prov):
            return (client or self.client).post("/api/kernel/puppet", headers={"X-Matrix-Actor": "admin"}, json={
                "session": self.sess(sid), "sessionId": sid, "actorUserId": "admin", "figure": {"id": fig["id"], "name": fig["name"]},
                "text": text, "targetId": self.M["id"], **({"klaerungen": klaerungen} if klaerungen is not None else {})})

    def mk_push(self, seg="Johann schubst Frau Nowak", ziel="Frau Nowak"):
        c = dict(self._act_comp(seg), ziel=ziel, wirkung="gewalt")
        return FakeProvider([plan("action", "act", [c])], wirkung=_ok_effect,
                            vollzug=lambda p: {"geschieht": True, "art": "tatsaechlich", "beleg": None, "taeter": "Johann Bruckner", "ziel": ziel})

    def rejected(self, r, grund, sid="ses_mm", before=None):
        self.assertEqual((r.status_code, (r.get_json() or {}).get("code"), (r.get_json() or {}).get("grund")), (422, "KLAERUNG_UNGUELTIG", grund),
                         r.get_data(as_text=True)[:300])
        self.assertIn("Nichts wurde gespeichert", r.get_json()["message"])
        if before is not None:
            self.assertEqual(self.snapshot(self.sess(sid)), before, "SQLite unveraendert")

    def ask(self, text, prov, sid="ses_mm", fig=None, client=None):
        before = self.snapshot(self.sess(sid))
        r = self.post(prov, text, sid=sid, fig=fig, client=client)
        self.assertEqual((r.status_code, (r.get_json() or {}).get("code")), (422, "IDENTITAET_KLAEREN"), r.get_data(as_text=True)[:300])
        self.assertEqual(self.snapshot(self.sess(sid)), before, "nothing stored before the answer")
        return r.get_json()["klaerung"]

    # ---- A: the answer is checked against the question the server issued ----
    def test_forged_unsolicited_tampered_and_foreign_answers_are_rejected_before_any_write(self):
        s0 = self.sess()
        q = self.ask("Johann schubst Frau Nowak.", self.mk_push())
        self.assertEqual([(x["text"], x["a"], x["b"], [c["id"] for c in x["kandidaten"]]) for x in q], [("Frau Nowak", 15, 25, [self.M["id"]])])
        before = self.snapshot(self.sess())
        # 1) a figure the question did not offer (Paket-16-Pruefung N1)
        self.rejected(self.post(self.mk_push(), "Johann schubst Frau Nowak.", [{"frage": q[0]["frage"], "id": S}]), "nicht_angeboten", before=before)
        # 2) unsolicited: the P16 form without the server's question, and an invented question (N2)
        self.rejected(self.post(self.mk_push(), "Johann schubst Frau Nowak.", [{"text": "Frau Nowak", "id": self.M["id"]}]), "nicht_gestellt", before=before)
        self.rejected(self.post(self.mk_push(), "Johann schubst Frau Nowak.", [{"frage": "eyJ4IjoxfQ.00", "id": self.M["id"]}]), "nicht_gestellt", before=before)
        # 3) the question changed by the client (Schmidt added to the candidates, signature kept)
        body, sig = q[0]["frage"].split(".")
        p = json.loads(base64.urlsafe_b64decode(body + "=" * (-len(body) % 4))); p["c"].append(S)
        forged = base64.urlsafe_b64encode(json.dumps(p, ensure_ascii=False, sort_keys=True).encode()).decode().rstrip("=") + "." + sig
        self.rejected(self.post(self.mk_push(), "Johann schubst Frau Nowak.", [{"frage": forged, "id": S}]), "nicht_gestellt", before=before)
        # 4) changed input text, other session, other puppet figure (Forderung C)
        self.rejected(self.post(self.mk_push(), "Johann schubst Frau Nowak!", [{"frage": q[0]["frage"], "id": self.M["id"]}]), "andere_eingabe", before=before)
        b2 = self.snapshot(self.sess("ses_m2"))
        self.rejected(self.post(self.mk_push(), "Johann schubst Frau Nowak.", [{"frage": q[0]["frage"], "id": self.M["id"]}], sid="ses_m2"), "andere_eingabe", sid="ses_m2", before=b2)
        self.rejected(self.post(self.mk_push(), "Johann schubst Frau Nowak.", [{"frage": q[0]["frage"], "id": self.M["id"]}], fig=self.M), "andere_eingabe", before=before)
        # 5) two answers for one place
        self.rejected(self.post(self.mk_push(), "Johann schubst Frau Nowak.", [{"frage": q[0]["frage"], "id": self.M["id"]}, {"frage": q[0]["frage"], "id": None}]),
                      "doppelt", before=before)
        # 6) a question of an earlier server start (new app instance = restart)
        from matrix_api import app as appmod
        restarted = appmod.create_app(self.dbp).test_client()
        self.rejected(self.post(self.mk_push(), "Johann schubst Frau Nowak.", [{"frage": q[0]["frage"], "id": self.M["id"]}], client=restarted), "nicht_gestellt", before=before)
        # nobody was hurt by any of these
        s = self.sess()
        self.assertEqual((pain(s, self.M["id"]), pain(s, S)), (pain(s0, self.M["id"]), pain(s0, S)))
        self.assertFalse([f for f in s["facts"] if f.get("kind") == "physical"])
        # the issued question answered correctly: Mara Nowak, body effect, readable after restart
        r = self.post(self.mk_push(), "Johann schubst Frau Nowak.", [{"frage": q[0]["frage"], "id": self.M["id"]}])
        self.assertEqual(r.status_code, 200, r.get_data(as_text=True)[:300])
        with closing(connect(self.dbp)) as c:                                            # new connection = reader after a restart
            s = get_session(c, "admin", "ses_mm")
        self.assertEqual([(f.get("kind"), f.get("targetId")) for f in s["facts"] if f.get("kind") in ("action", "physical") and f.get("actorId") == self.J["id"]],
                         [("action", self.M["id"]), ("physical", self.M["id"])])
        self.assertGreater(pain(s, self.M["id"]), pain(s0, self.M["id"])); self.assertEqual(pain(s, S), pain(s0, S))
        # 7) stale: the same question after the stored turn
        before = self.snapshot(self.sess())
        self.rejected(self.post(self.mk_push(), "Johann schubst Frau Nowak.", [{"frage": q[0]["frage"], "id": self.M["id"]}]), "andere_eingabe", before=before)

    def test_answered_address_names_the_addressee_over_the_route(self):
        prov = lambda: FakeProvider([plan("smalltalk", "chat", [{"typ": "rede", "segment": "Hallo Mara, wie geht es dir?", "akteur": "Johann Bruckner"}])])
        q = self.ask("Hallo Mara, wie geht es dir?", prov())
        self.assertEqual([(x["text"], x["a"], x["b"], sorted(c["id"] for c in x["kandidaten"])) for x in q],
                         [("Hallo Mara", 0, 10, sorted([self.M["id"], S]))])
        r = self.post(prov(), "Hallo Mara, wie geht es dir?", [{"frage": q[0]["frage"], "id": S}])
        self.assertEqual(r.status_code, 200, r.get_data(as_text=True)[:300])
        f = [x for x in self.sess()["facts"] if x.get("kind") == "speech" and x.get("actorId") == self.J["id"]][-1]
        self.assertEqual((f.get("text"), f.get("targetId")), ("Hallo Mara, wie geht es dir?", S), "the answer outranks the selected recipient")

    # ---- B: one question and one answer per written place ----
    def test_two_places_two_answers_over_http_sqlite_restart_and_follow_up(self):
        s0 = self.sess()
        comps = [dict(self._act_comp("Johann schubst Mara"), ziel="Mara", wirkung="gewalt"), dict(self._act_comp("Johann umarmt Mara"), ziel="Mara")]
        mk = lambda: FakeProvider([plan("action", "act", comps)], wirkung=_ok_effect,
                                  vollzug=lambda p: {"geschieht": True, "art": "tatsaechlich", "beleg": None, "taeter": "Johann Bruckner", "ziel": "Mara"})
        text = "Johann schubst Mara. Johann umarmt Mara."
        q = self.ask(text, mk())
        self.assertEqual([(x["text"], x["a"], x["b"]) for x in q], [("Mara", 15, 19), ("Mara", 35, 39)])
        self.assertNotEqual(q[0]["frage"], q[1]["frage"])
        self.assertEqual([(x["vor"], x["nach"]) for x in q], [("Johann schubst ", ". Johann umarmt Mara."), ("n schubst Mara. Johann umarmt ", ".")])
        # only the first place answered: nothing stored, exactly the second place is asked again
        before = self.snapshot(self.sess())
        r = self.post(mk(), text, [{"frage": q[0]["frage"], "id": self.M["id"]}])
        self.assertEqual((r.status_code, r.get_json()["code"]), (422, "IDENTITAET_KLAEREN"))
        self.assertEqual([(x["a"], x["b"], x["frage"]) for x in r.get_json()["klaerung"]], [(35, 39, q[1]["frage"])])
        self.assertEqual(self.snapshot(self.sess()), before)
        # both places: Nowak pushed, Schmidt hugged - each act its own person
        r = self.post(mk(), text, [{"frage": q[0]["frage"], "id": self.M["id"]}, {"frage": q[1]["frage"], "id": S}])
        self.assertEqual(r.status_code, 200, r.get_data(as_text=True)[:300])
        with closing(connect(self.dbp)) as c:
            s = get_session(c, "admin", "ses_mm")
        acts = [(f.get("text"), f.get("kind"), f.get("targetId")) for f in s["facts"] if f.get("kind") in ("action", "physical") and f.get("actorId") == self.J["id"]]
        self.assertEqual([(k, t) for _x, k, t in acts], [("action", self.M["id"]), ("physical", self.M["id"]), ("action", S)], acts)
        self.assertGreater(pain(s, self.M["id"]), pain(s0, self.M["id"])); self.assertEqual(pain(s, S), pain(s0, S))
        mem = lambda fid: sorted({m.get("kind") for m in s.get("memories") or [] if m.get("characterId") == fid and m.get("sourceTurnId") == s["turnTruths"][-1].get("id")})
        self.assertIn("erlebt", mem(self.M["id"])); self.assertIn("erlebt", mem(S))
        # restart: a new app instance reads the same truth and the follow-up turn binds a proven name directly
        from matrix_api import app as appmod
        restarted = appmod.create_app(self.dbp).test_client()
        c2 = dict(self._act_comp("Johann schubst Mara Schmidt"), ziel="Mara Schmidt", wirkung="gewalt")
        r = self.post(FakeProvider([plan("action", "act", [c2])], wirkung=_ok_effect,
                                   vollzug=lambda p: {"geschieht": True, "art": "tatsaechlich", "beleg": None, "taeter": "Johann Bruckner", "ziel": "Mara Schmidt"}),
                      "Johann schubst Mara Schmidt.", client=restarted)
        self.assertEqual(r.status_code, 200, r.get_data(as_text=True)[:300])
        s2 = self.sess()
        self.assertEqual(s2["facts"][:len(s["facts"])], s["facts"], "the earlier truth is unchanged after the restart")
        self.assertGreater(pain(s2, S), pain(s, S))


class P17AvatarRoute(unittest.TestCase):
    """Echte Route /api/kernel/prepare (Avatar Johann) und /api/kernel/commit: dieselbe Pruefung."""
    setUp0 = _AV.AvatarRouteChain.setUp
    session = _AV.AvatarRouteChain.session
    snapshot = _AV.AvatarRouteChain.snapshot
    prepare = _AV.AvatarRouteChain.prepare

    def setUp(self):
        self.setUp0()
        with closing(connect(self.dbp)) as c:
            jrow = c.execute("select world_id, owner_user_id, json from characters where id=?", (self.M["id"],)).fetchone()
            w = dict(json.loads(jrow[2])); w["id"] = S; w["name"] = "Mara Schmidt"; w["aliases"] = []
            c.execute("INSERT INTO characters(id, world_id, owner_user_id, json) VALUES(?,?,?,?)", (w["id"], jrow[0], jrow[1], json.dumps(w, ensure_ascii=False)))
            s = get_session(c, "admin", "ses_av")
            c.execute("UPDATE sessions SET json=? WHERE id=?", (json.dumps({**s, "scene": {**s["scene"], "presentIds": [self.J["id"], self.M["id"], S]}}, ensure_ascii=False), "ses_av"))
            c.commit()

    def test_avatar_two_places_forged_answer_and_unsolicited_commit_answer(self):
        if S not in (self.session().get("scene") or {}).get("presentIds", []):
            self.skipTest("presence not writable in this fixture")
        s0 = self.session()
        comps = [dict(act("Ich schubse Mara", akteur="ich", ziel="Mara"), wirkung="gewalt"), act("Ich umarme Mara", akteur="ich", ziel="Mara")]
        mk = lambda: FakeProvider([plan("action", "act", comps)], wirkung=_ok_effect,
                                  vollzug=lambda p: {"geschieht": True, "art": "tatsaechlich", "beleg": None, "taeter": "figur", "ziel": "Mara"})
        text = "Ich schubse Mara. Ich umarme Mara."
        before = self.snapshot(self.session())
        r = self.prepare(mk(), text)
        self.assertEqual((r.status_code, r.get_json()["code"]), (422, "IDENTITAET_KLAEREN"), r.get_data(as_text=True)[:300])
        q = r.get_json()["klaerung"]
        self.assertEqual([(x["text"], x["a"], x["b"]) for x in q], [("Mara", 12, 16), ("Mara", 29, 33)])
        self.assertEqual(self.snapshot(self.session()), before)
        # forged (unsolicited text answer) and changed text
        for bad, grund, t in (([{"text": "Mara", "id": self.M["id"]}], "nicht_gestellt", text),
                              ([{"frage": q[0]["frage"], "id": self.M["id"]}, {"frage": q[1]["frage"], "id": S}], "andere_eingabe", text + " ")):
            r = self.prepare(mk(), t, bad)
            self.assertEqual((r.status_code, r.get_json()["code"], r.get_json().get("grund")), (422, "KLAERUNG_UNGUELTIG", grund), r.get_data(as_text=True)[:300])
            self.assertEqual(self.snapshot(self.session()), before)
        r = self.prepare(mk(), text, [{"frage": q[0]["frage"], "id": S}, {"frage": q[1]["frage"], "id": self.M["id"]}])
        self.assertEqual(r.status_code, 200, r.get_data(as_text=True)[:300])
        s = self.session()
        acts = [(f.get("kind"), f.get("targetId")) for f in s["facts"] if f.get("kind") in ("action", "physical") and f.get("actorId") == self.J["id"]]
        self.assertEqual(acts, [("action", S), ("physical", S), ("action", self.M["id"])])
        self.assertGreater(pain(s, S), pain(s0, S)); self.assertEqual(pain(s, self.M["id"]), pain(s0, self.M["id"]))
        # the figure's response to this stored input has no open question: an answer sent with it is unsolicited
        self.assertTrue(s.get("pendingInputTurnId"))
        tt = next(t for t in s["turnTruths"] if t.get("id") == s["pendingInputTurnId"])
        with patch.object(urllib.request, "urlopen", FakeProvider([])):
            r = self.client.post("/api/kernel/commit", headers={"X-Matrix-Actor": "admin"}, json={
                "session": s, "actorUserId": "admin", "trace_id": "kc_p17", "truth": {**tt, "role": "character", "authority": "character"},
                "speaker": {"id": self.M["id"], "name": self.M["name"]}, "result": {"speech": "Au."},
                "klaerungen": [{"frage": q[0]["frage"], "id": self.M["id"]}]})
        self.assertEqual((r.status_code, r.get_json().get("code"), r.get_json().get("grund")), (422, "KLAERUNG_UNGUELTIG", "keine_offene_frage"),
                         r.get_data(as_text=True)[:300])
        self.assertEqual(self.snapshot(self.session()), self.snapshot(s))


class P17Frontend(unittest.TestCase):
    """Die Oberflaeche beantwortet jede Frage ueber ihre Kennung und zeigt die Stellen unterscheidbar."""

    def test_source_contract(self):
        hint = (ROOT / "src/lib/matrix/eingabe-hinweis.ts").read_text(encoding="utf-8")
        chat = (ROOT / "src/routes/chat.$sessionId.tsx").read_text(encoding="utf-8")
        self.assertIn("export type KlaerungAntwort = { frage: string; id: string | null };", hint)
        self.assertIn('"KLAERUNG_UNGUELTIG"', hint)
        self.assertIn(".filter((q) => q.frage && q.text && q.kandidaten.length);", hint)
        for needle in ("const antworten = [...klaerung.antworten.filter((a) => a.frage !== frage), { frage, id }];",
                       "klaerung.fragen.some((f) => !antworten.some((a) => a.frage === f.frage))",
                       "<div key={f.frage}", "data-v92-stelle={i + 1}", "(Stelle ${i + 1} von ${klaerung.fragen.length})",
                       "onClick={() => klaere(f.frage, c.id)}", "onClick={() => klaere(f.frage, null)}", "data-v92-kontext"):
            self.assertIn(needle, chat, needle)
        self.assertNotIn("a.text === f.text", chat)


if __name__ == "__main__":
    unittest.main()
