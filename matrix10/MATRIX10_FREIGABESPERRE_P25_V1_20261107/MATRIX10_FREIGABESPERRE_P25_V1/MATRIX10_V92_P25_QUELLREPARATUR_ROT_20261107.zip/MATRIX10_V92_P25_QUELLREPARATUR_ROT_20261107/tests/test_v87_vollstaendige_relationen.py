"""Independent regressions for multi-party effects and directed evidence.
Uses existing canonical appraisal writer; no alternate truth or character rules.
"""
import copy
import os
import tempfile
from pathlib import Path
from contextlib import closing
import unittest
import test_v84_kausal_chain
from test_v84_kausal_chain import scene, MARA, JOHANN
from matrix_api import kernel
from matrix_api.seed_builtin import seed_if_missing
from matrix_api.db import connect, init_schema, GASTHAUS_ID
from matrix_api.repos import create_session, save_session, get_session
from test_v87_regie_kette import ROBERT, CLARA


class CompleteDirectedEffects(unittest.TestCase):
    def sample(self):
        s, pending, one = scene('Johann hilft Mara beim Aufraeumen')
        people = [MARA, JOHANN, ROBERT, CLARA]
        s['scene']['presentIds'] = [x['id'] for x in people]
        s['scene']['hearsIds'] = list(s['scene']['presentIds'])
        sources = [one]
        for i, figure in enumerate((ROBERT, CLARA), 2):
            fact = kernel.make_fact(turn=2, actorId=figure['id'], targetId=MARA['id'],
                kind='speech', event_kind='speech', text=f'{figure["name"]} spricht mit Mara.',
                sourceTurnId='tt1', authority='character', validated=True)
            fact['id'] = f'evt{i}'
            fact['plan'] = {'event_kind':'report', 'speech_act':'report', 'source':'llm',
                            'validation_status':'validated'}
            s['facts'].append(fact)
            s['witnessKnowledge'].append({'character_id':MARA['id'], 'fact_id':fact['id'], 'access':'heard'})
            pending[0]['events'].append({'fact':fact, 'access':'heard'})
            sources.append(fact)
        notes = {
            JOHANN['id']: 'Johann wird seit Jahren als verlässlicher Helfer erlebt',
            ROBERT['id']: 'Robert wird seit Jahren als unberechenbar erlebt',
            CLARA['id']: 'Clara wird seit Jahren als aufmerksame Freundin erlebt',
        }
        for figure in (ROBERT, CLARA):
            s['relations'].append({'fromId':MARA['id'],'toId':figure['id'], 'trust':.4,
                                   'closeness':.2,'fear':.1,'note':notes[figure['id']], 'kind':'knows'})
        s['relations'][0]['note'] = notes[JOHANN['id']]
        row = {'figur':MARA['name'], 'aktivierung':.8,
               'beziehung_aenderung':[{'zu':figure['name'], 'trust': .1}
                                      for figure in (JOHANN, ROBERT, CLARA)]}
        return s, pending, sources, notes, row, people

    def test_three_individual_relationship_effects_are_all_written_and_reloadable(self):
        s, pending, sources, notes, row, people = self.sample()
        expected = ['beziehung.0.trust', 'beziehung.1.trust', 'beziehung.2.trust']
        self.assertEqual(kernel.appraisal_effect_fields(row), expected)
        row['_kausalpruefung']={'pruefungen':[
            {'feld': f, 'urteil':'gestuetzt', 'factId':src['id'], 'beleg':src['text'],
             'dispositionsBeleg':notes[person['id']], 'richtung':('steigt' if kernel.appraisal_field_sign(row,f)>0 else 'sinkt'),
             'begruendung': f'{notes[person["id"]]} – dieses Ereignis wird fuer die Beziehung beruecksichtigt.'}
            for f,src,person in zip(expected,sources,(JOHANN,ROBERT,CLARA))]}
        out,proto=kernel.apply_appraisals(s,pending,{'bewertungen':[row]},natives=people)
        self.assertFalse(proto[0]['rejects'],proto)
        self.assertEqual(len(proto[0]['relationDelta']),3)
        self.assertEqual({r['toId'] for r in proto[0]['relationDelta']},
                         {JOHANN['id'],ROBERT['id'],CLARA['id']})
        self.assertEqual([r['trust'] for r in out['relations']],[.46,.46,.46])
        second,_ = kernel.apply_appraisals(out,pending,{'bewertungen':[row]},natives=people)
        self.assertEqual(second['relations'],out['relations'])
        # Writer -> canonical SQLite -> new connection -> Reader -> idempotency
        prior = os.environ.pop('MATRIX_SKIP_SEED', None)
        try:
            with tempfile.TemporaryDirectory() as tmp:
                dbpath = Path(tmp) / 'contract.sqlite'
                with closing(connect(dbpath)) as db:
                    init_schema(db)
                    seed_if_missing(db)  # temp DB test fixture; independent of test runner
                    create_session(db, {'id':out['id'], 'worldId':GASTHAUS_ID,
                                        'name':'Drei Relationen', 'presentIds':s['scene']['presentIds']}, 'admin')
                    save_session(db, 'admin', out)
                    db.commit()
                with closing(connect(dbpath)) as db:
                    reloaded = get_session(db, 'admin', out['id'])
                    self.assertEqual(db.execute('PRAGMA quick_check').fetchone()[0], 'ok')
                self.assertEqual({r['toId']:r['trust'] for r in reloaded['relations'] if r.get('fromId')==MARA['id'] and r.get('toId') in {JOHANN['id'],ROBERT['id'],CLARA['id']}},
                                 {r['toId']:r['trust'] for r in out['relations'] if r.get('fromId')==MARA['id']})
                replayed, _ = kernel.apply_appraisals(reloaded,pending,{'bewertungen':[row]},natives=people)
                self.assertEqual(replayed['relations'], reloaded['relations'])
                ctx = kernel.brain_context(reloaded,MARA['id'])
                self.assertFalse(ctx['writable'])
                self.assertIn('currentState',ctx)
        finally:
            if prior is not None:
                os.environ['MATRIX_SKIP_SEED'] = prior

    def test_one_persons_directed_relation_cannot_prove_anothers(self):
        s, pending, sources, notes, row, people = self.sample()
        row['beziehung_aenderung']=[{'zu':ROBERT['name'],'trust':.1}]
        row['_kausalpruefung']={'pruefungen':[
            {'feld':'beziehung.0.trust', 'urteil':'gestuetzt', 'factId':sources[1]['id'],
             'beleg':sources[1]['text'], 'dispositionsBeleg':notes[JOHANN['id']], 'richtung':'steigt',
             'begruendung': notes[JOHANN['id']]+' – solle auf Robert uebertragen werden.'}]}
        out,proto=kernel.apply_appraisals(s,pending,{'bewertungen':[row]},natives=people)
        self.assertEqual(out['relations'],s['relations'])
        self.assertIn('disposition_nicht_belegt:beziehung.0.trust',proto[0]['rejects'])
        self.assertTrue(kernel.pending_appraisals(out,people))

if __name__=='__main__': unittest.main()
