"""V85 independent regression targets: do not replace older regression tests."""
import unittest
from test_v84_kausal_chain import scene, proposed, proofs, NATIVES
from matrix_api import kernel


class RegressionForV85(unittest.TestCase):
    def test_one_cause_can_commit_two_independent_relation_dimensions(self):
        s, p, e = scene('Danke fuer deine Hilfe')
        row = proposed(state=0, trust=.1, closeness=.1, feeling='')
        row['_kausalpruefung'] = proofs(row, e)
        after, protocol = kernel.apply_appraisals(s, p, {'bewertungen': [row]}, natives=NATIVES)
        r = after['relations'][0]
        self.assertAlmostEqual(r['trust'], .46)
        self.assertAlmostEqual(r['closeness'], .28)
        self.assertEqual(len(protocol[0]['relationDelta']), 1)  # one dyad write with both columns

    def test_failed_review_must_not_consume_perceived_event(self):
        s, p, e = scene('Danke fuer deine Hilfe')
        result = {'bewertungen': [proposed(state=.1, trust=.1, closeness=.1, feeling='Freude')]}
        unsuccessful, protocol = kernel.apply_appraisals(s,p,result,natives=NATIVES)
        self.assertIn('kausalpruefung_fehlend:zustand.lust', protocol[0]['rejects'])
        self.assertNotIn(e['id'], unsuccessful['runtimes']['char_g7_mara'].get('appraisedFactIds',[]))
        self.assertEqual(len(kernel.pending_appraisals(unsuccessful,NATIVES)), 1)
        row = proposed(state=.1, trust=.1, closeness=.1, feeling='Freude')
        row['_kausalpruefung'] = proofs(row,e)
        recovered, protocol = kernel.apply_appraisals(unsuccessful,p,{'bewertungen':[row]},natives=NATIVES)
        self.assertGreater(recovered['runtimes']['char_g7_mara']['lust'],.05)
        self.assertAlmostEqual(recovered['relations'][0]['trust'],.46)
        self.assertAlmostEqual(recovered['relations'][0]['closeness'],.28)

    def test_partial_review_can_resume_without_reapplying_first_dimension(self):
        s,p,e=scene('Danke fuer deine Hilfe')
        row=proposed(state=0,trust=.1,closeness=.1,feeling='')
        row['_kausalpruefung']=proofs(row,e,fields=['beziehung.0.trust'])
        once,protocol=kernel.apply_appraisals(s,p,{'bewertungen':[row]},natives=NATIVES)
        self.assertAlmostEqual(once['relations'][0]['trust'],.46)
        self.assertAlmostEqual(once['relations'][0]['closeness'],.2)
        self.assertNotIn(e['id'],once['runtimes']['char_g7_mara'].get('appraisedFactIds',[]))
        row2=proposed(state=0,trust=.1,closeness=.1,feeling='')
        row2['_kausalpruefung']=proofs(row2,e)
        twice,protocol2=kernel.apply_appraisals(once,p,{'bewertungen':[row2]},natives=NATIVES)
        self.assertAlmostEqual(twice['relations'][0]['trust'],.46) # no reinforcement
        self.assertAlmostEqual(twice['relations'][0]['closeness'],.28)
        self.assertIn(e['id'],twice['runtimes']['char_g7_mara'].get('appraisedFactIds',[]))
        twice_again, _=kernel.apply_appraisals(twice,p,{'bewertungen':[row2]},natives=NATIVES)
        self.assertEqual(twice_again['relations'],twice['relations'])

    def test_explicit_negative_review_is_a_completed_zero_effect(self):
        s,p,e=scene('Danke fuer deine Hilfe')
        row=proposed(state=.1,trust=.1,closeness=.1,feeling='Freude')
        row['_kausalpruefung']=proofs(row,e,supported=False)
        after,diag=kernel.apply_appraisals(s,p,{'bewertungen':[row]},natives=NATIVES)
        self.assertEqual(after['relations'][0]['trust'],.4)
        self.assertIn(e['id'],after['runtimes']['char_g7_mara'].get('appraisedFactIds',[]))

    def test_missing_character_review_must_not_mark_finished(self):
        s,p,e=scene('Danke fuer deine Hilfe')
        after,diag=kernel.apply_appraisals(s,p,{'bewertungen':[]},natives=NATIVES)
        self.assertIn('keine_bewertung',diag[0]['rejects'])
        self.assertNotIn(e['id'],after['runtimes']['char_g7_mara'].get('appraisedFactIds',[]))

if __name__ == '__main__': unittest.main()
