"""V92 canonical Puppet writer: capability -> facts -> SQLite -> reader/isolation.

No live provider or browser is assumed. All SQLite paths are temporary.
"""
import copy
import json
import os
from contextlib import closing
from pathlib import Path
from tempfile import TemporaryDirectory
import unittest
from unittest.mock import patch

import test_v84_kausal_chain  # preexisting offline Flask import shim for repo unit tests
from matrix_api import kernel
from matrix_api.db import GASTHAUS_ID, connect, init_schema
from matrix_api.repos import create_session, get_session, save_session

ROOT=Path(__file__).resolve().parents[1]
SEED=json.loads((ROOT/'matrix_api/gasthaus_seed.json').read_text(encoding='utf8'))
MARA=next(c for c in SEED['characters'] if c['name']=='Mara Nowak')
JOHANN=next(c for c in SEED['characters'] if c['name']=='Johann Bruckner')


def initial(session_id='v92puppet'):
    return {
        'id':session_id, 'userId':'admin', 'worldId':GASTHAUS_ID,
        'role':'puppet', 'turnIndex':0,
        'scene':{'presentIds':[MARA['id'],JOHANN['id']],
                 'hearsIds':[MARA['id'],JOHANN['id']],
                 'seesIds':[MARA['id'],JOHANN['id']], 'placeId':'schankraum'},
        'runtimes':{MARA['id']:{'characterId':MARA['id'],'gagged':True,'canSpeak':False},
                    JOHANN['id']:{'characterId':JOHANN['id'],'canSpeak':True}},
        'turns':[], 'facts':[], 'relations':[], 'turnTruths':[],
        'memories':[], 'witnessKnowledge':[],
    }


class PuppetWriterCausality(unittest.TestCase):
    def test_gagged_speech_alone_is_not_a_turn_fact_relationship_or_memory(self):
        before=initial()
        after=kernel.commit_puppet(before,MARA,'Hallo Johann',target_id=JOHANN['id'],actions=[])
        self.assertEqual(after,before)
        self.assertEqual(before['turnIndex'],0)
        self.assertFalse(after['turns'])
        self.assertFalse(after['facts'])
        self.assertFalse(after['relations'])
        self.assertFalse(after['turnTruths'])
        self.assertFalse(after['memories'])

    def test_gagged_figure_can_still_execute_genuinely_possible_body_action(self):
        before=initial()
        after=kernel.commit_puppet(before,MARA,'Hallo Johann',actions=[{
            'text':'geht zur Tür','targetId':None,'effectKind':None,'effectValid':False,
        }])
        self.assertEqual(after['turnIndex'],1)
        self.assertEqual(len(after['turns']),1)
        self.assertEqual(after['turns'][0]['speech'],'')
        self.assertEqual(after['turns'][0]['action'],'geht zur Tür')
        self.assertTrue(any(f['kind']=='action' and f['text']=='geht zur Tür' and f['validated'] for f in after['facts']))
        self.assertFalse([f for f in after['facts'] if f['kind']=='speech'])
        self.assertFalse(after['relations'])
        self.assertTrue(any(m.get('kind')=='getan' and m.get('characterId')==MARA['id'] for m in after['memories']))

    def test_gagged_and_immobile_figure_cannot_create_rejected_body_turn(self):
        before=initial()
        before['runtimes'][MARA['id']]['canMove']=False
        after=kernel.commit_puppet(before,MARA,'Hallo Johann',actions=[{
            'text':'geht zur Tür','targetId':None,'effectKind':None,'effectValid':False,
        }])
        self.assertEqual(after,before)

    def test_valid_speech_keeps_relationship_and_trace(self):
        before=initial()
        before['runtimes'][MARA['id']]={'characterId':MARA['id'],'canSpeak':True,'gagged':False}
        after=kernel.commit_puppet(before,MARA,'Hallo Johann',target_id=JOHANN['id'],actions=[])
        self.assertEqual(after['turnIndex'],1)
        said=[f for f in after['facts'] if f['kind']=='speech']
        self.assertEqual(len(said),1)
        self.assertEqual(said[0]['text'],'Hallo Johann')
        self.assertEqual(said[0]['actorId'],MARA['id'])
        self.assertEqual(said[0]['targetId'],JOHANN['id'])
        self.assertEqual(len(after['relations']),2)
        self.assertTrue(any(m.get('kind')=='gesagt' and m.get('factId')==said[0]['id'] for m in after['memories']))
        self.assertEqual(before['turnIndex'],0)

    def test_canonical_sqlite_reader_refuses_ghost_then_roundtrips_real_action_isolated(self):
        with TemporaryDirectory() as td, patch.dict(os.environ,{'MATRIX_SKIP_SEED':'0','PYTEST_CURRENT_TEST':''}):
            dbfile=Path(td)/'only_v92_test.sqlite'
            with closing(connect(dbfile)) as conn:
                init_schema(conn)
                create_session(conn, {'id':'v92puppet','worldId':GASTHAUS_ID,'name':'Puppet',
                                      'presentIds':[MARA['id'],JOHANN['id']]},'admin')
                create_session(conn, {'id':'v92other','worldId':GASTHAUS_ID,'name':'Other',
                                      'presentIds':[MARA['id'],JOHANN['id']]},'admin')
                start=initial()
                save_session(conn,'admin',start)
                untouched=get_session(conn,'admin','v92other')
                conn.commit()
                stored_before=get_session(conn,'admin','v92puppet')
            blocked=kernel.commit_puppet(stored_before,MARA,'Hallo Johann',target_id=JOHANN['id'],actions=[])
            with closing(connect(dbfile)) as conn:
                save_session(conn,'admin',blocked)
                conn.commit()
                loaded=get_session(conn,'admin','v92puppet')
                other=get_session(conn,'admin','v92other')
                self.assertEqual(loaded['turnIndex'],stored_before['turnIndex'])
                self.assertEqual(loaded['turns'],stored_before['turns'])
                self.assertEqual(loaded['facts'],stored_before['facts'])
                self.assertEqual(loaded['relations'],stored_before['relations'])
                self.assertEqual(other['turnIndex'],untouched['turnIndex'])
            act=kernel.commit_puppet(loaded,MARA,'',actions=[{
                'text':'geht zur Tür','targetId':None,'effectKind':None,'effectValid':False,
            }])
            with closing(connect(dbfile)) as conn:
                save_session(conn,'admin',act)
                conn.commit()
            with closing(connect(dbfile)) as conn:
                persisted=get_session(conn,'admin','v92puppet')
                isolated=get_session(conn,'admin','v92other')
                self.assertEqual(conn.execute('PRAGMA quick_check').fetchone()[0],'ok')
                self.assertEqual(persisted['turnIndex'],stored_before['turnIndex']+1)
                self.assertEqual(persisted['turns'][-1]['action'],'geht zur Tür')
                self.assertEqual(persisted['turns'][-1]['speech'],'')
                self.assertFalse([f for f in persisted['facts'] if f.get('kind')=='speech'])
                self.assertEqual(isolated['turnIndex'],untouched['turnIndex'])
                self.assertEqual(isolated['turns'],untouched['turns'])
                self.assertEqual(isolated['facts'],untouched['facts'])


class FigureWriterCausality(unittest.TestCase):
    def truth(self, session, *, input_text=''):
        return kernel.bind_turn_truth(
            user_id='admin', world_id=session['worldId'], session_id=session['id'],
            role='character', authority='character', speaker_id=MARA['id'],
            avatar_id=None, target_id=JOHANN['id'],
            present_ids=session['scene']['presentIds'],
            hears_ids=session['scene']['hearsIds'], input_kind='autochat' if not input_text else 'speech',
            text=input_text, input_actor_id=JOHANN['id'],
        )

    def test_autochat_gagged_speech_writes_no_ghost_and_keeps_turn_index(self):
        before=initial('v92fig_gagged')
        after=kernel.commit_turn(before,truth=self.truth(before),speaker=MARA,present=[MARA,JOHANN],
                                 result={'speech':'Ich kann reden','proposals':{}})
        self.assertEqual(after,before)
        self.assertFalse(after['turns'])
        self.assertFalse(after['facts'])
        self.assertFalse(after['turnTruths'])

    def test_autochat_valid_speech_writes_canon_and_valid_action_survives_gag(self):
        before=initial('v92fig_good')
        before['runtimes'][MARA['id']].update({'gagged':False,'canSpeak':True})
        said=kernel.commit_turn(before,truth=self.truth(before),speaker=MARA,present=[MARA,JOHANN],
                                result={'speech':'Guten Tag','proposals':{}})
        self.assertEqual(said['turnIndex'],1)
        self.assertEqual(said['turns'][-1]['speech'],'Guten Tag')
        self.assertTrue(any(f['kind']=='speech' and f['text']=='Guten Tag' for f in said['facts']))
        gagged=initial('v92fig_act')
        acted=kernel.commit_turn(gagged,truth=self.truth(gagged),speaker=MARA,present=[MARA,JOHANN],
                                 result={'speech':'*geht zur Tür*','action':'geht zur Tür','proposals':{}})
        self.assertEqual(acted['turnIndex'],1)
        self.assertEqual(acted['turns'][-1]['speech'],'')
        self.assertEqual(acted['turns'][-1]['action'],'geht zur Tür')
        self.assertTrue(any(f['kind']=='action' and f['validated'] and f['text']=='geht zur Tür' for f in acted['facts']))
        self.assertFalse(any(f['kind']=='speech' for f in acted['facts']))

    def test_two_phase_gagged_reply_keeps_user_input_pending_not_fabricated_reply(self):
        before=initial('v92fig_two_phase')
        truth=self.truth(before,input_text='Hallo Mara')
        pending=kernel.commit_turn(before,truth=truth,speaker=MARA,present=[MARA,JOHANN],
                                   result={},phase='input')
        self.assertEqual(pending['pendingInputTurnId'],truth['id'])
        rejected=kernel.commit_turn(pending,truth=truth,speaker=MARA,present=[MARA,JOHANN],
                                    result={'speech':'Kann nicht reden'},phase='response')
        self.assertEqual(rejected,pending)
        self.assertEqual(rejected['pendingInputTurnId'],truth['id'])
        self.assertFalse(any(x['speakerId']==MARA['id'] and x.get('speech')=='—' for x in rejected['turns']))
        self.assertFalse(any(f.get('actorId')==MARA['id'] and f.get('text')=='—' for f in rejected['facts']))


if __name__=='__main__':unittest.main()
