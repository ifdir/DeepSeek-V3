"""V90: V89 real recorded semantic components; tests canonical binder/SQLite/followturn.
No live provider is simulated or counted as an HTTP acceptance. Test databases are temporary.
"""
import copy
import os
from contextlib import closing
from pathlib import Path
import tempfile
import unittest
import test_v84_kausal_chain
from test_v87_regie_kette import SEED, BY_NAME, MARA, ROBERT, make_scene
from matrix_api import kernel
from matrix_api.db import connect, init_schema
from matrix_api.seed_builtin import seed_if_missing
from matrix_api.repos import create_session, get_session, save_session
ROOT=Path(__file__).resolve().parents[1]
JOHANN=BY_NAME['Johann Bruckner']
TEXT='Klatsch mara fest auf ihren Arsch, und sage ihr das du sie heiss findest'
# Component structure was recorded by the provider in the submitted V89 live log.
# No prepared fact, relationship, appraisal, or turn outcome is supplied.
PLAN={'komponenten':[
 {'typ':'handlung','akteur':'Johann Bruckner','ziel':'Mara Nowak',
  'segment':'Klatsch mara fest auf ihren Arsch',
  'beschreibung':'Johann Bruckner klatscht Mara Nowak fest auf ihren Arsch.',
  'wirkung':'gewalt'},
 {'typ':'rede','akteur':'Johann Bruckner','ziel':None,
  'segment':'sage ihr das du sie heiss findest','inhalt':'Ich finde dich heiß.',
  'redeverb':'sage','adressat':'Mara Nowak'}], 'unklar':[]}
CAST=[JOHANN,MARA]

def begin():
 return make_scene(session_id='ses_v90_regie',present=[JOHANN['id'],MARA['id']])

class V90LiveFixtureBinding(unittest.TestCase):
 def test_user_log_same_plan_without_actor_is_not_a_successful_regie(self):
  # What happened in V89: targetId named Johann; actorId was empty.
  s=begin()
  resolved=kernel.resolve_regie_actor_target(actor_id=None,target_id=JOHANN['id'],text=TEXT,figures=CAST)
  self.assertEqual(resolved[0],'regie')
  self.assertEqual(resolved[1],JOHANN['id'])
  bound=kernel.bind_regie_components(TEXT,PLAN,directed_id=resolved[0],
       figures=CAST,present_ids=s['scene']['presentIds'],ui_target_id=resolved[1],avatar_id=None)
  self.assertFalse(bound['actions']);self.assertFalse(bound['speech'])
  self.assertEqual([r['grund'] for r in bound['unclear']],['akteur_nicht_belegt']*2)

 def test_user_log_same_plan_with_selected_johann_binds_action_and_speech(self):
  s=begin()
  a=kernel.apply_regie(s,SEED['world'],TEXT,actor_id=JOHANN['id'],target_id=MARA['id'],
                       components=copy.deepcopy(PLAN),present=CAST)
  self.assertEqual(s['turnIndex'],0)
  self.assertEqual(a['turnIndex'],1)
  row=next(r for r in a['turns'] if r.get('role')=='regie')
  self.assertEqual(row['directiveFor'],JOHANN['id'])
  self.assertEqual(row['regieEffects']['unclear'],[])
  self.assertEqual(len(row['regieEffects']['executed']),1)
  self.assertTrue(row['regieEffects']['executed'][0]['validated'])
  self.assertEqual(len(row['regieEffects']['speech']),1)
  physical=next(f for f in a['facts'] if f.get('kind')=='action')
  self.assertTrue(physical['validated'])
  self.assertEqual(physical['actorId'],JOHANN['id'])
  self.assertEqual(physical['targetId'],MARA['id'])
  self.assertEqual(physical['authority'],'regie')
  self.assertTrue(any(w['character_id']==MARA['id'] and w['access']=='affected' for w in a['witnessKnowledge']))
  self.assertEqual(kernel.autochat_gate(a,CAST,1)['speakerId'],MARA['id'])

 def test_incorrect_ui_target_does_not_become_the_doer(self):
  s=begin()
  a=kernel.apply_regie(s,SEED['world'],TEXT,actor_id=JOHANN['id'],target_id=JOHANN['id'],
                      components=copy.deepcopy(PLAN),present=CAST)
  act=next(f for f in a['facts'] if f.get('kind')=='action')
  self.assertEqual(act['actorId'],JOHANN['id'])
  self.assertEqual(act['targetId'],MARA['id'])

 def test_actor_named_in_the_order_works_without_ui_default(self):
  t='Johann Bruckner klatscht Mara Nowak fest auf ihren Arsch.'
  pl={'komponenten':[{'typ':'handlung','akteur':'Johann Bruckner','ziel':'Mara Nowak',
     'segment':t,'beschreibung':t,'wirkung':'gewalt'}],'unklar':[]}
  a=kernel.apply_regie(begin(),SEED['world'],t,actor_id=None,target_id=None,
                       components=pl,present=CAST)
  act=next(f for f in a['facts'] if f.get('kind')=='action')
  self.assertEqual(act['actorId'],JOHANN['id'])
  self.assertTrue(act['validated'])

 def test_sqlite_reload_two_figures_followturn_and_isolation(self):
  with tempfile.TemporaryDirectory() as tmp:
   dbpath=Path(tmp)/'test.sqlite'
   with closing(connect(dbpath)) as conn:
    init_schema(conn)
    seed_if_missing(conn)
    create_session(conn,{'id':'ses_v90_regie','worldId':SEED['world']['id'], 'name':'Regie',
        'presentIds':[JOHANN['id'],MARA['id']]},'admin')
    create_session(conn,{'id':'ses_v90_other','worldId':SEED['world']['id'], 'name':'Other',
        'presentIds':[ROBERT['id']]},'admin')
    regie=kernel.apply_regie(begin(),SEED['world'],TEXT,actor_id=JOHANN['id'],
                target_id=MARA['id'],components=copy.deepcopy(PLAN),present=CAST)
    save_session(conn,'admin',regie); conn.commit()
   with closing(connect(dbpath)) as conn:
    one=get_session(conn,'admin','ses_v90_regie')
    unrelated=get_session(conn,'admin','ses_v90_other')
    self.assertEqual(kernel.autochat_gate(one,CAST,1)['speakerId'],MARA['id'])
    self.assertTrue(any(f['actorId']==JOHANN['id'] and f['kind']=='action'
            for f in one['facts']))
    # Deterministic stored reply only; NOT a prediction of model personality.
    t=kernel.normalize_truth({'userId':'admin','worldId':one['worldId'],
        'sessionId':one['id'],'role':'character','authority':'character',
        'speakerId':MARA['id'],'targetId':JOHANN['id'],'inputKind':'autochat',
        'presentIds':one['scene']['presentIds'], 'hearsIds':one['scene']['hearsIds'],
        'seesIds':one['scene']['seesIds'],'inputActorId':'user','text':''})
    reacted=kernel.commit_turn(one,truth=t,speaker=MARA,present=CAST,
           result={'speech':'Lass das!', 'action':'Mara tritt zurück.',
                   'proposals':{'plan':{'event_kind':'refusal','speech_act':'refuse'}}})
    save_session(conn,'admin',reacted);conn.commit()
   with closing(connect(dbpath)) as conn:
    final=get_session(conn,'admin','ses_v90_regie')
    other=get_session(conn,'admin','ses_v90_other')
    self.assertEqual(conn.execute('PRAGMA quick_check').fetchone()[0],'ok')
    self.assertEqual(final['turns'][-1]['speakerId'],MARA['id'])
    self.assertEqual(final['turns'][-1]['speech'],'Lass das!')
    self.assertTrue(any(f.get('actorId')==JOHANN['id'] and f.get('kind')=='action'
                        and f.get('validated') for f in final['facts']))
    self.assertTrue(any(f.get('text')=='Lass das!' for f in kernel.brain_context(final,JOHANN['id'])['facts']))
    self.assertEqual(unrelated['facts'],other['facts'])
    self.assertEqual(unrelated['turns'],other['turns'])

 def test_existing_frontend_reaches_same_ids_and_mixed_order_followup(self):
  ts=(ROOT/'src/routes/chat.$sessionId.tsx').read_text(encoding='utf8')
  js='\n'.join(f.read_text(encoding='utf8') for f in (ROOT/'frontend_dist/assets').glob('index-*.js'))
  api=(ROOT/'matrix_api/app.py').read_text(encoding='utf8')
  self.assertIn('actorId: regieActorId || undefined',ts)
  self.assertIn('targetId: targetId || undefined',ts)
  self.assertIn('Angewiesene Figur (wer handelt;',ts)
  self.assertIn('Direktes Ziel (betroffene Figur',ts)
  self.assertIn('Angewiesene Figur (wer handelt;',js)
  self.assertIn('figureCommitted) queueAuto',ts)
  self.assertRegex(js,r'\w+\.autoChat\.enabled\?\w+\.autoChat\.turns:1')
  self.assertIn('const figureDirective = actAlreadyWritten && speechDirective ? speechDirective : msg',ts)
  self.assertNotIn('body.get("actorId") or body.get("actor_id") or body.get("targetId")',api)
  self.assertIn('REGIE_AKTEUR_NICHT_GEBUNDEN',api)

if __name__=='__main__':unittest.main()
