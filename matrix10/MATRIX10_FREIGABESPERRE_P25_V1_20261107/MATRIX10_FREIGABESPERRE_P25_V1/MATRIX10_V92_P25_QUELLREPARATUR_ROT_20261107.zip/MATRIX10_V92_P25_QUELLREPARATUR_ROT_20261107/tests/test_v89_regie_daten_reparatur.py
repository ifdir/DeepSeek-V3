"""V89 specific regression checks. All DB writes are to temporary fixtures.
No fake provider response is counted as live-LMM proof; provider/UI is still RED.
"""
from __future__ import annotations
import hashlib
import json
import os
from pathlib import Path
import sqlite3
import tempfile
import unittest
from unittest.mock import patch
from contextlib import closing

import test_v84_kausal_chain  # repository's import-only Flask shim, not HTTP
from matrix_api import kernel, llm_contract
from matrix_api.db import connect, init_schema
from matrix_api.repos import create_session, get_session, save_session
import datenbank_projekt_v81 as dbprep
from test_v87_regie_kette import make_scene, apply_order, FIGS, ROBERT, MARA, CLARA

ROOT = Path(__file__).resolve().parents[1]


def make_source(path: Path, name: str, with_key=False) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with closing(connect(path)) as c:
        init_schema(c)
        c.execute("INSERT OR IGNORE INTO users(id,json) VALUES(?,?)", ('admin', '{"id":"admin"}'))
        # The provenance marker is a real user-owned preference record.
        c.execute("INSERT OR REPLACE INTO preferences(id,user_id,json) VALUES(?,?,?)",
                  ('pref_' + name, 'admin', json.dumps({'id': 'pref_' + name, 'userId': 'admin'})))
        if with_key:
            c.execute("INSERT INTO config(scope,scope_id,json) VALUES(?,?,?)",
                      ('user','admin',json.dumps({'scope':'user','scope_id':'admin','provider':'openai',
                                                  'model':'test-model','apiKey':'TEST_ONLY_NOT_REAL_KEY'})))
        c.commit()


class V89DataChain(unittest.TestCase):
    def test_only_latest_previous_database_merged_with_last_provider_settings(self):
        with tempfile.TemporaryDirectory() as tmp:
            base=Path(tmp)
            v85=base/'MATRIX10_V85_BASE'/'data'/'matrix10.sqlite'
            v88=base/'MATRIX10_V88_PRIOR'/'MATRIX10_V88_PRIOR'/'data'/'matrix10.sqlite'
            new=base/'MATRIX10_V89_TEST'
            new.mkdir()
            make_source(v85,'v85',True)
            make_source(v88,'v88',False)
            old_hashes=[hashlib.sha256(p.read_bytes()).hexdigest() for p in (v85,v88)]
            choices=dbprep.previous_release_dbs(new)
            self.assertEqual([v for v,_ in choices], [88,85])
            self.assertEqual(dbprep.newest_unambiguous(choices),v88.resolve())
            with patch.object(dbprep, 'ROOT', new), patch.dict(os.environ, {'MATRIX_SKIP_SEED':'1'}, clear=True):
                good,msg=dbprep.prepare_data()
                self.assertTrue(good,msg)
                self.assertIn('V85',msg)
                self.assertTrue(dbprep.project_db_path(new).exists())
                with closing(sqlite3.connect(dbprep.project_db_path(new))) as c:
                    self.assertEqual(c.execute("SELECT count(*) FROM preferences WHERE id='pref_v88'").fetchone()[0],1)
                    self.assertEqual(c.execute("SELECT count(*) FROM preferences WHERE id='pref_v85'").fetchone()[0],0)
                    row=c.execute("SELECT json FROM config WHERE scope='user' AND scope_id='admin'").fetchone()
                    self.assertTrue(row)
                    self.assertEqual(json.loads(row[0])['apiKey'],'TEST_ONLY_NOT_REAL_KEY')
                    self.assertEqual(c.execute('PRAGMA quick_check').fetchone()[0],'ok')
                again,msg=dbprep.prepare_data()
                self.assertTrue(again,msg)
            self.assertEqual([hashlib.sha256(p.read_bytes()).hexdigest() for p in (v85,v88)],old_hashes)

    def test_stale_launcher_db_cannot_override_newest_version(self):
        with tempfile.TemporaryDirectory() as tmp:
            base=Path(tmp)
            old=base/'MATRIX10_V85_PRIOR'/'data'/'matrix10.sqlite'
            recent=base/'MATRIX10_V88_PRIOR'/'data'/'matrix10.sqlite'
            new=base/'MATRIX10_V89_TEST'
            new.mkdir()
            make_source(old,'v85',True)
            make_source(recent,'v88',False)
            with patch.object(dbprep, 'ROOT', new), patch.dict(os.environ, {'MATRIX_DB':str(old),'MATRIX_SKIP_SEED':'1'}, clear=True):
                good,msg=dbprep.prepare_data()
                self.assertTrue(good,msg)
                with closing(sqlite3.connect(dbprep.project_db_path(new))) as c:
                    self.assertEqual(c.execute("SELECT count(*) FROM preferences WHERE id='pref_v88'").fetchone()[0],1)
                    self.assertEqual(c.execute("SELECT count(*) FROM preferences WHERE id='pref_v85'").fetchone()[0],0)
                    self.assertEqual(c.execute("SELECT count(*) FROM config WHERE scope='user'").fetchone()[0],1)

    def test_ambiguous_previous_version_stops_instead_of_guessing(self):
        with tempfile.TemporaryDirectory() as tmp:
            base=Path(tmp)
            root=base/'MATRIX10_V89_TEST';root.mkdir()
            for n in ('MATRIX10_V88_A','MATRIX10_V88_B'):
                make_source(base/n/'data'/'matrix10.sqlite',n)
            candidates=dbprep.previous_release_dbs(root)
            self.assertEqual(len(candidates),2)
            with self.assertRaisesRegex(ValueError,'Mehrere Datenbanken'):
                dbprep.newest_unambiguous(candidates)
            self.assertFalse(dbprep.project_db_path(root).exists())

    def test_provider_restore_never_crosses_users_or_overwrites_existing_config(self):
        with tempfile.TemporaryDirectory() as tmp:
            base=Path(tmp); src=base/'s.sqlite'; dest=base/'d.sqlite'
            make_source(src,'old',True); make_source(dest,'new',True)
            with closing(sqlite3.connect(dest)) as c:
                c.execute('UPDATE config SET json=? WHERE scope=? AND scope_id=?',
                          (json.dumps({'provider':'synapse','apiKey':'USER_REPLACED_KEY'}),'user','admin'))
                c.commit()
            self.assertEqual(dbprep.copy_missing_user_config(dest,src),0)
            with closing(sqlite3.connect(dest)) as c:
                self.assertEqual(json.loads(c.execute('SELECT json FROM config').fetchone()[0])['apiKey'],'USER_REPLACED_KEY')
                c.execute('DELETE FROM config');c.execute("DELETE FROM users WHERE id='admin'");c.commit()
            self.assertEqual(dbprep.copy_missing_user_config(dest,src),0)
            with closing(sqlite3.connect(dest)) as c:
                self.assertEqual(c.execute('SELECT count(*) FROM config').fetchone()[0],0)


class V89RegieBoundary(unittest.TestCase):
    def test_target_never_becomes_actor_when_missing(self):
        actor,target=kernel.resolve_regie_actor_target(actor_id=None,target_id=MARA['id'],
                                                       text='Schlage Mara',figures=FIGS)
        self.assertNotEqual(actor,MARA['id'])
        self.assertEqual(target,MARA['id'])

    def test_existing_real_regie_chain_robert_mara_writer_reader_next_turn(self):
        scene=apply_order(make_scene())
        hit=next(f for f in scene['facts'] if f.get('kind')=='action' and f.get('actorId')==ROBERT['id'])
        self.assertTrue(hit['validated'])
        self.assertEqual(hit['targetId'],MARA['id'])
        picked=kernel.autochat_gate(scene,FIGS,2)
        self.assertEqual(picked['speakerId'],MARA['id'])
        self.assertTrue(any(w.get('character_id')==MARA['id'] and w.get('access')=='affected'
                            for w in scene['witnessKnowledge']))
        self.assertFalse(any(w.get('character_id')==CLARA['id'] for w in scene['witnessKnowledge']))

    def test_semantics_without_provider_returns_none_not_a_successful_plan(self):
        with patch.object(llm_contract,'_routing',return_value={'allowed':False}):
            result=llm_contract.extract_regie_components(None,'admin','Robert schlaegt Mara',
                               directed_name='Robert',figures=['Robert','Mara'])
        self.assertIsNone(result)
        source=(ROOT/'matrix_api/app.py').read_text(encoding='utf-8')
        route=source[source.index('@app.post("/api/kernel/regie")'):source.index('@app.post("/api/kernel/puppet")')]
        self.assertIn('REGIE_SEMANTIK_NICHT_VERFUEGBAR',route)
        self.assertIn('REGIE_KEINE_VALIDIERTE_WIRKUNG',route)
        # Structural assertion only, NOT substituted for Flask HTTP test.
        self.assertLess(route.index('if regie_components is None and not (legacy_speech or legacy_action):'),
                        route.index('out = kernel.apply_regie('))
        self.assertLess(route.index('if not has_effect and not legacy_executed:'),
                        route.index('saved = kernel_session_response('))
        self.assertIn('legacy_speech, legacy_action = kernel.parse_regie_components',route)

    def test_flask_dependency_checked_before_first_database_is_initialized(self):
        start=(ROOT/'START.py').read_text(encoding='utf-8')
        self.assertLess(start.index('from flask import Flask as _flask_runtime_check'),
                        start.index('ready, explanation = prepare_data()'))
        self.assertIn('Keine Datenbank angelegt',start)

    def test_legacy_explicit_actions_remain_supported(self):
        self.assertEqual(kernel.parse_regie_components('*Robert hebt den Arm*'), (None,'Robert hebt den Arm'))
        self.assertEqual(kernel.parse_regie_components('Robert: Hallo Mara'), (None,None))

if __name__=='__main__': unittest.main()
