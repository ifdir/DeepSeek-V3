"""OPEN CONTRACT COUNTEREXAMPLE, intentionally RED until semantic interpretation is actually checked.
A true profile quote alone is not proof that a proposed trust increase is justified.
Do NOT add a hardcoded Mara/violence->feeling rule to make this green.
"""
import unittest
import test_v84_kausal_chain  # local Flask import-only shim; no HTTP path tested
from test_v87_regie_kette import make_scene,apply_order,FIGS,ROBERT,MARA
from matrix_api import kernel

class ExistingSourceNotEnough(unittest.TestCase):
    def test_true_profile_quote_must_not_authorize_unjustified_positive_trust(self):
        session=apply_order(make_scene())
        pending=kernel.pending_appraisals(session,FIGS)
        events=next(p for p in pending if p['id']==MARA['id'])['events']
        hit=next(e['fact'] for e in events if e['fact'].get('kind')=='action')
        row={'figur':MARA['name'],'aktivierung':.9,
             'beziehung_aenderung':[{'zu':ROBERT['name'],'trust':.15}],
             'grund':'angeblich Vertrauen durch Gewalt'}
        row['_kausalpruefung']={'pruefungen':[
            {'feld':'beziehung.0.trust', 'urteil':'gestuetzt', 'factId':hit['id'],
             'beleg':hit['text'], 'dispositionsBeleg':'trotzig unter Druck',
             'begruendung':'trotzig unter Druck: der Angriff habe angeblich Vertrauen geschaffen.'}]}
        after,protocol=kernel.apply_appraisals(session,pending,{'bewertungen':[row]},natives=FIGS)
        trust=next((r['trust'] for r in after['relations'] if r.get('fromId')==MARA['id'] and r.get('toId')==ROBERT['id']),.4)
        self.assertLessEqual(trust,.4,'Gültiges Profilzitat wird ohne tatsächliche semantische Begründung als positive Beziehungsevidenz akzeptiert')

if __name__=='__main__':unittest.main()
