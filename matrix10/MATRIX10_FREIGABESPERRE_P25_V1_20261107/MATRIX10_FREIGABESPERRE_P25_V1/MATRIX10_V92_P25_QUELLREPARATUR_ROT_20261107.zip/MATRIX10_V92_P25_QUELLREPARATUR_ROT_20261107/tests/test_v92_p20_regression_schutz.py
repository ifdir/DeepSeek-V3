"""Operator-visible regression guards: P16 positive and P19 negative behavior.

No model, customer DB, or network. Tests the canonical binder and body writer.
"""
import copy
import json
import re
import unittest
import tempfile
from contextlib import closing
from pathlib import Path
import test_v84_kausal_chain  # Provides the original offline Flask fallback for repo imports.
from matrix_api.db import connect, init_schema, GASTHAUS_ID
from matrix_api.seed_builtin import seed_if_missing
from matrix_api.repos import create_session, save_session, get_session
from matrix_api import kernel, god_extract
import test_v92_p17_klaerung as T


class P20RegressionSchutz(unittest.TestCase):
    def setUp(self):
        case = T.P17Kernel()
        case.setUp()
        self.f = case.f
        self.make_act = case.act
        self.M = self.f.M['id']
        self.S = T.S

    def effect(self, text, candidate, verified, figures=None):
        return kernel.apply_effect_check({'art':'gewalt','ziel':candidate}, text,
            {'bestaetigt':True,'zeit':'jetzt','ziel':verified,'beleg':'schubst'},
            figures=figures if figures is not None else self.f.chars)

    def bind(self, text, planner_target, reading_target, *, answer=None, figures=None, present=None):
        chars = figures if figures is not None else self.f.chars
        present = present if present is not None else self.f.present
        comp = self.make_act(text.rstrip('.'),planner_target,'gewalt')
        checks = {0: {'bestaetigt':True,'zeit':'jetzt','ziel':reading_target,'beleg':'schubst'}}
        comps = kernel.apply_component_effect_checks([comp],checks,figures=chars)
        if answer:
            at = text.index('Mara'); phrase = text[at:at + len(answer[0])]
            chars = kernel.with_klaerungen(chars,[{'text':phrase,'a':at,'b':at+len(phrase),'id':answer[1]}],text)
        bound = kernel.bind_puppet_input(text,{'komponenten':comps},self.f.J,chars,present,
                                          addressee_id=self.M)
        # Canonical writer receives the bound, verified effect.
        written = self.f.commit(bound)
        return bound, written

    def assert_hit_only(self, bound, written, fid):
        acts=bound['actions']
        self.assertEqual(len(acts),1, bound)
        self.assertEqual((acts[0]['targetId'],acts[0]['effectValid'],acts[0]['effectKind']),
                         (fid,True,'strike'), bound)
        self.assertGreater(T.pain(written,fid),0)
        for other in (self.M,self.S):
            if other!=fid:
                self.assertEqual(T.pain(written,other),0)
        self.assertTrue([fact for fact in written['facts']
                         if fact.get('kind')=='physical' and fact.get('targetId')==fid])

    def test_p16_same_generic_name_positive_effect(self):
        text='Johann schubst Mara.'
        self.assertEqual(self.effect(text,'Mara','Mara')['art'],'gewalt')
        b,s=self.bind(text,'Mara','Mara',answer=('Mara',self.M))
        self.assert_hit_only(b,s,self.M)
        b,s=self.bind(text,'Mara','Mara',answer=('Mara',self.S))
        self.assert_hit_only(b,s,self.S)

    def test_p16_second_duplicate_outside_scene_cannot_cancel_effect(self):
        other=copy.deepcopy(self.f.M)
        other['id']='char_external_mara_nowak'
        chars=self.f.chars+[other]
        text='Johann schubst Mara Nowak.'
        self.assertEqual(self.effect(text,'Mara Nowak','Mara Nowak',chars)['art'],'gewalt')
        b,s=self.bind(text,'Mara Nowak','Mara Nowak',figures=chars)
        self.assert_hit_only(b,s,self.M)

    def test_other_figure_full_name_reading_cannot_transfer_effect(self):
        text='Johann schubst Mara.'
        b,s=self.bind(text,'Mara Nowak','Mara Nowak',answer=('Mara',self.S))
        self.assertEqual(b['actions'][0]['targetId'],self.S)
        self.assertFalse(b['actions'][0]['effectValid'])
        self.assertEqual(T.pain(s,self.S),0)
        self.assertEqual(T.pain(s,self.M),0)
        self.assertTrue(any(a.get('grund')=='wirkungsziel_nach_klaerung_abweichend'
                             for a in b['ambiguous']))

    def test_unanswered_ambiguous_name_never_hits_body(self):
        text='Johann schubst Mara.'
        b,s=self.bind(text,'Mara','Mara')
        self.assertIsNone(b['actions'][0]['targetId'])
        self.assertFalse([f for f in s['facts'] if f.get('kind')=='physical'])

    def test_two_identical_names_at_two_places_keep_independent_body_targets(self):
        raw='Johann schubst Mara. Johann schubst Mara.'
        parts=[self.make_act('Johann schubst Mara','Mara','gewalt') for _ in range(2)]
        rd={i:{'bestaetigt':True,'zeit':'jetzt','ziel':'Mara','beleg':'schubst'} for i in range(2)}
        checked=kernel.apply_component_effect_checks(parts,rd,figures=self.f.chars)
        self.assertEqual([p['wirkung'] for p in checked],['gewalt','gewalt'])
        answers=[{'text':'Mara','a':m.start(),'b':m.end(),'id':self.M if i==0 else self.S}
                 for i,m in enumerate(re.finditer('Mara',raw))]
        projected=kernel.with_klaerungen(self.f.chars,answers,raw)
        bound=kernel.bind_puppet_input(raw,{'komponenten':checked},self.f.J,projected,self.f.present,
                                        addressee_id=self.M)
        self.assertEqual([(a['targetId'],a['effectValid'],a['effectKind']) for a in bound['actions']],
                         [(self.M,True,'strike'),(self.S,True,'strike')])
        written=self.f.commit(bound)
        self.assertEqual([f['targetId'] for f in written['facts'] if f.get('kind')=='physical'],
                         [self.M,self.S])

    def test_two_same_names_in_one_act_cannot_borrow_one_clarification_for_effect(self):
        raw='Johann schubst Mara neben Mara.'
        comp=self.make_act('Johann schubst Mara neben Mara','Mara','gewalt')
        checked=kernel.apply_component_effect_checks([comp],
             {0:{'bestaetigt':True,'zeit':'jetzt','ziel':'Mara','beleg':'schubst'}},figures=self.f.chars)
        names=list(re.finditer('Mara',raw))
        projected=kernel.with_klaerungen(self.f.chars,
            [{'text':'Mara','a':names[0].start(),'b':names[0].end(),'id':self.M}],raw)
        bound=kernel.bind_puppet_input(raw,{'komponenten':checked},self.f.J,projected,self.f.present,
                                        addressee_id=self.M)
        written=self.f.commit(bound)
        self.assertFalse([f for f in written['facts'] if f.get('kind')=='physical'])

    def test_god_knowledge_with_capitalised_object_remains_valid(self):
        phrase='Johann wei\u00df jetzt, dass Mara Geld versteckt.'
        raw={'anweisungen':[{'art':'wissen','ziel':'Johann Bruckner','text':phrase,'beleg':phrase}]}
        out,bad=god_extract.normalize_llm_instructions(raw,self.f.chars,source_text=phrase)
        self.assertEqual(bad,[],bad)
        self.assertEqual(len(out),1)
        self.assertEqual((out[0]['art'],out[0]['targetId'],out[0]['text']),('wissen',self.f.J['id'],phrase))

    def test_clarified_stoess_writer_survives_sqlite_new_connection_and_reader(self):
        text='Johann schubst Mara.'
        for final in (self.M,self.S):
            with self.subTest(target=final):
                bound,written=self.bind(text,'Mara','Mara',answer=('Mara',final))
                self.assert_hit_only(bound,written,final)
                with tempfile.TemporaryDirectory(prefix='matrix_p20_') as td:
                    filepath=Path(td)/'fresh.sqlite'
                    with closing(connect(filepath)) as c:
                        init_schema(c); seed_if_missing(c);c.commit()
                        original = c.execute('select world_id, owner_user_id, json from characters where id=?', (self.M,)).fetchone()
                        mirror = json.loads(original[2])
                        mirror['id'], mirror['name'], mirror['aliases'] = self.S, 'Mara Schmidt', []
                        c.execute('insert into characters(id,world_id,owner_user_id,json) values(?,?,?,?)',
                                  (self.S,original[0],original[1],json.dumps(mirror,ensure_ascii=False)))
                        create_session(c,{'id':written['id'],'worldId':GASTHAUS_ID,'name':'verification',
                                          'presentIds':self.f.present},'admin')
                        save_session(c,'admin',written);c.commit()
                    with closing(connect(filepath)) as c:
                        read=get_session(c,'admin',written['id'])
                        self.assertEqual(c.execute('PRAGMA quick_check').fetchone()[0],'ok')
                    self.assertGreater(T.pain(read,final),0)
                    self.assertGreater(float((kernel.brain_context(read,final).get('runtime') or {}).get('pain') or 0),0)
                    self.assertEqual([f.get('targetId') for f in read['facts'] if f.get('kind')=='physical'],[final])
                    other=self.S if final==self.M else self.M
                    self.assertEqual(T.pain(read,other),0)

    def test_god_knowledge_only_the_bound_holder_remembers(self):
        phrase='Johann wei\u00df jetzt, dass Mara Geld versteckt.'
        raw={'anweisungen':[{'art':'wissen','ziel':'Johann Bruckner','text':phrase,'beleg':phrase}]}
        ins,bad=god_extract.normalize_llm_instructions(raw,self.f.chars,source_text=phrase)
        self.assertFalse(bad)
        # God private knowledge writes its owner, not the other named figure.
        s=self.f.commit({'speech':'','actions':[],'ambiguous':[]})
        before=len(s.get('memories') or [])
        out=kernel.apply_god(s,ins[0]['text'],'knowledge',ins[0]['targetId'],natives=self.f.chars)
        new=(out.get('memories') or [])[before:]
        self.assertTrue([m for m in new if m.get('characterId')==self.f.J['id']])
        self.assertFalse([m for m in new if m.get('characterId') in (self.M,self.S)])
        self.assertTrue(out['godFacts'][-1]['applied'])

    def test_god_does_not_use_a_nonexistent_person(self):
        text='Ich streiche \u00fcber deinen Arsch.'
        raw={'anweisungen':[{'art':'handlung','ziel':'Mara Nowak','andere':'Johann Bruckner',
                               'text':'Mara Nowak streicht Johann Bruckner','beleg':text}]}
        out,bad=god_extract.normalize_llm_instructions(raw,self.f.chars,source_text=text)
        self.assertFalse(out)
        self.assertTrue(bad)

    def test_god_duplicate_knowledge_holder_is_ambiguous(self):
        other=copy.deepcopy(self.f.J)
        other['id']='johann_duplicated'; other['aliases']=[]
        text='Johann Bruckner wei\u00df jetzt alles.'
        raw={'anweisungen':[{'art':'wissen','ziel':'Johann Bruckner','text':text,'beleg':text}]}
        out,bad=god_extract.normalize_llm_instructions(raw,self.f.chars+[other],source_text=text)
        self.assertFalse(out)
        self.assertTrue(bad)

if __name__=='__main__':
    unittest.main(verbosity=2)
