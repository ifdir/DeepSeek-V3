"""P23 failure-oriented unit and SQLite tests, with real assertions.
No Flask/browser/LLM run is implied; those are separate release requirements.
"""
import copy
import json
import tempfile
import unittest
from contextlib import closing
from pathlib import Path

import test_v84_kausal_chain  # noqa: F401; offline repo import shim, NOT a Flask runtime
from matrix_api import kernel
from matrix_api.db import GASTHAUS_ID, connect, init_schema
from matrix_api.seed_builtin import seed_if_missing
from matrix_api.repos import create_session, get_session, save_session
import test_v92_p22_component_art_and_name_gate as P22
import test_v92_negativgrenzen as NG


class P23ContractChecks(unittest.TestCase):
    def setUp(self):
        self.f = NG.Negativgrenzen()
        self.f.setUp()
        self.j, self.m = self.f.J, self.f.M
        self.g = copy.deepcopy(self.j)
        self.g.update({"id": "char_gustav", "name": "Gustav Pfeiffer", "aliases": []})
        self.clara = copy.deepcopy(self.m)
        self.clara.update({"id": "char_clara", "name": "Clara", "aliases": []})
        self.cast = [self.j, self.m, self.g, self.clara]

    def test_authorized_absent_puppet_even_in_empty_scene(self):
        ids = [c['id'] for c in kernel.puppet_kind_cast(self.cast, [], self.clara['id'])]
        self.assertEqual(ids, [self.clara['id']])
        # The semantic cast is NOT a scene mutation; actual SQL presence only
        # changes within the successful writer transaction.
        session = {'scene': {'presentIds': []}}
        self.assertEqual(session['scene']['presentIds'], [])

    def test_own_puppet_and_present_cast_only(self):
        ids = [c['id'] for c in kernel.puppet_kind_cast(self.cast, [self.j['id']], self.clara['id'])]
        self.assertEqual(ids, [self.j['id'], self.clara['id']])
        self.assertNotIn(self.m['id'], ids)
        self.assertNotIn(self.g['id'], ids)

    def test_unknown_and_other_world_character_id_denied(self):
        for actor in ('', 'char_unauthorized', 'char_clara  ', self.m['name']):
            with self.subTest(actor=actor):
                with self.assertRaisesRegex(ValueError, 'authorized_cast'):
                    kernel.puppet_kind_cast(self.cast, [], actor)

    def test_duplicate_name_never_confers_puppet_id(self):
        second = {**self.clara, 'id': 'char_other_clara'}
        ids = [c['id'] for c in kernel.puppet_kind_cast([*self.cast, second], [], self.clara['id'])]
        self.assertEqual(ids, [self.clara['id']])

    def _vocative(self, raw, segment, target, cast=None):
        figures = cast if cast is not None else self.cast
        proposal = [{'typ':'rede', 'segment':segment,'akteur':target['name']}]
        self.assertEqual(kernel.component_kind_candidate_indices(raw,proposal,figures,self.j['id']),[0])
        return kernel.apply_component_kind_readings(
            raw, proposal,{0:{'art':'rede','beleg':segment}},
            figures=figures,actor_id=self.j['id'],actor_name=self.j['name'])

    def test_gustav_address_outside_model_segment_preserved(self):
        raw = 'Gustav, setz dich.'
        out = self._vocative(raw,'setz dich.',self.g)
        self.assertEqual(out[0]['typ'],'rede')
        self.assertEqual(out[0]['akteur'],self.j['name'])
        self.assertEqual(out[0]['segment'],raw.rstrip('.'))
        bind=kernel.bind_puppet_input(raw, {'komponenten':out},self.j,self.cast,[self.j['id'],self.g['id']],addressee_id=self.g['id'])
        self.assertFalse(bind.get('incomplete'),bind)
        self.assertEqual(bind['speech'],raw,bind)
        self.assertFalse(bind['actions'])

    def test_title_address_outside_model_segment_preserved(self):
        # Official source-token reading, not lexical prefix heuristics.
        gate=P22.P22NameGate();gate.setUp()
        raw='Herr Pfeiffer, setzen Sie sich.'
        cast=kernel.with_name_boundary_reading(raw,gate.figures,
            gate.reading(raw, wortklassen=['titel','name'],rolle='anrede'))
        proposal=[{'typ':'rede','segment':'setzen Sie sich.','akteur':'Gustav Pfeiffer'}]
        out=kernel.apply_component_kind_readings(raw,proposal,{0:{'art':'rede','beleg':'setzen Sie sich.'}},
                                                  figures=cast,actor_id='j',actor_name='Johann Bruckner')
        self.assertEqual((out[0]['typ'],out[0]['akteur']),('rede','Johann Bruckner'),out)
        self.assertEqual(out[0]['segment'],raw.rstrip('.'))

    def test_foreign_narration_never_becomes_puppet_speech(self):
        raw='Mara sagt: Hallo.'
        proposal=[{'typ':'rede','segment':'Mara sagt: Hallo.','akteur':self.m['name']}]
        out=kernel.apply_component_kind_readings(raw,proposal,{0:{'art':'rede','beleg':'Hallo'}},
                                                   figures=self.cast,actor_id=self.j['id'],actor_name=self.j['name'])
        self.assertEqual(out[0]['typ'],'unklar',out)

    def test_unreadable_or_foreign_speech_stays_uncommitted(self):
        raw='Mara sagt: Hallo.'
        out=kernel.apply_component_kind_readings(raw,
            [{'typ':'rede','segment':raw,'akteur':self.m['name']}],{0:{'art':'rede','beleg':raw}},
            figures=self.cast,actor_id=self.j['id'],actor_name=self.j['name'])
        bound=kernel.bind_puppet_input(raw,{'komponenten':out},self.j,self.cast,[self.j['id'],self.m['id']])
        self.assertEqual((bound.get('speech'),bound.get('actions')),('',[]),bound)
        self.assertTrue(bound.get('nichts_ausfuehrbar') or bound.get('incomplete'))

    def test_puppet_presence_writer_success_is_sqlite_visible(self):
        with tempfile.TemporaryDirectory(prefix='p23_sql_') as tmp:
            db_path=Path(tmp)/'p23.sqlite'
            with closing(connect(db_path)) as conn:
                init_schema(conn);seed_if_missing(conn)
                chars={json.loads(r[1])['name']:json.loads(r[1]) for r in conn.execute('select id,json from characters')}
                figure=next(v for k,v in chars.items() if 'Mara' in k)
                create_session(conn,{'id':'p23_s','worldId':GASTHAUS_ID,'name':'P23','presentIds':[self.j['id']]},'admin')
                s=get_session(conn,'admin','p23_s')
                before_facts=len(s['facts'])
                self.assertNotIn(figure['id'],s['scene']['presentIds'])
                # Simulate the route's writer boundary (after a successful
                # semantic read). The route's network/Flask lifecycle is not run.
                entered=kernel.apply_presence(s,figure['id'],natives=[figure])
                self.assertIn(figure['id'],entered['scene']['presentIds'])
                saved=kernel.commit_puppet(entered,figure,'Ich bin wieder da.',figures=[figure])
                self.assertTrue([f for f in saved['facts'] if f.get('kind')=='speech' and f.get('actorId')==figure['id']])
                save_session(conn,'admin',saved)
                conn.commit()
            with closing(connect(db_path)) as c:
                read=get_session(c,'admin','p23_s')
                self.assertEqual(c.execute('PRAGMA quick_check').fetchone()[0],'ok')
            self.assertIn(figure['id'],read['scene']['presentIds'])
            self.assertGreater(len(read['facts']),before_facts)
            self.assertTrue([f for f in read['facts'] if f.get('kind')=='speech' and f.get('actorId')==figure['id'] and f.get('validated')])

    def test_pending_attempt_unknown_is_not_safe_to_repeat(self):
        s={"pendingInputTurnId":"tt_pending","turnTruths":[{"id":"tt_pending", "text":"Hallo Mara", "speaker_id":self.m['id']}],
           "pendingInputAttempt":{"turnTruthId":"tt_pending", "attempts":[{"state":"laeuft","boot":"other_server"}]}}
        unclear=kernel.pending_input_view(s,boot_id="current_server",alive=lambda a:None)
        self.assertTrue(unclear['attemptRunning'])
        self.assertTrue(unclear['attemptUnklar'])
        stopped=kernel.pending_input_view(s,boot_id="current_server",alive=lambda a:False)
        self.assertFalse(stopped['attemptRunning'])
        self.assertFalse(stopped['attemptUnklar'])
        running=kernel.pending_input_view(s,boot_id="other_server",alive=lambda a:False)
        self.assertTrue(running['attemptRunning'])
        self.assertFalse(running['attemptUnklar'])
        app=(Path(__file__).resolve().parents[1]/'matrix_api/app.py').read_text(encoding='utf-8')
        self.assertIn('"PENDING_RESPONSE_ATTEMPT_ACTIVE"',app)
        self.assertIn('_attempt_view.get("attemptRunning")',app)

    def test_rejected_puppet_sqlite_transaction_leaves_absence_and_facts_unchanged(self):
        with tempfile.TemporaryDirectory(prefix='p23_reject_sql_') as tmp:
            db_path=Path(tmp)/'p23.sqlite'
            with closing(connect(db_path)) as conn:
                init_schema(conn);seed_if_missing(conn)
                create_session(conn,{'id':'p23_reject','worldId':GASTHAUS_ID,'name':'P23',
                                     'presentIds':[self.j['id']]},'admin')
                conn.commit()
                before=get_session(conn,'admin','p23_reject')
                self.assertNotIn(self.m['id'],before['scene']['presentIds'])
                conn.execute('BEGIN IMMEDIATE')
                try:
                    candidate=kernel.apply_presence(before,self.m['id'],natives=self.cast)
                    self.assertIn(self.m['id'],candidate['scene']['presentIds'])
                    unread=kernel.bind_puppet_input('Mara ist wieder da.',None,self.m,self.cast,
                                                     candidate['scene']['presentIds'])
                    self.assertTrue(unread['incomplete'])
                    # As the actual _persist route does on an incomplete reading:
                    # raise WriterError before saving and roll back the transaction.
                    raise ValueError('PLAN_INCOMPLETE')
                except ValueError:
                    conn.rollback()
            with closing(connect(db_path)) as c:
                after=get_session(c,'admin','p23_reject')
                self.assertEqual(c.execute('pragma quick_check').fetchone()[0],'ok')
            self.assertEqual(after['scene']['presentIds'],before['scene']['presentIds'])
            self.assertEqual(after['facts'],before['facts'])
            self.assertEqual(after['turns'],before['turns'])

    def test_puppet_rejected_input_does_not_write_or_add_presence(self):
        s={'scene':{'presentIds':[]},'facts':[],'turns':[]}
        snapshot=copy.deepcopy(s)
        result=kernel.bind_puppet_input('Clara ist hier.',None,self.clara,self.cast,[])
        self.assertTrue(result.get('incomplete'))
        # The route must throw before publishing the private writer state.
        self.assertEqual(s,snapshot)
        source=Path(__file__).resolve().parents[1]/'matrix_api/app.py'
        text=source.read_text(encoding='utf-8')
        self.assertIn('kernel.puppet_kind_cast(',text)
        self.assertIn('if where == "puppet":',text)
        self.assertNotIn('body.get("allowAbsent")',text)
        self.assertIn('raise WriterError(',text)


if __name__ == '__main__':
    unittest.main()
