"""P25 source-bound R1/R2/R3 regression tests. No Flask/DB claim is made.
All tests assert the actual binder decision, actor ID and recipient ID.
"""
import unittest
import test_v84_kausal_chain  # loads the existing OFFLINE Flask import shim only for binder tests
from matrix_api import kernel, llm_contract

J={'id':'j','name':'Johann Bruckner'}
M={'id':'m','name':'Mara Nowak'}
G={'id':'g','name':'Gustav Pfeiffer'}
R={'id':'r','name':'Robert'}
CAST=[J,M,G,R]


def act(segment, *, done=True, independent=True, actor='Johann Bruckner'):
    comp={'typ':'handlung','segment':segment,'akteur':actor,'geschieht':done,
          'zeit':'jetzt','wirkung':'ohne_koerperwirkung'}
    if independent:
        comp['vollzugPruefung']={'geschieht':done,'art':'tatsaechlich' if done else 'verneint',
                                 'beleg':segment,'taeter':'figur'}
    return comp


def vocative(segment, intro, who):
    return {'typ':'rede','segment':segment,'einleitung':intro,'akteur':'Johann Bruckner',
            'sprecherPruefung':{'sprecher':'Johann Bruckner','adressat':who,
                               'ansageRolle':'anrede','ansageBeleg':intro,'beleg':segment}}


def bind(text, parts, cast=CAST, selected='m'):
    return kernel.bind_puppet_input(text, {'komponenten':parts}, J, cast,
                                   [f['id'] for f in cast], addressee_id=selected)


class P25SourceBoundContracts(unittest.TestCase):
    def test_r1_own_subject_only_is_covered_by_its_exact_identity(self):
        for text, part in [('Johann trinkt sein Bier aus.','trinkt sein Bier aus.'),
                           ('Johann stellt das Glas auf den Tisch.','stellt das Glas auf den Tisch.')]:
            with self.subTest(text=text):
                got=bind(text,[act(part)])
                self.assertEqual([a['text'] for a in got.get('actions') or []],[part.rstrip('.')],got)
                self.assertFalse(got.get('partial_rejection'),got)
                self.assertFalse([a for a in got['ambiguous'] if a['grund']=='rest_ohne_komponente'],got)

    def test_r1_independent_denial_is_read_but_not_committed_or_lost_speech(self):
        text='Johann küsst Mara nicht und sagt: Hallo.'
        parts=[act('Johann küsst Mara nicht',done=False),
               {'typ':'rede','segment':'Hallo.','einleitung':'sagt:','akteur':J['name'],
                'sprecherPruefung':{'sprecher':J['name'],'adressat':None,'ansageRolle':'sprecheransage',
                                   'ansageBeleg':'sagt:','beleg':'Hallo.'}}]
        got=bind(text,parts)
        self.assertEqual(got['speech'],'Hallo.',got)
        self.assertFalse(got['actions'],got)
        self.assertFalse(got.get('partial_rejection'),got)
        denial=[a for a in got['ambiguous'] if a.get('grund')=='handlung_nicht_vollzogen']
        self.assertEqual(len(denial),1,got)
        self.assertTrue(denial[0].get('readNonEvent'),got)

    def test_r1_missing_independent_non_event_read_still_fails_closed(self):
        got=bind('Johann verneint etwas und sagt: Hallo.',[
            act('Johann verneint etwas',done=False,independent=False),
            {'typ':'rede','segment':'Hallo.','einleitung':'sagt:','akteur':J['name'],
             'sprecherPruefung':{'sprecher':J['name'],'adressat':None,'ansageRolle':'sprecheransage',
                                'ansageBeleg':'sagt:','beleg':'Hallo.'}}])
        self.assertTrue(got.get('partial_rejection'),got)

    def test_r1_foreign_actor_must_not_be_covered_or_committed(self):
        got=bind('Gustav trinkt sein Bier aus.',[act('trinkt sein Bier aus.')])
        self.assertFalse(got['actions'],got)
        self.assertTrue(got.get('nichts_ausfuehrbar') or got.get('incomplete'),got)

    def test_r1_unread_later_sentence_is_not_silently_ignored(self):
        got=bind('Johann trinkt sein Bier aus. Robert steht auf.',[act('trinkt sein Bier aus.')])
        self.assertTrue(got.get('partial_rejection'),got)
        self.assertIn('Robert steht auf',str(got['ambiguous']),got)

    def test_r2_two_distinct_proven_addresses_fail_closed_not_first_wins(self):
        text='Mara, schön dich zu sehen. Gustav, setz dich.'
        got=bind(text,[vocative('schön dich zu sehen.','Mara,','Mara'),
                       vocative('setz dich.','Gustav,','Gustav')],selected='m')
        self.assertTrue(got.get('partial_rejection'),got)
        self.assertEqual(got['speech'],'',got)
        self.assertIsNone(got.get('speechTarget'),got)
        self.assertTrue(any(a.get('grund')=='rede_adressat_unklar' for a in got['ambiguous']),got)

    def test_r2_same_recipient_twice_remains_a_single_consistent_binding(self):
        text='Mara, schön dich zu sehen. Mara, komm doch mit.'
        got=bind(text,[vocative('schön dich zu sehen.','Mara,','Mara'),
                       vocative('komm doch mit.','Mara,','Mara')])
        self.assertFalse(got.get('partial_rejection'),got)
        self.assertEqual(got.get('speechTarget'),'m',got)
        self.assertEqual(got['speech'],text,got)

    def test_r2_explicit_one_recipient_overrides_selected_ui_recipient(self):
        got=bind('Gustav, setz dich.',[vocative('setz dich.','Gustav,','Gustav')],selected='m')
        self.assertEqual(got['speech'],'Gustav, setz dich.',got)
        self.assertEqual(got.get('speechTarget'),'g',got)
        self.assertFalse(got.get('partial_rejection'),got)

    def test_r2_foreign_speaker_announcement_is_not_vocative(self):
        got=bind('Robert sagt: Ich gehe jetzt.',[{'typ':'rede','segment':'Ich gehe jetzt.',
                        'einleitung':'Robert sagt:','akteur':'Robert',
                        'sprecherPruefung':{'sprecher':'Robert','adressat':None,'beleg':'Robert sagt:',
                                           'ansageRolle':'sprecheransage','ansageBeleg':'Robert sagt:'}}])
        self.assertEqual(got.get('speech'),'',got)
        self.assertTrue(got.get('nichts_ausfuehrbar') or got.get('incomplete'),got)

    def test_r1_writer_sqlite_reader_receives_only_validated_actor_action(self):
        # Actual canonical writer, independent SQLite connection, no route.
        import os
        from tempfile import TemporaryDirectory
        from pathlib import Path
        from contextlib import closing
        from unittest.mock import patch
        from test_v92_puppet_writer_full_chain import initial, JOHANN, MARA
        from matrix_api.db import connect, init_schema, GASTHAUS_ID
        from matrix_api.seed_builtin import seed_if_missing
        from matrix_api.repos import create_session, save_session, get_session
        text='Johann trinkt sein Bier aus.'
        bound=kernel.bind_puppet_input(text, {'komponenten':[act('trinkt sein Bier aus.')]},
                                      JOHANN, [JOHANN,MARA], [JOHANN['id'],MARA['id']],
                                      addressee_id=MARA['id'])
        self.assertFalse(bound.get('partial_rejection'),bound)
        self.assertEqual(len(bound['actions']),1,bound)
        with TemporaryDirectory(prefix='p25_sqlite_') as td, patch.dict(os.environ,{'MATRIX_SKIP_SEED':'0'}):
            db=Path(td)/'isolated.sqlite'
            with closing(connect(db)) as c:
                init_schema(c)
                seed_if_missing(c)
                create_session(c, {'id':'p25_sql','worldId':GASTHAUS_ID,'name':'Probe',
                    'presentIds':[JOHANN['id'],MARA['id']]}, 'admin')
                source=initial('p25_sql')
                result=kernel.commit_puppet(source,JOHANN,bound.get('speech') or '',actions=bound['actions'])
                save_session(c,'admin',result)
                c.commit()
            with closing(connect(db)) as c:
                loaded=get_session(c,'admin','p25_sql')
                self.assertEqual(c.execute('PRAGMA quick_check').fetchone()[0],'ok')
            acts=[f for f in loaded['facts'] if f.get('kind')=='action']
            self.assertEqual(len(acts),1,acts)
            self.assertEqual(acts[0]['actorId'],JOHANN['id'],acts)
            self.assertEqual(acts[0]['text'],'trinkt sein Bier aus',acts)
            self.assertTrue(acts[0].get('validated'),acts)
            self.assertFalse([f for f in loaded['facts'] if f.get('kind')=='speech'])
            self.assertEqual(loaded['turnIndex'],1)

    def test_r1_second_unread_clause_not_hidden_by_actor_prefix(self):
        got=bind('Johann trinkt sein Bier aus. Und dann verspricht Robert alles.',
                 [act('trinkt sein Bier aus.')])
        self.assertTrue(got.get('partial_rejection'),got)
        self.assertIn('verspricht Robert',str(got['ambiguous']))

    def test_r3_prompt_contains_generic_roles_not_acceptance_examples(self):
        rule=llm_contract.SPRECHER_CHECK_RULES
        self.assertIn('ANREDE',rule)
        self.assertIn('SPRECHERANSAGE',rule)
        for forbidden in ('Gustav, setz dich.','Ja, Gustav, setz dich.','Gustav sagt: Hallo.'):
            self.assertNotIn(forbidden,rule)


if __name__=='__main__':
    unittest.main()
