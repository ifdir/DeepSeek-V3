"""V92 Paket 15 (Paket-14-Pruefung 05.11.2026): ein bekannter Vollname darf nicht als Praefix eines laengeren fremden Namens binden.

Befund: "Johann schubst Mara Nowak-Schmidt." band Mara Nowak (Handlung, Koerper-Fact, Schmerz, Erinnerung "erlebt") - auch mit
der vollen Lesung "Mara Nowak-Schmidt"; "Johann Bruckner-Weber schubst/sagt" wurde Johann Bruckners Handlung/Rede. Erste falsche
Stelle: name_occurrences band die bekannte Namensform sofort, ohne den Umfang des geschriebenen Namens (Bindestrich, folgende
Namenswoerter) zu pruefen. Bedingung: dieselbe Umfangsregel fuer Ziel, Taeter, Sprecher, Adressat, Koerperwirkung, Erinnerung
und die uebrigen Namensleser; keine Wortliste, kein zweiter Resolver; Positivfaelle duerfen nicht regressieren.
"""
import copy
import json
import unittest
import urllib.request
from contextlib import closing
from unittest.mock import patch

import test_v84_kausal_chain  # noqa: F401  (offline Flask shim wie die übrigen Tests)
from matrix_api import kernel
from matrix_api.db import connect
from matrix_api.repos import get_session
import test_v92_negativgrenzen as _NG
import test_v92_puppet_vertrag as _PV
import test_v92_avatar_route as _AV
from test_v92_negativgrenzen import hc, rc, JA
from test_v92_puppet_vertrag import FakeProvider, plan, comp
from test_v92_avatar_route import rede


def pain(s, fid):
    return float(((s.get("runtimes") or {}).get(fid) or {}).get("pain") or 0)


def reading(ziel=None, taeter="figur"):
    return {**JA, "taeter": taeter, **({"ziel": ziel} if ziel is not None else {})}


def speech(seg, einl=None, akteur="Johann Bruckner", sprecher=None, adressat=None):
    c = rc(seg, akteur=akteur, einleitung=einl)
    if sprecher is not None or adressat is not None:
        c["sprecherPruefung"] = {"sprecher": sprecher or "figur", "beleg": None, "adressat": adressat}
    return c


class P15NameExtent(unittest.TestCase):
    setUp = _NG.Negativgrenzen.setUp
    bind = _NG.Negativgrenzen.bind
    commit = _NG.Negativgrenzen.commit
    grunds = _NG.Negativgrenzen.grunds

    def _fig(self, fid, name, present=True):
        s = copy.deepcopy(self.M); s["id"] = fid; s["name"] = name; s["aliases"] = []
        self.chars = self.chars + [s]
        if present:
            self.present = self.present + [s["id"]]
        return s

    def _nothing_for_mara(self, r, key):
        s = self.commit(r)
        self.assertFalse([f for f in s.get("facts", []) if f.get("targetId") == self.M["id"] and f.get("kind") in ("action", "physical")], key)
        self.assertEqual(pain(s, self.M["id"]), 0.0, key)
        self.assertNotIn((self.M["id"], "erlebt"), {(m.get("characterId"), m.get("kind")) for m in s.get("memories") or []}, key)
        return s

    # ---- the one identity reading itself ----
    def test_name_occurrences_reads_the_whole_written_name(self):
        F = [self.J, self.M]
        occ = lambda t, lit=(): [(o["state"], o["words"], sorted(o["ids"])) for o in kernel.name_occurrences(t, F, lit)]
        for t in ("Johann schubst Mara Nowak-Schmidt.", "Johann schubst Mara Nowak Schmidt.", "Johann schubst Anna-Mara Nowak.",
                  "Johann schubst Mara-Lena."):
            self.assertNotIn(("ok", "mara nowak", [self.M["id"]]), occ(t), t)
            self.assertFalse([o for o in occ(t) if self.M["id"] in o[2]], t)
        # the reading's literal full name of the unknown person makes it "unbekannt" (not a shortened part)
        self.assertIn(("unbekannt", "mara nowak schmidt", []), occ("Johann schubst Mara Nowak-Schmidt.", ["Mara Nowak-Schmidt"]))
        self.assertIn(("unklar", "mara nowak schmidt", []), occ("Johann schubst Mara Nowak-Schmidt.", ["Mara Nowak"]))
        self.assertEqual(occ("Johann Bruckner-Weber sagt:"), [("unklar", "johann bruckner weber", [])])
        # positives: the known full name, alone, after a capitalised word before it, before punctuation
        self.assertEqual(occ("Mara Nowak lacht."), [("ok", "mara nowak", [self.M["id"]])])
        # V92 Paket 16 (Paket-15-Pruefung, Entscheidung zum Namensanfang): a capitalised word directly before the name does not prove
        # the boundary ("Neben" vs "Anna" cannot be told apart by form) - unbound, the clarification offers Mara Nowak
        self.assertEqual(occ("Neben Mara Nowak sitzt Johann."), [("unklar", "neben mara nowak", []), ("ok", "johann", [self.J["id"]])])
        self.assertEqual(occ("Mara Nowak, Schmidt ist da."), [("ok", "mara nowak", [self.M["id"]])])

    def test_a_cast_name_with_a_hyphen_still_binds(self):
        al = self._fig("char_test_anna_lena", "Anna-Lena Berg")
        F = self.chars
        self.assertEqual([sorted(o["ids"]) for o in kernel.name_occurrences("Johann umarmt Anna-Lena Berg.", F)], [[self.J["id"]], [al["id"]]])
        r = self.bind("Johann umarmt Anna-Lena Berg.", [hc("Johann umarmt Anna-Lena Berg", wirkung="zaertlich", pruefung=reading("Anna-Lena Berg", "Johann"), ziel="Anna-Lena Berg")])
        self.assertEqual([a["targetId"] for a in r["actions"]], [al["id"]])

    # ---- target (Paket-14-Pruefung N1, both spellings, every reading) ----
    def test_known_full_name_as_prefix_of_a_longer_target_binds_nobody(self):
        for raw in ("Johann schubst Mara Nowak-Schmidt.", "Johann schubst Mara Nowak Schmidt.", "Johann schubst Anna-Mara Nowak."):
            seg = raw.rstrip(".")
            full = raw.split("schubst ")[1].rstrip(".")
            for lit in (full, "Mara Nowak", "Mara", None):
                for rev in (False, True):
                    self.setUp()
                    if rev:
                        self.chars = list(reversed(self.chars)); self.present = list(reversed(self.present))
                    r = self.bind(raw, [hc(seg, wirkung="gewalt", pruefung=reading(lit, "Johann Bruckner"), ziel="Mara Nowak")])
                    self._nothing_for_mara(r, (raw, lit, rev))
                    self.assertEqual([a["targetId"] for a in r["actions"]], [None], (raw, lit))
                    self.assertTrue(set(self.grunds(r)) & {"ziel_name_unklar", "ziel_nicht_anwesend_oder_unbekannt"}, (raw, lit, self.grunds(r)))

    def test_the_readings_full_unknown_name_is_not_overridden_by_a_known_form_inside_it(self):
        # when the blind reading gives the whole longer name literally, a known form inside it never binds (Paket 15);
        # V92 Paket 16: a capitalised word before the name with a blank leaves it unbound too ("Frau Mara Nowak": asked)
        for rev in (False, True):
            self.setUp()
            if rev:
                self.chars = list(reversed(self.chars)); self.present = list(reversed(self.present))
            r = self.bind("Johann schubst Anna Mara Nowak.", [hc("Johann schubst Anna Mara Nowak", wirkung="gewalt", pruefung=reading("Anna Mara Nowak", "Johann"), ziel="Mara Nowak")])
            self._nothing_for_mara(r, rev); self.assertIn("ziel_nicht_anwesend_oder_unbekannt", self.grunds(r))
        occ = [(o["state"], o["words"]) for o in kernel.name_occurrences("Johann schubst Anna Mara Nowak.", self.chars, ["Anna Mara Nowak"])]
        self.assertIn(("unbekannt", "anna mara nowak"), occ)
        self.assertEqual([(o["state"], sorted(o["ids"]), o["kandidaten"]) for o in kernel.name_occurrences("Frau Mara Nowak lacht.", self.chars)],
                         [("unklar", [], [self.M["id"]])])

    def test_a_segment_that_stops_inside_the_name_cannot_hide_its_rest(self):
        r = self.bind("Johann schubst Mara Nowak-Schmidt.", [hc("Johann schubst Mara Nowak", wirkung="gewalt", pruefung=reading("Mara Nowak", "Johann"), ziel="Mara Nowak")])
        self._nothing_for_mara(r, "segment ends at Nowak")
        r = self.bind("Johann Bruckner-Weber winkt.", [hc("Weber winkt", wirkung="ohne_koerperwirkung", pruefung=reading(None, "Johann Bruckner"), ziel=None)])
        self.assertEqual(r["actions"], []); self.assertIn("akteur_name_unklar", self.grunds(r))

    def test_two_maras_present_and_a_longer_name(self):
        sch = self._fig("char_test_mara_schmidt", "Mara Schmidt")
        r = self.bind("Johann schubst Mara Nowak-Schmidt.", [hc("Johann schubst Mara Nowak-Schmidt", wirkung="gewalt", pruefung=reading("Mara Nowak-Schmidt", "Johann"), ziel="Mara Nowak")])
        s = self._nothing_for_mara(r, "zwei Maras")
        self.assertFalse([f for f in s.get("facts", []) if f.get("targetId") == sch["id"]])
        # the identity reading itself: ONE figure must carry every further word (Live-Lauf 05.11.: with Mara Schmidt in the cast the
        # union of both surnames made "Mara Nowak-Schmidt" look like a name of "the Maras")
        occ = [(o["state"], o["words"], sorted(o["ids"])) for o in kernel.name_occurrences("Mara Nowak-Schmidt, komm her.", self.chars)]
        self.assertEqual(occ, [("unklar", "mara nowak schmidt", [])])
        sess = {"scene": {"presentIds": [self.J["id"], self.M["id"]]}, "facts": [], "propositions": [], "goals": []}
        d = kernel.resolve_target_detail(sess, self.chars, "Mara Nowak-Schmidt, komm her.", ui_target_id=self.M["id"], input_actor_id=self.J["id"])
        self.assertEqual((d["target_id"], d["reason"]), (None, "explicit_address_unknown"))
        self.assertEqual(kernel._name_roles("Mara Nowak-Schmidt komm her", self.chars), {})
        # positives with both present: each full name binds its own figure
        r = self.bind("Johann schubst Mara Schmidt.", [hc("Johann schubst Mara Schmidt", wirkung="gewalt", pruefung=reading("Mara Schmidt", "Johann"), ziel="Mara Schmidt")])
        self.assertEqual([a["targetId"] for a in r["actions"]], [sch["id"]])
        r = self.bind("Johann schubst Mara Nowak.", [hc("Johann schubst Mara Nowak", wirkung="gewalt", pruefung=reading("Mara Nowak", "Johann"), ziel="Mara Nowak")])
        self.assertEqual([a["targetId"] for a in r["actions"]], [self.M["id"]])
        self.assertGreater(pain(self.commit(r), self.M["id"]), 0.0)

    # ---- doer (Paket-14-Pruefung N2) ----
    def test_known_full_name_as_prefix_of_a_longer_doer_is_no_own_act(self):
        for raw in ("Johann Bruckner-Weber schubst Mara Nowak.", "Johann Bruckner Weber schubst Mara Nowak.", "Hans-Johann Bruckner schubst Mara Nowak."):
            for taeter in ("Johann Bruckner", "figur", "Johann"):
                r = self.bind(raw, [hc(raw.rstrip("."), wirkung="gewalt", pruefung=reading("Mara Nowak", taeter), ziel="Mara Nowak")])
                self.assertEqual(r["actions"], [], (raw, taeter)); self.assertIn("akteur_name_unklar", self.grunds(r))
                self._nothing_for_mara(r, (raw, taeter))

    # ---- speaker (Paket-14-Pruefung N3) ----
    def test_known_full_name_as_prefix_of_a_longer_speaker_is_no_own_speech(self):
        for einl in ("Johann Bruckner-Weber sagt:", "sagt:", "Weber sagt:", "Bruckner-Weber sagt:", None):
            for sprecher in ("Johann Bruckner", "figur", "Johann", None):
                r = self.bind("Johann Bruckner-Weber sagt: Hallo.", [speech("Hallo.", einl, sprecher=sprecher)])
                self.assertEqual(r["speech"], "", (einl, sprecher))
                self.assertEqual([f for f in self.commit(r).get("facts", []) if f.get("kind") == "speech"], [], (einl, sprecher))

    # ---- addressee, direct address, memory referents, the other name readers ----
    def test_longer_addressee_and_other_readers_name_nobody(self):
        for ad in ("Mara Nowak", "Mara Nowak-Schmidt", "Mara", None):
            r = self.bind("Johann sagt zu Mara Nowak-Schmidt: Komm her.", [speech("Komm her.", "Johann sagt zu Mara Nowak-Schmidt:", sprecher="Johann", adressat=ad)])
            self.assertEqual((r["speech"], r.get("speechTargetSet"), r.get("speechTarget")), ("Komm her.", True, None), ad)
            self.assertEqual([f.get("targetId") for f in self.commit(r).get("facts", []) if f.get("kind") == "speech"], [None], ad)
        sess = {"scene": {"presentIds": [self.J["id"], self.M["id"]]}, "facts": [], "propositions": [], "goals": []}
        for t in ("Mara Nowak-Schmidt, komm her.", "Komm her, Mara Nowak Schmidt!"):
            d = kernel.resolve_target_detail(sess, self.chars, t, ui_target_id=self.M["id"], input_actor_id=self.J["id"])
            self.assertEqual((d["target_id"], d["reason"]), (None, "explicit_address_unknown"), t)
        self.assertEqual(kernel._name_roles("Mara Nowak-Schmidt komm her", self.chars), {})
        self.assertEqual(kernel.bind_referents("Ich habe Mara Nowak-Schmidt gesehen.", self.chars), [])
        self.assertNotIn(self.M["id"], kernel._named_in("Johann schubst Mara Nowak-Schmidt", self.chars, set()))
        # positives
        d = kernel.resolve_target_detail(sess, self.chars, "Mara Nowak, komm her.", ui_target_id=None, input_actor_id=self.J["id"])
        self.assertEqual(d["target_id"], self.M["id"])
        self.assertEqual(kernel.bind_referents("Ich habe Mara Nowak gesehen.", self.chars), [self.M["id"]])

    # ---- positives that must not regress ----
    def test_own_act_and_speech_with_the_known_full_name(self):
        r = self.bind("Johann Bruckner lächelt.", [hc("Johann Bruckner lächelt", wirkung="ohne_koerperwirkung", pruefung=reading(None, "Johann Bruckner"), ziel=None)])
        self.assertEqual([a["text"] for a in r["actions"]], ["Johann Bruckner lächelt"])
        r = self.bind("Johann Bruckner sagt: Hallo.", [speech("Hallo.", "Johann Bruckner sagt:", sprecher="Johann Bruckner")])
        self.assertEqual(r["speech"], "Hallo.")
        r = self.bind("Johann schubst Mara Nowak.", [hc("Johann schubst Mara Nowak", wirkung="gewalt", pruefung=reading("Mara Nowak", "Johann Bruckner"), ziel="Mara Nowak")])
        self.assertEqual([a["targetId"] for a in r["actions"]], [self.M["id"]])
        # V92 Paket 16 (Paket-15-Pruefung): "Neben Mara Nowak" is not provable by form - nothing is bound, the operator is asked;
        # after the answer "Mara Nowak" the act is Johann's (the clause no longer opens with an unproven name)
        comp = [hc("Neben Mara Nowak lächelt Johann", wirkung="ohne_koerperwirkung", pruefung=reading(None, "Johann"), ziel=None)]
        r = self.bind("Neben Mara Nowak lächelt Johann.", copy.deepcopy(comp))
        self.assertEqual(r["actions"], []); self.assertIn({"text": "Neben Mara Nowak", "a": 0, "b": 16, "kandidaten": [self.M["id"]]}, [a.get("klaerung") for a in r["ambiguous"]])
        self.chars = [dict(c, klaerung=["Neben Mara Nowak"]) if c["id"] == self.M["id"] else c for c in self.chars]
        r = self.bind("Neben Mara Nowak lächelt Johann.", copy.deepcopy(comp))
        self.assertEqual(len(r["actions"]), 1, self.grunds(r))


class P15PuppetRoute(unittest.TestCase):
    setUp = _PV.PuppetRouteChain.setUp
    session = _PV.PuppetRouteChain.session
    puppet = _PV.PuppetRouteChain.puppet
    snapshot = _PV.PuppetRouteChain.snapshot
    _nothing_committed = _PV.PuppetRouteChain._nothing_committed
    _act_comp = _PV.PuppetRouteChain._act_comp

    def test_longer_names_commit_nothing_wrong_over_the_route_and_the_follow_up_works(self):
        s0 = self.session()
        ok_effect = lambda p: {"bestaetigt": True, "zeit": "jetzt", "ziel": p.get("ziel"), "beleg": "schubst"}
        for raw, lit in (("Johann schubst Mara Nowak-Schmidt.", "Mara Nowak-Schmidt"), ("Johann schubst Mara Nowak Schmidt.", "Mara Nowak")):
            c = dict(self._act_comp(raw.rstrip(".")), ziel="Mara Nowak", wirkung="gewalt")
            prov = FakeProvider([plan("action", "act", [c])], wirkung=ok_effect,
                                vollzug=lambda p, lit=lit: {"geschieht": True, "art": "tatsaechlich", "beleg": None, "taeter": "Johann Bruckner", "ziel": lit})
            r = self.puppet(prov, raw)
            self.assertIn(r.status_code, (200, 422), r.get_data(as_text=True)[:300])
            s = self.session()                                                # new connection = reader after a restart
            self.assertFalse([f for f in s["facts"] if f.get("targetId") == self.M["id"] and f.get("kind") in ("action", "physical")], raw)
            self.assertEqual(pain(s, self.M["id"]), pain(s0, self.M["id"]), raw)
            self.assertFalse([m for m in s.get("memories") or [] if m.get("characterId") == self.M["id"] and m.get("kind") == "erlebt"], raw)
        # doer and speaker with the longer name: nothing stored at all
        # V92 Paket 16: the unproven name is asked first (nothing stored); answered "nobody of the cast" -> nothing stored either
        c = dict(self._act_comp("Johann Bruckner-Weber schubst Mara Nowak"), ziel="Mara Nowak", wirkung="gewalt")
        prov = FakeProvider([plan("action", "act", [c])] * 2, wirkung=ok_effect,
                            vollzug=lambda p: {"geschieht": True, "art": "tatsaechlich", "beleg": None, "taeter": "Johann Bruckner", "ziel": "Mara Nowak"})
        r = self._nothing_committed(prov, "Johann Bruckner-Weber schubst Mara Nowak.", None, code="IDENTITAET_KLAEREN")
        self.assertEqual([(q["text"], [x["id"] for x in q["kandidaten"]]) for q in r.get_json()["klaerung"]], [("Johann Bruckner-Weber", [self.J["id"]])])
        self._nothing_committed(prov, "Johann Bruckner-Weber schubst Mara Nowak.", None, klaerungen=[{"text": "Johann Bruckner-Weber", "id": None}])
        rd = dict(comp("rede", "Hallo."), einleitung="Johann Bruckner-Weber sagt:")
        prov = FakeProvider([plan("smalltalk", "chat", [rd])] * 2, sprecher=lambda p: {"sprecher": "Johann Bruckner", "beleg": None})
        self._nothing_committed(prov, "Johann Bruckner-Weber sagt: Hallo.", None, code="IDENTITAET_KLAEREN")
        self._nothing_committed(prov, "Johann Bruckner-Weber sagt: Hallo.", None, klaerungen=[{"text": "Johann Bruckner-Weber", "id": None}])
        # the provider gives no reading at all: fail-closed
        c = dict(self._act_comp("Johann schubst Mara Nowak-Schmidt"), ziel="Mara Nowak", wirkung="gewalt")
        self._nothing_committed(FakeProvider([plan("action", "act", [c])], wirkung=ok_effect, vollzug=lambda p: None),
                                "Johann schubst Mara Nowak-Schmidt.", None)
        # follow-up turn with the real present Mara Nowak: the effect reaches her
        c = dict(self._act_comp("Johann schubst Mara Nowak"), ziel="Mara Nowak", wirkung="gewalt")
        r = self.puppet(FakeProvider([plan("action", "act", [c])], wirkung=ok_effect,
                                     vollzug=lambda p: {"geschieht": True, "art": "tatsaechlich", "beleg": None, "taeter": "Johann Bruckner", "ziel": "Mara Nowak"}),
                        "Johann schubst Mara Nowak.")
        self.assertEqual(r.status_code, 200, r.get_data(as_text=True)[:300])
        s = self.session()
        self.assertTrue([f for f in s["facts"] if f.get("targetId") == self.M["id"] and f.get("kind") == "physical"])
        self.assertGreater(pain(s, self.M["id"]), pain(s0, self.M["id"]))


    def test_address_to_a_longer_name_with_a_second_mara_in_the_world(self):
        # Live-Lauf 05.11. (Paket 15 vorher): Mara Schmidt existiert in der Welt (nicht anwesend); "Mara Nowak-Schmidt, komm her."
        # wurde an die ausgewaehlte Mara Nowak gespeichert. The address names nobody - never the selected recipient.
        with closing(connect(self.dbp)) as c:
            jrow = c.execute("select world_id, owner_user_id, json from characters where id=?", (self.M["id"],)).fetchone()
            w = dict(json.loads(jrow[2])); w["id"] = "char_test_mara_schmidt"; w["name"] = "Mara Schmidt"; w["aliases"] = []
            c.execute("INSERT INTO characters(id, world_id, owner_user_id, json) VALUES(?,?,?,?)", (w["id"], jrow[0], jrow[1], json.dumps(w, ensure_ascii=False))); c.commit()
        # V92 Paket 16: the address is asked first (Mara Nowak or Mara Schmidt?), nothing stored; "nobody of the cast" -> no addressee
        prov = FakeProvider([plan("request", "request", [comp("rede", "Mara Nowak-Schmidt, komm her.")])] * 2)
        before = self.snapshot(self.session())
        r = self.puppet(prov, "Mara Nowak-Schmidt, komm her.")
        self.assertEqual((r.status_code, r.get_json()["code"]), (422, "IDENTITAET_KLAEREN"))
        self.assertEqual([(q["text"], sorted(x["id"] for x in q["kandidaten"])) for q in r.get_json()["klaerung"]],
                         [("Mara Nowak-Schmidt", sorted([self.M["id"], "char_test_mara_schmidt"]))])
        self.assertEqual(self.snapshot(self.session()), before)
        r = self.puppet(prov, "Mara Nowak-Schmidt, komm her.", [{"text": "Mara Nowak-Schmidt", "id": None}])
        self.assertEqual(r.status_code, 200, r.get_data(as_text=True)[:300])
        f = [x for x in self.session()["facts"] if x.get("kind") == "speech" and x.get("actorId") == self.J["id"]][-1]
        self.assertEqual((f["text"], f.get("targetId")), ("Mara Nowak-Schmidt, komm her.", None))
        r = self.puppet(FakeProvider([plan("request", "request", [comp("rede", "Mara Nowak, komm her.")])]), "Mara Nowak, komm her.")
        self.assertEqual(r.status_code, 200, r.get_data(as_text=True)[:300])
        f = [x for x in self.session()["facts"] if x.get("kind") == "speech" and x.get("actorId") == self.J["id"]][-1]
        self.assertEqual(f.get("targetId"), self.M["id"])


class P15AvatarRoute(unittest.TestCase):
    setUp = _AV.AvatarRouteChain.setUp
    session = _AV.AvatarRouteChain.session
    prepare = _AV.AvatarRouteChain.prepare

    def test_avatar_speech_to_a_longer_name_has_no_addressee(self):
        rd = dict(rede("Hallo.", akteur="ich"), einleitung="Ich sage zu Mara Nowak-Schmidt:")
        prov = FakeProvider([plan("smalltalk", "chat", [rd])] * 3, sprecher=lambda p: {"sprecher": "figur", "beleg": None, "adressat": "Mara Nowak"})
        # V92 Paket 16: the shortened addressee reading proves nothing - asked first, nothing stored
        r = self.prepare(prov, "Ich sage zu Mara Nowak-Schmidt: Hallo.")
        self.assertEqual((r.status_code, (r.get_json() or {}).get("code")), (422, "IDENTITAET_KLAEREN"), r.get_data(as_text=True)[:300])
        self.assertEqual([q["text"] for q in r.get_json()["klaerung"]], ["Mara Nowak-Schmidt"])
        self.assertFalse([x for x in self.session()["facts"] if x.get("kind") == "speech" and x.get("actorId") == self.J["id"]])
        r = self.prepare(prov, "Ich sage zu Mara Nowak-Schmidt: Hallo.", [{"text": "Mara Nowak-Schmidt", "id": None}])
        self.assertEqual(r.status_code, 200, r.get_data(as_text=True)[:300])
        f = [x for x in self.session()["facts"] if x.get("kind") == "speech" and x.get("actorId") == self.J["id"]][-1]
        self.assertEqual((f["text"], f.get("targetId")), ("Hallo.", None))


if __name__ == "__main__":
    unittest.main()
