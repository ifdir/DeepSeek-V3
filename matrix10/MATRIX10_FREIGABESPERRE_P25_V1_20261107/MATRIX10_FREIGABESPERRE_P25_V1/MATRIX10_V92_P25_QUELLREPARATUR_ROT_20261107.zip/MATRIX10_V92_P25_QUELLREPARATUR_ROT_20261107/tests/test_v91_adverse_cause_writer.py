"""AMASTER §§36.5, 44, 50: relationship provenance must not contradict
canonical consequences from the *same* recorded event. This is not a
prescribed feeling, refusal or per-character content rule.
"""
import copy
import os
from unittest.mock import patch
from contextlib import closing
import tempfile
from pathlib import Path
import unittest

import test_v84_kausal_chain  # official test dependency import environment
from test_v87_regie_kette import apply_order, make_scene, FIGS, MARA, ROBERT
from matrix_api import kernel
from matrix_api.seed_builtin import seed_if_missing
from matrix_api.db import connect, init_schema, GASTHAUS_ID
from matrix_api.repos import create_session, save_session, get_session


def source(session):
    pending = kernel.pending_appraisals(session, FIGS)
    item = next(p for p in pending if p['id'] == MARA['id'])
    harm = next(e['fact'] for e in item['events'] if e['fact']['kind'] == 'action')
    return pending, harm


def propose(harm, *, delta, feeling=None):
    row = {'figur': MARA['name'], 'aktivierung': .9,
           'beziehung_aenderung': [{'zu': ROBERT['name'], 'trust': delta}],
           'grund': 'Aussage der KI zur Wirkung des Ereignisses'}
    row['_kausalpruefung'] = {'pruefungen': [{
        'feld': 'beziehung.0.trust', 'urteil': 'gestuetzt',
        'factId': harm['id'], 'beleg': harm['text'],
        'dispositionsBeleg': 'trotzig unter Druck', 'richtung': 'steigt' if delta > 0 else 'sinkt',
        'begruendung': 'trotzig unter Druck: das Ereignis habe angeblich Vertrauen erzeugt.',
    }]}
    return row


class AdverseCauseContract(unittest.TestCase):
    def test_harm_is_not_itself_evidence_for_positive_trust(self):
        session = apply_order(make_scene())
        pending, harm = source(session)
        row = propose(harm, delta=.17)
        after, protocol = kernel.apply_appraisals(session, pending, {'bewertungen': [row]}, natives=FIGS)
        self.assertEqual(after['relations'], session['relations'])
        self.assertIn('koerperfolge_widerspricht_beziehungsanstieg:beziehung.0.trust', protocol[0]['rejects'])
        self.assertFalse(protocol[0]['relationDelta'])
        self.assertFalse([f for f in after['facts'] if f['kind']=='appraisal' and
                          any(x.get('after',{}).get('trust',.4)>.4 for x in f.get('payload',{}).get('relationDelta',[]))])
        self.assertEqual(session['relations'], [])

    def test_negative_trust_is_not_forced_but_can_be_justified(self):
        session = apply_order(make_scene())
        pending, harm = source(session)
        row = propose(harm, delta=-.17)
        after, protocol = kernel.apply_appraisals(session, pending, {'bewertungen': [row]}, natives=FIGS)
        rel = next(r for r in after['relations'] if r['fromId'] == MARA['id'] and r['toId'] == ROBERT['id'])
        self.assertLess(rel['trust'], .4)
        self.assertFalse(any(x.startswith('koerperfolge_widerspricht_beziehungsanstieg:') for x in protocol[0]['rejects']))

    def test_no_harm_record_may_have_either_grounded_direction(self):
        from test_v84_kausal_chain import scene, proposed, proofs, NATIVES
        s, p, event = scene('Johann hilft Mara beim Tragen')
        # This test does not assert a specific emotion; it verifies that the
        # new canonical physical-causality boundary is not a generic refusal.
        for delta in (-.1, .1):
            row = proposed(state=0,trust=delta,closeness=0,feeling='')
            row['_kausalpruefung'] = proofs(row,event)
            out, diag = kernel.apply_appraisals(s,p,{'bewertungen':[row]},natives=NATIVES)
            self.assertFalse(any(x.startswith('koerperfolge_widerspricht_') for x in diag[0]['rejects']))
            self.assertNotEqual(out['relations'][0]['trust'], .4)

    def test_unrelated_physical_effect_in_same_turn_does_not_block_other_action(self):
        # One source turn can contain several independent components. An
        # injury from another action must never be attributed to this cause.
        session = apply_order(make_scene())
        pending, harm = source(session)
        unrelated = copy.deepcopy(pending)
        for e in next(p for p in unrelated if p['id'] == MARA['id'])['events']:
            if e['fact']['kind'] == 'physical':
                e['fact']['text'] = 'Unabhängige andere Handlung'
        row = propose(harm, delta=.12)
        after, protocol = kernel.apply_appraisals(session,unrelated,{'bewertungen':[row]},natives=FIGS)
        self.assertFalse(any(x.startswith('koerperfolge_widerspricht_') for x in protocol[0]['rejects']))
        self.assertTrue(any(r['trust']>.4 for r in after['relations'] if r['fromId']==MARA['id']))

    def test_provenance_validation_survives_sqlite_reload_and_isolation(self):
        session = apply_order(make_scene())
        pending, harm = source(session)
        row = propose(harm, delta=.17)
        after, protocol = kernel.apply_appraisals(session,pending,{'bewertungen':[row]},natives=FIGS)
        with patch.dict(os.environ, {"MATRIX_SKIP_SEED": ""}):
            with tempfile.TemporaryDirectory() as folder:
                db_path = Path(folder)/'only_test.sqlite'
                with closing(connect(db_path)) as db:
                    init_schema(db)
                    seed_if_missing(db)  # temp DB test fixture; independent of test runner
                    for scene_id in ('ses_v87_regie','ses_unrelated'):
                        create_session(db,{'id':scene_id, 'worldId':GASTHAUS_ID,
                                           'name':'Test', 'presentIds':[ROBERT['id'],MARA['id']]},'admin')
                    unrelated_before = get_session(db,'admin','ses_unrelated')
                    baseline = get_session(db,'admin','ses_v87_regie')
                    save_session(db,'admin',after)
                    db.commit()
                with closing(connect(db_path)) as db:
                    loaded = get_session(db,'admin','ses_v87_regie')
                    unrelated_after = get_session(db,'admin','ses_unrelated')
                    self.assertEqual(db.execute('PRAGMA quick_check').fetchone()[0],'ok')
                self.assertEqual(unrelated_after['facts'],unrelated_before['facts'])
                self.assertEqual([(r['fromId'],r['toId'],r['trust']) for r in loaded['relations']],
                                 [(r['fromId'],r['toId'],r['trust']) for r in baseline['relations']])
                self.assertFalse([f for f in loaded['facts'] if f.get('kind')=='appraisal' and
                                  f.get('payload',{}).get('relationDelta')])
                bc = kernel.brain_context(loaded, MARA['id'])
                self.assertNotIn('0.49',repr(bc.get('relations') or []))

if __name__=='__main__': unittest.main()
