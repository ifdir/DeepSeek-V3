"""V92 repair: proof that shipped START.py serves the patched UI asset.

This is a real localhost HTTP server test for static delivery, NOT a Flask,
provider or real-world browser acceptance. User data is not opened/changed.
"""
import hashlib
import importlib.util
import json
import re
import threading
import unittest
import urllib.error
import urllib.request
from http.server import ThreadingHTTPServer
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
INDEX_HTML = (ROOT / 'frontend_dist' / 'index.html').read_text(encoding='utf-8')
# Source-built dist: the entry bundle is content-hashed; take it from index.html.
_entry = re.search(r'/assets/(index-[A-Za-z0-9_-]+\.js)', INDEX_HTML)
ENTRY_NAME = _entry.group(1) if _entry else ''
ASSET = ROOT / 'frontend_dist' / 'assets' / ENTRY_NAME


class FrontendDeliveryContract(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        spec = importlib.util.spec_from_file_location('matrix_start_for_test', ROOT / 'START.py')
        cls.launcher = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(cls.launcher)
        cls.server = ThreadingHTTPServer(('127.0.0.1', 0), cls.launcher._make_handler('1'))
        cls.thread = threading.Thread(target=cls.server.serve_forever, daemon=True)
        cls.thread.start()
        cls.url = f'http://127.0.0.1:{cls.server.server_port}'

    @classmethod
    def tearDownClass(cls):
        cls.server.shutdown()
        cls.server.server_close()
        cls.thread.join(timeout=3)

    def test_marker_and_index_are_served_from_actual_launcher(self):
        with urllib.request.urlopen(self.url + '/__matrix_start_health', timeout=3) as response:
            payload = json.load(response)
            self.assertEqual(response.status, 200)
            self.assertEqual(payload['service'], 'matrix10-python-ui')
            self.assertEqual(payload['buildId'], self.launcher.BUILD_ID)
        with urllib.request.urlopen(self.url + '/', timeout=3) as response:
            html = response.read().decode('utf-8')
            self.assertTrue(ENTRY_NAME, 'index.html references no hashed entry bundle')
            self.assertIn(ENTRY_NAME, html)
            self.assertEqual(response.status, 200)

    def test_compiled_patch_is_the_asset_actually_served_over_http(self):
        contents = ASSET.read_bytes()
        # Behaviour markers of the repaired follow-up/AutoChat logic (identifiers are minified).
        for marker in (b'figure_turn_not_committed', b'AUTOCHAT_STOP', b'TURN_WITHOUT_LINE'):
            self.assertTrue(any(marker in p.read_bytes() for p in ASSET.parent.glob('*.js')), marker)
        self.assertNotIn(b'V91-VollstaendigeBasis', contents)
        request = urllib.request.Request(self.url + '/assets/' + ENTRY_NAME)
        with urllib.request.urlopen(request, timeout=3) as response:
            served = response.read()
            self.assertEqual(response.status, 200)
            self.assertEqual(hashlib.sha256(served).digest(), hashlib.sha256(contents).digest())
            self.assertEqual(response.headers.get('Cache-Control'), 'no-cache')
            etag = response.headers.get('ETag')
            self.assertTrue(etag)
        request.add_header('If-None-Match', etag)
        with self.assertRaises(urllib.error.HTTPError) as error:
            urllib.request.urlopen(request, timeout=3)
        self.assertEqual(error.exception.code, 304)


if __name__ == '__main__':
    unittest.main()
