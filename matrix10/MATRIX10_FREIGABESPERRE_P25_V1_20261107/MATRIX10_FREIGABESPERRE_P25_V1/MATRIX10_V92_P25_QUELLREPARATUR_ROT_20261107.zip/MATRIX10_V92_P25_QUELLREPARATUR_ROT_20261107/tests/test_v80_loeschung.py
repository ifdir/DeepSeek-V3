"""V80 contract regression: DELETE world/character/session, SQLite reopen, scope isolation.

Tests use ONLY isolated temp SQLite files and no private user database.
"""
from __future__ import annotations
import json
import os
from pathlib import Path
import sqlite3
import sys
import tempfile
import unittest

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))
os.environ['MATRIX_SKIP_SEED']='1'
# Repository-only isolation tests: Flask is not installed in this test container.
# Stub only the import-time HTTP names, never any product delete logic.
try:
    import flask  # noqa: F401
except ImportError:
    import types
    sys.modules['flask'] = types.SimpleNamespace(jsonify=None, request=None)
from matrix_api.db import connect, init_schema
from matrix_api import repos

U='test_owner'
V='test_foreign'
W='world_test_delete'
Z='world_test_keep'
C='char_test_delete'
D='char_test_keep'
S='session_test_delete'
T='session_test_keep'


def _js(x):return json.dumps(x,ensure_ascii=False)


class DeleteContract(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        self.path=Path(self.tmp.name)/'matrix10.sqlite'
        self.db=connect(self.path)
        init_schema(self.db)
        self.addCleanup(lambda: self.db.close())
        for u in [U,V]:
            self.db.execute('INSERT INTO users(id,json) VALUES (?,?)',(u,_js({'id':u,'lastWorldId':W,'selectedSessionId':S} if u==U else {'id':u})))
        for world in [W,Z]:
            self.db.execute('INSERT INTO worlds(id,owner_user_id,json) VALUES (?,?,?)',(world,U,_js({'id':world,'name':world,'characterIds':([C,D] if world==W else []),'places':[]})))
        for char in [C,D]:
            self.db.execute('INSERT INTO characters(id,world_id,owner_user_id,json) VALUES (?,?,?,?)',(char,W,U,_js({'id':char,'name':char,'worldId':W})))
        for ses, world, user in [(S,W,U),(T,Z,U),('session_foreign',Z,V)]:
            self.db.execute('INSERT INTO sessions(id,world_id,user_id,json) VALUES (?,?,?,?)',(ses,world,user,_js({'id':ses,'worldId':world,'userId':user,'scene':{'presentIds':([C,D] if ses==S else [])},'avatarId':(C if ses==S else None),'runtimes':{C:{'holding':D},D:{'heldBy':C}} if ses==S else {}})))
        for eid, sid, world, c in [('fact_delete',S,W,C),('fact_keep',S,W,D),('fact_other',T,Z,D)]:
            self.db.execute('INSERT INTO scene_facts(id,user_id,world_id,session_id,json) VALUES (?,?,?,?,?)',(eid,U,world,sid,_js({'id':eid,'actorId':c,'sourceTurnId':f'turn_{eid}','worldId':world,'sessionId':sid})))
        for eid, sid, world, c in [('memory_delete',S,W,C),('memory_keep',S,W,D),('memory_other',T,Z,D)]:
            self.db.execute('INSERT INTO memories(id,user_id,world_id,session_id,json) VALUES (?,?,?,?,?)',(eid,U,world,sid,_js({'id':eid,'characterId':c,'sessionId':sid,'worldId':world})))
        self.db.execute('INSERT INTO relationships(id,user_id,world_id,session_id,from_id,to_id,json) VALUES (?,?,?,?,?,?,?)',('rel_delete',U,W,S,C,D,_js({'id':'rel_delete','fromId':C,'toId':D,'worldId':W,'sessionId':S})))
        self.db.execute('INSERT INTO snapshots(id,user_id,session_id,json) VALUES (?,?,?,?)',('snapshot_delete',U,S,_js({'id':'snapshot_delete','sessionId':S,'runtimes':{C:{'id':C}}})))
        for eid, owner, world, ses in [('log_delete',U,W,S),('log_keep',U,Z,T),('log_foreign',V,Z,'session_foreign')]:
            self.db.execute('INSERT INTO logs(id,user_id,json) VALUES (?,?,?)',(eid,owner,_js({'id':eid,'userId':owner,'sessionId':ses,'worldId':world,'message':'signal'})))
        for eid, world in [('doc_delete',W),('doc_keep',Z)]:
            self.db.execute('INSERT INTO documents(id,user_id,json) VALUES (?,?,?)',(eid,U,_js({'id':eid,'worldId':world})))
            self.db.execute('INSERT INTO document_index(document_id,user_id,json) VALUES (?,?,?)',(eid,U,_js({'id':eid,'worldId':world})))
        self.db.execute('INSERT INTO documents(id,user_id,json) VALUES (?,?,?)',('doc_session',U,_js({'id':'doc_session','worldId':W,'sessionId':S})))
        self.db.execute('INSERT INTO document_index(document_id,user_id,json) VALUES (?,?,?)',('doc_session',U,_js({'id':'doc_session','sessionId':S})))
        self.db.commit()

    def reopen(self):
        self.db.close()
        self.db=connect(self.path)
        init_schema(self.db)
        self.assertEqual(self.db.execute('PRAGMA quick_check').fetchone()[0],'ok')
        self.assertFalse(self.db.execute('PRAGMA foreign_key_check').fetchall())

    def row(self, table, ident):
        k='document_id' if table=='document_index' else 'id'
        return self.db.execute(f'SELECT json FROM {table} WHERE {k}=?',(ident,)).fetchone()

    def test_session_deletion_removes_logs_by_default_not_other_sessions(self):
        result=repos.delete_session(self.db,S,U)
        self.assertEqual(result['deletedSessionLogs'],1)
        self.db.commit()
        self.reopen()
        for table, item in [('sessions',S),('memories','memory_delete'),('snapshots','snapshot_delete'),('logs','log_delete'),('documents','doc_session'),('document_index','doc_session')]:
            self.assertIsNone(self.row(table,item),(table,item))
        for table,item in [('sessions',T),('logs','log_keep'),('logs','log_foreign'),('documents','doc_delete'),('documents','doc_keep'),('worlds',W),('characters',C)]:
            self.assertIsNotNone(self.row(table,item),(table,item))

    def test_character_deletion_erases_history_but_not_other_character(self):
        result=repos.delete_character(self.db,C,U)
        self.assertFalse(result['historyPreserved'])
        self.db.commit()
        self.reopen()
        for table, item in [('characters',C),('memories','memory_delete'),('scene_facts','fact_delete'),('relationships','rel_delete'),('snapshots','snapshot_delete')]:
            self.assertIsNone(self.row(table,item),(table,item))
        for table, item in [('characters',D),('memories','memory_keep'),('scene_facts','fact_keep'),('sessions',S),('sessions',T),('documents','doc_keep'),('logs','log_foreign')]:
            self.assertIsNotNone(self.row(table,item),(table,item))
        self.assertNotIn(C,self.row('sessions',S)[0])
        self.assertNotIn(C,self.row('worlds',W)[0])
        self.assertNotIn(C,self.row('users',U)[0])

    def test_world_deletion_removes_all_owned_related_preserving_other_world(self):
        result=repos.delete_world(self.db,W,U)
        self.assertEqual(result['deletedCharacters'],2)
        self.assertEqual(result['deletedSessions'],1)
        self.db.commit()
        self.reopen()
        for table, item in [('worlds',W),('characters',C),('characters',D),('sessions',S),('documents','doc_session'),('document_index','doc_session'),('scene_facts','fact_delete'),('memories','memory_delete'),('logs','log_delete')]:
            self.assertIsNone(self.row(table,item),(table,item))
        for table,item in [('worlds',Z),('sessions',T),('documents','doc_keep'),('logs','log_keep'),('logs','log_foreign'),('sessions','session_foreign')]:
            self.assertIsNotNone(self.row(table,item),(table,item))
        self.assertNotIn(W,self.row('users',U)[0])

    def test_deletion_rejected_for_foreign_user_no_mutation(self):
        before=self.db.execute("SELECT count(*) FROM sessions").fetchone()[0]
        with self.assertRaises(repos.WriterError):
            repos.delete_session(self.db,S,V)
        with self.assertRaises(repos.WriterError):
            repos.delete_world(self.db,W,V)
        with self.assertRaises(repos.WriterError):
            repos.delete_character(self.db,C,V)
        self.db.commit()
        self.reopen()
        self.assertEqual(before,self.db.execute('SELECT count(*) FROM sessions').fetchone()[0])
        self.assertIsNotNone(self.row('characters',C))

    def test_world_delete_blocked_if_foreign_session_depends_on_world(self):
        self.db.execute('UPDATE sessions SET world_id=? WHERE id=?',(W,'session_foreign'))
        self.db.commit()
        with self.assertRaises(repos.WriterError):
            repos.delete_world(self.db,W,U)
        self.db.rollback()
        self.reopen()
        self.assertIsNotNone(self.row('worlds',W))
        self.assertIsNotNone(self.row('sessions','session_foreign'))

    def test_no_false_success_missing_session(self):
        with self.assertRaises(repos.WriterError):
            repos.delete_session(self.db,'missing_session',U)

if __name__=='__main__': unittest.main()
