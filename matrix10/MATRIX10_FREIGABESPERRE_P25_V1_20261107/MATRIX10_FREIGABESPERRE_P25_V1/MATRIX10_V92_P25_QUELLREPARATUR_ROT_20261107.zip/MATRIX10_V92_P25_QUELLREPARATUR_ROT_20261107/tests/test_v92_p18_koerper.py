"""V92 Paket 18 (unabhaengige Pruefung Paket 17, 06.11.2026): der Koerper-Writer schreibt nur eine gepruefte, typisierte Aenderung.

Befund: apply_body_directive machte aus Worttreffern kanonische Koerperzustaende ("Mara keucht vor Schmerzen." -> pain 0.40,
"Mara wird nicht bewusstlos." -> bewusstlos und stumm, "Mara ist nicht blind." -> blind). AMASTER §43.1: "Handlungstext allein
beweist noch keinen erfolgreichen Vollzug ... Eine Handlung erzeugt nur die Folgen, die aus validiertem Vollzug, Intensitaet,
Koerperlage, Weltphysik oder ausdruecklicher Authority getragen werden."
Echte Writer (commit_turn, Puppet-, Avatar-, Commit-Route), SQLite-Ruecklesung ueber neue Verbindung, Neustart (neue App-Instanz),
Folgezug. Gott setzt nur ueber seine getypte Lesung. Keine Nutzer-DB.
V92 Paket 19 (Pruefung Paket 18): eine Lesung wirkt nur mit ihrer Bestaetigungslesung an der zitierten Stelle (`bestaetigt`);
Regie liest nicht mehr aus Woertern (_regie_body_words entfernt); Schlaf ist ein eigener Zustand (`schlaeft`).
"""
import copy
import json
import unittest
import urllib.request
from contextlib import closing
from unittest.mock import patch

import test_v84_kausal_chain as _K84  # offline Flask shim + Szenen-Fixture
from matrix_api import kernel
from matrix_api.db import connect
from matrix_api.repos import get_session
import test_v92_puppet_vertrag as _PV
import test_v92_avatar_route as _AV
from test_v92_puppet_vertrag import FakeProvider, plan
from test_v92_p19_koerper import bestaetigt

MARA, JOHANN, NATIVES = _K84.MARA, _K84.JOHANN, _K84.NATIVES


def figure_commit(action, lesung=None, speech="Au!", start=None, proposals=None):
    s, _, _ = _K84.scene("Johann schubst Mara.")
    s["runtimes"][MARA["id"]].update(start or {"pain": 0.25, "consciousness": 1.0, "canSpeak": True, "canSee": True})
    truth = kernel.bind_turn_truth(user_id="admin", world_id=s["worldId"], session_id=s["id"], role="teilnehmer", speaker_id=MARA["id"],
                                   avatar_id=None, target_id=JOHANN["id"], authority="character", present_ids=s["scene"]["presentIds"],
                                   hears_ids=s["scene"]["hearsIds"], input_kind="autochat", text="", input_actor_id=JOHANN["id"])
    out = kernel.commit_turn(s, truth=truth, speaker=MARA, present=NATIVES, result={"speech": speech, "action": action},
                             proposals=proposals, koerper_lesung=lesung)
    rt = out["runtimes"][MARA["id"]]
    body = [f for f in out["facts"] if f.get("kind") == "body_state" and f.get("actorId") == MARA["id"]]
    act = [f for f in out["facts"] if f.get("kind") == "action" and f.get("actorId") == MARA["id"]]
    return out, rt, body, act


class P18Writer(unittest.TestCase):
    """Kernel: Writer nur mit typisierter, gepruefter Aenderung; Rechte je Authority."""

    def test_words_alone_never_change_the_body(self):
        for action, keys in (("Mara keucht vor Schmerzen.", {"pain": 0.25}), ("Mara wird nicht bewusstlos.", {"consciousness": 1.0, "canSpeak": True}),
                             ("Mara ist nicht blind.", {"canSee": True}), ("Mara bleibt nicht stumm.", {"canSpeak": True}),
                             ("Mara ist nicht verletzt.", {"pain": 0.25}), ("Mara schläft nicht ein.", {"consciousness": 1.0}),
                             ("Mara setzt sich.", {"posture": None})):
            out, rt, body, act = figure_commit(action)
            self.assertEqual(({k: rt.get(k) for k in keys}, body), (keys, []), action)
            self.assertEqual(act[0]["effect"]["koerperPruefung"]["grund"], "keine_lesung", action)

    def test_a_validated_reading_changes_position_and_sleep_with_audit(self):
        a = "Mara setzt sich auf die Bank."
        out, rt, body, act = figure_commit(a, bestaetigt({"haltung": "sitzend", "schlaf": None, "zeit": "jetzt", "beleg": "setzt sich auf die Bank"}, a))
        self.assertEqual((rt.get("posture"), rt.get("mobility"), rt.get("pain")), ("sitzend", 0.7, 0.25))
        self.assertEqual(len(body), 1)
        self.assertEqual(body[0]["payload"]["aenderung"], {"haltung": "sitzend"})
        self.assertEqual(body[0]["cause_fact_id"] if "cause_fact_id" in body[0] else body[0].get("causeFactId"), act[0]["id"])
        self.assertEqual(act[0]["effect"]["koerperPruefung"], {"bestaetigt": True, "haltung": "sitzend", "beleg": "setzt sich auf die Bank", "zeit": "jetzt",
                                                                "bestaetigung": {"haltung": {"art": "tatsaechlich", "inhalt": "gleich",
                                                                                             "beleg": "setzt sich auf die Bank", "bestaetigt": True}}})
        a = "Mara schläft auf dem Stuhl ein."
        out, rt, body, act = figure_commit(a, bestaetigt({"haltung": "sitzend", "schlaf": "einschlafen", "zeit": "jetzt", "beleg": "schläft auf dem Stuhl ein"}, a))
        # V92 Paket 19: asleep she speaks no words (one speech rule) and the state says she sleeps
        self.assertEqual((rt.get("posture"), rt.get("consciousness"), rt.get("canSpeak"), rt.get("schlaeft")), ("sitzend", 0.4, False, True))
        # V92 Paket 19 (Pruefung P18 N1): asleep, her own validated waking is the one act she can do
        a = "Mara wacht auf."
        out, rt, body, act = figure_commit(a, bestaetigt({"schlaf": "aufwachen", "zeit": "jetzt", "beleg": "wacht auf"}, a),
                                           start={"consciousness": 0.4, "schlaeft": True, "canSpeak": False, "posture": "liegend"})
        self.assertEqual((act[0].get("validated"), act[0].get("rejection_reason"), rt.get("consciousness"), rt.get("canSpeak")), (True, None, 1.0, True))
        # unconscious (not asleep) she cannot wake herself - nothing of the turn is executable, no turn is written
        out, rt, body, act = figure_commit(a, bestaetigt({"schlaf": "aufwachen", "zeit": "jetzt", "beleg": "wacht auf"}, a),
                                           start={"consciousness": 0.2, "canSpeak": False, "posture": "liegend"})
        self.assertEqual((act, body, rt.get("consciousness")), ([], [], 0.2))
        for start, speak in (({"consciousness": 0.4, "schlaeft": True, "canSpeak": False}, True), ({"consciousness": 0.4, "canSpeak": False, "gagged": True}, False)):
            s = {"runtimes": {"m": dict(start)}, "facts": [], "scene": {"presentIds": ["m"]}}
            kernel.apply_body_directive(s, "m", {"schlaf": "aufwachen"}, fact_id="f", turn=2, authority="character", text="Mara wacht auf.")
            self.assertEqual((s["runtimes"]["m"].get("consciousness"), s["runtimes"]["m"].get("canSpeak")), (1.0, speak), "gagged stays mute")

    def test_an_invalid_reading_changes_nothing(self):
        cases = [({"haltung": "sitzend", "zeit": "vergangen", "beleg": "setzt sich"}, "zeit_vergangen"),
                 ({"haltung": "sitzend", "zeit": "jetzt", "beleg": "legt sich hin"}, "beleg_nicht_in_handlung"),
                 ({"haltung": "sich aufrichten", "zeit": "jetzt", "beleg": "setzt sich"}, "wert_unbekannt"),
                 ({"haltung": None, "schlaf": None, "zeit": "jetzt", "beleg": None}, "keine_veraenderung"),
                 # fields a participant's reading cannot carry: forged pain / unconsciousness / blindness are not even read
                 ({"schmerz": "neu", "bewusstsein": "bewusstlos", "sehen": "verliert", "zeit": "jetzt", "beleg": "setzt sich"}, "keine_veraenderung")]
        for lesung, grund in cases:
            out, rt, body, act = figure_commit("Mara setzt sich.", lesung)
            self.assertEqual((rt.get("posture"), rt.get("pain"), rt.get("consciousness"), rt.get("canSee"), body), (None, 0.25, 1.0, True, []), lesung)
            self.assertEqual(act[0]["effect"]["koerperPruefung"]["grund"], grund, lesung)

    def test_writer_rights_by_authority(self):
        full = {"haltung": "sitzend", "schmerz": "neu", "bewusstsein": "bewusstlos", "sehen": "verliert", "sprechen": "verliert",
                "verletzung": {"seite": "rechte", "glied": "arm", "art": "gebrochen", "schwer": True}}
        for auth, expect in (("character", {"posture": "sitzend", "pain": 0.25, "consciousness": 1.0, "canSee": True, "canSpeak": True}),
                             ("puppet", {"posture": "sitzend", "pain": 0.25, "consciousness": 1.0, "canSee": True, "canSpeak": True}),
                             ("teilnehmer", {"posture": "sitzend", "pain": 0.25, "consciousness": 1.0, "canSee": True, "canSpeak": True}),
                             ("god", {"posture": "liegend", "pain": 0.7, "consciousness": 0.2, "canSee": False, "canSpeak": False}),
                             ("regie", {"posture": "liegend", "pain": 0.7, "consciousness": 0.2, "canSee": False, "canSpeak": False})):
            s = {"runtimes": {"m": {"pain": 0.25, "consciousness": 1.0, "canSee": True, "canSpeak": True}}, "facts": [], "scene": {"presentIds": ["m"]}}
            kernel.apply_body_directive(s, "m", full, fact_id="f1", turn=2, authority=auth, text="x")
            self.assertEqual({k: s["runtimes"]["m"].get(k) for k in expect}, expect, auth)
        self.assertEqual(kernel.apply_body_directive({"runtimes": {}}, "m", "Mara wird bewusstlos.", fact_id="f", turn=1, authority="god"), {},
                         "text is no writer input any more")

    def test_regie_word_reading_is_removed(self):
        # V92 Paket 19 (Pruefung P18, Regie-Koerperkette): the former Regie word reading is gone - a Regie text without the
        # server's reading changes no body state (its typed contract: test_v92_p19_koerper.P19Regie)
        self.assertFalse(hasattr(kernel, "_regie_body_words"))
        self.assertFalse([n for n in dir(kernel) if n.startswith("_BODY_") and n.endswith("_RE")])
        for text in ("Mara wird nicht bewusstlos.", "Mara ist nicht blind.", "Mara keucht vor Schmerzen.", "Mara setzt sich."):
            s, _, _ = _K84.scene("x")
            s["runtimes"][MARA["id"]].update(pain=0.25, consciousness=1.0, canSee=True)
            out = kernel.apply_regie(s, {}, text, actor_id=MARA["id"], present=NATIVES)
            rt = out["runtimes"][MARA["id"]]
            self.assertEqual((rt.get("pain"), rt.get("consciousness"), rt.get("canSee"), rt.get("posture")), (0.25, 1.0, True, None), text)
            self.assertFalse([f for f in out["facts"] if f.get("kind") == "body_state"], text)

    def test_god_sets_only_from_its_typed_reading(self):
        s, _, _ = _K84.scene("x")
        s["runtimes"][MARA["id"]].update(pain=0.1, canSee=True, consciousness=1.0)
        out = kernel.apply_god(s, "Mara hat starke Schmerzen.", "body", MARA["id"], natives=NATIVES,
                               body_state=bestaetigt({"schmerz": "stark", "beleg": "starke Schmerzen"}, "Mara hat starke Schmerzen.",
                                                     authority="god", figur_id=MARA["id"]))
        self.assertEqual(out["runtimes"][MARA["id"]]["pain"], 0.8, "typed God reading still sets the value")
        out = kernel.apply_god(s, "Mara ist nicht blind und nicht verletzt.", "body", MARA["id"], natives=NATIVES, body_state=None)
        rt = out["runtimes"][MARA["id"]]
        self.assertEqual((rt.get("pain"), rt.get("canSee")), (0.1, True), "no reading -> no body state from words")
        self.assertTrue(out["godFacts"][-1].get("payload", {}).get("koerperNichtGelesen") or
                        any(f.get("payload", {}).get("koerperNichtGelesen") for f in out["facts"]))
        out = kernel.apply_god(s, "Mara schläft ein.", "character", MARA["id"], natives=NATIVES)
        self.assertEqual(out["runtimes"][MARA["id"]].get("consciousness"), 1.0, "a character-scope God fact writes no body state")

    def test_follow_up_turn_after_a_negated_unconsciousness_speaks(self):
        out, rt, body, act = figure_commit("Mara wird nicht bewusstlos.", {"haltung": None, "schlaf": None, "zeit": "jetzt", "beleg": None})
        truth = kernel.bind_turn_truth(user_id="admin", world_id=out["worldId"], session_id=out["id"], role="teilnehmer", speaker_id=MARA["id"],
                                       avatar_id=None, target_id=JOHANN["id"], authority="character", present_ids=out["scene"]["presentIds"],
                                       hears_ids=out["scene"]["hearsIds"], input_kind="autochat", text="", input_actor_id=JOHANN["id"])
        nxt = kernel.commit_turn(out, truth=truth, speaker=MARA, present=NATIVES, result={"speech": "Ich bin wach und antworte dir."})
        self.assertEqual([f["text"] for f in nxt["facts"][len(out["facts"]):] if f.get("kind") == "speech" and f.get("actorId") == MARA["id"]],
                         ["Ich bin wach und antworte dir."])


def _sitz(p):
    return {"haltung": "sitzend", "schlaf": None, "zeit": "jetzt", "beleg": "setzt sich auf die Bank"} if "setzt sich auf die Bank" in p.get("handlung", "") else {"haltung": None, "schlaf": None, "zeit": "jetzt", "beleg": None}


class P18PuppetRoute(unittest.TestCase):
    """Echte Route /api/kernel/puppet: Koerperlage nur aus der Server-Lesung; eine Lesung im Plan wird verworfen."""
    setUp = _PV.PuppetRouteChain.setUp
    session = _PV.PuppetRouteChain.session
    snapshot = _PV.PuppetRouteChain.snapshot
    puppet = _PV.PuppetRouteChain.puppet
    _act_comp = _PV.PuppetRouteChain._act_comp

    def sql(self):
        with closing(connect(self.dbp)) as c:
            return get_session(c, "admin", "ses_v92")

    def test_position_only_from_the_server_reading_over_http_sqlite_restart(self):
        c1 = dict(self._act_comp("Johann setzt sich auf die Bank"), ziel=None, wirkung="ohne_koerperwirkung")
        r = self.puppet(FakeProvider([plan("action", "act", [c1])], koerper=lambda p: {**_sitz(p), "beleg": "setzt sich auf die Bank"}),
                        "Johann setzt sich auf die Bank.")
        self.assertEqual(r.status_code, 200, r.get_data(as_text=True)[:300])
        s = self.sql()
        rt = s["runtimes"][self.J["id"]]
        self.assertEqual(rt.get("posture"), "sitzend")
        af = [f for f in s["facts"] if f.get("kind") == "action" and f.get("actorId") == self.J["id"]][-1]
        self.assertEqual(af["effect"]["koerperPruefung"]["bestaetigt"], True)
        self.assertTrue(any(f.get("kind") == "body_state" and f.get("actorId") == self.J["id"] for f in s["facts"]))
        # a reading that comes WITH the plan (model or client) is not the server's: removed, the server's reading decides
        before = self.snapshot(self.session())
        c2 = dict(self._act_comp("Johann legt sich nicht hin"), ziel=None, wirkung="ohne_koerperwirkung",
                  koerperPruefung={"haltung": "liegend", "zeit": "jetzt", "beleg": "legt sich"})
        r = self.puppet(FakeProvider([plan("action", "act", [c2])], vollzug=lambda p: {"geschieht": True, "art": "tatsaechlich", "beleg": None, "taeter": "figur"}),
                        "Johann legt sich nicht hin.")
        s2 = self.sql()
        self.assertEqual(s2["runtimes"][self.J["id"]].get("posture"), "sitzend", "plan-supplied reading ignored")
        # the stored truth is the same for a new reader after a restart
        from matrix_api import app as appmod
        appmod.create_app(self.dbp)
        self.assertEqual(self.sql()["runtimes"][self.J["id"]].get("posture"), s2["runtimes"][self.J["id"]].get("posture"))

    def test_pain_words_of_the_puppet_do_not_change_its_body(self):
        c1 = dict(self._act_comp("Johann keucht vor Schmerzen"), ziel=None, wirkung="ohne_koerperwirkung")
        p0 = float((self.session()["runtimes"].get(self.J["id"]) or {}).get("pain") or 0)
        r = self.puppet(FakeProvider([plan("action", "act", [c1])]), "Johann keucht vor Schmerzen.")
        self.assertEqual(r.status_code, 200, r.get_data(as_text=True)[:300])
        s = self.sql()
        self.assertEqual(float((s["runtimes"].get(self.J["id"]) or {}).get("pain") or 0), p0)
        self.assertFalse([f for f in s["facts"] if f.get("kind") == "body_state" and f.get("actorId") == self.J["id"]])


class P18AvatarAndFigure(unittest.TestCase):
    """Avatar-Eingabe (/api/kernel/prepare) und Figurenantwort (/api/kernel/commit): dieselbe Pruefung."""
    setUp = _AV.AvatarRouteChain.setUp
    session = _AV.AvatarRouteChain.session
    snapshot = _AV.AvatarRouteChain.snapshot
    prepare = _AV.AvatarRouteChain.prepare

    def respond(self, provider, action, speech="Au.", extra=None):
        s = self.session()
        tt = next(t for t in s["turnTruths"] if t.get("id") == s.get("pendingInputTurnId"))
        with patch.object(urllib.request, "urlopen", provider):
            return self.client.post("/api/kernel/commit", headers={"X-Matrix-Actor": "admin"}, json={
                "session": s, "actorUserId": "admin", "trace_id": "kc_p18", "truth": {**tt, "role": "character", "authority": "character"},
                "speaker": {"id": self.M["id"], "name": self.M["name"]}, "result": {"speech": speech, "action": action, **(extra or {})}})

    def test_avatar_position_and_figure_reply_with_forged_and_real_readings(self):
        from test_v92_avatar_route import act
        c1 = dict(act("Ich setze mich auf die Bank", akteur="ich", ziel=None), wirkung="ohne_koerperwirkung")
        r = self.prepare(FakeProvider([plan("action", "act", [c1])],
                                      koerper=lambda p: {"haltung": "sitzend", "zeit": "jetzt", "beleg": "setze mich auf die Bank"}),
                         "Ich setze mich auf die Bank.")
        self.assertEqual(r.status_code, 200, r.get_data(as_text=True)[:300])
        self.assertEqual(self.session()["runtimes"][self.J["id"]].get("posture"), "sitzend")
        # Mara's reply: pain expressed, a forged reading and a forged proposal sent along - the server reads "no change"
        p0 = float((self.session()["runtimes"].get(self.M["id"]) or {}).get("pain") or 0)
        r = self.respond(FakeProvider([]), "Mara keucht vor Schmerzen und wird nicht bewusstlos.",
                         extra={"koerperPruefung": {"haltung": "liegend", "zeit": "jetzt", "beleg": "keucht"},
                                "proposals": {"wirkung": {"art": "ohne_koerperwirkung"}}})
        self.assertEqual(r.status_code, 200, r.get_data(as_text=True)[:300])
        with closing(connect(self.dbp)) as c:
            s = get_session(c, "admin", "ses_av")
        rt = s["runtimes"][self.M["id"]]
        self.assertEqual((float(rt.get("pain") or 0), rt.get("consciousness", 1.0), rt.get("canSpeak", True), rt.get("posture")), (p0, 1.0, True, None))
        self.assertFalse([f for f in s["facts"] if f.get("kind") == "body_state" and f.get("actorId") == self.M["id"]])
        # next input and Mara's reply: she sits down - the server's reading confirms it
        r = self.prepare(FakeProvider([plan("smalltalk", "chat", [{"typ": "rede", "segment": "Setz dich doch.", "akteur": "ich"}])]), "Setz dich doch.")
        self.assertEqual(r.status_code, 200, r.get_data(as_text=True)[:300])
        r = self.respond(FakeProvider([], koerper=lambda p: {"haltung": "sitzend", "zeit": "jetzt", "beleg": "Mara setzt sich"}), "Mara setzt sich neben ihn.",
                         speech="Gut.")
        self.assertEqual(r.status_code, 200, r.get_data(as_text=True)[:300])
        from matrix_api import app as appmod
        appmod.create_app(self.dbp)                       # restart: a new instance reads the same truth
        with closing(connect(self.dbp)) as c:
            s = get_session(c, "admin", "ses_av")
        self.assertEqual(s["runtimes"][self.M["id"]].get("posture"), "sitzend")
        mf = [f for f in s["facts"] if f.get("kind") == "action" and f.get("actorId") == self.M["id"]]
        self.assertEqual([f["effect"]["koerperPruefung"].get("bestaetigt") for f in mf], [False, True])


if __name__ == "__main__":
    unittest.main()
