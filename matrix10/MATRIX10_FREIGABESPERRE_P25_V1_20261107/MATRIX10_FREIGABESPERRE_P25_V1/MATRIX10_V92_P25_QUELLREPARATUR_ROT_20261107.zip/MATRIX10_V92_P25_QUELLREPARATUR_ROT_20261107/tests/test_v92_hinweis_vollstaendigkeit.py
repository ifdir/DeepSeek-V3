"""V92: no raw server reason code may reach the user as the only explanation.

Every `grund` the kernel can put into an input_component_ambiguity record (bind_input_components,
bind_puppet_input, segment_binding_fault) needs a plain-language text in src/lib/matrix/eingabe-hinweis.ts.
Source-level contract, not a browser test.
"""
import re
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
KERNEL = (ROOT / 'matrix_api' / 'kernel.py').read_text(encoding='utf-8')
HINT = (ROOT / 'src' / 'lib' / 'matrix' / 'eingabe-hinweis.ts').read_text(encoding='utf-8')

# not ambiguity records of the input binding (classification outputs / other routes)
NOT_INPUT_BINDING = {'eindeutig', 'kein_signal', 'wer_ungebunden'}


def _body(name):
    i = KERNEL.index(f'def {name}(')
    j = KERNEL.find('\ndef ', i + 10)
    return KERNEL[i:j]


class HinweisVollstaendigkeit(unittest.TestCase):
    def test_every_input_binding_reason_has_plain_text(self):
        codes = set()
        for fn in ('bind_input_components', 'bind_puppet_input', 'segment_binding_fault', '_speech_from_components', 'act_vollzug_fault',
                   'input_binding_outcome', 'marker_act_components'):
            body = _body(fn)
            codes |= set(re.findall(r'"grund": ?"([a-z_]+)"', body))
            codes |= set(re.findall(r'why = "([a-z_]+)"', body))
            codes |= set(re.findall(r'return "(segment_[a-z_]+)"', body))
            codes |= set(re.findall(r'else "([a-z_]+)"', body))
            codes |= set(re.findall(r'return "([a-z_]*vollz[a-z_]*|[a-z_]*angegeben)"', body))
        codes -= NOT_INPUT_BINDING
        self.assertIn('akteur_ist_nicht_der_sprecher', codes)  # guards the regex itself
        self.assertIn('segment_satz_unvollstaendig', codes)
        self.assertIn('handlung_nicht_vollzogen', codes)
        self.assertIn('vollzug_nicht_angegeben', codes)
        self.assertIn('vollzug_nicht_geprueft', codes)
        self.assertIn('plan_fehlt', codes)
        self.assertIn('komponente_ungueltig', codes)
        missing = sorted(c for c in codes if f'{c}:' not in HINT)
        self.assertEqual(missing, [], f'reason codes without plain text: {missing}')

    def test_tense_reasons_have_prefix_text(self):
        self.assertIn('startsWith("satzzeit_")', HINT)
        self.assertIn('startsWith("zeit_")', HINT)


if __name__ == '__main__':
    unittest.main()
