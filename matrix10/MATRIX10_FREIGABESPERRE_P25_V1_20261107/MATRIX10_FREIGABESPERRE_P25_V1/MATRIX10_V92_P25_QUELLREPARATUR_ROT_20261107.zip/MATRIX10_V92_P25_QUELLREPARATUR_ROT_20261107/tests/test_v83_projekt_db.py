"""Regression for project-local SQLite startup + non-resurrection of deleted seed.
All writes strictly to temporary directories; no original databases modified.
"""
from __future__ import annotations
import re
from contextlib import contextmanager, closing
import json
import os
from pathlib import Path
import shutil
import sqlite3
import sys
import tempfile
import threading
from http.server import ThreadingHTTPServer
from urllib.request import urlopen
import unittest

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from START import BUILD_ID, _build_env, _make_handler
from datenbank_projekt_v81 import project_db_path, prepare_data, verify_db, MARKER
from matrix_api.db import connect, init_schema, _SCHEMA_READY, GASTHAUS_ID

@contextmanager
def unseeded_env(seed: bool = False):
    keys = ('MATRIX_DB','MATRIX_SKIP_SEED','PYTEST_CURRENT_TEST')
    prior = {key: os.environ.get(key) for key in keys}
    try:
        os.environ.pop('MATRIX_DB',None)
        os.environ.pop('PYTEST_CURRENT_TEST',None)
        if seed:
            os.environ.pop('MATRIX_SKIP_SEED',None)
        else:
            os.environ['MATRIX_SKIP_SEED']='1'
        yield
    finally:
        for key, value in prior.items():
            if value is None:
                os.environ.pop(key,None)
            else:
                os.environ[key]=value

class ProjectDatabaseContract(unittest.TestCase):
    def test_first_run_creates_db_in_this_project_and_reuses_it(self):
        with tempfile.TemporaryDirectory() as folder, unseeded_env():
            root = Path(folder)/'Matrix10_Projekt'
            root.mkdir()
            local = project_db_path(root)
            self.assertFalse(local.exists())
            ok,msg = prepare_data(root=root)
            self.assertTrue(ok,msg)
            self.assertTrue(local.is_file())
            verify_db(local)
            self.assertEqual(Path(os.environ['MATRIX_DB']),local.resolve())
            self.assertTrue((local.parent / MARKER).exists())
            with closing(sqlite3.connect(local)) as db:
                tables={r[0] for r in db.execute("SELECT name FROM sqlite_master WHERE type='table'")}
                self.assertIn('worlds',tables)
                db.execute("INSERT INTO users(id,json) VALUES ('my_user','{\"id\":\"my_user\"}')")
                db.commit()
            ok,msg=prepare_data(root=root)
            self.assertTrue(ok,msg)
            with closing(sqlite3.connect(local)) as db:
                self.assertEqual(db.execute("SELECT count(*) FROM users WHERE id='my_user'").fetchone()[0],1)

    def test_known_current_db_imported_into_project_and_source_untouched(self):
        with tempfile.TemporaryDirectory() as folder, unseeded_env():
            root=Path(folder)/'Matrix10_Projekt'
            root.mkdir()
            source=Path(folder)/'MATRIX10_DATEN'/'matrix10.sqlite'
            source.parent.mkdir()
            with closing(connect(source)) as db:
                init_schema(db)
                db.execute("INSERT INTO users(id,json) VALUES ('imported','{\"id\":\"imported\"}')")
                db.commit()
            src_before=source.read_bytes()
            ok,msg=prepare_data(root=root, previous_db=source)
            self.assertTrue(ok,msg)
            dest=project_db_path(root)
            self.assertTrue(dest.exists())
            with closing(sqlite3.connect(dest)) as db:
                self.assertEqual(db.execute("SELECT count(*) FROM users WHERE id='imported'").fetchone()[0],1)
                self.assertEqual(db.execute('PRAGMA quick_check').fetchone()[0],'ok')
            self.assertEqual(source.read_bytes(),src_before)

    def test_existing_project_db_preferred_over_older_legacy_db(self):
        with tempfile.TemporaryDirectory() as folder, unseeded_env():
            root=Path(folder)/'project'; root.mkdir()
            existing=project_db_path(root)
            existing.parent.mkdir()
            with closing(connect(existing)) as db:
                init_schema(db)
                db.execute("INSERT INTO users(id,json) VALUES ('new_user','{\"id\":\"new_user\"}')")
                db.commit()
            source=Path(folder)/'MATRIX10_DATEN'/'matrix10.sqlite'
            source.parent.mkdir()
            with closing(connect(source)) as db:
                init_schema(db)
                db.execute("INSERT INTO users(id,json) VALUES ('old_user','{\"id\":\"old_user\"}')")
                db.commit()
            ok,msg=prepare_data(root=root, previous_db=source)
            self.assertTrue(ok,msg)
            with closing(sqlite3.connect(existing)) as db:
                self.assertEqual(db.execute("SELECT count(*) FROM users WHERE id='new_user'").fetchone()[0],1)
                self.assertEqual(db.execute("SELECT count(*) FROM users WHERE id='old_user'").fetchone()[0],0)

    def test_corrupt_existing_project_sqlite_is_not_replaced(self):
        with tempfile.TemporaryDirectory() as folder, unseeded_env():
            root=Path(folder); local=project_db_path(root)
            local.parent.mkdir()
            local.write_bytes(b'not an sqlite database')
            source=Path(folder)/'old.sqlite'
            with closing(connect(source)) as db:
                init_schema(db)
            with self.assertRaises(sqlite3.DatabaseError):
                prepare_data(root=root,previous_db=source)
            self.assertEqual(local.read_bytes(),b'not an sqlite database')

    def test_db_missing_after_initialization_never_silent_blank(self):
        with tempfile.TemporaryDirectory() as folder, unseeded_env():
            root=Path(folder); db=project_db_path(root)
            ok,msg=prepare_data(root=root)
            self.assertTrue(ok,msg)
            db.unlink()
            ok,msg=prepare_data(root=root)
            self.assertFalse(ok)
            self.assertFalse(db.exists())
            self.assertIn('unerwartet',msg)

    def test_deleted_seed_world_and_character_not_recreated_after_restart(self):
        with tempfile.TemporaryDirectory() as folder, unseeded_env(seed=True):
            path=Path(folder)/'matrix10.sqlite'
            with closing(connect(path)) as db:
                init_schema(db)
                self.assertIsNotNone(db.execute('SELECT id FROM worlds WHERE id=?',(GASTHAUS_ID,)).fetchone())
                db.execute("DELETE FROM characters WHERE id='char_g7_mara'")
                db.commit()
            # In a new Python process the in-memory schema-ready flag is reset.
            _SCHEMA_READY.discard(str(path))
            with closing(connect(path)) as db:
                init_schema(db)
                self.assertIsNone(db.execute("SELECT id FROM characters WHERE id='char_g7_mara'").fetchone())
                db.execute('DELETE FROM characters WHERE world_id=?',(GASTHAUS_ID,))
                db.execute('DELETE FROM worlds WHERE id=?',(GASTHAUS_ID,))
                db.commit()
            _SCHEMA_READY.discard(str(path))
            with closing(connect(path)) as db:
                init_schema(db)
                self.assertIsNone(db.execute('SELECT id FROM worlds WHERE id=?',(GASTHAUS_ID,)).fetchone())
                self.assertEqual(db.execute('SELECT count(*) FROM characters WHERE world_id=?',(GASTHAUS_ID,)).fetchone()[0],0)
                self.assertEqual(db.execute('PRAGMA quick_check').fetchone()[0],'ok')

    def test_static_app_assets_match_version(self):
        self.assertEqual(BUILD_ID,'MATRIX10_CHATHERE_V91_KETTENREPARATUR_20261103')
        server=ThreadingHTTPServer(('127.0.0.1',0),_make_handler('0'))
        thread=threading.Thread(target=server.serve_forever,daemon=True)
        thread.start()
        try:
            base='http://127.0.0.1:'+str(server.server_port)
            with urlopen(base+'/__matrix_start_health') as response:
                self.assertEqual(json.load(response)['buildId'],BUILD_ID)
            with urlopen(base+'/') as response:
                html=response.read().decode('utf-8')
                self.assertIn('content="'+BUILD_ID+'"',html)
                index_asset = re.search(r'/assets/(index-[A-Za-z0-9_-]{8}\.js)', html).group(1)
            with urlopen(base+'/assets/'+index_asset) as response:
                self.assertEqual(response.status,200)
                self.assertGreater(len(response.read()),1000)
            with urlopen(base+'/__matrix_speicher') as response:
                self.assertIn('V91',response.read().decode('utf-8'))
        finally:
            server.shutdown(); server.server_close()

if __name__=='__main__':
    unittest.main()

# Separate dynamically added regression, no source file or production DB involved.
def _parallel_new_project_test(self):
    from concurrent.futures import ThreadPoolExecutor
    with tempfile.TemporaryDirectory() as folder, unseeded_env():
        root = Path(folder)
        with ThreadPoolExecutor(max_workers=2) as pool:
            results = list(pool.map(lambda _i:prepare_data(root=root),[1,2]))
        self.assertTrue(all(ok for ok,_msg in results), results)
        local = project_db_path(root)
        verify_db(local)
        self.assertTrue(local.is_file())
        self.assertEqual(len(list(local.parent.glob('matrix10.sqlite'))),1)
ProjectDatabaseContract.test_parallel_start_cannot_overwrite = _parallel_new_project_test

def _delete_builtin_world_test(self):
    # Tests the actual scoped delete writer, not a direct DELETE statement.
    import types
    try:
        import flask
    except ImportError:
        sys.modules.setdefault('flask',types.SimpleNamespace(jsonify=None,request=None))
    from matrix_api import repos
    with tempfile.TemporaryDirectory() as folder, unseeded_env(seed=True):
        path=Path(folder)/'matrix10.sqlite'
        with closing(connect(path)) as db:
            init_schema(db)
            self.assertEqual(db.execute('SELECT count(*) FROM characters WHERE world_id=?',(GASTHAUS_ID,)).fetchone()[0],5)
            result=repos.delete_world(db,GASTHAUS_ID,'admin')
            db.commit()
            self.assertEqual(result['deleted'],GASTHAUS_ID)
        _SCHEMA_READY.discard(str(path))
        with closing(connect(path)) as db:
            init_schema(db)
            self.assertIsNone(db.execute('SELECT id FROM worlds WHERE id=?',(GASTHAUS_ID,)).fetchone())
            self.assertEqual(db.execute('SELECT count(*) FROM characters WHERE world_id=?',(GASTHAUS_ID,)).fetchone()[0],0)
            self.assertEqual(db.execute('PRAGMA quick_check').fetchone()[0],'ok')
ProjectDatabaseContract.test_built_in_world_deletable_via_writer_and_not_reseeded = _delete_builtin_world_test


def _asset(prefix, root):
    """V92: das aus den Quellen gebaute Dist hat Hash-Namen; genau eine Datei je Chunk-Praefix."""
    hits = sorted(root.glob(prefix + "-*.js"))
    hits = [h for h in hits if re.fullmatch(re.escape(prefix) + r"-[A-Za-z0-9_-]{8}\.js", h.name)]
    assert len(hits) == 1, (prefix, [h.name for h in hits])
    return hits[0]

def _compiled_frontend_has_no_reseed_guards(self):
    root=ROOT/'frontend_dist/assets'
    shell=_asset('shell',root).read_text(encoding='utf-8')
    self.assertIn('worlds:[],characters:[]',shell)
    self.assertNotIn('worlds:Ds().worlds',shell)
    self.assertNotIn('deleteWorld:n=>{n!==`world_gasthaus_7kreis`',shell)
    self.assertNotIn('function ac(){let e=$.getState();if(!e.worlds.some',shell)
    self.assertIn('deleteWorld:n=>{Q(`DELETE /api/worlds`',shell)
    a=_asset('welt.index',root).read_text(encoding='utf-8')
    b=_asset('welt._worldId',root).read_text(encoding='utf-8')
    self.assertNotIn('t.id===`world_gasthaus_7kreis`?null:',a)
    self.assertNotIn('A.id===`world_gasthaus_7kreis`?null:',b)
ProjectDatabaseContract.test_delivered_ui_has_delete_button_for_all_worlds = _compiled_frontend_has_no_reseed_guards

def _copy_active_wal_source_test(self):
    with tempfile.TemporaryDirectory() as folder, unseeded_env():
        base=Path(folder)
        source=base/'previous'/'matrix10.sqlite'
        source.parent.mkdir()
        old=connect(source)
        try:
            init_schema(old)
            old.execute("INSERT INTO users(id,json) VALUES ('wal_user','{\"id\":\"wal_user\"}')")
            old.commit()
            # Keep source connection and its WAL open while taking online backup.
            source_wal=source.with_name(source.name+'-wal')
            self.assertTrue(source_wal.exists())
            root=base/'new-project';root.mkdir()
            ok,msg=prepare_data(root=root,previous_db=source)
            self.assertTrue(ok,msg)
            with closing(sqlite3.connect(project_db_path(root))) as conn:
                self.assertEqual(conn.execute("SELECT count(*) FROM users WHERE id='wal_user'").fetchone()[0],1)
                self.assertEqual(conn.execute('PRAGMA quick_check').fetchone()[0],'ok')
        finally:
            old.close()
ProjectDatabaseContract.test_import_includes_uncheckpointed_committed_WAL = _copy_active_wal_source_test
