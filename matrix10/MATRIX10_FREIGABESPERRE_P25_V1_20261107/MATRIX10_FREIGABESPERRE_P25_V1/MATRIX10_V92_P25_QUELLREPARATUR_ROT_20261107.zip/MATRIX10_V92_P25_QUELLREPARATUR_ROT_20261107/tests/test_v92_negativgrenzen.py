"""V92 Gegenpruefung 04.11.2026 (unabhaengiger Befund, Fall A und B): Negativgrenzen der Puppet-Eingabe.

Binder -> Writer, ohne Provider. Der Routenweg mit SQLite steht in test_v92_puppet_vertrag.py (PuppetRouteChain).
Kein Wort- oder Verneinungslexikon: die Planner-Pflichtangabe `geschieht` und die blinde Zweitlesung `vollzugPruefung` entscheiden.
"""
import json
import unittest
from pathlib import Path

from matrix_api import kernel
from matrix_api.db import GASTHAUS_ID

ROOT = Path(__file__).resolve().parents[1]


def hc(seg, akteur="Johann Bruckner", wirkung="zaertlich", geschieht=True, pruefung=None, ziel="Mara Nowak"):
    c = {"typ": "handlung", "segment": seg, "akteur": akteur, "ziel": ziel, "zeit": "jetzt", "wirkung": wirkung, "bezug": None}
    if geschieht is not None:
        c["geschieht"] = geschieht
    if pruefung is not None:
        c["vollzugPruefung"] = pruefung
    return c


def rc(seg, akteur="Johann Bruckner", einleitung=None, sprecher=None):
    c = {"typ": "rede", "segment": seg, "akteur": akteur, "ziel": "Mara Nowak", "zeit": "jetzt", "wirkung": None, "bezug": None, "einleitung": einleitung}
    if sprecher is not None:
        # V92 Paket 13: binder-level tests hand the binder the server's blind speaker reading where the route attaches it
        # (app._check_component_vollzug, kernel.speaker_reading_needed: an announcement naming nobody or several figures)
        c["sprecherPruefung"] = {"sprecher": sprecher, "beleg": None}
    return c


NEIN = {"geschieht": False, "art": "verneint", "beleg": "nicht", "taeter": "figur"}
JA = {"geschieht": True, "art": "tatsaechlich", "beleg": None, "taeter": "figur"}


class Negativgrenzen(unittest.TestCase):
    def setUp(self):
        seed = json.loads((ROOT / "matrix_api/gasthaus_seed.json").read_text(encoding="utf-8"))
        self.J = next(c for c in seed["characters"] if "Johann" in c["name"]); self.M = next(c for c in seed["characters"] if "Mara" in c["name"])
        self.chars = [self.J, self.M]; self.present = [self.J["id"], self.M["id"]]

    def bind(self, raw, comps, puppet=None):
        puppet = puppet or self.J; target = self.M if puppet is self.J else self.J
        return kernel.bind_puppet_input(raw, {"event_kind": "action", "speech_act": "act", "komponenten": comps}, puppet, self.chars, self.present, addressee_id=target["id"])

    def commit(self, bound, puppet=None):
        puppet = puppet or self.J; target = self.M if puppet is self.J else self.J
        s = {"id": "neg", "userId": "admin", "worldId": GASTHAUS_ID, "role": "puppet", "turnIndex": 0,
             "scene": {"presentIds": self.present, "hearsIds": self.present, "seesIds": self.present, "placeId": "schankraum"},
             "runtimes": {}, "turns": [], "facts": [], "relations": [], "turnTruths": [], "memories": [], "witnessKnowledge": []}
        # same addressee rule as the puppet route (app.py, V92 Paket 14): a speech-named addressee outranks the selection
        return kernel.commit_puppet(s, puppet, bound.get("speech") or "", actions=bound.get("actions"),
                                    target_id=(bound.get("speechTarget") if bound.get("speechTargetSet") else target["id"]),
                                    component_ambiguity=bound.get("ambiguous") or None, figures=self.chars)

    def grunds(self, r):
        return [a.get("grund") for a in r.get("ambiguous") or []]

    # ---- Paket-5-Pruefung 04.11.2026: die Zweitlesung ist Pflicht (fail-closed), nicht optional ----
    def test_p5_missing_or_incomplete_reading_is_no_act(self):
        for pr in (None, {"geschieht": True, "art": "tatsaechlich"}, {"geschieht": True, "art": "tatsaechlich", "taeter": ""},
                   {"geschieht": True, "art": "", "taeter": "figur"}, {"geschieht": "ja", "art": "tatsaechlich", "taeter": "figur"}, "x"):
            r = self.bind("Johann küsst Mara.", [hc("Johann küsst Mara", geschieht=True, pruefung=pr)])
            self.assertEqual((r["actions"], r["speech"]), ([], ""), pr); self.assertIn("vollzug_nicht_geprueft", self.grunds(r))
            self.assertEqual([f for f in self.commit(r).get("facts", []) if f.get("kind") in ("action", "speech")], [])

    def test_p5_apply_component_vollzug_removes_planner_supplied_reading(self):
        c = hc("Johann küsst Mara nicht", geschieht=True, pruefung=JA)
        for readings in ({}, {0: None}, {0: {"geschieht": True, "art": "tatsaechlich"}}):
            out = kernel.apply_component_vollzug([c], readings)
            self.assertNotIn("vollzugPruefung", out[0], readings)
        self.assertIn("vollzugPruefung", c, "the input is not mutated")
        out = kernel.apply_component_vollzug([c], {0: NEIN})
        self.assertEqual(out[0]["vollzugPruefung"]["art"], "verneint")

    def test_p5_extract_turn_plan_drops_planner_supplied_reading(self):
        from unittest.mock import patch
        from matrix_api import llm_contract
        answer = {"komponenten": [dict(hc("Johann küsst Mara nicht"), vollzugPruefung=JA)]}
        routing = {"allowed": True, "model": "m", "endpoint": "http://x", "apiKey": "k"}
        with patch.object(llm_contract, "_llm_json", lambda *a, **k: answer), patch.object(llm_contract, "_routing", lambda d, c: routing), patch.object(llm_contract, "_cfg", lambda *a, **k: {}):
            out = llm_contract.extract_turn_plan(None, "admin", "Johann küsst Mara nicht.", speaker_name="Johann", recipient_name="Mara", puppet=True)
        self.assertNotIn("vollzugPruefung", out["komponenten"][0])

    def test_p5_vollzug_check_needs_a_named_doer(self):
        from unittest.mock import patch
        from matrix_api import llm_contract
        routing = {"allowed": True, "model": "m", "endpoint": "http://x", "apiKey": "k"}
        for ans, ok in (({"geschieht": True, "art": "tatsaechlich", "taeter": "figur"}, True), ({"geschieht": True, "art": "tatsaechlich"}, False),
                        ({"geschieht": True, "art": "tatsaechlich", "taeter": " "}, False), ({"geschieht": True, "art": "tatsaechlich", "taeter": None}, False)):
            with patch.object(llm_contract, "_llm_json", lambda *a, **k: ans), patch.object(llm_contract, "_routing", lambda d, c: routing), patch.object(llm_contract, "_cfg", lambda *a, **k: {}):
                got = llm_contract.vollzug_check(None, "admin", action="x", figur="Johann", aeusserung="x")
            self.assertEqual(got is not None, ok, ans)

    # ---- Paket-6-Pruefung 04.11.2026: der `*Marker*` ist keine Vollzugsentscheidung; ungueltige Komponenten sind keine Rede ----
    def test_p6_marker_cannot_turn_a_denied_act_into_an_event(self):
        r = self.bind("*Johann küsst Mara nicht.*", [hc("Johann küsst Mara nicht.", geschieht=True, pruefung=NEIN)])
        self.assertEqual((r["actions"], r["speech"]), ([], "")); self.assertTrue(r.get("nichts_ausfuehrbar")); self.assertIn("handlung_nicht_vollzogen", self.grunds(r))
        self.assertEqual([f for f in self.commit(r).get("facts", []) if f.get("kind") in ("action", "speech")], [])

    def test_p6_marker_cannot_override_the_actor(self):
        reading = {"geschieht": True, "art": "tatsaechlich", "beleg": None, "taeter": "Johann Bruckner"}
        r = self.bind("*Johann nimmt Mara an der Hand.*", [hc("Johann nimmt Mara an der Hand.", akteur="Mara Nowak", ziel="Johann Bruckner", pruefung=reading)], puppet=self.M)
        self.assertEqual((r["actions"], r["speech"]), ([], "")); self.assertTrue(r.get("nichts_ausfuehrbar"))
        self.assertEqual([f for f in self.commit(r, puppet=self.M).get("facts", []) if f.get("kind") in ("action", "speech")], [])

    # ---- Paket-8-Pruefung C5/C6: reine fremde Rede, abgeschnittene Lesung ----
    def test_p8_pure_foreign_speech_is_no_speech_of_the_puppet(self):
        r = self.bind("Mara sagt: Lass mich in Ruhe!", [rc("Lass mich in Ruhe!", akteur="Mara Nowak", einleitung="Mara sagt:")])
        self.assertEqual((r["speech"], r["actions"]), ("", [])); self.assertTrue(r.get("nichts_ausfuehrbar"))
        self.assertEqual(self.grunds(r), ["rede_akteur_ist_nicht_der_sprecher"], "the foreign speech is listed once, with its announcement")
        self.assertEqual([f for f in self.commit(r).get("facts", []) if f.get("kind") in ("action", "speech")], [])

    def test_p8_cut_reading_rest_is_visible_not_speech(self):
        r = kernel.bind_puppet_input("Johann lächelt. Mara sagt: Lass mich in Ruhe!",
                                     {"event_kind": "action", "speech_act": "act", "_abgeschnitten": True,
                                      "komponenten": [hc("Johann lächelt", wirkung="ohne_koerperwirkung", pruefung=JA)]},
                                     self.J, self.chars, self.present, addressee_id=self.M["id"])
        self.assertEqual([a["text"] for a in r["actions"]], ["Johann lächelt"]); self.assertEqual(r["speech"], "")
        self.assertIn("lesung_abgeschnitten", self.grunds(r)); self.assertIn("rest_ohne_komponente", self.grunds(r))
        self.assertEqual([f["kind"] for f in self.commit(r).get("facts", []) if f.get("kind") in ("action", "speech")], ["action"])

    def test_p8_own_speech_keeps_its_sentence_mark(self):
        r = self.bind("Hallo Mara.", [rc("Hallo Mara")]); self.assertEqual(r["speech"], "Hallo Mara.")
        r = self.bind("Lass mich in Ruhe!", [rc("Lass mich in Ruhe")]); self.assertEqual(r["speech"], "Lass mich in Ruhe!")

    # ---- Paket-10-Pruefung: Identitaet von Sprecher und Akteur ueber die Figur-ID; mehrere Saetze sind mehrere Handlungen ----
    def _with_second_johann(self):
        import copy as _cp
        w = _cp.deepcopy(self.J); w["id"] = "char_test_johann_weber"; w["name"] = "Johann Weber"; w["aliases"] = []
        self.chars = self.chars + [w]; self.present = self.present + [w["id"]]
        return w

    def test_p11_speech_of_another_figure_is_never_the_puppets(self):
        raw = "Mara sagt: Lass mich in Ruhe!"
        for c in (rc("Lass mich in Ruhe!", akteur=None, einleitung="Mara sagt:"), rc("Lass mich in Ruhe!", einleitung="Mara sagt:"),
                  rc("Lass mich in Ruhe!")):
            r = self.bind(raw, [c])
            self.assertEqual(r["speech"], "", c); self.assertTrue(r.get("nichts_ausfuehrbar"), c)
            self.assertEqual([f for f in self.commit(r).get("facts", []) if f.get("kind") in ("action", "speech")], [])

    def test_p11_speech_without_speaker_is_unproven(self):
        r = self.bind("Hallo Mara.", [rc("Hallo Mara.", akteur=None)])
        self.assertEqual(r["speech"], ""); self.assertIn("rede_sprecher_fehlt", self.grunds(r))

    def test_p11_announcement_naming_the_speaker_stays_speech(self):
        r = self.bind("Johann sagt: Komm her.", [rc("Komm her.", einleitung="Johann sagt:")])
        self.assertEqual((r["speech"], self.grunds(r)), ("Komm her.", []))

    def test_p12_announcement_naming_two_figures_needs_the_speaker_reading(self):   # Paket-11-Pruefung Sprecherrolle
        def c(sprecher=None, einl="Johann sagt zu Mara:"):
            x = rc("Komm her.", einleitung=einl)
            if sprecher is not None:
                x["sprecherPruefung"] = {"sprecher": sprecher, "beleg": None}
            return x
        self.assertEqual(self.bind("Johann sagt zu Mara: Komm her.", [c("figur")])["speech"], "Komm her.")
        self.assertEqual(self.bind("Johann sagt zu Mara: Komm her.", [c("Johann Bruckner")])["speech"], "Komm her.")
        r = self.bind("Johann sagt zu Mara: Komm her.", [c()]); self.assertEqual(r["speech"], ""); self.assertIn("rede_sprecher_unklar", self.grunds(r))
        r = self.bind("Mara sagt zu Johann: Komm her.", [c("Mara Nowak", "Mara sagt zu Johann:")])
        self.assertEqual(r["speech"], ""); self.assertIn("rede_akteur_ist_nicht_der_sprecher", self.grunds(r))
        self.assertEqual([f for f in self.commit(r).get("facts", []) if f.get("kind") == "speech"], [])
        self.assertEqual(kernel.speaker_reading_indices("Mara sagt zu Johann: Komm her.", [c(None, "Mara sagt zu Johann:")], self.chars), [0])
        # V92 Paket 13: the route reads every validated announcement (an own act may stand inside it); the BINDER needs the
        # reading only where the announcement does not decide by itself - "Johann sagt:" decides by itself
        self.assertFalse(kernel.speaker_reading_needed("Johann sagt:", self.chars)[0])
        self.assertTrue(kernel.speaker_reading_needed("Mara sagt zu Johann:", self.chars)[0])

    def test_p12_one_identity_procedure_for_targets(self):                         # Paket-11-Pruefung Zielidentitaet
        import copy as _cp
        s = _cp.deepcopy(self.M); s["id"] = "char_test_mara_schmidt"; s["name"] = "Mara Schmidt"; s["aliases"] = []
        for figs in ([self.J, self.M, s], [s, self.J, self.M]):
            self.assertEqual(kernel._match_figure("Mara Schmidt", figs)["id"], s["id"])
            self.assertEqual(kernel._match_figure("Mara Nowak", figs)["id"], self.M["id"])
            self.assertIsNone(kernel._match_figure("Mara", figs), "a name two figures carry binds nobody")
        self.chars = self.chars + [s]; self.present = self.present + [s["id"]]
        r = self.bind("Johann berührt Mara.", [hc("Johann berührt Mara", ziel="Mara", pruefung=JA)])
        self.assertIsNone(r["actions"][0]["targetId"]); self.assertIn("ziel_unklar", self.grunds(r))
        r = self.bind("Johann schubst Mara Schmidt.", [hc("Johann schubst Mara Schmidt", ziel="Mara Nowak", wirkung="gewalt", pruefung=JA)])
        self.assertIsNone(r["actions"][0]["targetId"]); self.assertFalse(r["actions"][0]["effectValid"]); self.assertIn("ziel_widerspricht_text", self.grunds(r))
        r = self.bind("Johann schubst Mara Schmidt.", [hc("Johann schubst Mara Schmidt", ziel="Mara Schmidt", wirkung="gewalt", pruefung=JA)])
        self.assertEqual(r["actions"][0]["targetId"], s["id"])
        out = self.commit(r)
        self.assertEqual({f.get("targetId") for f in out["facts"] if f.get("kind") in ("action", "physical")}, {s["id"]})
        self.assertGreater(float((out.get("runtimes") or {}).get(s["id"], {}).get("pain") or 0), 0)
        self.assertEqual(float((out.get("runtimes") or {}).get(self.M["id"], {}).get("pain") or 0), 0.0)
        self.assertEqual({(m["characterId"], m["kind"]) for m in out.get("memories", [])},
                         {(self.J["id"], "getan"), (s["id"], "erlebt"), (self.M["id"], "gesehen")})

    def test_p12_compound_split_before_the_reading(self):
        parts = kernel.split_compound_acts([hc("Johann lächelt. Johann winkt.", wirkung="ohne_koerperwirkung", pruefung=JA), rc("Hallo.")])
        self.assertEqual([(p["typ"], p["segment"], "vollzugPruefung" in p) for p in parts],
                         [("handlung", "Johann lächelt.", False), ("handlung", "Johann winkt.", False), ("rede", "Hallo.", False)])

    def test_p11_two_figures_called_johann(self):
        self._with_second_johann()
        r = self.bind("Johann Weber winkt.", [hc("Johann Weber winkt", akteur="Johann Weber", pruefung=dict(JA, taeter="Johann Weber"))])
        self.assertEqual(r["actions"], []); self.assertIn("akteur_ist_nicht_der_sprecher", self.grunds(r))
        r = self.bind("Johann winkt.", [hc("Johann winkt", akteur="Johann", pruefung=dict(JA, taeter="Johann"))])
        self.assertEqual(r["actions"], []); self.assertIn("akteur_unklar", self.grunds(r))
        r = self.bind("Johann Weber sagt: Hallo.", [rc("Hallo.", akteur="Johann Weber", einleitung="Johann Weber sagt:")])
        self.assertEqual(r["speech"], ""); self.assertIn("rede_akteur_ist_nicht_der_sprecher", self.grunds(r))
        r = self.bind("Johann sagt: Hallo.", [rc("Hallo.", akteur="Johann", einleitung="Johann sagt:")])
        self.assertEqual(r["speech"], ""); self.assertIn("rede_sprecher_unklar", self.grunds(r))
        r = self.bind("Johann Bruckner winkt.", [hc("Johann Bruckner winkt", pruefung=dict(JA, taeter="Johann Bruckner"))])
        self.assertEqual([a["text"] for a in r["actions"]], ["Johann Bruckner winkt"])          # full name: bound

    def test_p11_one_component_over_two_sentences_is_not_one_act(self):
        r = self.bind("*Johann lächelt. Johann winkt.*", [hc("Johann lächelt. Johann winkt.", wirkung="ohne_koerperwirkung", pruefung=JA)])
        self.assertEqual(r["actions"], []); self.assertIn("segment_mehrere_saetze", self.grunds(r))

    def test_p11_unread_marker_with_two_sentences_gives_two_components(self):
        mks = kernel.marker_act_components("*Johann lächelt. Johann winkt.* Hallo.", [rc("Hallo.")], "Johann Bruckner")
        self.assertEqual([m["segment"] for m in mks], ["Johann lächelt.", "Johann winkt."])
        for m in mks:
            m["vollzugPruefung"] = JA
        r = self.bind("*Johann lächelt. Johann winkt.* Hallo.", [rc("Hallo.")] + mks)
        self.assertEqual([a["text"] for a in r["actions"]], ["Johann lächelt", "Johann winkt"]); self.assertEqual(r["speech"], "Hallo.")
        self.assertEqual([f["text"].rstrip(".") for f in self.commit(r).get("facts", []) if f.get("kind") == "action"], ["Johann lächelt", "Johann winkt"])

    # ---- Paket-9-Pruefung P9-01/P9-02: Marker machen keinen Handlungstext; jeder Marker zaehlt ----
    def test_p10_partial_marker_never_widens_the_checked_act(self):
        for rest in ("Johann küsst Mara nicht.", "Mara küsst Johann.", "Johann schubst Mara."):
            raw = "*Johann lächelt. " + rest + "*"
            r = self.bind(raw, [hc("Johann lächelt", wirkung="ohne_koerperwirkung", pruefung=JA)])
            self.assertEqual([a["text"] for a in r["actions"]], ["Johann lächelt"], rest)
            self.assertIn(("rest_ohne_komponente", rest), [(a["grund"], a["segment"]) for a in r["ambiguous"]])
            out = [f["text"] for f in self.commit(r).get("facts", []) if f.get("kind") in ("action", "speech")]
            self.assertEqual(out, ["Johann lächelt"], rest)

    def test_p10_every_marker_keeps_its_checked_act(self):
        r = self.bind("*Johann lächelt.* *Johann winkt.*", [hc("Johann lächelt", wirkung="ohne_koerperwirkung", pruefung=JA),
                                                             hc("Johann winkt", wirkung="ohne_koerperwirkung", pruefung=JA)])
        self.assertEqual([a["text"] for a in r["actions"]], ["Johann lächelt", "Johann winkt"])
        self.assertEqual([f["text"] for f in self.commit(r).get("facts", []) if f.get("kind") == "action"], ["Johann lächelt", "Johann winkt"])

    def test_p10_a_second_marker_nobody_read_is_unproven_not_lost_silently(self):
        r = self.bind("*Johann lächelt.* *Johann schubst Mara.*", [hc("Johann lächelt", wirkung="ohne_koerperwirkung", pruefung=JA)])
        self.assertEqual([a["text"] for a in r["actions"]], ["Johann lächelt"])
        self.assertIn(("vollzug_nicht_geprueft", "Johann schubst Mara."), [(a["grund"], a["segment"]) for a in r["ambiguous"]])

    def test_p10_a_second_marker_denied_by_its_reading_stays_out(self):
        comps = [hc("Johann lächelt", wirkung="ohne_koerperwirkung", pruefung=JA)]
        mks = kernel.marker_act_components("*Johann lächelt.* *küsst Mara nicht*", comps, "Johann Bruckner")
        self.assertEqual([m["segment"] for m in mks], ["küsst Mara nicht"])
        mks[0]["vollzugPruefung"] = NEIN
        r = self.bind("*Johann lächelt.* *küsst Mara nicht*", comps + mks)
        self.assertEqual([a["text"] for a in r["actions"]], ["Johann lächelt"]); self.assertIn("handlung_nicht_vollzogen", self.grunds(r))

    def test_p10_words_inside_a_marker_are_never_speech(self):
        r = self.bind("*sagt leise Hallo* Komm her.", [rc("sagt leise Hallo"), rc("Komm her.")])
        self.assertEqual(r["speech"], "Komm her."); self.assertIn("rede_ueberlappt_handlung", self.grunds(r))

    # ---- Paket 9: Komponente aus dem eigenen *Marker* (Planer liess ihn aus) - Zweitlesung bleibt Pflicht ----
    def _mk(self, raw, comps):
        mks = kernel.marker_act_components(raw, comps, "Johann Bruckner")
        return comps + mks, (mks[0] if mks else None)

    def test_p9_marker_component_is_added_only_when_the_reading_left_the_marker_out(self):
        _, mk = self._mk("*lächelt* Hallo Mara.", [rc("Hallo Mara.")])
        self.assertEqual((mk["segment"], mk["markierung"], mk.get("geschieht")), ("lächelt", True, None))
        _, mk = self._mk("*Johann lächelt.* Hallo.", [hc("Johann lächelt", geschieht=True), rc("Hallo.")])
        self.assertIsNone(mk, "the reading has the marked act already")
        self.assertIsNone(self._mk("Hallo Mara.", [rc("Hallo Mara.")])[1], "no marker, no component")

    def test_p9_marker_component_with_complete_reading_is_the_act(self):
        comps, mk = self._mk("*lächelt* Hallo Mara.", [rc("Hallo Mara.")])
        mk["vollzugPruefung"] = JA
        r = self.bind("*lächelt* Hallo Mara.", comps)
        self.assertEqual([a["text"] for a in r["actions"]], ["lächelt"]); self.assertEqual(r["speech"], "Hallo Mara.")

    def test_p9_marker_component_still_needs_the_reading_and_obeys_it(self):
        for pr, grund in ((None, "vollzug_nicht_geprueft"), (NEIN, "handlung_nicht_vollzogen"),
                          ({"geschieht": True, "art": "tatsaechlich", "beleg": None, "taeter": "Mara Nowak"}, "akteur_ist_nicht_der_sprecher")):
            comps, mk = self._mk("*küsst Mara nicht* Hallo.", [rc("Hallo.")])
            if pr is not None:
                mk["vollzugPruefung"] = pr
            r = self.bind("*küsst Mara nicht* Hallo.", comps)
            self.assertEqual(r["actions"], [], pr); self.assertIn(grund, self.grunds(r)); self.assertEqual(r["speech"], "Hallo.")

    def test_p9_marked_act_is_never_the_announcement_of_speech(self):        # live 05.11.: einleitung "*lächelt*"
        comps, mk = self._mk("*lächelt* Hallo Mara.", [rc("Hallo Mara.", einleitung="*lächelt*")])
        mk["vollzugPruefung"] = JA
        r = self.bind("*lächelt* Hallo Mara.", comps)
        self.assertEqual([a["text"] for a in r["actions"]], ["lächelt"]); self.assertEqual(r["speech"], "Hallo Mara."); self.assertNotIn("segment_satz_unvollstaendig", self.grunds(r))
        r = self.bind("Johann sagt: Hallo.", [rc("Hallo.", einleitung="Johann sagt:")])      # a real announcement stays one
        self.assertEqual((r["speech"], self.grunds(r)), ("Hallo.", []))

    def test_p9_marker_flag_on_other_words_is_no_declaration(self):
        c = hc("Johann küsst Mara", geschieht=None, pruefung=JA); c["markierung"] = True       # not the marked text of the input
        r = self.bind("Johann küsst Mara. *lächelt*", [c])
        self.assertEqual(r["actions"], []); self.assertIn("vollzug_nicht_angegeben", self.grunds(r))

    # ---- Paket-7-Pruefung P7-01/02, A7-01/02 ----
    def test_p7_marker_rest_with_foreign_speech_is_not_johanns_speech(self):
        r = self.bind("*Johann lächelt.* Mara sagt: Lass mich in Ruhe!",
                      [hc("Johann lächelt", wirkung="ohne_koerperwirkung", geschieht=True, pruefung=JA), rc("Lass mich in Ruhe!", akteur="Mara Nowak", einleitung="Mara sagt:")])
        self.assertEqual([a["text"] for a in r["actions"]], ["Johann lächelt"]); self.assertEqual(r["speech"], "")
        out = self.commit(r); self.assertEqual([f["text"] for f in out["facts"] if f.get("kind") == "speech" and f.get("actorId") == self.J["id"]], [])

    def test_p7_marker_rest_with_foreign_act_is_not_johanns_speech(self):
        r = self.bind("*Johann lächelt.* Mara geht aus dem Raum.",
                      [hc("Johann lächelt", wirkung="ohne_koerperwirkung", geschieht=True, pruefung=JA),
                       hc("Mara geht aus dem Raum", akteur="Mara Nowak", ziel=None, wirkung="ohne_koerperwirkung", geschieht=True, pruefung=JA)])
        self.assertEqual(r["speech"], ""); self.assertIn("akteur_ist_nicht_der_sprecher", self.grunds(r))
        out = self.commit(r); self.assertEqual([f for f in out["facts"] if f.get("kind") == "speech"], [])

    def test_p7_marker_with_own_speech_keeps_both(self):
        r = self.bind("*Johann lächelt.* Hallo Mara.", [hc("Johann lächelt", wirkung="ohne_koerperwirkung", geschieht=True, pruefung=JA), rc("Hallo Mara.")])
        self.assertEqual(([a["text"] for a in r["actions"]], r["speech"]), (["Johann lächelt"], "Hallo Mara."))

    def test_p6_marker_act_copied_with_its_stars_by_the_planner_works(self):      # Live-Befund Paket 7: Segment "*lächelt*"
        r = self.bind("*lächelt*", [hc("*lächelt*", wirkung="ohne_koerperwirkung", geschieht=True, pruefung=JA)])
        self.assertEqual([a["text"] for a in r["actions"]], ["lächelt"]); self.assertFalse(r.get("nichts_ausfuehrbar"))
        r = self.bind("*Johann küsst Mara nicht.*", [hc("*Johann küsst Mara nicht.*", geschieht=True, pruefung=NEIN)])
        self.assertEqual(r["actions"], []); self.assertTrue(r.get("nichts_ausfuehrbar"))

    def test_p6_marker_without_any_validated_component_is_unproven(self):
        for comps in ([hc("Johann küsst Mara", geschieht=True)], [rc("Hallo.")]):                  # no reading / only speech elsewhere
            r = self.bind("*Johann küsst Mara.*", comps)
            self.assertEqual(r["actions"], []); self.assertTrue(r.get("nichts_ausfuehrbar")); self.assertIn("vollzug_nicht_geprueft", self.grunds(r))

    def test_p6_marker_with_a_checked_act_still_works(self):
        r = self.bind("*Johann streichelt Mara.* Hallo.", [hc("Johann streichelt Mara", geschieht=True, pruefung=JA), rc("Hallo.")])
        self.assertEqual([a["text"] for a in r["actions"]], ["Johann streichelt Mara"]); self.assertEqual(r["speech"].rstrip("."), "Hallo")
        self.assertEqual(r["actions"][0]["targetId"], self.M["id"])

    def test_p6_marker_keeps_the_denied_part_out_and_the_checked_part_in(self):
        r = self.bind("*Johann küsst Mara nicht und streichelt ihren Arm.*",
                      [hc("Johann küsst Mara nicht", geschieht=False), hc("streichelt ihren Arm", geschieht=True, pruefung=JA)])
        self.assertEqual([a["text"] for a in r["actions"]], ["streichelt ihren Arm"]); self.assertIn("handlung_nicht_vollzogen", self.grunds(r))

    def test_p6_unknown_component_type_is_not_speech(self):
        for typ in ("request", "unbekannt", ""):
            r = self.bind("Greife Mara auf die Schenkel.", [{"typ": typ, "segment": "Greife Mara auf die Schenkel.", "akteur": "Johann Bruckner"}])
            self.assertTrue(r.get("incomplete"), typ); self.assertEqual((r["speech"], r["actions"]), ("", [])); self.assertIn("komponente_ungueltig", self.grunds(r))
            self.assertEqual([f for f in self.commit(r).get("facts", []) if f.get("kind") in ("action", "speech")], [])

    def test_p6_speech_component_that_stands_nowhere_is_not_speech(self):
        r = self.bind("Hallo Mara.", [rc("ganz etwas anderes")]); self.assertTrue(r.get("incomplete")); self.assertEqual(r["speech"], "")

    def test_p6_real_speech_component_still_speech(self):
        r = self.bind("Hallo Mara.", [rc("Hallo Mara.")]); self.assertFalse(r.get("incomplete")); self.assertEqual(r["speech"], "Hallo Mara.")

    # ---- Fall A: Verneinung im vermeintlich vollstaendigen Segment ----
    def test_a_planner_without_declaration_is_an_unproven_act(self):          # der Fall des unabhaengigen Skripts
        r = self.bind("Johann küsst Mara nicht.", [hc("Johann küsst Mara nicht.", geschieht=None)])
        self.assertEqual(r["actions"], []); self.assertIn("vollzug_nicht_angegeben", self.grunds(r)); self.assertTrue(r.get("nichts_ausfuehrbar"))
        self.assertEqual([f for f in self.commit(r).get("facts", []) if f.get("kind") in ("action", "speech")], [])

    def test_a_planner_declares_denied(self):
        r = self.bind("Johann küsst Mara nicht.", [hc("Johann küsst Mara nicht.", geschieht=False)])
        self.assertEqual(r["actions"], []); self.assertIn("handlung_nicht_vollzogen", self.grunds(r))

    def test_a_independent_reading_overrules_a_wrong_planner_declaration(self):
        r = self.bind("Johann küsst Mara nicht.", [hc("Johann küsst Mara nicht.", geschieht=True, pruefung=NEIN)])
        self.assertEqual(r["actions"], []); self.assertIn("handlung_nicht_vollzogen", self.grunds(r)); self.assertEqual(r["speech"], "")
        self.assertEqual([f for f in self.commit(r).get("facts", []) if f.get("kind") in ("action", "speech")], [])

    def test_a_reading_that_is_no_tatsaechlich_is_no_act_even_with_geschieht_true(self):
        for art in ("wunsch", "frage", "bedingung", "ankuendigung", "erzaehlt", "zitat"):
            r = self.bind("Johann küsst Mara.", [hc("Johann küsst Mara", pruefung={"geschieht": True, "art": art, "beleg": None})])
            self.assertEqual(r["actions"], [], art)

    def test_a_confirmed_act_is_still_bound(self):
        r = self.bind("Johann küsst Mara.", [hc("Johann küsst Mara", geschieht=True, pruefung=JA)])
        self.assertEqual(len(r["actions"]), 1); self.assertEqual(r["actions"][0]["targetId"], self.M["id"])
        facts = self.commit(r).get("facts", []); self.assertTrue([f for f in facts if f.get("kind") == "action" and f.get("validated")])

    def test_a_negation_as_speech_stays_speech_and_is_no_act(self):
        r = self.bind('Johann sagt: "Ich küsse Mara nicht."', [rc("Ich küsse Mara nicht.", einleitung="Johann sagt:")])
        self.assertEqual(r["actions"], []); self.assertIn("küsse Mara nicht", r["speech"])
        self.assertEqual([f for f in self.commit(r).get("facts", []) if f.get("kind") == "action"], [])

    def test_a_denied_act_with_real_speech_keeps_only_the_speech(self):
        r = self.bind("Johann küsst Mara nicht und sagt: Hallo.", [hc("Johann küsst Mara nicht", geschieht=False), rc("Hallo.", einleitung="sagt:", sprecher="Johann")])
        self.assertEqual(r["actions"], []); self.assertEqual(r["speech"].rstrip("."), "Hallo"); self.assertIn("handlung_nicht_vollzogen", self.grunds(r))
        self.assertFalse(r.get("nichts_ausfuehrbar"))

    def test_a_one_denied_one_real_act(self):
        r = self.bind("Johann küsst Mara nicht und streichelt ihren Arm.",
                      [hc("Johann küsst Mara nicht", geschieht=False), hc("streichelt ihren Arm", geschieht=True, pruefung=JA)])
        self.assertEqual([a["text"] for a in r["actions"]], ["streichelt ihren Arm"]); self.assertIn("handlung_nicht_vollzogen", self.grunds(r))

    # ---- Fall B: verworfene Fremdhandlung wird keine Rede ----
    def test_b_foreign_act_is_not_relabelled_as_speech(self):                  # der Fall des unabhaengigen Skripts
        r = self.bind("Johann nimmt Mara an der Hand.", [hc("Johann nimmt Mara an der Hand.", akteur="Johann Bruckner", geschieht=True)], puppet=self.M)
        self.assertEqual((r["actions"], r["speech"]), ([], "")); self.assertTrue(r.get("nichts_ausfuehrbar"))
        self.assertIn("akteur_ist_nicht_der_sprecher", self.grunds(r))
        out = self.commit(r, puppet=self.M)
        self.assertEqual([f for f in out.get("facts", []) if f.get("kind") in ("action", "speech")], [])
        self.assertEqual(out.get("turns"), [], "kein Zug ohne Rede und Handlung")

    def test_b_foreign_act_with_own_real_speech_keeps_only_that_speech(self):
        r = self.bind("Johann nimmt Mara an der Hand und Mara sagt: Hallo.",
                      [hc("Johann nimmt Mara an der Hand", akteur="Johann Bruckner"), rc("Hallo.", akteur="Mara Nowak", einleitung="Mara sagt:")], puppet=self.M)
        self.assertEqual(r["actions"], []); self.assertEqual(r["speech"].rstrip("."), "Hallo")

    def test_b_actor_target_isolation(self):                                   # Johann fuehrt, Mara-Handlung gehoert nicht ihm
        r = self.bind("Johann streichelt Mara und Mara streichelt Johann.",
                      [hc("Johann streichelt Mara", geschieht=True, pruefung=JA), hc("Mara streichelt Johann", akteur="Mara Nowak", ziel="Johann Bruckner", geschieht=True, pruefung=JA)])
        self.assertEqual([a["text"] for a in r["actions"]], ["Johann streichelt Mara"]); self.assertEqual(r["actions"][0]["targetId"], self.M["id"])
        self.assertIn("akteur_ist_nicht_der_sprecher", self.grunds(r))

    # ---- Live-Befund 04.11.: der Planner nannte Mara als Akteur von "Johann nimmt Mara an der Hand." ----
    def test_b_wrong_planner_actor_is_caught_by_the_readings_doer(self):
        reading = {"geschieht": True, "art": "tatsaechlich", "beleg": None, "taeter": "Johann Bruckner"}
        r = self.bind("Johann nimmt Mara an der Hand.", [hc("Johann nimmt Mara an der Hand", akteur="Mara Nowak", ziel="Johann Bruckner", pruefung=reading)], puppet=self.M)
        self.assertEqual((r["actions"], r["speech"]), ([], "")); self.assertTrue(r.get("nichts_ausfuehrbar"))
        self.assertIn("akteur_ist_nicht_der_sprecher", self.grunds(r))
        out = self.commit(r, puppet=self.M)
        self.assertEqual([f for f in out.get("facts", []) if f.get("kind") in ("action", "speech")], [])

    def test_b_reading_doer_figur_or_own_name_is_accepted(self):
        for taeter in ("figur", "Johann Bruckner", "Johann", "ich"):
            reading = {"geschieht": True, "art": "tatsaechlich", "beleg": None, "taeter": taeter}
            r = self.bind("Johann streichelt Mara.", [hc("Johann streichelt Mara", pruefung=reading)])
            self.assertEqual(len(r["actions"]), 1, taeter)

    def test_rejected_act_is_listed_once_not_twice(self):
        r = self.bind("Johann küsst Mara nicht und sagt: Hallo.", [hc("Johann küsst Mara nicht", geschieht=False), rc("Hallo.", einleitung="sagt:", sprecher="Johann")])
        segs = [(a.get("segment"), a.get("grund")) for a in r["ambiguous"]]
        self.assertEqual(len([g for _, g in segs if g == "handlung_nicht_vollzogen"]), 1)
        self.assertFalse([1 for sg, g in segs if g == "rest_ohne_komponente" and "küsst" in str(sg)], segs)

    def test_pure_speech_and_quote_and_mixed_still_work(self):
        self.assertEqual(self.bind("Guten Morgen, Mara.", [rc("Guten Morgen, Mara.")])["speech"], "Guten Morgen, Mara.")
        m = self.bind("Johann lächelt und sagt: Hallo.", [hc("Johann lächelt", wirkung="ohne_koerperwirkung", geschieht=True, pruefung=JA), rc("Hallo.", einleitung="sagt:", sprecher="Johann")])
        self.assertEqual(len(m["actions"]), 1); self.assertEqual(m["speech"].rstrip("."), "Hallo")

    def test_every_rejection_reason_has_a_plain_wording_for_the_error(self):
        for g in ("akteur_ist_nicht_der_sprecher", "handlung_nicht_vollzogen", "vollzug_nicht_angegeben", "zeit_vergangen", "satzzeit_past", "segment_im_zitat", "wirkung_unklar"):
            self.assertTrue(kernel.act_rejection_text(g))


if __name__ == "__main__":
    unittest.main()
