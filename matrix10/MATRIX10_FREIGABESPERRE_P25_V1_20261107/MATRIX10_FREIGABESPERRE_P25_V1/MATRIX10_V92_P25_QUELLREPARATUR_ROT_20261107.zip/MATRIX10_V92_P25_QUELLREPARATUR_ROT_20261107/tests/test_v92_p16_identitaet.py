"""V92 Paket 16 (Paket-15-Pruefung 05.11.2026): Namensgrenze links und rechts belegt, gleiche volle Namensformen gemeinsam, und
eine geschlossene Klaerungskette.

Befunde: "Johann schubst Anna Mara Nowak." mit Planer UND Lesung verkuerzt auf "Mara Nowak" -> Koerperwirkung bei Mara Nowak;
"Anna Johann Bruckner schubst/sagt" -> Handlung/Rede Johann Bruckners; zwei Figuren "Mara Nowak" (Name oder Alias) ->
name_occurrences nahm die ERSTE (bind_referents eine falsche Einzel-ID). Entscheidung: ist die Namensgrenze nicht belegt, bleibt
die ID ungebunden; die Oberflaeche fragt nach, die Antwort bindet genau die gewaehlte Figur. Keine Wortliste, kein zweiter Owner.
"""
import copy
import json
import unittest
import urllib.request
from contextlib import closing
from pathlib import Path
from unittest.mock import patch

import test_v84_kausal_chain  # noqa: F401  (offline Flask shim wie die übrigen Tests)
from matrix_api import kernel
from matrix_api.db import connect
from matrix_api.repos import create_session, get_session
import test_v92_negativgrenzen as _NG
import test_v92_puppet_vertrag as _PV
import test_v92_avatar_route as _AV
from test_v92_negativgrenzen import hc, rc, JA
from test_v92_puppet_vertrag import FakeProvider, plan, comp
from test_v92_avatar_route import act as av_act

ROOT = Path(__file__).resolve().parents[1]


def pain(s, fid):
    return float(((s.get("runtimes") or {}).get(fid) or {}).get("pain") or 0)


def reading(ziel=None, taeter="figur"):
    return {**JA, "taeter": taeter, **({"ziel": ziel} if ziel is not None else {})}


def speech(seg, einl=None, akteur="Johann Bruckner", sprecher=None, adressat=None):
    c = rc(seg, akteur=akteur, einleitung=einl)
    if sprecher is not None or adressat is not None:
        c["sprecherPruefung"] = {"sprecher": sprecher or "figur", "beleg": None, "adressat": adressat}
    return c


def questions(r):
    return [(k["text"], k["kandidaten"]) for k in (a.get("klaerung") for a in r.get("ambiguous") or []) if k]


class P16NameReader(unittest.TestCase):
    setUp = _NG.Negativgrenzen.setUp
    bind = _NG.Negativgrenzen.bind
    commit = _NG.Negativgrenzen.commit
    grunds = _NG.Negativgrenzen.grunds

    def _nothing_for_mara(self, r, key):
        s = self.commit(r)
        self.assertFalse([f for f in s.get("facts", []) if f.get("targetId") == self.M["id"] and f.get("kind") in ("action", "physical")], key)
        self.assertEqual(pain(s, self.M["id"]), 0.0, key)
        self.assertNotIn((self.M["id"], "erlebt"), {(m.get("characterId"), m.get("kind")) for m in s.get("memories") or []}, key)
        return s

    def _claim(self, fid, span):
        self.chars = [dict(c, klaerung=[span]) if c["id"] == fid else c for c in self.chars]

    # ---- Fehlerklasse A: Namensgrenze links (Paket-15-Pruefung N1-N3) ----
    def test_prepended_word_leaves_target_doer_and_speaker_unbound_and_asks(self):
        for lit in ("Mara Nowak", "Mara", None):
            for rev in (False, True):
                self.setUp()
                if rev:
                    self.chars = list(reversed(self.chars)); self.present = list(reversed(self.present))
                r = self.bind("Johann schubst Anna Mara Nowak.", [hc("Johann schubst Anna Mara Nowak", wirkung="gewalt", pruefung=reading(lit, "Johann Bruckner"), ziel="Mara Nowak")])
                self._nothing_for_mara(r, (lit, rev))
                self.assertIn(("Anna Mara Nowak", [self.M["id"]]), questions(r), (lit, rev))
        r = self.bind("Anna Johann Bruckner schubst Mara Nowak.", [hc("Anna Johann Bruckner schubst Mara Nowak", wirkung="gewalt", pruefung=reading("Mara Nowak", "Johann Bruckner"), ziel="Mara Nowak")])
        self.assertEqual(r["actions"], []); self.assertIn("akteur_name_unklar", self.grunds(r)); self._nothing_for_mara(r, "doer")
        self.assertIn(("Anna Johann Bruckner", [self.J["id"]]), questions(r))
        for einl in ("Anna Johann Bruckner sagt:", "sagt:", "Johann Bruckner sagt:"):
            r = self.bind("Anna Johann Bruckner sagt: Hallo.", [speech("Hallo.", einl, sprecher="Johann Bruckner")])
            self.assertEqual(r["speech"], "", einl)
            self.assertEqual([f for f in self.commit(r).get("facts", []) if f.get("kind") == "speech"], [], einl)
            self.assertIn(("Anna Johann Bruckner", [self.J["id"]]), questions(r), einl)
        # a full literal reading of the unknown name: no binding (Paket 15) - it holds the cast name "Mara Nowak", so the operator
        # is asked whether that person is Mara Nowak; a name without any cast name ("Peter") is not asked
        r = self.bind("Johann schubst Anna Mara Nowak.", [hc("Johann schubst Anna Mara Nowak", wirkung="gewalt", pruefung=reading("Anna Mara Nowak", "Johann"), ziel="Mara Nowak")])
        self._nothing_for_mara(r, "voll"); self.assertIn(("Anna Mara Nowak", [self.M["id"]]), questions(r))
        r = self.bind("Johann schubst Peter.", [hc("Johann schubst Peter", wirkung="gewalt", pruefung=reading("Peter", "Johann"), ziel="Peter")])
        self._nothing_for_mara(r, "Peter"); self.assertEqual(questions(r), [])

    def test_the_answer_binds_exactly_the_chosen_figure(self):
        comp_ = [hc("Johann schubst Anna Mara Nowak", wirkung="gewalt", pruefung=reading("Mara Nowak", "Johann Bruckner"), ziel="Mara Nowak")]
        self._claim(self.M["id"], "Anna Mara Nowak")
        r = self.bind("Johann schubst Anna Mara Nowak.", copy.deepcopy(comp_))
        self.assertEqual([a["targetId"] for a in r["actions"]], [self.M["id"]]); self.assertEqual(questions(r), [])
        self.assertGreater(pain(self.commit(r), self.M["id"]), 0.0)
        self.setUp(); self._claim(self.J["id"], "Anna Johann Bruckner")
        r = self.bind("Anna Johann Bruckner sagt: Hallo.", [speech("Hallo.", "Anna Johann Bruckner sagt:", sprecher="Johann Bruckner")])
        self.assertEqual(r["speech"], "Hallo.")
        # the operator's answer outranks the planner's contrary claim (browser 05.11.: answered "Mara Schmidt", planner said Mara Nowak)
        self.setUp(); sch = dict(copy.deepcopy(self.M), id="char_test_mara_schmidt", name="Mara Schmidt", aliases=[])
        self.chars = self.chars + [sch]; self.present = self.present + [sch["id"]]; self._claim(sch["id"], "Mara")
        r = self.bind("Johann berührt Mara.", [hc("Johann berührt Mara", wirkung="zaertlich", pruefung=reading("Mara", "Johann"), ziel="Mara Nowak")])
        self.assertEqual([a["targetId"] for a in r["actions"]], [sch["id"]], self.grunds(r))
        # "Neben Mara Nowak": the answer "Mara Nowak" makes the place phrase no subject - the act stays Johann's
        self.setUp(); self._claim(self.M["id"], "Neben Mara Nowak")
        r = self.bind("Neben Mara Nowak lächelt Johann.", [hc("Neben Mara Nowak lächelt Johann", wirkung="ohne_koerperwirkung", pruefung=reading(None, "Johann"), ziel=None)])
        self.assertEqual(len(r["actions"]), 1, self.grunds(r))

    def test_proven_boundaries_still_bind_without_a_question(self):
        for raw, ids in (("Johann schubst Mara Nowak.", [self.M["id"]]), ("Mara Nowak lacht.", [self.M["id"]]), ("Johann sagt: Mara, komm her.", [self.M["id"]]),
                         ("*Johann lächelt* Mara lacht.", [self.M["id"]]), ("Guten Morgen, Mara.", [self.M["id"]])):
            occ = [o for o in kernel.name_occurrences(raw, self.chars) if self.M["id"] in o["ids"] or o["state"] != "ok"]
            self.assertEqual([(o["state"], sorted(o["ids"])) for o in occ], [("ok", ids)], raw)

    # ---- Fehlerklasse B: gleiche volle Namensformen (Paket-15-Pruefung N4/N5) ----
    def test_identical_full_forms_are_read_together_never_the_first(self):
        for kind in ("name", "alias"):
            second = copy.deepcopy(self.M); second["id"] = "char_test_second_mara"
            second["name"], second["aliases"] = ("Mara Nowak", []) if kind == "name" else ("Mara Schmidt", ["Mara Nowak"])
            for cast in ([self.J, self.M, second], [self.J, second, self.M]):
                self.assertEqual(kernel.figure_ids_for_name("Mara Nowak", cast), {self.M["id"], second["id"]})
                occ = kernel.name_occurrences("Mara Nowak, komm her.", cast)
                self.assertEqual([(o["state"], sorted(o["ids"])) for o in occ], [("ok", sorted([self.M["id"], second["id"]]))], kind)
                self.assertEqual(kernel.bind_referents("Ich habe Mara Nowak gesehen.", cast), [], kind)
                # an answer chooses exactly one (V92 Paket 17: placed in the input it was given for; the name stands there once)
                claimed = kernel.with_klaerungen(cast, [{"text": "Mara Nowak", "id": second["id"]}], "Ich habe Mara Nowak gesehen.")
                self.assertEqual(kernel.figure_ids_for_name("Mara Nowak", claimed), {second["id"]})
                self.assertEqual(kernel.bind_referents("Ich habe Mara Nowak gesehen.", claimed), [second["id"]])
        # a direct address with a FULL name two figures carry: no present preference (Entscheidung 2), asked
        sess = {"scene": {"presentIds": [self.J["id"], self.M["id"]]}, "facts": [], "propositions": [], "goals": []}
        second = dict(copy.deepcopy(self.M), id="char_test_second_mara", name="Mara Nowak", aliases=[])
        d = kernel.resolve_target_detail(sess, [self.J, self.M, second], "Mara Nowak, komm her.", ui_target_id=self.M["id"], input_actor_id=self.J["id"])
        self.assertEqual((d["target_id"], d["reason"]), (None, "multiple_addressees"))
        self.assertEqual(sorted(d["klaerung"]["kandidaten"]), sorted([self.M["id"], second["id"]]))

    def test_identity_questions_are_answered_once(self):
        amb = [{"grund": "ziel_name_unklar", "klaerung": {"text": "Anna Mara Nowak", "kandidaten": [self.M["id"]]}},
               {"grund": "akteur_name_unklar", "klaerung": {"text": "Anna Mara Nowak", "kandidaten": [self.M["id"]]}}]
        q = kernel.identity_questions(amb, None, [], self.chars)
        self.assertEqual(q, [{"text": "Anna Mara Nowak", "kandidaten": [{"id": self.M["id"], "name": self.M["name"]}]}])
        # V92 Paket 17: an answer naming a figure the question does not offer answers nothing (Paket-16-Pruefung N1/N2)
        self.assertEqual(len(kernel.identity_questions(amb, None, [{"text": "Anna Mara Nowak", "id": self.J["id"]}], self.chars)), 1)
        self.assertEqual(kernel.identity_questions(amb, None, [{"text": "anna  mara nowak", "id": None}], self.chars), [])
        self.assertEqual(kernel.identity_questions(amb, None, [], [self.J]), [], "only figures of the cast are offered")
        # with_klaerungen: only figures of the given cast, "nobody" adds nothing, never more than the request
        f = kernel.with_klaerungen(self.chars, [{"text": "Anna Mara Nowak", "id": self.M["id"]}, {"text": "X", "id": "char_fremd"}, {"text": "Y", "id": None}])
        self.assertEqual([c.get("klaerung") for c in f], [None if c["id"] != self.M["id"] else [{"text": "Anna Mara Nowak"}] for c in self.chars])
        # V92 Paket 17: placed in an input - only where the span stands, only for a figure the span offers
        f = kernel.with_klaerungen(self.chars, [{"text": "Anna Mara Nowak", "id": self.M["id"]}], "Johann schubst Anna Mara Nowak.")
        self.assertEqual([c.get("klaerung") for c in f if c["id"] == self.M["id"]], [[{"text": "Anna Mara Nowak", "a": 15, "b": 30, "eindeutig": True}]])
        f = kernel.with_klaerungen(self.chars, [{"text": "Anna Mara Nowak", "id": self.J["id"]}], "Johann schubst Anna Mara Nowak.")
        self.assertEqual([c.get("klaerung") for c in f if c["id"] == self.J["id"]], [[]], "Johann is no candidate of that span")
        self.assertNotIn("klaerung", self.M, "the cast itself is never changed")


class P16PuppetRoute(unittest.TestCase):
    setUp = _PV.PuppetRouteChain.setUp
    session = _PV.PuppetRouteChain.session
    puppet = _PV.PuppetRouteChain.puppet
    snapshot = _PV.PuppetRouteChain.snapshot
    _nothing_committed = _PV.PuppetRouteChain._nothing_committed
    _act_comp = _PV.PuppetRouteChain._act_comp

    def test_question_then_answer_over_http_sqlite_and_follow_up(self):
        s0 = self.session()
        ok_effect = lambda p: {"bestaetigt": True, "zeit": "jetzt", "ziel": p.get("ziel"), "beleg": "schubst"}
        c = dict(self._act_comp("Johann schubst Anna Mara Nowak"), ziel="Mara Nowak", wirkung="gewalt")
        mk = lambda: FakeProvider([plan("action", "act", [c])], wirkung=ok_effect,
                                  vollzug=lambda p: {"geschieht": True, "art": "tatsaechlich", "beleg": None, "taeter": "Johann Bruckner", "ziel": "Mara Nowak"})
        # 1) both readings shortened: asked, NOTHING stored (SQLite unchanged)
        r = self._nothing_committed(mk(), "Johann schubst Anna Mara Nowak.", None, code="IDENTITAET_KLAEREN")
        self.assertEqual([{k: q[k] for k in ("text", "a", "b", "kandidaten")} for q in r.get_json()["klaerung"]],
                         [{"text": "Anna Mara Nowak", "a": 15, "b": 30, "kandidaten": [{"id": self.M["id"], "name": self.M["name"], "anwesend": True}]}])
        # 2) answered "nobody of the cast": the act is stored without a target, no body effect, Mara only a witness
        r = self.puppet(mk(), "Johann schubst Anna Mara Nowak.", [{"text": "Anna Mara Nowak", "id": None}])
        self.assertEqual(r.status_code, 200, r.get_data(as_text=True)[:300])
        s = self.session()                                                        # new connection = reader after a restart
        last = [f for f in s["facts"] if f.get("kind") == "action" and f.get("actorId") == self.J["id"]][-1]
        self.assertEqual((last["text"], last.get("targetId")), ("Johann schubst Anna Mara Nowak", None))
        self.assertEqual(pain(s, self.M["id"]), pain(s0, self.M["id"]))
        self.assertFalse([m for m in s.get("memories") or [] if m.get("characterId") == self.M["id"] and m.get("kind") == "erlebt"])
        # 3) answered "Mara Nowak": the operator's explicit binding - target, body, memory. V92 Paket 17: the question of step 1
        # belongs to the state before step 2 - the same input is asked again first (a stale answer is rejected, nothing stored)
        r = self._nothing_committed(mk(), "Johann schubst Anna Mara Nowak.", None, code="IDENTITAET_KLAEREN")
        r = self.puppet(mk(), "Johann schubst Anna Mara Nowak.", [{"text": "Anna Mara Nowak", "id": self.M["id"]}])
        self.assertEqual(r.status_code, 200, r.get_data(as_text=True)[:300])
        s = self.session()
        self.assertTrue([f for f in s["facts"] if f.get("kind") == "physical" and f.get("targetId") == self.M["id"]])
        self.assertGreater(pain(s, self.M["id"]), pain(s0, self.M["id"]))
        self.assertTrue([m for m in s.get("memories") or [] if m.get("characterId") == self.M["id"] and m.get("kind") == "erlebt"])
        # 4) follow-up turn: a proven name binds directly, no question
        c2 = dict(self._act_comp("Johann schubst Mara Nowak"), ziel="Mara Nowak", wirkung="gewalt")
        r = self.puppet(FakeProvider([plan("action", "act", [c2])], wirkung=ok_effect,
                                     vollzug=lambda p: {"geschieht": True, "art": "tatsaechlich", "beleg": None, "taeter": "Johann Bruckner", "ziel": "Mara Nowak"}),
                        "Johann schubst Mara Nowak.")
        self.assertEqual(r.status_code, 200, r.get_data(as_text=True)[:300])

    def test_doer_and_speaker_questions_over_the_route(self):
        c = dict(self._act_comp("Anna Johann Bruckner schubst Mara Nowak"), ziel="Mara Nowak", wirkung="gewalt")
        prov = FakeProvider([plan("action", "act", [c])] * 2,
                            vollzug=lambda p: {"geschieht": True, "art": "tatsaechlich", "beleg": None, "taeter": "Johann Bruckner", "ziel": "Mara Nowak"})
        r = self._nothing_committed(prov, "Anna Johann Bruckner schubst Mara Nowak.", None, code="IDENTITAET_KLAEREN")
        self.assertEqual([q["text"] for q in r.get_json()["klaerung"]], ["Anna Johann Bruckner"])
        self._nothing_committed(prov, "Anna Johann Bruckner schubst Mara Nowak.", None, klaerungen=[{"text": "Anna Johann Bruckner", "id": None}])
        rd = dict(comp("rede", "Hallo."), einleitung="Anna Johann Bruckner sagt:")
        prov = FakeProvider([plan("smalltalk", "chat", [rd])] * 3, sprecher=lambda p: {"sprecher": "Johann Bruckner", "beleg": None})
        self._nothing_committed(prov, "Anna Johann Bruckner sagt: Hallo.", None, code="IDENTITAET_KLAEREN")
        self._nothing_committed(prov, "Anna Johann Bruckner sagt: Hallo.", None, klaerungen=[{"text": "Anna Johann Bruckner", "id": None}])
        r = self.puppet(prov, "Anna Johann Bruckner sagt: Hallo.", [{"text": "Anna Johann Bruckner", "id": self.J["id"]}])
        self.assertEqual(r.status_code, 200, r.get_data(as_text=True)[:300])
        self.assertEqual([f["text"] for f in self.session()["facts"] if f.get("kind") == "speech" and f.get("actorId") == self.J["id"]][-1:], ["Hallo."])

    def test_two_figures_with_the_same_full_name_in_the_world(self):
        with closing(connect(self.dbp)) as c:
            jrow = c.execute("select world_id, owner_user_id, json from characters where id=?", (self.M["id"],)).fetchone()
            w = dict(json.loads(jrow[2])); w["id"] = "char_test_second_mara"; w["name"] = "Mara Nowak"; w["aliases"] = []
            c.execute("INSERT INTO characters(id, world_id, owner_user_id, json) VALUES(?,?,?,?)", (w["id"], jrow[0], jrow[1], json.dumps(w, ensure_ascii=False))); c.commit()
        # the push on the present, bound Mara Nowak keeps its body effect (live 05.11.: the effect check compared the two equal
        # names "Mara Nowak" through the cast, found two figures and dropped the confirmed effect)
        s0 = self.session()
        c2 = dict(self._act_comp("Johann schubst Mara Nowak"), ziel="Mara Nowak", wirkung="gewalt")
        r = self.puppet(FakeProvider([plan("action", "act", [c2])], wirkung=lambda p: {"bestaetigt": True, "zeit": "jetzt", "ziel": p.get("ziel"), "beleg": "schubst"},
                                     vollzug=lambda p: {"geschieht": True, "art": "tatsaechlich", "beleg": None, "taeter": "Johann Bruckner", "ziel": "Mara Nowak"}),
                        "Johann schubst Mara Nowak.")
        self.assertEqual(r.status_code, 200, r.get_data(as_text=True)[:300])
        s = self.session()
        self.assertEqual([(f.get("kind"), f.get("targetId")) for f in s["facts"] if f.get("kind") == "physical"][-1:], [("physical", self.M["id"])])
        self.assertGreater(pain(s, self.M["id"]), pain(s0, self.M["id"])); self.assertEqual(pain(s, "char_test_second_mara"), 0.0)
        prov = FakeProvider([plan("request", "request", [comp("rede", "Mara Nowak, komm her.")])] * 2)
        before = self.snapshot(self.session())
        r = self.puppet(prov, "Mara Nowak, komm her.")
        self.assertEqual((r.status_code, r.get_json()["code"]), (422, "IDENTITAET_KLAEREN"), r.get_data(as_text=True)[:300])
        self.assertEqual(sorted((x["id"], x["anwesend"]) for x in r.get_json()["klaerung"][0]["kandidaten"]),
                         sorted([(self.M["id"], True), ("char_test_second_mara", False)]), "same name: the scene tells them apart")
        self.assertEqual(self.snapshot(self.session()), before)
        r = self.puppet(prov, "Mara Nowak, komm her.", [{"text": "Mara Nowak", "id": self.M["id"]}])
        self.assertEqual(r.status_code, 200, r.get_data(as_text=True)[:300])
        f = [x for x in self.session()["facts"] if x.get("kind") == "speech" and x.get("actorId") == self.J["id"]][-1]
        self.assertEqual(f.get("targetId"), self.M["id"])


class P16AvatarRoute(unittest.TestCase):
    setUp = _AV.AvatarRouteChain.setUp
    session = _AV.AvatarRouteChain.session
    prepare = _AV.AvatarRouteChain.prepare
    snapshot = _AV.AvatarRouteChain.snapshot

    def test_avatar_question_nothing_stored_then_answer(self):
        prov = FakeProvider([plan("action", "act", [dict(av_act("Ich schubse Anna Mara Nowak", akteur="ich", ziel="Mara Nowak"), wirkung="gewalt")])] * 2,
                            vollzug=lambda p: {"geschieht": True, "art": "tatsaechlich", "beleg": None, "taeter": "ich", "ziel": "Mara Nowak"})
        before = self.snapshot(self.session())
        r = self.prepare(prov, "Ich schubse Anna Mara Nowak.")
        self.assertEqual((r.status_code, (r.get_json() or {}).get("code")), (422, "IDENTITAET_KLAEREN"), r.get_data(as_text=True)[:300])
        self.assertEqual([q["text"] for q in r.get_json()["klaerung"]], ["Anna Mara Nowak"])
        self.assertEqual(self.snapshot(self.session()), before, "SQLite unchanged, no open input")
        r = self.prepare(prov, "Ich schubse Anna Mara Nowak.", [{"text": "Anna Mara Nowak", "id": None}])
        self.assertEqual(r.status_code, 200, r.get_data(as_text=True)[:300])
        acts = [f for f in self.session()["facts"] if f.get("kind") == "action" and f.get("actorId") == self.J["id"]]
        self.assertEqual([a.get("targetId") for a in acts][-1:], [None])
        self.assertFalse([f for f in self.session()["facts"] if f.get("kind") == "physical"])


class P16Frontend(unittest.TestCase):
    def test_the_ui_shows_the_question_and_sends_the_same_input_with_the_answer(self):
        tsx = (ROOT / "src" / "routes" / "chat.$sessionId.tsx").read_text(encoding="utf-8")
        for needle in ('data-v92="identitaet-klaeren"', "function klaere(frage: string, id: string | null)", "void send(msg, antworten);",
                       "identitaetsKlaerung(e)", "kernelPuppet({ session: live, figure: fig, text: msg, klaerungen })",
                       "{ speakAs: speakerAs, klaerungen }", "klaerungen: extra?.klaerungen", "Niemand davon"):
            self.assertIn(needle, tsx)
        hint = (ROOT / "src" / "lib" / "matrix" / "eingabe-hinweis.ts").read_text(encoding="utf-8")
        self.assertIn('"IDENTITAET_KLAEREN"', hint); self.assertIn("export function identitaetsKlaerung", hint)
        self.assertIn("export function klaerungLabel", hint); self.assertIn("{klaerungLabel(f, c)}", tsx)
        api = (ROOT / "src" / "lib" / "matrix" / "api.ts").read_text(encoding="utf-8")
        self.assertIn("{ body: data }", api)
        bridge = (ROOT / "src" / "lib" / "matrix" / "kernel-bridge.ts").read_text(encoding="utf-8")
        self.assertEqual(bridge.count("...(opts.klaerungen?.length ? { klaerungen: opts.klaerungen } : {}),"), 2)


if __name__ == "__main__":
    unittest.main()
