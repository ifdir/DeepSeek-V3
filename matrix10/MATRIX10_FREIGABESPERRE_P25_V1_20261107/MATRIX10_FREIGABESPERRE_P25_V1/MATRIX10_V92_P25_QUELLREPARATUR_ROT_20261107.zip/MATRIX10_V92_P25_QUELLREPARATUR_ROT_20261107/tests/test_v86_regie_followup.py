"""V86 contract regression: Regie action -> bound figure answer -> SQLite -> reader.

Does not write any attached user database or call a live model. The speech and
physical action reproduce the form of the actual, previously lost model reply.
Flask HTTP and live model are NOT claimed as verified by these code/SQL tests.
"""
import ast
import copy
import os
from contextlib import closing
from pathlib import Path
import tempfile
import unittest

from test_v84_kausal_chain import MARA, JOHANN  # Flask import shim only for offline tests
from matrix_api import kernel
from matrix_api.db import connect, init_schema, GASTHAUS_ID
from matrix_api.repos import create_session, get_session, save_session
from matrix_api.seed_builtin import seed_if_missing

ROOT = Path(__file__).resolve().parents[1]

# Execute the actual pure authority functions from app.py, not a rewritten
# imitation. Flask app cannot be imported in an offline environment without
# Flask. This is explicitly NOT an HTTP route test.
def app_binding_functions():
    source = ast.parse((ROOT / 'matrix_api' / 'app.py').read_text(encoding='utf-8'))
    names = {'authority_from_role', 'normal_kernel_authority'}
    functions = [node for node in source.body if isinstance(node, ast.FunctionDef) and node.name in names]
    assert len(functions) == len(names)
    module = ast.fix_missing_locations(ast.Module(body=functions, type_ignores=[]))
    class WriterError(Exception):
        def __init__(self, message, status, error):
            super().__init__(message)
            self.status = status
            self.error = error
    namespace = {'kernel': kernel, 'WriterError': WriterError}
    exec(compile(module, str(ROOT / 'matrix_api' / 'app.py'), 'exec'), namespace)
    return namespace['normal_kernel_authority'], WriterError

AUTHORITY, WriterError = app_binding_functions()

SPEECH = 'Lass das sofort! Glaub nicht, dass du damit durchkommst!'
ACTION = 'Ich weiche zurück, die Hände schützend vor meinem Rock.'

def result():
    return {'speech': SPEECH, 'action': ACTION, 'proposals': {
        'emotion': 'Ekel', 'wirkung': {'art': 'entfernung', 'ziel': 'Johann Bruckner'},
        'plan': {'event_kind': 'refusal', 'speech_act': 'refuse', 'durability': 'utterance',
                 'summary': 'Mara weist Johann zurück.', 'subject': 'Mara Nowak',
                 'predicate': 'will nicht angefasst werden', 'object': 'Johann Bruckner'},
        'synapsen': [{'raum': 'Angst', 'aktivierung': 1.0,
                      'grund': 'Johann zieht Mara den Rock runter.'}],
    }}


def session():
    ids = [JOHANN['id'], MARA['id']]
    s = {'id': 'ses_v86_regie_followup', 'userId': 'admin', 'worldId': GASTHAUS_ID,
         'role': 'regie', 'avatarId': None, 'turnIndex': 7,
         'autoChat': {'enabled': False, 'turns': 2, 'delayMs': 0},
         'scene': {'presentIds': ids, 'hearsIds': ids, 'seesIds': ids,
                   'placeId': 'schankraum', 'placeName': 'Schankraum'},
         'runtimes': {MARA['id']: {'characterId': MARA['id'], 'canSpeak': True},
                      JOHANN['id']: {'characterId': JOHANN['id'], 'canSpeak': True}},
         'turns': [{'id': 'ln_prev', 'turn': 7, 'role': 'character',
                    'speakerId': JOHANN['id'], 'speakerName': JOHANN['name'],
                    'speech': '', 'action': 'Johann zieht Mara den Rock runter.'}],
         'facts': [], 'turnTruths': [], 'relations': [], 'memories': []}
    regie_tt = kernel.bind_turn_truth(
        user_id='admin', world_id=GASTHAUS_ID, session_id=s['id'], role='regie',
        authority='regie', speaker_id=JOHANN['id'], avatar_id=None,
        target_id=MARA['id'], present_ids=ids, hears_ids=ids, sees_ids=ids,
        input_kind='regie', text='Johann zieht Mara den Rock runter.', input_actor_id=JOHANN['id'])
    s['turnTruths'].append(regie_tt)
    s['facts'].append(kernel.make_fact(turn=7, actorId=JOHANN['id'], targetId=MARA['id'],
        kind='action', event_kind='action', text='Johann zieht Mara den Rock runter.',
        authority='regie', sourceTurnId=regie_tt['id'], truth=regie_tt,
        scene=s['scene'], validated=True))
    return s


def followup_truth(s):
    row = {'userId': 'admin', 'worldId': s['worldId'], 'sessionId': s['id'],
           'role': 'character', 'authority': 'character',
           'speakerId': MARA['id'], 'targetId': JOHANN['id'], 'inputKind': 'autochat',
           'text': '', 'presentIds': list(s['scene']['presentIds']),
           'hearsIds': list(s['scene']['presentIds']), 'seesIds': list(s['scene']['presentIds']),
           'inputActorId': 'user'}
    return kernel.normalize_truth(row)


class RegieFollowupChain(unittest.TestCase):
    def test_regie_god_puppet_followup_is_character_even_without_avatar_autochat_switch_off(self):
        for role in ('regie','god','puppet','beobachter','teilnehmer'):
            for enabled in (False, True):
                with self.subTest(role=role, enabled=enabled):
                    sess = {'role': role, 'avatarId': None, 'autoChat': {'enabled': enabled}}
                    raw = {'inputKind': 'autochat', 'text': ''}
                    self.assertTrue(kernel.is_figure_followup_turn(raw))
                    self.assertEqual(AUTHORITY(sess, raw), 'character')
                    self.assertEqual(sess['role'], role)

    def test_special_command_with_text_cannot_be_smuggled_through_figure_route(self):
        for role in ('god','regie','puppet'):
            with self.subTest(role=role):
                with self.assertRaises(WriterError):
                    AUTHORITY({'role': role}, {'inputKind': 'autochat', 'text': 'Regie: befehle!'})
                with self.assertRaises(WriterError):
                    AUTHORITY({'role': role}, {'inputKind': 'speech', 'text': 'eine Anweisung'})

    def test_explicit_observer_stays_observer(self):
        self.assertEqual(AUTHORITY({'role':'beobachter'}, {'inputKind':'comment','text':'Ich beobachte.'}), 'observer')
        self.assertFalse(kernel.is_figure_followup_turn({'inputKind':'autochat','text':'vom Nutzer'}))
        self.assertFalse(kernel.is_figure_followup_turn({'inputKind':'speech','text':''}))
        self.assertEqual(AUTHORITY({'role':'teilnehmer'}, {'inputKind':'speech','text':'Hallo'}),'teilnehmer')

    def test_unbound_observer_can_no_longer_swallow_real_model_speech_and_action(self):
        s = session()
        t = followup_truth(s)
        t['role'], t['authority'] = 'regie', 'observer'  # V85 first wrong binding
        before = copy.deepcopy(s)
        with self.assertRaisesRegex(ValueError, 'FIGURE_RESPONSE_AS_OBSERVER'):
            kernel.commit_turn(s, truth=t, speaker=MARA, present=[MARA,JOHANN], result=result())
        self.assertEqual(s, before)

    def test_character_followup_in_regie_session_preserves_both_output_components(self):
        s = session()
        t = followup_truth(s)
        out = kernel.commit_turn(s, truth=t, speaker=MARA, present=[MARA,JOHANN], result=result())
        self.assertEqual(s['turnIndex'], 7)
        self.assertEqual(s['role'], 'regie')
        self.assertEqual(out['role'], 'regie')
        self.assertEqual(out['turnIndex'], 8)
        self.assertEqual(out['turns'][-1]['speakerId'], MARA['id'])
        self.assertEqual(out['turns'][-1]['speech'], SPEECH)
        self.assertEqual(out['turns'][-1]['action'], ACTION)
        new = [f for f in out['facts'] if f.get('sourceTurnId') == t['id']]
        self.assertIn('speech', {f['kind'] for f in new})
        self.assertIn('action', {f['kind'] for f in new})
        self.assertNotIn('observer', {f.get('authority') for f in new})
        self.assertEqual(next(f for f in new if f['kind']=='speech')['text'], SPEECH)
        self.assertEqual(next(f for f in new if f['kind']=='action')['text'], ACTION)
        self.assertEqual(kernel.brain_context(out, MARA['id'])['runtime']['characterId'], MARA['id'])

    def test_character_followup_sqlite_reload_reader_and_other_session_unchanged(self):
        with tempfile.TemporaryDirectory() as tmp:
            path=Path(tmp)/'matrix_v86_test.sqlite'
            prior_seed = os.environ.pop('MATRIX_SKIP_SEED', None)
            try:
                with closing(connect(path)) as db:
                    init_schema(db)
                    seed_if_missing(db)
                    db.commit()
            finally:
                if prior_seed is not None:
                    os.environ['MATRIX_SKIP_SEED'] = prior_seed
            with closing(connect(path)) as db:
                for sid in ('ses_v86_regie_followup','ses_v86_unrelated'):
                    create_session(db, {'id': sid, 'worldId': GASTHAUS_ID,
                           'name':'Regie-Folge-Test', 'presentIds':[JOHANN['id'],MARA['id']]},'admin')
                s=session()
                save_session(db, 'admin', s)
                db.commit()
            with closing(connect(path)) as db:
                before = get_session(db,'admin',s['id'])
                unrelated = get_session(db,'admin','ses_v86_unrelated')
                tt=followup_truth(before)
                self.assertEqual(AUTHORITY(before, {'inputKind':'autochat','text':''}), 'character')
                output=kernel.commit_turn(before, truth=tt, speaker=MARA,
                    present=[MARA,JOHANN], result=result())
                save_session(db,'admin',output)
                db.commit()
            with closing(connect(path)) as db:
                after=get_session(db,'admin',s['id'])
                other=get_session(db,'admin','ses_v86_unrelated')
                self.assertEqual(after['role'],'regie')
                self.assertEqual(after['turnIndex'],8)
                self.assertEqual(after['turns'][-1]['speech'],SPEECH)
                self.assertEqual(after['turns'][-1]['action'],ACTION)
                self.assertEqual(other['turnIndex'],unrelated['turnIndex'])
                self.assertEqual(other['facts'],unrelated['facts'])
                self.assertEqual(other['turns'],unrelated['turns'])
                reader=kernel.brain_context(after,MARA['id'])
                self.assertTrue(any(f['text']==SPEECH for f in reader['facts']))
                self.assertEqual(db.execute('PRAGMA quick_check').fetchone()[0],'ok')

    def test_route_prepare_and_commit_both_set_server_bound_reaction_role(self):
        # Static route invariant in addition to executing the real authority
        # function: both server endpoints must use the same role binder.
        src=(ROOT/'matrix_api/app.py').read_text(encoding='utf-8')
        self.assertEqual(src.count('bound["role"] = "character" if kernel.is_figure_followup_turn(raw)'),2)
        self.assertIn('if kernel.is_figure_followup_turn(raw):\n                allowed =',src)

if __name__ == '__main__':
    unittest.main()
