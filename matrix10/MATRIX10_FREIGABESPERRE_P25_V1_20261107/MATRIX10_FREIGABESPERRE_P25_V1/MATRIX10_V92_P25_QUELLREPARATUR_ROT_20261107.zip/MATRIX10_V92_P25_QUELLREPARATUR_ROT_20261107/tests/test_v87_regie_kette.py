"""V87 independent contract counterprobes: actual canonical Regie writer and
appraisal writer, SQLite reload, next turn and isolation. No user's DB changed.
No model/provider emulation is counted as live-LLM acceptance.
"""
import json
import os
from pathlib import Path
from contextlib import closing
import tempfile
import unittest

import test_v84_kausal_chain  # import-time offline Flask shim used by existing repo tests
from matrix_api import kernel
from matrix_api.seed_builtin import seed_if_missing
from matrix_api.db import connect, init_schema
from matrix_api.repos import create_session, get_session, save_session

ROOT = Path(__file__).resolve().parents[1]
SEED = json.loads((ROOT / 'matrix_api/gasthaus_seed.json').read_text(encoding='utf-8'))
FIGS = SEED['characters']
BY_NAME = {f['name']: f for f in FIGS}
ROBERT = BY_NAME['Robert Färber']
MARA = BY_NAME['Mara Nowak']
CLARA = BY_NAME['Clara Mertens']
COMMAND = 'Robert schlägt Mara ins Gesicht.'


def make_scene(*, session_id='ses_v87_regie', avatar=None, present=None):
    present = list(present or (ROBERT['id'], MARA['id']))
    return {
        'id': session_id, 'userId': 'admin', 'worldId': SEED['world']['id'],
        'role': 'regie', 'avatarId': avatar, 'turnIndex': 0,
        'autoChat': {'enabled': False, 'turns': 2},
        'scene': {'presentIds': present, 'hearsIds': present, 'seesIds': present,
                  'placeId': 'schankraum', 'placeName': 'Schankraum'},
        'runtimes': {cid: {'characterId': cid, 'canSpeak': True} for cid in present},
        'turns': [], 'facts': [], 'turnTruths': [], 'relations': [], 'memories': [], 'witnessKnowledge': [],
    }


def directive(text=COMMAND):
    return {'komponenten': [{
        'typ': 'handlung', 'akteur': 'Robert Färber', 'ziel': 'Mara Nowak',
        'segment': text, 'beschreibung': text, 'wirkung': 'gewalt',
    }], 'unklar': []}


def apply_order(session):
    return kernel.apply_regie(session, SEED['world'], COMMAND, actor_id=ROBERT['id'], target_id=MARA['id'],
                              present=[ROBERT, MARA], components=directive())


def output_truth(session):
    return kernel.normalize_truth({
        'userId': 'admin', 'worldId': session['worldId'], 'sessionId': session['id'],
        'role': 'character', 'authority': 'character', 'speakerId': MARA['id'],
        'targetId': ROBERT['id'], 'inputKind': 'autochat', 'text': '',
        'presentIds': session['scene']['presentIds'], 'hearsIds': session['scene']['hearsIds'],
        'seesIds': session['scene']['seesIds'], 'inputActorId': 'user',
    })


class RealRegieChain(unittest.TestCase):
    def test_real_writer_binds_robert_as_actor_and_selects_affected_mara(self):
        before = make_scene()
        after = apply_order(before)
        self.assertEqual(before['turnIndex'], 0, 'original session not mutated')
        self.assertEqual(after['turnIndex'], 1)
        self.assertEqual(after['role'], 'regie')
        actors = [t for t in after['turns'] if t.get('role') == 'character' and t.get('action') == COMMAND]
        self.assertEqual(len(actors), 1)
        self.assertEqual(actors[0]['speakerId'], ROBERT['id'])
        self.assertTrue(actors[0]['byRegie'], 'internal provenance is not a different scene actor')
        acts = [f for f in after['facts'] if f.get('kind') == 'action' and f.get('text') == COMMAND]
        self.assertEqual(len(acts), 1)
        self.assertTrue(acts[0]['validated'])
        self.assertEqual(acts[0]['actorId'], ROBERT['id'])
        self.assertEqual(acts[0]['targetId'], MARA['id'])
        self.assertEqual(acts[0]['authority'], 'regie')
        self.assertEqual({x['character_id'] for x in after['witnessKnowledge']}, {ROBERT['id'], MARA['id']})
        self.assertTrue(any(x['character_id'] == MARA['id'] and x['access'] == 'affected'
                            for x in after['witnessKnowledge']))
        self.assertFalse(any(x['character_id'] == CLARA['id'] for x in after['witnessKnowledge']))
        picked = kernel.autochat_gate(after, [ROBERT, MARA, CLARA], 2)
        self.assertFalse(picked['stop'])
        self.assertEqual(picked['speakerId'], MARA['id'])
        pending = kernel.pending_appraisals(after, FIGS)
        own = [p for p in pending if p['id'] == MARA['id']]
        self.assertEqual(len(own), 1)
        self.assertTrue(any(e['fact']['id'] == acts[0]['id'] for e in own[0]['events']))
        self.assertEqual([f['actorId'] for f in kernel.brain_context(after, MARA['id'])['facts']
                          if f.get('text') == COMMAND and f.get('kind') == 'action'], [ROBERT['id']])

    def test_real_writer_rejects_actor_or_target_not_bound_without_inventing_an_act(self):
        s = make_scene(present=[ROBERT['id']])
        after = kernel.apply_regie(s, SEED['world'], COMMAND, actor_id=ROBERT['id'],
                                   target_id=MARA['id'], present=[ROBERT], components=directive())
        self.assertFalse([f for f in after['facts'] if f.get('kind') == 'action' and f.get('validated')])
        self.assertFalse([t for t in after['turns'] if t.get('role') == 'character' and t.get('action') == COMMAND])
        self.assertFalse(after.get('witnessKnowledge'))

    def test_grounded_and_unproven_causes_keep_their_writers_and_retry_boundary(self):
        scene = apply_order(make_scene())
        pending = kernel.pending_appraisals(scene, FIGS)
        mara = next(p for p in pending if p['id'] == MARA['id'])
        act = next(e['fact'] for e in mara['events'] if e['fact']['kind'] == 'action')
        row = {'figur': MARA['name'], 'raum': 'Gewalt', 'aktivierung': 0.8,
               'gefuehl': 'Zorn', 'gegenueber': ROBERT['name'],
               'beziehung_aenderung': [{'zu': ROBERT['name'], 'trust': -.2}]}
        field_names = kernel.appraisal_effect_fields(row)
        self.assertIn('beziehung.0.trust', field_names)
        row['_kausalpruefung'] = {'pruefungen': [{
            'feld': field, 'urteil': 'gestuetzt', 'factId': act['id'],
            'beleg': act['text'], 'begruendung': 'Der Schlag trifft Mara; sie ist trotzig unter Druck und verliert Vertrauen.',
            'dispositionsBeleg': 'trotzig unter Druck', 'richtung': ('steigt' if kernel.appraisal_field_sign(row, field) > 0 else 'sinkt'),
        } for field in field_names]}
        approved, checks = kernel.apply_appraisals(scene, pending, {'bewertungen': [row]}, natives=FIGS)
        self.assertFalse(any(reason.startswith('disposition_nicht_belegt:') for reason in checks[0]['rejects']))
        self.assertTrue(checks[0]['relationDelta'])
        after_rel = next(r for r in approved['relations'] if r['fromId'] == MARA['id'] and r['toId'] == ROBERT['id'])
        self.assertLess(after_rel['trust'], 0.4)
        self.assertEqual(after_rel['sourceFactId'], act['id'])
        # Direct writer must NOT accept the same verdict with a fabricated source
        for proof in row['_kausalpruefung']['pruefungen']:
            proof['dispositionsBeleg'] = 'Maras erfundene Liebesgeschichte'
        rejected, bad = kernel.apply_appraisals(scene, pending, {'bewertungen': [row]}, natives=FIGS)
        self.assertEqual(rejected['relations'], scene['relations'])
        self.assertIn('disposition_nicht_belegt:gefuehl', bad[0]['rejects'])
        self.assertFalse(rejected['runtimes'][MARA['id']].get('appraisedFactIds'))
        self.assertTrue(kernel.pending_appraisals(rejected, FIGS))

    def test_regie_sqlite_character_reply_reloads_and_isolates_unwitnessed_figures(self):
        old = os.environ.pop('MATRIX_SKIP_SEED', None)
        try:
            with tempfile.TemporaryDirectory() as tmp:
                path = Path(tmp) / 'matrix.sqlite'
                with closing(connect(path)) as db:
                    init_schema(db)
                    seed_if_missing(db)  # temp DB test fixture; independent of test runner
                    create_session(db, {'id': 'ses_v87_regie', 'worldId': SEED['world']['id'],
                                        'name': 'Regie', 'presentIds': [ROBERT['id'], MARA['id']]}, 'admin')
                    create_session(db, {'id': 'ses_other', 'worldId': SEED['world']['id'],
                                        'name': 'Isolation', 'presentIds': [CLARA['id']]}, 'admin')
                    s = apply_order(make_scene())
                    save_session(db, 'admin', s)
                    db.commit()
                with closing(connect(path)) as db:
                    current = get_session(db, 'admin', 'ses_v87_regie')
                    other = get_session(db, 'admin', 'ses_other')
                    self.assertEqual(kernel.autochat_gate(current, FIGS, 2)['speakerId'], MARA['id'])
                    # This is a deterministic replay of one permissible figure
                    # answer, NOT evidence that a live provider would choose it.
                    result = {'speech': 'Fass mich nicht an!', 'action': 'Mara weicht zurück.',
                              'proposals': {'plan': {'event_kind': 'refusal', 'speech_act': 'refuse',
                                                     'summary': 'Mara wehrt sich.'}}}
                    next_s = kernel.commit_turn(current, truth=output_truth(current), speaker=MARA,
                                                 present=[ROBERT, MARA], result=result)
                    save_session(db, 'admin', next_s)
                    db.commit()
                with closing(connect(path)) as db:
                    final = get_session(db, 'admin', 'ses_v87_regie')
                    unrelated = get_session(db, 'admin', 'ses_other')
                    self.assertEqual(unrelated['facts'], other['facts'])
                    self.assertEqual(unrelated['turns'], other['turns'])
                    self.assertEqual(db.execute('PRAGMA quick_check').fetchone()[0], 'ok')
                    robert_acts = [f for f in final['facts'] if f['kind'] == 'action'
                                   and f.get('actorId') == ROBERT['id'] and f.get('text') == COMMAND]
                    self.assertEqual(len(robert_acts), 1)
                    self.assertTrue(robert_acts[0]['validated'])
                    last = final['turns'][-1]
                    self.assertEqual(last['speakerId'], MARA['id'])
                    self.assertEqual(last['speech'], 'Fass mich nicht an!')
                    self.assertEqual(last['action'], 'Mara weicht zurück.')
                    seen_robert = kernel.brain_context(final, ROBERT['id'])['facts']
                    self.assertTrue(any(f.get('text') == 'Fass mich nicht an!' for f in seen_robert))
                    seen_clara = kernel.brain_context(final, CLARA['id'])['facts']
                    self.assertFalse(any(f.get('text') == 'Fass mich nicht an!' for f in seen_clara))
        finally:
            if old is not None:
                os.environ['MATRIX_SKIP_SEED'] = old
