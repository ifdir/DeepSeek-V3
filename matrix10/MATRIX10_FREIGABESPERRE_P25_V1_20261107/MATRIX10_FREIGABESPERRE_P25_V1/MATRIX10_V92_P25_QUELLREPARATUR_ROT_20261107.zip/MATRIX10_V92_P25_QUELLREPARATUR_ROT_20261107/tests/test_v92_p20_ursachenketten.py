"""Quellengebundene Negativ- und Positivgegenproben der P19-Reparatur-Arbeitskopie.
Tests work with synthetic scenes and a disposable SQLite database; no real account,
provider, browser, user data or production database are used. Never treats a
passing test as full AMASTER/SPS or HTTP/Browser acceptance.
"""
import copy
import tempfile
import unittest
from contextlib import closing
from pathlib import Path

import test_v84_kausal_chain  # Provides the original offline Flask test shim.
from matrix_api import kernel, god_extract as god
from matrix_api.db import connect, init_schema, GASTHAUS_ID
from matrix_api.seed_builtin import seed_if_missing
from matrix_api.repos import create_session, get_session, save_session
from test_v92_p19_koerper import MARA, JOHANN, NATIVES, mara_state, bestaetigt
import test_v92_p17_klaerung as _P17


class RepairTruthChain(unittest.TestCase):
    def test_god_cannot_invent_new_actor_or_target_even_if_present(self):
        figs = NATIVES + [{'id':'clara','name':'Clara Mertens'}, {'id':'gustav','name':'Gustav Pfeiffer'}]
        raw = {'anweisungen':[{'art':'handlung','ziel':'Clara Mertens','andere':'Gustav Pfeiffer',
               'text':'Clara Mertens streicht Gustav Pfeiffer über den Körper.', 'beleg':'Ich streiche über deinen Arsch'}]}
        out, bad = god.normalize_llm_instructions(raw, figs, source_text='Ich streiche über deinen Arsch.')
        self.assertEqual(out, [])
        self.assertTrue(bad)
        local, why = god.local_god_instructions('Ich streiche über deinen Arsch.', figs)
        self.assertFalse(local, 'local fallback may not manufacture role identity')
        self.assertTrue(why)

    def test_duplicate_exact_names_are_not_selected_by_order(self):
        duplicate = {**MARA, 'id':'char_duplicate_mara', 'aliases':[]}
        figures = NATIVES + [duplicate]
        read = {'anweisungen':[{'art':'koerper','ziel':'Mara Nowak','text':'Mara Nowak ist bewusstlos',
                                  'beleg':'Mara Nowak ist bewusstlos'}]}
        out, bad = god.normalize_llm_instructions(read, figures, source_text='Mara Nowak ist bewusstlos')
        self.assertFalse(out)
        self.assertTrue(bad)
        out, bad = god.local_god_instructions('Mara Nowak ist bewusstlos', figures)
        self.assertFalse(out)
        self.assertTrue(bad)

    def test_god_binds_correct_actor_and_per_clause_parties(self):
        read = {'anweisungen':[{'art':'handlung','ziel':'Mara Nowak','andere':'Johann Bruckner',
                        'text':'Mara Nowak umarmt Johann Bruckner','beleg':'Mara Nowak umarmt Johann Bruckner'},
                       {'art':'handlung','ziel':'Johann Bruckner','andere':'Mara Nowak',
                        'text':'Johann Bruckner winkt Mara Nowak','beleg':'Johann Bruckner winkt Mara Nowak'}]}
        ins,bad = god.normalize_llm_instructions(read, NATIVES,
                 source_text='Mara Nowak umarmt Johann Bruckner. Johann Bruckner winkt Mara Nowak.')
        self.assertFalse(bad, bad)
        self.assertEqual([(i['targetId'],i.get('otherId')) for i in ins],
                         [(MARA['id'],JOHANN['id']), (JOHANN['id'],MARA['id'])])

    def test_god_cannot_forge_body_fact_with_right_actor(self):
        # Critical: actor is genuinely Mara, but the model fabricates unconsciousness
        # from an order in which she merely sits down. No owner gets model-only prose.
        raw = {'anweisungen':[{'art':'koerper','ziel':'Mara Nowak',
                               'text':'Mara Nowak ist bewusstlos','beleg':'Mara Nowak setzt sich auf die Bank'}]}
        ins,bad = god.normalize_llm_instructions(raw,NATIVES,
                          source_text='Mara Nowak setzt sich auf die Bank.')
        self.assertFalse(bad, bad)
        self.assertEqual([x['text'] for x in ins], ['Mara Nowak setzt sich auf die Bank'])
        no_quote = {'anweisungen':[{'art':'koerper','ziel':'Mara Nowak',
                                   'text':'Mara Nowak ist bewusstlos'}]}
        ins,bad = god.normalize_llm_instructions(no_quote,NATIVES,
                                                 source_text='Mara Nowak setzt sich auf die Bank.')
        self.assertFalse(ins)
        self.assertTrue(bad)

    def test_unconfirmed_god_body_is_not_applied_nor_shown_as_fact(self):
        s = mara_state()
        count = len(s['facts']); turns = len(s.get('turns') or [])
        out = kernel.apply_god(s, 'Mara hat starke Schmerzen.', 'body', MARA['id'], natives=NATIVES)
        self.assertEqual(out['runtimes'][MARA['id']]['pain'], s['runtimes'][MARA['id']]['pain'])
        self.assertFalse(out['godFacts'][-1]['applied'])
        self.assertFalse(out['facts'][-1]['validated'])
        self.assertEqual(len(out.get('turns') or []), turns)
        self.assertEqual([f['kind'] for f in out['facts'][count:]], ['god'])
        self.assertFalse([f for f in out['facts'][count:] if f.get('kind') == 'body_state'])

    def test_confirmed_god_body_writes_canon_once(self):
        text = 'Mara hat starke Schmerzen.'
        b = bestaetigt({'schmerz':'stark','beleg':'starke Schmerzen'}, text,
                      authority='god', figur_id=MARA['id'])
        s = mara_state()
        out = kernel.apply_god(s,text,'body',MARA['id'],natives=NATIVES,body_state=b)
        self.assertTrue(out['godFacts'][-1]['applied'])
        self.assertTrue([f for f in out['facts'] if f.get('kind')=='body_state'])
        self.assertEqual(out['runtimes'][MARA['id']]['pain'],.8)
        self.assertEqual(len(out.get('turns') or []),len(s.get('turns') or [])+1)

    def test_false_touch_from_single_reading_never_writes_effect(self):
        action = 'Johann lehnt sich näher zu Mara Nowak, die Hände ballen sich zu Fäusten.'
        first = {'bestaetigt':False,'zeit':'jetzt','ziel':MARA['name'],
                 'beruehrung':True,'beruehrungBeleg':'lehnt sich näher zu Mara Nowak'}
        proposed = kernel.apply_effect_check({'art':'gewalt','ziel':MARA['name']},action,first,figures=NATIVES)
        self.assertEqual(proposed['art'],'ohne_koerperwirkung')
        self.assertTrue(kernel.touch_confirmation_needed(proposed))
        empty = kernel.apply_touch_confirmation(proposed,action,None,figures=NATIVES,planned_target=MARA['name'])
        self.assertEqual(empty['art'],'ohne_koerperwirkung')
        deny = kernel.apply_touch_confirmation(proposed,action,{'beruehrt':False,'zeit':'jetzt','ziel':MARA['name'],
                             'beleg':'lehnt sich näher zu Mara Nowak'},figures=NATIVES,planned_target=MARA['name'])
        self.assertEqual(deny['art'],'ohne_koerperwirkung')
        wrong = kernel.apply_touch_confirmation(proposed,action,{'beruehrt':True,'zeit':'jetzt','ziel':JOHANN['name'],
                             'beleg':'lehnt sich näher zu Mara Nowak'},figures=NATIVES,planned_target=MARA['name'])
        self.assertEqual(wrong['art'],'ohne_koerperwirkung')

    def test_two_valid_independent_contact_readings_can_write(self):
        action = 'Johann greift Mara Nowak an den Hintern.'
        first = {'bestaetigt':False,'zeit':'jetzt','ziel':MARA['name'], 'beruehrung':True,
                 'beruehrungBeleg':'greift Mara Nowak an den Hintern'}
        effect=kernel.apply_effect_check({'art':'gewalt','ziel':MARA['name']},action,first,figures=NATIVES)
        self.assertTrue(kernel.touch_confirmation_needed(effect))
        confirmed=kernel.apply_touch_confirmation(effect,action,
            {'beruehrt':True,'zeit':'jetzt','ziel':MARA['name'],'beleg':'greift Mara Nowak an den Hintern'},
            figures=NATIVES, planned_target=MARA['name'])
        self.assertEqual(confirmed['art'],'zaertlich')
        self.assertEqual(confirmed['pruefung']['ersatz'],'zaertlich')
        self.assertEqual(confirmed['pruefung']['beruehrungBestaetigung']['grund'],'bestaetigt')

    def test_effect_does_not_transfer_to_other_person_after_clarification(self):
        ftest=_P17.P17Kernel(); ftest.setUp()
        f=ftest.f
        text='Johann schubst Mara.'
        comp=ftest.act('Johann schubst Mara','Mara Nowak','gewalt')
        read={0:{'bestaetigt':True,'zeit':'jetzt','ziel':'Mara Nowak','beleg':'schubst'}}
        c=kernel.apply_component_effect_checks([comp],read,figures=f.chars)
        self.assertTrue(c[0]['wirkungPruefung']['bestaetigt'])
        clarified=kernel.with_klaerungen(f.chars,
            [{'text':'Mara','a':15,'b':19,'id':_P17.S}], text)
        bound=kernel.bind_puppet_input(text,{'komponenten':c},f.J,clarified,f.present,
                                       addressee_id=f.M['id'])
        self.assertEqual(bound['actions'][0]['targetId'],_P17.S)
        self.assertFalse(bound['actions'][0]['effectValid'])
        self.assertIn('wirkungsziel_nach_klaerung_abweichend',
                      [x.get('grund') for x in bound['ambiguous']])
        wrote=f.commit(bound)
        self.assertEqual(_P17.pain(wrote,_P17.S),0)
        self.assertEqual(_P17.pain(wrote,f.M['id']),0)

    def test_god_body_canonical_state_survives_fresh_sqlite_connection(self):
        s=mara_state()
        with tempfile.TemporaryDirectory(prefix='matrix10_repair_chain_') as td:
            file=Path(td)/'verification.sqlite'
            with closing(connect(file)) as c:
                init_schema(c);seed_if_missing(c);c.commit()
                create_session(c,{'id':s['id'],'worldId':GASTHAUS_ID,'name':'Counterprobe',
                                  'presentIds':[MARA['id'],JOHANN['id']]},'admin')
                c.commit()
            text='Mara hat starke Schmerzen.'
            r=bestaetigt({'schmerz':'stark','beleg':'starke Schmerzen'},text,authority='god',figur_id=MARA['id'])
            out=kernel.apply_god(s,text,'body',MARA['id'],natives=NATIVES,body_state=r)
            with closing(connect(file)) as c:
                save_session(c,'admin',out);c.commit()
            with closing(connect(file)) as c:
                reread=get_session(c,'admin',s['id'])
                self.assertEqual(c.execute('PRAGMA quick_check').fetchone()[0],'ok')
            self.assertEqual(reread['runtimes'][MARA['id']]['pain'],.8)
            self.assertTrue([f for f in reread['facts'] if f.get('kind')=='body_state'])
            self.assertEqual(kernel.brain_context(reread,MARA['id'])['runtime']['pain'],.8)

    def test_unbound_named_target_proposal_never_becomes_performed_event(self):
        from test_v92_negativgrenzen import Negativgrenzen, hc, JA
        f = Negativgrenzen(); f.setUp()
        raw = 'Johann stößt Anna weg.'
        bound = f.bind(raw, [hc('Johann stößt Anna weg', ziel='Anna', wirkung='gewalt', pruefung=JA)])
        self.assertEqual(len(bound['actions']), 1, 'proposal must remain inspectable')
        self.assertIsNone(bound['actions'][0]['targetId'])
        self.assertTrue(bound['actions'][0]['targetBindingInvalid'])
        self.assertIn('ziel_nicht_anwesend_oder_unbekannt', [a.get('grund') for a in bound.get('ambiguous') or []])
        committed = f.commit(bound)
        self.assertFalse([fact for fact in committed['facts'] if fact.get('kind') in ('action', 'physical')])
        self.assertEqual(committed.get('turnIndex'), 0)
        self.assertFalse(committed.get('memories'))

    def test_uncommitted_attack_cannot_enter_figure_spiegel(self):
        from test_v92_negativgrenzen import Negativgrenzen
        f = Negativgrenzen(); f.setUp()
        # Build a REAL canonical Fact, rather than crafting fixture objects
        # missing writer invariants / sourceTurnId and claiming a reader bug.
        s = f.commit({'speech':'Hallo.', 'actions':[{'text':'Johann stößt Anna weg',
                      'targetBindingInvalid':True, 'targetId':None}],
                      'ambiguous':[{'segment':'Johann stößt Anna weg',
                                    'grund':'ziel_nicht_anwesend_oder_unbekannt'}]})
        self.assertEqual([x['kind'] for x in s['facts']], ['speech'])
        raw='Hallo. *Johann schubst Mara.*'
        truth=kernel.bind_turn_truth(user_id='admin',world_id=s['worldId'],session_id=s['id'],
                                    role='teilnehmer',speaker_id=MARA['id'],avatar_id=None,
                                    target_id=JOHANN['id'],authority='character',
                                    present_ids=s['scene']['presentIds'],hears_ids=s['scene']['hearsIds'],
                                    input_kind='autochat',text=raw,input_actor_id=JOHANN['id'])
        sp=kernel.bind_formulation_spiegel(s,truth,speaker=MARA,present=NATIVES)
        self.assertEqual(sp.get('userUtterance'),'Hallo.',sp)
        self.assertEqual((sp.get('immediateStimulus') or {}).get('text'),'Hallo.',sp)

if __name__ == '__main__':
    unittest.main(verbosity=2)
