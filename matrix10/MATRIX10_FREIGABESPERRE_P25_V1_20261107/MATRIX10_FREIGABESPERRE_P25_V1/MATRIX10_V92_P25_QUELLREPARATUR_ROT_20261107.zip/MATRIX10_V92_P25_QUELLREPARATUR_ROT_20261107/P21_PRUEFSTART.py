#!/usr/bin/env python3
"""Matrix10 P21 QUELLPRUEFUNG (NICHT der produktive Start)."""
from __future__ import annotations
import os, subprocess, sys, tempfile
from pathlib import Path
ROOT=Path(__file__).resolve().parent
ENV=os.environ.copy()
ENV["PYTHONPATH"]=os.pathsep.join((str(ROOT),str(ROOT/"tests"),ENV.get("PYTHONPATH", "")))
CORE=["test_v92_p21_token_name_scope","test_v92_p20_semantische_name_god_scope",
      "test_v92_p20_regression_schutz","test_v92_p15_identitaet.P15NameExtent",
      "test_v92_p16_identitaet.P16NameReader","test_v92_p17_klaerung.P17Kernel",
      "test_v92_p19_koerper.P19Contract","test_v92_p19_koerper.P19Sleep",
      "test_v92_p19_koerper.P19God","test_v92_p19_koerper.P19Regie"]
def run(label,args,sec=120):
    try:
        p=subprocess.run(args,cwd=ROOT,env=ENV,encoding="utf-8",errors="replace",
                         capture_output=True,timeout=sec)
        return f"==== {label}: exitcode {p.returncode} ====\n{p.stdout}{p.stderr}\n",p.returncode
    except Exception as e:
        return f"==== {label}: NICHT PRUEFBAR ====\n{type(e).__name__}: {e}\n",2

def main():
    runs=[]
    runs.append(run("P21 + alte Kernpruefungen",[sys.executable,"-m","unittest","-q",*CORE]))
    runs.append(run("P19 Koerper (ohne Flask-HTTP)",
                    [sys.executable,str(ROOT/"pruefungen/MATRIX10_V92_PAKET19_KOERPER_GEGENPROBEN.py"),str(ROOT)]))
    runs.append(run("P18 Vertrags-Gegenprobe",
                    [sys.executable,str(ROOT/"pruefungen/MATRIX10_V92_PAKET18_PRUEFERSKRIPT_VOLLER_VERTRAG.py"),str(ROOT)]))
    if "--gesamt" in sys.argv:
        runs.append(run("VOLLSTAENDIGE SUITE (Backend+UI benoetigt)",
                        [sys.executable,"-m","pytest","-q","tests"],sec=180))
    header="MATRIX10 V92 P21 - QUELLPRUEFUNG, KEINE PRODUKTABNAHME\n"
    report=header+"\n".join(x for x,_ in runs)
    (ROOT/"P21_PRUEFBERICHT_LAUF.txt").write_text(report,encoding="utf-8")
    print(report)
    print("VERTRAGSSTATUS: ROT - keine vollstaendige Live-/Browser-/AMASTER-Abnahme")
    print("Ergebnisdatei: P21_PRUEFBERICHT_LAUF.txt")
    return 2 if any(c!=0 for _,c in runs) else 0
if __name__=="__main__":
    sys.exit(main())
