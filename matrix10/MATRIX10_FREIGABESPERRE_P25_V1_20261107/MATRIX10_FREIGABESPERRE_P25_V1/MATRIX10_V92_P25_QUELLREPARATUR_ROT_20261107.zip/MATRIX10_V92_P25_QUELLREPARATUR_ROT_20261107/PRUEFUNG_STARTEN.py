#!/usr/bin/env python3
"""V91 local contract audit: existing tests + independent audits, never hidden by pass counts.
Does not start the product, migrate data, connect to providers or edit user DBs.
"""
from __future__ import annotations
from pathlib import Path
import os
import sys
import unittest
ROOT = Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT))
sys.path.insert(0,str(ROOT/'tests'))

def run(pattern: str, label: str) -> bool:
    print('\n===== '+label+' =====', flush=True)
    suite = unittest.defaultTestLoader.discover(str(ROOT/'tests'), pattern=pattern, top_level_dir=str(ROOT/'tests'))
    result = unittest.TextTestRunner(verbosity=1, stream=sys.stdout).run(suite)
    print(label+': '+('GRUEN' if result.wasSuccessful() else 'ROT'), flush=True)
    return result.wasSuccessful()

if __name__ == '__main__':
    ordinary = run('test_*.py','REGULAERE REGRESSIONEN')
    audit = run('audit_*.py','UNABHAENGIGE VERTRAGSGEGENPROBEN')
    # Contract §§3, 18 and 19: even two green offline suites are not a
    # release approval when the real UI/provider/Android flow is unverified.
    if not ordinary or not audit:
        print('\nVERTRAGSSTATUS: ROT (REGRESSION ODER GEGENPROBE)',flush=True)
        sys.exit(2)
    print('\nVERTRAGSSTATUS: BLOCKIERT (ECHTE FRONTEND/HTTP/PROVIDER/ANDROID-ABNAHME FEHLT)',flush=True)
    sys.exit(3)
