@echo off
setlocal
cd /d "%~dp0"
echo MATRIX10 V92 P25 - QUELLPRUEFUNG - KEIN PRODUKTSTART
echo Die Originaldatenbank wird nicht benutzt.
where py >nul 2>nul
if not errorlevel 1 (
    py -3 P25_PRUEFSTART.py
) else (
    python P25_PRUEFSTART.py
)
echo.
echo STATUS ROT - KEINE PRODUKTFREIGABE.
echo Ergebnisdatei: P25_PRUEFLOG_WINDOWS.txt
pause
endlocal
