"""B11 Upload-Sicherheit lokal."""
from __future__ import annotations

from pathlib import Path
from typing import Any


ALLOWED_EXT = {".txt", ".md", ".epub", ".pdf", ".html", ".htm", ".json", ".zip", ".png", ".jpg", ".jpeg", ".webp", ".pptx", ".ppt"}
ALLOWED_MIME_PREFIX = (
    "text/",
    "image/",
    "application/json",
    "application/zip",
    "application/epub",
    "application/pdf",
    "application/vnd.openxmlformats",
    "application/vnd.ms-powerpoint",
)
MAX_BYTES = 8 * 1024 * 1024
MAX_ZIP_ENTRIES = 200
MAX_ZIP_UNCOMPRESSED = 32 * 1024 * 1024


class UploadSecurityError(ValueError):
    def __init__(self, code: str, message: str):
        super().__init__(message)
        self.code = code
        self.message = message


def validate_upload_meta(*, name: str, mime: str = "", size: int | None = None) -> dict[str, Any]:
    ext = Path(str(name or "")).suffix.lower()
    if ext and ext not in ALLOWED_EXT:
        raise UploadSecurityError("UPLOAD_TYPE_FORBIDDEN", f"Dateityp {ext} nicht erlaubt")
    n = str(name or "").replace("\\", "/")
    if ".." in n or n.startswith("/"):
        raise UploadSecurityError("UPLOAD_PATH_FORBIDDEN", "Pfadmanipulation")
    if size is not None and int(size) > MAX_BYTES:
        raise UploadSecurityError("UPLOAD_TOO_LARGE", "Datei zu groß")
    ml = (mime or "").lower()
    if ml and not any(ml.startswith(p) or ml in ("application/octet-stream",) for p in ALLOWED_MIME_PREFIX):
        if ext and ext not in ALLOWED_EXT:
            raise UploadSecurityError("UPLOAD_MIME_FORBIDDEN", f"MIME {mime} nicht erlaubt")
    return {"ok": True, "ext": ext, "maxBytes": MAX_BYTES}


def looks_like_zip_bomb(entry_count: int, uncompressed: int) -> bool:
    return entry_count > MAX_ZIP_ENTRIES or uncompressed > MAX_ZIP_UNCOMPRESSED
