"""V45 Lokaler Renderer ohne KI (Vorbild: Ursprungssystem services/text_renderer.py — „No-AI-Finalizer“).

Nutzerentscheidung: Läuft ein Provider, antwortet die KI. Der Renderer ist NUR die
Ausfallschicht (kein Provider konfiguriert / Provider antwortet nicht). Er erzeugt aus dem
Spiegel eine deterministische, figurengebundene Antwort: Reaktion aus Zustand/Synapse,
Inhalt aus Wissen/Vereinbarungen/Widerspruch/Erinnerung, Ton aus Sprachregister und
typischen Wendungen, Handlung aus Kompass-Körperzeichen. Kein Wahrheitswriter, keine
erfundenen Fakten — was die Figur nicht weiß, sagt sie in der Rolle.
"""
from __future__ import annotations

import re
from typing import Any

_Q_RE = re.compile(r"\?\s*$|^\s*(wer|was|wann|wo|wie|warum|wieso|weshalb|welche[rs]?|kennst|weißt|weisst|hast|bist|kannst|willst|magst)\b", re.I)
_GREET_RE = re.compile(r"^\s*(hallo|hi|hey|guten (?:morgen|tag|abend)|servus|moin|grüß|gruess|na\b)", re.I)
_REQUEST_RE = re.compile(r"\b(bitte|kannst du|könntest du|koenntest du|würdest du|wuerdest du|mach|gib mir|komm|lass uns|sollst|musst)\b", re.I)
_OPENERS = {
    "Angst": ["Warte …", "Ich … ich weiß nicht.", "Das macht mir Angst."],
    "Wut": ["Hör auf damit.", "Nein.", "Das reicht jetzt."],
    "Misstrauen": ["Warum fragst du das?", "Ich traue dem nicht.", "Das glaube ich dir nicht einfach so."],
    "Skepsis": ["Hm. Sicher?", "Das passt nicht zusammen.", "Moment."],
    "Trauer": ["…", "Lass mich kurz.", "Das tut weh."],
    "Scham": ["Ich … das ist mir unangenehm.", "Muss das jetzt sein?"],
    "Sorge": ["Ist alles in Ordnung?", "Das beunruhigt mich."],
    "Nähe": ["Ja.", "Ich bin hier."],
    "Eifersucht": ["Ach so. Und was hat sie damit zu tun?", "Warum interessiert dich das?"],
    "Entsetzen": ["Was?", "Das … das kann nicht sein."],
    "Erleichterung": ["Gut.", "Endlich."],
}


def _tokens(s: Any) -> set[str]:
    return {t for t in re.findall(r"[a-zäöüß]{4,}", str(s or "").lower())}


def _register(profile: dict) -> dict[str, Any]:
    reg = str(profile.get("speechRegister") or "").lower()
    formal = any(k in reg for k in ("förmlich", "foermlich", "gehoben", "distanziert", "höflich", "hoeflich", "sie-form", "siezt"))
    terse = any(k in reg for k in ("knapp", "kurz", "wortkarg", "einsilbig"))
    return {"formal": formal, "terse": terse}


def _first_person(text: str, name: str, gender: str = "") -> str:
    """Stammwissen in dritter Person → Ich-Form (nur einfache Muster)."""
    t = str(text or "").strip()
    first = (name.split()[0] if name else "").strip()
    if not first:
        return t
    fem = str(gender or "").lower().startswith("w")
    t = re.sub(rf"^{re.escape(first)}(?: {re.escape(name.split()[-1])})?\s+ist\b", "Ich bin", t)
    t = re.sub(rf"^{re.escape(first)}(?: {re.escape(name.split()[-1])})?\s+hat\b", "Ich habe", t)
    t = re.sub(rf"^{re.escape(first)}(?: {re.escape(name.split()[-1])})?\s+war\b", "Ich war", t)
    t = re.sub(rf"^{re.escape(first)}(?: {re.escape(name.split()[-1])})?\s+(\w+t)\b", lambda m: "Ich " + (m.group(1)[:-1] + "e" if m.group(1).endswith("t") else m.group(1)), t)
    t = re.sub(r"\b(?:ihre|seine)\b", "meine", t) if fem or not fem else t
    t = re.sub(r"\b(?:ihrem|seinem)\b", "meinem", t)
    t = re.sub(r"\b(?:ihren|seinen)\b", "meinen", t)
    t = re.sub(r"\b(?:ihrer|seiner)\b", "meiner", t)
    t = re.sub(r"\b(?:ihr|sein)\b", "mein", t)
    t = re.sub(r"\bsich\b", "mich", t)
    return t[:1].upper() + t[1:]


def _pick(items: list, seed: int) -> Any:
    items = [x for x in items if x]
    return items[seed % len(items)] if items else None


def render_local_reply(spiegel: dict[str, Any], text: str, seed: int = 0) -> tuple[str, str | None]:
    profile = spiegel.get("profile") if isinstance(spiegel.get("profile"), dict) else {}
    rt = spiegel.get("runtime") if isinstance(spiegel.get("runtime"), dict) else {}
    body = spiegel.get("body") if isinstance(spiegel.get("body"), dict) else {}
    name = str(profile.get("name") or (spiegel.get("speaker") or {}).get("name") or "").strip()
    utter = str(text or spiegel.get("userUtterance") or "").strip()
    who = str(spiegel.get("utteredBy") or "").split(" (")[0].strip()
    reg = _register(profile)
    emo = str(rt.get("emotion") or "wach").strip()
    fired = [f for f in (spiegel.get("fired") or []) if isinstance(f, dict)]
    cell = fired[0].get("cell") if fired and isinstance(fired[0].get("cell"), dict) else {}
    parts: list[str] = []

    # 1) Widerspruch hat Vorrang (kanonisch bemerkt)
    contradictions = [c for c in (spiegel.get("contradictions") or []) if isinstance(c, dict) and float(c.get("sicherheit") or 0) >= 0.5]
    if contradictions:
        c = contradictions[0]
        if c.get("art") == "selbstwiderspruch":
            parts.append(f"Moment — vorhin hieß es noch „{str(c.get('bekannt'))[:90]}“. Was stimmt jetzt?")
        else:
            parts.append(f"Das passt nicht zu dem, was ich weiß: {str(c.get('bekannt'))[:90]}.")
    # 2) Reaktion aus Zustand/Synapse
    if not parts:
        opener = _pick(_OPENERS.get(emo, []), seed) if emo not in ("wach", "calm", "") else None
        if opener:
            parts.append(opener)
        elif cell.get("reaction"):
            r = str(cell.get("reaction")).strip().rstrip(".")
            parts.append(r[:1].upper() + r[1:] + ".")
    # 3) Inhalt: Frage → Wissen/Vereinbarung/Erinnerung; Bitte → Zusage/Ablehnung nach Vertrauen; Gruß → Gruß
    qt = _tokens(utter)
    if spiegel.get("temporalQuestion") and (spiegel.get("framesText") or spiegel.get("frames")):
        fr = [f for f in (spiegel.get("frames") or []) if isinstance(f, dict)]
        open_fr = [f for f in fr if f.get("status") in ("accepted", "committed", "proposed", "requested")]
        if open_fr:
            f = open_fr[0]
            when = (f.get("when") or {}).get("label") or ""
            st = {"accepted": "das haben wir ausgemacht", "committed": "das habe ich versprochen", "proposed": "das war dein Vorschlag, ich habe noch nicht zugesagt", "requested": "darum hast du gebeten"}.get(str(f.get("status")), "")
            parts.append(f"{str(f.get('what'))[:100]}{' — ' + when if when else ''}: {st}.")
        else:
            parts.append("Wir haben nichts ausgemacht. Jedenfalls nicht mit mir.")
    elif spiegel.get("temporalQuestion"):
        parts.append("Wir haben nichts ausgemacht. Jedenfalls nicht mit mir.")
    elif _GREET_RE.search(utter):
        parts.append(("Guten Tag." if reg["formal"] else "Hey.") + (f" {who}." if who and not reg["formal"] and seed % 2 else ""))
    elif _REQUEST_RE.search(utter):
        rels = [r for r in (spiegel.get("relationsHere") or []) if isinstance(r, dict)]
        rel = next((r for r in rels if who and str(r.get("name") or "").lower().startswith(who.lower())), rels[0] if rels else None)
        trust = float((rel or {}).get("trust") or 0.4)
        if trust >= 0.6 and emo not in ("Wut", "Misstrauen"):
            parts.append("Gut. Ich mache es.")
        elif trust < 0.3 or emo in ("Wut", "Misstrauen"):
            parts.append("Nein. Nicht so.")
        else:
            parts.append("Warum sollte ich?")
    elif _Q_RE.search(utter):
        know = [str(k) for k in (spiegel.get("knowledge") or []) if k]
        mems = [m for m in (spiegel.get("memories") or []) if isinstance(m, dict)]
        hit = next((k for k in know if len(qt & _tokens(k)) >= 2), None)
        mem = next((m for m in mems if len(qt & _tokens(m.get("text"))) >= 2), None)
        if hit:
            parts.append(f"{_first_person(hit.rstrip('.'), name, str(profile.get('gender') or ''))}.")
        elif mem:
            parts.append(f"Ich erinnere mich: {str(mem.get('text') or '').rstrip('.')[:120]}.")
        else:
            parts.append("Das weiß ich nicht." if reg["terse"] else "Ehrlich gesagt: Das weiß ich nicht.")
    else:
        # Aussage: aufgreifen, kurz
        intent = str(rt.get("intent") or "").strip()
        if intent and seed % 2 == 0:
            parts.append(f"Ich will {intent.rstrip('.')}." if not intent.lower().startswith(("ich ", "das ")) else intent)
        elif profile.get("typicalPhrases") and seed % 3 == 0:
            parts.append(str(_pick(list(profile.get("typicalPhrases")), seed)).rstrip(".") + ".")
        else:
            parts.append("Verstehe." if reg["terse"] else "Ich habe dich gehört.")
    # 4) Körperliche Lage, wenn sie das Gespräch berührt
    if body.get("posture") in ("Handstand", "liegend") and seed % 2 == 0:
        parts.append(f"Und ja — ich bin gerade {body['posture']}." if body["posture"] != "Handstand" else "Und ja — ich stehe gerade auf den Händen.")
    if body.get("injuries") and seed % 3 == 0:
        inj = body["injuries"][0] if isinstance(body["injuries"][0], dict) else {}
        parts.append(f"Mein {inj.get('part') or 'Arm'} tut weh.")
    speech = " ".join(p.strip() for p in parts if p and p.strip())
    if reg["terse"]:
        speech = " ".join(re.split(r"(?<=[.!?])\s+", speech)[:2])
    speech = speech[:320]
    action = str(cell.get("bodyCue") or "").strip() or None
    if not action and emo in ("Angst", "Entsetzen"):
        action = "weicht einen halben Schritt zurück"
    elif not action and emo == "Wut":
        action = "ballt die Hände"
    return speech or "…", action
