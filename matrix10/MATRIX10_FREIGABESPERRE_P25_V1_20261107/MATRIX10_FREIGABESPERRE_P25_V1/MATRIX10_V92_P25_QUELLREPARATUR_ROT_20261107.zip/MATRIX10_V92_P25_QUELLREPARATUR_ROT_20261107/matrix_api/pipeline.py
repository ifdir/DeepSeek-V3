"""Upload → Analyse → Review-Kandidaten. Kein automatisches Stamm-Overwrite."""
from __future__ import annotations

import json
import uuid
from typing import Any

from matrix_api.analyze import analyze_text
from matrix_api.llm_contract import _cfg as _llm_cfg, _routing as _llm_routing, enrich_analysis
from matrix_api.genre_policy import evaluate_genre
from matrix_api.ids import uid
from matrix_api.repos import (
    WriterError,
    append_session_fact,
    commit_upload,
    create_review,
    create_session_goal,
    create_session_memory,
    get_character,
    get_session,
    get_upload,
    get_world,
    list_characters,
    list_reviews,
    put_session_relation,
    save_session,
    set_upload_status,
)
from matrix_api import repos as _repos


def _rid(prefix: str) -> str:
    return f"{prefix}_{uuid.uuid4().hex[:10]}"


def _rev(conn, actor: str, body: dict[str, Any]) -> dict[str, Any]:
    return create_review(conn, body, actor)["review"]


def _same_open_review(conn, actor: str, world_id: Any, field: str, new_value: Any, character_id: Any = None) -> bool:
    try:
        rows = list_reviews(conn, actor).get("reviews") or []
    except Exception:
        return False
    nv = str(new_value)
    wid = str(world_id or "")
    cid = str(character_id or "")
    for r in rows:
        if not isinstance(r, dict) or r.get("status") != "open":
            continue
        if str(r.get("worldId") or "") != wid:
            continue
        if str(r.get("field") or "") != str(field):
            continue
        if cid and str(r.get("characterId") or "") not in ("", cid):
            continue
        if str(r.get("newValue") or "") == nv:
            return True
    return False


def _maybe_rev(conn, actor: str, reviews: list[dict[str, Any]], body: dict[str, Any]) -> None:
    nv = body.get("newValue")
    ov = body.get("oldValue")
    if nv is None or nv == "":
        return
    if ov is not None and str(ov) == str(nv):
        return
    if _same_open_review(conn, actor, body.get("worldId"), str(body.get("field") or ""), nv, body.get("characterId")):
        return
    if "id" not in body:
        body["id"] = _rid("rev")
    reviews.append(_rev(conn, actor, body))


def _old_world(conn, actor: str, world_id: Any, field: str) -> str:
    if not world_id:
        return ""
    try:
        w = get_world(conn, str(world_id), actor)
    except Exception:
        return ""
    if not isinstance(w, dict):
        return ""
    ov = w.get(field)
    if ov is None:
        return ""
    if isinstance(ov, str):
        return ov[:400]
    return json.dumps(ov, ensure_ascii=False)[:400]


def _old_char(conn, actor: str, char_id: Any, field: str) -> str:
    if not char_id:
        return ""
    try:
        c = get_character(conn, str(char_id), actor)
    except Exception:
        return ""
    obj = c.get("character") if isinstance(c, dict) and "character" in c else c
    if not isinstance(obj, dict):
        return ""
    ov = obj.get(field)
    if ov is None:
        return ""
    if isinstance(ov, str):
        return ov[:400]
    return json.dumps(ov, ensure_ascii=False)[:400]


def _conscious_witness(runtimes: dict[str, Any], cid: str) -> bool:
    rt = runtimes.get(cid) or {}
    if not isinstance(rt, dict):
        return True
    try:
        val = rt.get("consciousness")
        return float(val if val is not None else 1) > 0
    except (TypeError, ValueError):
        return True


def _id_list(val: Any) -> list[str]:
    if not isinstance(val, list):
        return []
    return [str(x) for x in val if x]


def _apply_mode_b_session_knowledge(conn, actor: str, upload: dict[str, Any], upload_id: str) -> list[str]:
    session_id = upload.get("sessionId") or upload.get("session_id")
    kind = str(upload.get("targetKind") or "").lower()
    if not session_id and kind in ("session", "scene"):
        session_id = upload.get("targetId")
    if not session_id:
        raise WriterError("Mode B Sessionwissen braucht eine Session", 400, "MODE_B_NO_SESSION")
    session = get_session(conn, actor, str(session_id))
    if isinstance(session, dict) and isinstance(session.get("session"), dict) and not session.get("scene"):
        session = session["session"]
    if not isinstance(session, dict):
        raise WriterError("session not found", 404, "NOT_FOUND")
    scene = session.get("scene") if isinstance(session.get("scene"), dict) else {}
    runtimes = session.get("runtimes") if isinstance(session.get("runtimes"), dict) else {}
    mime = str(upload.get("mime") or "")
    is_image = mime.lower().startswith("image/")
    present = _id_list(scene.get("presentIds") or scene.get("present_ids"))

    # V3: Mode-B uses the same canonical perception resolver as speech,
    # WitnessKnowledge, Memory and BrainContext. Derived presence is not
    # persisted as a user whitelist; explicit overrides/capabilities still bind.
    from matrix_api.kernel import _scene_perception

    hears, sees = _scene_perception(session, present)
    candidates = sees if is_image else hears
    witnesses = [wid for wid in candidates if _conscious_witness(runtimes, wid)]
    name = str(upload.get("name") or upload_id)
    note = str(upload.get("note") or upload.get("text") or "")
    # V70 (Audit10 §7 Nr. 4 "Zeitruecklauf"): the upload belongs to the current turn of the stored history - never below a turn
    # already written (a session whose counter an earlier reset set back, ses_3422, gave its upload facts an older number)
    from matrix_api import scene_state as _sc
    turn_i = max(int(session.get("turnIndex") or 0), _sc.history_turn(session))
    existing_facts = session.get("facts") if isinstance(session.get("facts"), list) else []
    already_fact = any(
        isinstance(f, dict) and str(f.get("sourceUploadId") or f.get("source_upload_id") or "") == str(upload_id)
        for f in existing_facts
    )
    fact_id = None
    access = "seen" if is_image else "heard"
    if not already_fact:
        written = append_session_fact(
            conn,
            str(session_id),
            {
                "id": uid("fact"),
                "turn": turn_i,
                "actorId": "observer",
                "kind": "upload",
                "text": f"Beobachtung/Referenz: {name} — {note[:180]}",
                "authority": "observer",
                "witnessedBy": list(witnesses),
                "source_type": "upload",
                "provenance": "ingest",
                "sourceUploadId": upload_id,
                # V70 (Audit10 §2): the ingest is the server's validating owner of this observation - stated, not implied
                "validated": True,
            },
            actor,
        )
        fact_payload = written.get("fact") if isinstance(written, dict) else None
        fact_id = str((fact_payload or {}).get("id") or "") or None
        # V70 (found by the V25 chain test on its rebuilt fixture; AMASTER §34.2 Kausalprovenienz, V66 "a cause from an upload
        # hands on its upload"): the knowledge effect of a witness names this upload fact as its cause - the kernel can hand on
        # the upload as the effect's source only if it sees the fact. V69 left it out of the session, so the effect row had
        # only cause_fact_id and the whole ingest was refused (422 FACT_SOURCE_UNBOUND) once a witness drew a meaning from it.
        if isinstance(fact_payload, dict) and fact_id and isinstance(session, dict):
            session.setdefault("facts", []).append(fact_payload)
    else:
        for f in existing_facts:
            if isinstance(f, dict) and str(f.get("sourceUploadId") or f.get("source_upload_id") or "") == str(upload_id):
                fact_id = str(f.get("id") or "") or None
                break
    if fact_id and witnesses:
        wk = [w for w in (session.get("witnessKnowledge") or []) if isinstance(w, dict)]
        have = {(str(w.get("character_id") or w.get("characterId") or ""), str(w.get("fact_id") or w.get("factId") or "")) for w in wk}
        for wid in witnesses:
            key = (str(wid), str(fact_id))
            if key in have:
                continue
            entry = {
                "characterId": str(wid),
                "character_id": str(wid),
                "factId": str(fact_id),
                "fact_id": str(fact_id),
                "access": access,
                # V68 (E2E am Kandidaten: Upload einlesen 422 WITNESS_SOURCE_INVALID; AMASTER §6.2 Datenrollen, §34.2, §39): the
                # witness of an upload knows the upload FACT, which carries the upload as its source (sourceUploadId). There is
                # no Quellturn - V25..V67 put the fact id into the Quellturn field (a fact in a TurnTruth role, the confusion
                # V65Z A01 closed for facts). The witness writer now checks a named Quellturn, so none is named.
                "turn": turn_i,
            }
            wk.append(entry)
            have.add(key)
            # B.19: persistiere in witness_knowledge-Tabelle (eigener Writer).
            # V25 UPL-B02 (AMASTERv2 §65 "Fehler dürfen nicht verschluckt werden",
            # Vertrag §10): Ein Writerfehler bricht den Ingest ab; der HTTP-Writer
            # rollt Fact/Memory zurück statt Teilerfolg als ok=true zu melden.
            try:
                _repos.upsert_witness_knowledge(conn, str(session_id), entry, actor, on_conflict="skip")
            except WriterError:
                raise
            except Exception as exc:
                raise WriterError(
                    f"WitnessKnowledge-Writer fehlgeschlagen für {wid}: {exc}",
                    500,
                    "WITNESS_WRITER_FAILED",
                ) from exc
        # SQL witness_knowledge is canonical. Do not mirror this derived child
        # state back through the client-envelope writer.
        session["witnessKnowledge"] = wk
    existing_mems = session.get("memories") if isinstance(session.get("memories"), list) else []
    have_mem = {
        str(m.get("characterId") or m.get("character_id") or "")
        for m in existing_mems
        if isinstance(m, dict) and str(m.get("source") or "") == str(upload_id)
    }
    mem_kind = "gesehen" if is_image else "gelesen"
    for witness_id in witnesses:
        if witness_id in have_mem:
            continue
        create_session_memory(
            conn,
            str(session_id),
            {
                "id": uid("mem"),
                "characterId": witness_id,
                "kind": mem_kind,
                "text": f"Upload {name}: {note[:280]}",
                "salience": 0.7,
                "turn": turn_i,
                "witnesses": list(witnesses),
                "layer": "session",
                "truthStatus": "canon",
                "source": upload_id,
            },
            actor,
        )
    # V25 UPL-B03 (MATRIX10 Nr. 16, AMASTERv2 §16/§41/§42/§44, Vertrag §10):
    # Wissen wird nicht nur gespeichert, es wirkt figurenspezifisch auf
    # Runtime, gerichtete Beziehung und Ziele — nur für Berechtigte, mit dem
    # Upload-Fact als kanonischer Ursache. Abwesende bleiben unverändert.
    effects: list[dict[str, Any]] = []
    if fact_id and witnesses and not already_fact:
        from matrix_api.kernel import apply_knowledge_effect

        listed = list_characters(conn, actor)
        chars = listed.get("characters") if isinstance(listed, dict) else listed
        world_id = str(session.get("worldId") or "")
        chars = [c for c in (chars or []) if isinstance(c, dict) and (not world_id or str(c.get("worldId") or c.get("world_id") or "") == world_id)]
        by_id = {str(c.get("id")): c for c in chars}
        avatar_id = str(session.get("avatarId") or "")
        for wid in witnesses:
            if wid == avatar_id:
                continue  # Avatar: Zustand setzt nur der Nutzer (AMASTERv2 §27.3)
            character = by_id.get(str(wid))
            if not character:
                continue
            effect = apply_knowledge_effect(
                session,
                character,
                text=note or name,
                fact_id=str(fact_id),
                turn=turn_i,
                characters=chars,
                source="upload",
                authority="observer",
            )
            if effect.get("effectFact"):
                append_session_fact(conn, str(session_id), effect["effectFact"], actor, on_conflict="skip")
            if effect.get("goal"):
                create_session_goal(conn, str(session_id), effect["goal"], actor, on_conflict="skip")
            for rd in effect.get("relationDelta") or []:
                hit = next(
                    (r for r in session.get("relations") or [] if isinstance(r, dict) and r.get("fromId") == rd["fromId"] and r.get("toId") == rd["toId"]),
                    None,
                )
                if isinstance(hit, dict):
                    put_session_relation(conn, str(session_id), hit, actor, on_conflict="skip")
            effects.append({k: v for k, v in effect.items() if k != "effectFact"})
        if effects:
            # Runtime ist Envelope-Zustand: kanonischer interner Writer (kein Client-PUT).
            save_session(conn, actor, {"id": str(session_id), "worldId": world_id or session.get("worldId"), "runtimes": session.get("runtimes") or {}})
    upload["_effects"] = effects
    return witnesses


def ingest_upload(conn, upload_id: str, actor: str) -> dict[str, Any]:
    pre = get_upload(conn, upload_id, actor)
    upload_pre = (pre.get("upload") or pre) if isinstance(pre, dict) else {}
    mode = str(upload_pre.get("mode") or "B")
    world_id = upload_pre.get("worldId") or upload_pre.get("world_id") or upload_pre.get("targetId")
    character_id = upload_pre.get("characterId") or (
        upload_pre.get("targetId") if upload_pre.get("targetKind") == "character" else None
    )
    if mode == "A" and not (world_id or character_id or upload_pre.get("targetId")):
        raise WriterError("Mode A requires targetId, worldId or characterId", 400, "MODE_A_NO_TARGET")
    # V25 UPL-A01/A02 (AMASTERv2 §11/§30, Vertrag §13): Analyse und Review
    # BLEIBEN Entwurf. Der Upload wird nicht vor der Analyse committed; ein
    # gescheiterter Parse darf nie als committed persistieren.
    upload = dict(upload_pre)
    text = str(upload.get("text") or upload.get("note") or "")
    world_id = upload.get("worldId") or upload.get("world_id") or upload.get("targetId") or world_id
    title = str(upload.get("name") or upload.get("title") or "")
    analysis = analyze_text(
        text,
        world_id=str(world_id) if world_id else None,
        source_title=title,
    )
    if mode == "A":
        # Profil-/Erkennungs-Ergänzung über den konfigurierten Provider (LLM-03);
        # ohne Provider bleibt es ehrlich ein lokaler Entwurf (profileSource).
        cfg = _llm_cfg(conn, actor, {})
        routing = _llm_routing({}, cfg)
        analysis = enrich_analysis(analysis, text, title=title, network=bool(routing.get("allowed")), routing=routing)
    else:
        analysis = enrich_analysis(analysis, text, title=title)
    mode = str(upload.get("mode") or mode or "B")
    if not analysis.get("ok"):
        failed = set_upload_status(
            conn,
            upload_id,
            actor,
            status="failed",
            committed=False,
            extra={"error": analysis.get("error") or "parse_failed", "reviewOpen": 0},
        )
        return {
            "ok": False,
            "upload": failed.get("upload") or upload,
            "analysis": analysis,
            "policy": {},
            "reviews": [],
            "reviewIds": [],
            "witnessIds": [],
            "memoryCount": 0,
            "error": analysis.get("error") or "parse_failed",
            "message": "Analyse fehlgeschlagen — nichts committed, keine Wissensverteilung.",
        }
    witness_ids: list[str] = []
    effects: list[dict[str, Any]] = []
    if mode == "B":
        witness_ids = _apply_mode_b_session_knowledge(conn, actor, upload, upload_id)
        effects = list(upload.pop("_effects", []) or [])
        # Mode B: der Commit IST die Wissensverteilung an Berechtigte.
        committed = commit_upload(conn, upload_id, actor)
        upload = (committed.get("upload") or {}) if isinstance(committed, dict) else upload
        upload["witnessIds"] = witness_ids
    genre = analysis.get("world", {}).get("genre") or upload.get("genre") or ""
    policy = evaluate_genre(str(genre), text)
    reviews: list[dict[str, Any]] = []
    world_block = analysis.get("world") or {}
    cid = upload.get("characterId") or (upload.get("targetId") if upload.get("targetKind") == "character" else None)
    target_kind = str(upload.get("targetKind") or "").lower()
    if not target_kind:
        if cid:
            target_kind = "character"
        elif world_id:
            target_kind = "world"

    if mode == "A" and target_kind in ("session", "scene"):
        raise WriterError(
            "Mode A nur für Welt oder Charakterstamm. Session/Scene haben keinen dauerhaften Mode-A-Owner.",
            400,
            "MODE_A_SCOPE",
        )

    if mode == "A" and target_kind == "world" and world_id:
        if world_block.get("short"):
            _maybe_rev(
                conn,
                actor,
                reviews,
                {
                    "kind": "world",
                    "worldId": world_id,
                    "field": "long",
                    "oldValue": _old_world(conn, actor, world_id, "long"),
                    "newValue": world_block["short"],
                    "status": "open",
                    "reason": "analyze ingest",
                    "sourceUploadId": upload_id,
                },
            )
        if genre:
            _maybe_rev(
                conn,
                actor,
                reviews,
                {
                    "kind": "world",
                    "worldId": world_id,
                    "field": "genre",
                    "oldValue": _old_world(conn, actor, world_id, "genre"),
                    "newValue": genre,
                    "status": "open",
                    "reason": "analyze genre",
                    "sourceUploadId": upload_id,
                },
            )
        for field in (
            "places",
            "factions",
            "rules",
            "conflicts",
            "history",
            "timeline",
            "items",
            "worldKnowledge",
            "secretKnowledge",
            "knowledgeBounds",
            "startScenes",
            "storyGoals",
            "fateBeats",
            "figureRelations",
            "culture",
            "language",
            "subplaces",
            "placeRelations",
        ):
            items = world_block.get(field) or []
            if not items:
                continue
            _maybe_rev(
                conn,
                actor,
                reviews,
                {
                    "kind": "world",
                    "worldId": world_id,
                    "field": field,
                    "oldValue": _old_world(conn, actor, world_id, field),
                    "newValue": json.dumps(items, ensure_ascii=False),
                    "status": "open",
                    "reason": f"analyze {field}",
                    "sourceUploadId": upload_id,
                },
            )

    if mode == "A" and target_kind == "character" and cid:
        char_obj = {}
        try:
            char_obj = get_character(conn, str(cid), actor) or {}
        except WriterError:
            char_obj = {}
        cname = str(char_obj.get("name") or "").strip().lower()
        matched = None
        for cand in list(analysis.get("spawnCandidates") or []) + list(analysis.get("characterCandidates") or []):
            if not isinstance(cand, dict):
                continue
            if cname and str(cand.get("name") or "").strip().lower() == cname:
                matched = cand
                break
            if str(cand.get("id") or "") == str(cid):
                matched = cand
                break
        if matched:
            payload = matched
            for field, key in (
                ("name", "name"),
                ("role", "role"),
                ("biography", "biography"),
                ("origin", "origin"),
                ("personality", "personality"),
            ):
                val = payload.get(key)
                if not val:
                    continue
                _maybe_rev(
                    conn,
                    actor,
                    reviews,
                    {
                        "kind": "stamm",
                        "worldId": world_id,
                        "characterId": cid,
                        "field": field,
                        "oldValue": _old_char(conn, actor, cid, field),
                        "newValue": val if isinstance(val, str) else json.dumps(val, ensure_ascii=False),
                        "status": "open",
                        "reason": f"analyze character {field}",
                        "sourceUploadId": upload_id,
                    },
                )
            for field in ("goals", "fears", "knowledge", "coreFacts"):
                val = payload.get(field)
                if not val:
                    continue
                _maybe_rev(
                    conn,
                    actor,
                    reviews,
                    {
                        "kind": "stamm",
                        "worldId": world_id,
                        "characterId": cid,
                        "field": field,
                        "oldValue": _old_char(conn, actor, cid, field),
                        "newValue": json.dumps(val, ensure_ascii=False) if not isinstance(val, str) else val,
                        "status": "open",
                        "reason": f"analyze character {field}",
                        "sourceUploadId": upload_id,
                    },
                )
    elif mode == "A" and target_kind == "world" and world_id:
        for cand in analysis.get("spawnCandidates") or analysis.get("characterCandidates") or []:
            name = cand.get("name") if isinstance(cand, dict) else None
            if not name:
                continue
            payload = cand if isinstance(cand, dict) else {"name": name}
            _maybe_rev(
                conn,
                actor,
                reviews,
                {
                    "kind": "spawn",
                    "worldId": world_id,
                    "field": "character",
                    "newValue": json.dumps(payload, ensure_ascii=False),
                    "status": "open",
                    "reason": "analyze spawn candidate",
                    "sourceUploadId": upload_id,
                },
            )

    if mode == "A":
        # Mode A: Entwurf → Review. Commit erst durch bewusste Freigabe
        # (repos._settle_upload_after_review). Ohne Reviewvorschlag gibt es
        # nichts zu prägen: analyzed, nicht committed.
        status = "review_open" if reviews else "analyzed"
        updated = set_upload_status(
            conn,
            upload_id,
            actor,
            status=status,
            committed=False,
            extra={
                "reviewOpen": len(reviews),
                "reviewIds": [r.get("id") for r in reviews if isinstance(r, dict)],
                "profileSource": analysis.get("profileSource"),
            },
        )
        upload = updated.get("upload") or upload
    return {
        "ok": True,
        "upload": upload,
        "analysis": analysis,
        "policy": policy,
        "reviews": reviews,
        "reviewIds": [r.get("id") for r in reviews if isinstance(r, dict)],
        "witnessIds": witness_ids,
        "memoryCount": len(witness_ids),
        "effects": effects,
        "committed": bool(upload.get("committed")),
        "status": upload.get("status"),
        "profileSource": analysis.get("profileSource"),
        "llmError": analysis.get("llmError"),
    }
