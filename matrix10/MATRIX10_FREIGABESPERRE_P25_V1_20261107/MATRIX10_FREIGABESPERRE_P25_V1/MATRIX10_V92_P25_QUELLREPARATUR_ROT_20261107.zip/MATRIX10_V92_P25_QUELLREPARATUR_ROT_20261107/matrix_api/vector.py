"""Strukturierte Suche zuerst, dann lokales TF-IDF. Semantik findet, IDs bleiben Owner."""
from __future__ import annotations

import json
import math
import re
from collections import Counter
from typing import Any

TOKEN = re.compile(r"[a-zäöüß]{3,}", re.I)
ART = re.compile(r"(?:artikel(?:nummer)?|art\.?\s*nr\.?|sku|nr\.?)\s*[:#]?\s*([a-z0-9][-a-z0-9/]{1,24})", re.I)


def _tok(s: str) -> list[str]:
    return [t.lower() for t in TOKEN.findall(s or "")]


def _obj(raw: str) -> dict[str, Any]:
    try:
        o = json.loads(raw)
        return o if isinstance(o, dict) else {}
    except Exception:
        return {}


_TABLE_SQL = {
    "worlds": "SELECT id, json FROM worlds WHERE owner_user_id = ? OR ? = 'admin'",
    "characters": (
        "SELECT c.id, c.json FROM characters c JOIN worlds w ON w.id = c.world_id "
        "WHERE w.owner_user_id = ? OR ? = 'admin'"
    ),
    "memories": "SELECT id, json FROM memories WHERE user_id = ? OR ? = 'admin'",
    "uploads": "SELECT id, json FROM uploads WHERE user_id = ? OR ? = 'admin'",
    "documents": "SELECT id, json FROM documents WHERE user_id = ? OR ? = 'admin'",
    "reviews": "SELECT id, json FROM reviews WHERE user_id = ? OR ? = 'admin'",
    "graph_edges": "SELECT id, json FROM graph_edges WHERE user_id = ? OR ? = 'admin'",
    "document_index": "SELECT document_id, json FROM document_index WHERE user_id = ? OR ? = 'admin'",
}


def vector_search(conn, actor: str, q: str, limit: int = 20) -> dict[str, Any]:
    from matrix_api.repos import ensure_document_index

    ensure_document_index(conn, actor)
    qn = (q or "").strip()
    q_l = qn.lower()
    qtok = _tok(qn)
    art_q = None
    m = ART.search(qn)
    if m:
        art_q = m.group(1).lower()
    structured: list[dict[str, Any]] = []
    seen: set[tuple[str, str]] = set()
    docs: list[tuple[str, str, str]] = []
    aid = str(actor or "")
    for table, kind in (
        ("worlds", "world"),
        ("characters", "character"),
        ("memories", "memory"),
        ("uploads", "upload"),
        ("document_index", "document"),
        ("reviews", "review"),
        ("graph_edges", "graph"),
    ):
        sql = _TABLE_SQL.get(table)
        try:
            if sql:
                rows = conn.execute(sql, (aid, aid)).fetchall()
            else:
                rows = conn.execute(f"SELECT id, json FROM {table}").fetchall()
        except Exception:
            continue
        for r in rows:
            oid = str(r[0])
            raw = str(r[1] or "")
            obj = _obj(raw)
            owner = str(
                obj.get("userId")
                or obj.get("ownerUserId")
                or obj.get("user_id")
                or obj.get("owner_user_id")
                or ""
            )
            if aid != "admin" and owner and owner != aid:
                continue
            docs.append((kind, oid, raw))
            if not q_l:
                continue
            obj = _obj(raw)
            article = str(obj.get("articleNo") or obj.get("article_no") or "").lower()
            title = str(obj.get("title") or obj.get("name") or "").lower()
            keywords = obj.get("keywords") or []
            kw = [str(x).lower() for x in keywords] if isinstance(keywords, list) else []
            match = None
            score = 0.0
            if art_q and art_q in article:
                match, score = "articleNo", 100.0
            elif q_l and title and q_l == title:
                match, score = "title-exact", 90.0
            elif q_l and title and q_l in title:
                match, score = "title", 70.0
            elif q_l and any(q_l == k or q_l in k for k in kw):
                match, score = "keyword", 60.0
            if match:
                structured.append({"kind": kind, "id": oid, "score": score, "match": match})
                seen.add((kind, oid))
    structured.sort(key=lambda h: h["score"], reverse=True)
    if not qtok:
        return {"ok": True, "engine": "structured", "q": q, "hits": structured[: max(1, min(limit, 50))]}
    df: Counter[str] = Counter()
    bag: list[tuple[str, str, Counter[str]]] = []
    for kind, oid, text in docs:
        c = Counter(_tok(text))
        bag.append((kind, oid, c))
        df.update(set(c))
    n = max(len(bag), 1)
    qset = Counter(qtok)

    def score(c: Counter[str]) -> float:
        s = 0.0
        for t, qc in qset.items():
            if t not in c:
                continue
            idf = math.log((n + 1) / (1 + df[t])) + 1
            s += qc * c[t] * idf
        return s

    ranked = sorted(((score(c), kind, oid) for kind, oid, c in bag), reverse=True)
    semantic = [
        {"kind": k, "id": i, "score": round(sc, 4), "match": "tfidf"}
        for sc, k, i in ranked
        if sc > 0 and (k, i) not in seen
    ]
    hits = (structured + semantic)[: max(1, min(limit, 50))]
    return {"ok": True, "engine": "structured+tfidf-local", "q": q, "hits": hits}
