"""Session learning provenance and explicit owner approval.
V41 wrote speech into character stem fields. V56 keeps that legacy ledger,
but canonical readers exclude unapproved session-derived additions. Session
facts/knowledge are untouched. Approval uses the normal character editor.
"""
from __future__ import annotations

import re
from datetime import datetime, timezone
from typing import Any

LIST_CAPS = {"likes": 14, "dislikes": 14, "goals": 12, "knowledge": 16, "coreFacts": 12, "favoriteWords": 14, "typicalPhrases": 10, "fears": 10, "secrets": 8, "values": 10}
_STOP = set("aber also auch bist bitte dann dass dein deine denn dich dieser dieses doch eine einem einen einer eines euch habe haben hast hier immer jetzt kann kannst mich mein meine nicht noch nur oder schon sein seine sich sind soll sollen sowas über unser viel vielleicht warum weil wenn werde werden wieder wird wirklich wollen würde wurde zwar einfach gerade genau heute morgen sagen sagst sagte machen mache macht denke denkst gehen komme kommen sehen sehe weiß weißt wissen".split())

_LIKE_RE = re.compile(r"\bich (?:mag|liebe|liebe es|genieße|geniesse|steh(?:e)? auf|bin (?:ein )?(?:fan|freund) von|finde .{0,30} (?:toll|schön|schoen|super|gut|klasse|wunderbar))\s+(.{2,60}?)(?:[.!?,;]|$| und | aber )", re.I)
_DISLIKE_RE = re.compile(r"\bich (?:hasse|verabscheue|kann .{0,10}nicht (?:leiden|ausstehen)|mag .{0,10}nicht|ertrage .{0,10}nicht|finde .{0,30} (?:schrecklich|furchtbar|ekelhaft|blöd|bloed|dumm))\s*(.{2,60}?)(?:[.!?,;]|$| und | aber )", re.I)
_GOAL_RE = re.compile(r"\bich (?:will|möchte|moechte|werde|muss|habe vor|plane|nehme mir vor)\s+(.{4,80}?)(?:[.!?;]|$| und | aber )", re.I)
_SELF_FACT_RE = re.compile(r"\bich (?:bin|war|habe|arbeite|wohne|lebe|komme aus|heiße|heisse|studiere|besitze)\s+(.{3,70}?)(?:[.!?;]|$| und | aber )", re.I)
_REL_RE = re.compile(r"\b([A-ZÄÖÜ][\wäöüß-]+)(?: [A-ZÄÖÜ][\wäöüß-]+)? ist (?:mein|meine)\s+(bruder|schwester|mutter|vater|mann|frau|freund|freundin|ex|ex-freund|exfreund|chef|chefin|kollege|kollegin|tochter|sohn|feind|feindin|nachbar|nachbarin|mentor|schüler|lehrer|onkel|tante|cousin|cousine|verlobte[r]?|partner|partnerin)\b", re.I)
_OTHER_LIKE_RE = re.compile(r"\b(?:du magst|du liebst|du stehst auf|(?P<name>[A-ZÄÖÜ][\wäöüß-]+) (?:mag|liebt|steht auf))\s+(?:doch |ja |wirklich )?(.{2,60}?)(?:[.!?,;]|$| und | aber )", re.I)
_OTHER_DISLIKE_RE = re.compile(r"\b(?:du hasst|du magst .{0,8}nicht|(?P<name>[A-ZÄÖÜ][\wäöüß-]+) (?:hasst|mag .{0,8}nicht))\s*(.{2,60}?)(?:[.!?,;]|$| und | aber )", re.I)


def _clean(v: str, n: int = 80) -> str:
    v = re.sub(r"\s+", " ", str(v or "")).strip(" .,;:!?\"„“”")
    return v[:n]


def _norm(v: str) -> str:
    return _clean(v, 200).lower()


def _dedupe_add(lst: list, value: str, cap: int) -> bool:
    val = _clean(value, 120)
    if not val:
        return False
    nv = _norm(val)
    for x in lst:
        xn = _norm(str(x))
        if xn == nv or (len(nv) > 6 and (nv in xn or xn in nv)):
            return False
    lst.append(val)
    del lst[: max(0, len(lst) - cap)]
    return True


def local_learning(text: str, *, speaker_is_figure: bool, figure_name: str, addressee_name: str | None) -> dict[str, list[str]]:
    """Lokale Lesung ohne LLM (Selbstauskünfte in Ich-Form; Fremdaussagen 'du magst …')."""
    t = str(text or "")
    out: dict[str, list[str]] = {"likes": [], "dislikes": [], "goals": [], "knowledge": [], "favoriteWords": [], "typicalPhrases": [], "relations": []}
    if speaker_is_figure:
        for m in _LIKE_RE.finditer(t):
            out["likes"].append(_clean(m.group(1)))
        for m in _DISLIKE_RE.finditer(t):
            out["dislikes"].append(_clean(m.group(1)))
        for m in _GOAL_RE.finditer(t):
            g = _clean(m.group(1))
            if g and not (re.match(r"^(dir|dich|es|das|nicht|nur|ja|nein)\b", g, re.I) and len(g.split()) <= 2) and not re.match(r"^(es|das) nicht\b", g, re.I):
                out["goals"].append(g)
        for m in _SELF_FACT_RE.finditer(t):
            f = _clean(m.group(1))
            if f and len(f) >= 4 and not re.match(r"^(mir|dir|so|hier|da|nicht|müde|muede|sicher|froh|bereit)\b", f, re.I):
                out["knowledge"].append(f"{figure_name} sagt: ist/hat {f}")
        for m in _REL_RE.finditer(t):
            out["relations"].append(f"{m.group(1)}:{m.group(2).lower()}")
        # Wortschatz: markante Wörter (≥ 6 Zeichen, keine Stoppwörter), kurze wiederkehrende Sätze
        words = [w for w in re.findall(r"[A-Za-zÄÖÜäöüß]{6,}", t) if w.lower() not in _STOP]
        out["favoriteWords"] = list(dict.fromkeys(w for w in words if w[0].isupper() or len(w) >= 8))[:4]
        short = [s.strip() for s in re.split(r"(?<=[.!?])\s+", t) if 8 <= len(s.strip()) <= 60]
        out["typicalPhrases"] = short[:2]
    else:
        for m in _OTHER_LIKE_RE.finditer(t):
            nm = m.group("name")
            if nm and figure_name and not figure_name.lower().startswith(nm.lower()):
                continue
            out["likes"].append(_clean(m.group(2)))
        for m in _OTHER_DISLIKE_RE.finditer(t):
            nm = m.group("name")
            if nm and figure_name and not figure_name.lower().startswith(nm.lower()):
                continue
            out["dislikes"].append(_clean(m.group(2)))
    return {k: [x for x in v if x] for k, v in out.items()}


def normalize_learning(raw: Any) -> dict[str, list[str]]:
    """LLM-Lernvorschlag validieren: nur bekannte Felder, Strings, gekürzt."""
    out: dict[str, list[str]] = {}
    if not isinstance(raw, dict):
        return out
    for key in ("likes", "dislikes", "goals", "knowledge", "favoriteWords", "typicalPhrases", "fears", "secrets", "values", "coreFacts"):
        vals = raw.get(key)
        if isinstance(vals, str):
            vals = [vals]
        if isinstance(vals, list):
            cleaned = [_clean(str(x), 120) for x in vals if _clean(str(x), 120)]
            if cleaned:
                out[key] = cleaned[:6]
    rels = raw.get("relations")
    if isinstance(rels, list):
        rr = []
        for r in rels:
            if isinstance(r, dict) and r.get("to") and r.get("kind"):
                rr.append(f"{_clean(str(r['to']), 60)}:{_clean(str(r['kind']), 30).lower()}")
            elif isinstance(r, str) and ":" in r:
                rr.append(_clean(r, 90))
        if rr:
            out["relations"] = rr[:4]
    return out


def apply_learning(character: dict, learned: dict[str, list[str]], *, source: str, session_id: str, turn: int, characters_by_name: dict[str, str] | None = None, min_word_count: int = 2) -> list[dict[str, Any]]:
    """Direkter Stamm-Writer: ergänzt Felder (nie überschreiben), führt Ledger `learnedItems`,
    setzt fieldProvenance[feld]='gelernt'. Gibt neue Ledger-Einträge zurück."""
    if not isinstance(character, dict) or not learned:
        return []
    ledger = character.setdefault("learnedItems", [])
    prov = character.setdefault("fieldProvenance", {}) if isinstance(character.get("fieldProvenance"), dict) else {}
    character["fieldProvenance"] = prov
    added: list[dict[str, Any]] = []
    now = datetime.now(timezone.utc).isoformat(timespec="seconds")

    def _log(field: str, value: str):
        entry = {"id": f"learn_{turn}_{len(ledger) + 1}", "field": field, "value": value, "source": source, "sessionId": session_id, "turn": turn, "at": now}
        ledger.append(entry)
        added.append(entry)
        prov[field] = "gelernt"

    for field in ("likes", "dislikes", "goals", "knowledge", "typicalPhrases", "fears", "secrets", "values", "coreFacts"):
        for val in learned.get(field) or []:
            lst = character.setdefault(field, [])
            if not isinstance(lst, list):
                lst = character[field] = [str(lst)] if lst else []
            if _dedupe_add(lst, val, LIST_CAPS.get(field, 12)):
                _log(field, _clean(val, 120))
    # Lieblingswörter erst ab wiederholtem Gebrauch (Zähler im Stamm)
    counts = character.setdefault("_wordCounts", {}) if isinstance(character.get("_wordCounts"), dict) else {}
    character["_wordCounts"] = counts
    for w in learned.get("favoriteWords") or []:
        key = _norm(w)
        if not key:
            continue
        counts[key] = int(counts.get(key) or 0) + 1
        if counts[key] >= min_word_count:
            lst = character.setdefault("favoriteWords", [])
            if isinstance(lst, list) and _dedupe_add(lst, w, LIST_CAPS["favoriteWords"]):
                _log("favoriteWords", _clean(w, 40))
    if len(counts) > 200:
        for k in sorted(counts, key=lambda k: counts[k])[: len(counts) - 200]:
            counts.pop(k, None)
    # Beziehungsart (Stamm-Ausgangsbeziehung) ergänzen/benennen
    for rel in learned.get("relations") or []:
        if ":" not in rel:
            continue
        name, kind = rel.split(":", 1)
        name, kind = _clean(name, 60), _clean(kind, 30).lower()
        if not name or not kind:
            continue
        rels = character.setdefault("relations", [])
        if not isinstance(rels, list):
            continue
        hit = next((r for r in rels if isinstance(r, dict) and _norm(str(r.get("targetName") or "")).startswith(_norm(name))), None)
        if hit is None:
            rels.append({"targetName": name, "kind": kind, "trust": 0.5, "closeness": 0.5, "fear": 0.1, "note": f"gelernt aus Rede ({source})"})
            _log("relations", f"{name}: {kind}")
        elif str(hit.get("kind") or "").lower() in ("", "kennt", "knows") and kind:
            hit["kind"] = kind
            hit["note"] = (str(hit.get("note") or "") + f" | Art gelernt: {kind} ({source})").strip(" |")[:200]
            _log("relations", f"{name}: {kind}")
    return added


def remove_learned(character: dict, item_id: str) -> bool:
    """Ledger-Eintrag löschen und den Wert aus dem Feld entfernen (bearbeitbar)."""
    ledger = [x for x in (character.get("learnedItems") or []) if isinstance(x, dict)]
    hit = next((x for x in ledger if x.get("id") == item_id), None)
    if not hit:
        return False
    field, value = str(hit.get("field") or ""), str(hit.get("value") or "")
    character["learnedItems"] = [x for x in ledger if x.get("id") != item_id]
    if field == "relations":
        name = value.split(":", 1)[0].strip()
        character["relations"] = [r for r in (character.get("relations") or []) if not (isinstance(r, dict) and _norm(str(r.get("targetName") or "")) == _norm(name) and "gelernt" in str(r.get("note") or ""))]
    else:
        lst = character.get(field)
        if isinstance(lst, list):
            character[field] = [x for x in lst if _norm(str(x)) != _norm(value)]
    if not any(x.get("field") == field for x in character.get("learnedItems") or []):
        prov = character.get("fieldProvenance") if isinstance(character.get("fieldProvenance"), dict) else {}
        if prov.get(field) == "gelernt":
            prov.pop(field, None)
    return True


# V56: session learning is not a new starting identity without owner approval.
def canonical_stem(character: dict) -> dict:
    """Read projection from the existing character/learnedItems owner.

    Legacy V41 appended session utterances directly to stem fields. Keep those
    rows in the ledger, but only an explicit owner approval gives them stem
    authority. No wording/personality blacklist and no mutation of source data.
    """
    from copy import deepcopy
    out = deepcopy(character) if isinstance(character, dict) else {}
    ledger = [x for x in (out.get("learnedItems") or []) if isinstance(x, dict)]
    approved = {(str(x.get("field")), _norm(str(x.get("value") or "")))
                for x in ledger if x.get("status") == "approved" and x.get("approvedBy")}
    for item in ledger:
        if not item.get("sessionId"):
            continue
        if item.get("status") == "approved" and item.get("approvedBy"):
            continue
        item["status"] = "pending"
        item["scope"] = "session"
        field, value = str(item.get("field") or ""), str(item.get("value") or "")
        if (field, _norm(value)) in approved:
            continue
        if field == "relations":
            # An old learner-created relation is not a world-canon relation.
            name = value.split(":", 1)[0].strip()
            out[field] = [r for r in (out.get(field) or [])
                          if not (isinstance(r, dict) and
                                  _norm(str(r.get("targetName") or "")) == _norm(name) and
                                  str(r.get("note") or "").startswith("gelernt aus Rede"))]
            continue
        if isinstance(out.get(field), list):
            out[field] = [v for v in out[field]
                          if not isinstance(v, str) or _norm(v) != _norm(value)]
    out["learnedItems"] = ledger
    return out


def approve_learned(character: dict, item_id: str, actor: str) -> bool:
    """Explicit existing character-editor write, never an automatic turn write."""
    hit = next((i for i in character.get("learnedItems") or []
                if isinstance(i, dict) and i.get("id") == item_id), None)
    if hit is None:
        return False
    field, value = str(hit.get("field") or ""), str(hit.get("value") or "")
    if field == "relations":
        name, sep, kind = value.partition(":")
        if not sep:
            return False
        rels = character.setdefault("relations", [])
        rel = next((r for r in rels if isinstance(r, dict) and
                    _norm(str(r.get("targetName") or "")) == _norm(name)), None)
        if rel is None:
            rels.append({"targetName": name.strip(), "kind": kind.strip(),
                         "note": "Vom Besitzer dauerhaft uebernommen"})
        else:
            rel["kind"] = kind.strip()
    elif field in LIST_CAPS:
        vals = character.setdefault(field, [])
        if not isinstance(vals, list):
            return False
        if not any(isinstance(v, str) and _norm(v) == _norm(value) for v in vals):
            vals.append(value)
    else:
        return False
    hit.update(status="approved", scope="stem", approvedBy=actor,
               approvedAt=datetime.now(timezone.utc).isoformat(timespec="seconds"))
    return True
