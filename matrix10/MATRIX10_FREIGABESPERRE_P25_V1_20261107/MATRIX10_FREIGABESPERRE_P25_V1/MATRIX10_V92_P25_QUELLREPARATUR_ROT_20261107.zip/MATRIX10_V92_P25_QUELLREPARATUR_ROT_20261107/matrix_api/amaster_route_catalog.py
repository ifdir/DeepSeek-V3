"""Live Flask route catalog for AMASTER coverage. Keys must match create_app().url_map."""

from __future__ import annotations

from typing import Any

# Flask rules (method, path). Sorted by path then method. Regenerated from url_map.
FLASK_ROUTES: tuple[tuple[str, str], ...] = (
    ("POST", "/api/amaster/system-loop"),
    ("POST", "/api/analyze"),
    ("GET", "/api/characters"),
    ("POST", "/api/characters"),
    ("DELETE", "/api/characters/<char_id>"),
    ("GET", "/api/characters/<char_id>"),
    ("PATCH", "/api/characters/<char_id>"),
    ("GET", "/api/characters/<char_id>/backup"),
    ("POST", "/api/characters/<char_id>/backup"),
    ("POST", "/api/characters/<char_id>/restore-backup"),
    # B.26: Backend ist Source of Truth für Compass-Trigger
    ("GET", "/api/compass/triggers"),
    ("GET", "/api/config"),
    ("PUT", "/api/config"),
    ("GET", "/api/document-index"),
    ("POST", "/api/document-index/search"),
    ("GET", "/api/documents"),
    ("POST", "/api/documents"),
    ("DELETE", "/api/documents/<doc_id>"),
    ("GET", "/api/documents/<doc_id>"),
    ("PATCH", "/api/documents/<doc_id>"),
    ("POST", "/api/genre/policy"),
    ("GET", "/api/health"),
    ("POST", "/api/ids/allocate"),
    ("POST", "/api/import/mcc"),
    ("POST", "/api/kernel/autochat-gate"),
    ("POST", "/api/kernel/commit"),
    ("POST", "/api/kernel/fate"),
    ("POST", "/api/kernel/god"),
    ("POST", "/api/kernel/move"),
    ("POST", "/api/kernel/perception"),
    ("POST", "/api/kernel/prepare"),
    ("POST", "/api/kernel/presence"),
    ("POST", "/api/kernel/puppet"),
    ("POST", "/api/kernel/regie"),
    ("POST", "/api/kernel/reset"),
    ("GET", "/api/live-log"),
    ("POST", "/api/llm/characters"),
    ("POST", "/api/llm/compass"),
    ("POST", "/api/llm/complete-profiles"),
    ("POST", "/api/llm/formulate"),
    ("GET", "/api/llm/ping"),
    ("POST", "/api/llm/ping"),
    ("POST", "/api/llm/profile"),
    ("POST", "/api/llm/world"),
    ("GET", "/api/logs"),
    ("POST", "/api/logs"),
    ("DELETE", "/api/logs/<log_id>"),
    ("GET", "/api/logs/<log_id>"),
    ("PUT", "/api/logs/<log_id>"),
    ("POST", "/api/logs/live"),
    ("GET", "/api/mcc"),
    ("PUT", "/api/mcc"),
    ("GET", "/api/preferences"),
    ("POST", "/api/preferences"),
    ("DELETE", "/api/preferences/<pref_id>"),
    ("GET", "/api/preferences/<pref_id>"),
    ("PATCH", "/api/preferences/<pref_id>"),
    ("GET", "/api/reviews"),
    ("POST", "/api/reviews"),
    ("GET", "/api/reviews/<review_id>"),
    ("PATCH", "/api/reviews/<review_id>"),
    ("POST", "/api/reviews/<review_id>/resolve"),
    ("POST", "/api/search"),
    ("GET", "/api/sessions"),
    ("POST", "/api/sessions"),
    ("DELETE", "/api/sessions/<session_id>"),
    ("GET", "/api/sessions/<session_id>"),
    ("PATCH", "/api/sessions/<session_id>"),
    ("PUT", "/api/sessions/<session_id>"),
    ("GET", "/api/sessions/<session_id>/appointments"),
    ("POST", "/api/sessions/<session_id>/appointments"),
    ("GET", "/api/sessions/<session_id>/evidence"),
    ("POST", "/api/sessions/<session_id>/goals"),
    ("PATCH", "/api/sessions/<session_id>/goals/<goal_id>"),
    ("GET", "/api/sessions/<session_id>/graph"),
    ("POST", "/api/sessions/<session_id>/graph"),
    ("POST", "/api/sessions/<session_id>/memories"),
    ("POST", "/api/sessions/<session_id>/propositions"),
    ("PATCH", "/api/sessions/<session_id>/propositions/<prop_id>"),
    ("POST", "/api/sessions/<session_id>/recall"),
    ("PUT", "/api/sessions/<session_id>/relations"),
    ("POST", "/api/sessions/<session_id>/reset-chat"),
    ("POST", "/api/sessions/<session_id>/reset-full"),
    ("POST", "/api/sessions/<session_id>/reset-memory"),
    ("POST", "/api/sessions/<session_id>/reset-uploads"),
    ("POST", "/api/sessions/<session_id>/snapshots"),
    ("GET", "/api/snapshots"),
    ("POST", "/api/snapshots"),
    ("DELETE", "/api/snapshots/<snap_id>"),
    ("GET", "/api/snapshots/<snap_id>"),
    ("POST", "/api/snapshots/<snap_id>/restore"),
    ("POST", "/api/speech/stt"),
    ("POST", "/api/speech/tts"),
    ("GET", "/api/triggers"),
    ("POST", "/api/triggers"),
    ("DELETE", "/api/triggers/<trigger_id>"),
    ("GET", "/api/triggers/<trigger_id>"),
    ("PATCH", "/api/triggers/<trigger_id>"),
    ("GET", "/api/uploads"),
    ("POST", "/api/uploads"),
    ("DELETE", "/api/uploads/<upload_id>"),
    ("GET", "/api/uploads/<upload_id>"),
    ("PATCH", "/api/uploads/<upload_id>"),
    ("POST", "/api/uploads/<upload_id>/commit"),
    ("POST", "/api/uploads/<upload_id>/ingest"),
    ("GET", "/api/users"),
    ("POST", "/api/users"),
    ("DELETE", "/api/users/<user_id>"),
    ("GET", "/api/users/<user_id>"),
    ("PATCH", "/api/users/<user_id>"),
    ("POST", "/api/users/<user_id>/hard-reset"),
    ("DELETE", "/api/users/<user_id>/logs"),
    ("POST", "/api/users/<user_id>/reset-sessions"),
    ("POST", "/api/vector/search"),
    ("GET", "/api/worlds"),
    ("POST", "/api/worlds"),
    ("DELETE", "/api/worlds/<world_id>"),
    ("GET", "/api/worlds/<world_id>"),
    ("PATCH", "/api/worlds/<world_id>"),
    ("GET", "/api/worlds/<world_id>/backup"),
    ("POST", "/api/worlds/<world_id>/backup"),
    ("POST", "/api/worlds/<world_id>/restore-backup"),
)

REQUIRED_META = (
    "reachable",
    "frontend",
    "authority",
    "reads",
    "writes",
    "owner",
    "isolation",
    "reader",
    "negative",
    "parallel",
)

EXPLICIT_META: dict[tuple[str, str], dict[str, str]] = {
    ("POST", "/api/ids/allocate"): {
        "authority": "none — allocation creates no product state; later writer enforces actor",
        "isolation": "no user/world/session data read or written",
        "negative": "400 invalid provisional id/prefix/count",
        "parallel": "none — canonical ids are consumed by existing SQLite writers",
    },
    ("GET", "/api/characters/<char_id>/backup"): {
        "reachable": "yes Flask",
        "frontend": "src/routes/charakter.$charId.tsx apiListCharacterBackups",
        "authority": "X-Matrix-Actor mutating; character/world owner",
        "reads": "snapshots kind=character-backup",
        "writes": "none",
        "owner": "snapshots TABLE",
        "isolation": "foreign actor 403",
        "reader": "GET /api/characters/<id>/backup",
        "negative": "foreign 403; missing 404",
        "parallel": "none — not a second master",
    },
    ("POST", "/api/characters/<char_id>/backup"): {
        "reachable": "yes Flask",
        "frontend": "src/routes/charakter.$charId.tsx apiBackupCharacter",
        "authority": "X-Matrix-Actor mutating; character/world owner",
        "reads": "characters row",
        "writes": "INSERT snapshots kind=character-backup",
        "owner": "snapshots TABLE",
        "isolation": "foreign actor 403",
        "reader": "GET /api/characters/<id>/backup",
        "negative": "foreign 403",
        "parallel": "none",
    },
    ("POST", "/api/characters/<char_id>/restore-backup"): {
        "reachable": "yes Flask",
        "frontend": "src/routes/charakter.$charId.tsx apiRestoreCharacterBackup",
        "authority": "X-Matrix-Actor mutating; backup owner",
        "reads": "snapshots + characters",
        "writes": "PATCH characters from backup payload",
        "owner": "characters TABLE",
        "isolation": "foreign actor 403; other character 409",
        "reader": "GET /api/characters/<id>",
        "negative": "foreign 403; mismatch 409",
        "parallel": "none",
    },
    ("GET", "/api/document-index"): {
        "reachable": "yes Flask",
        "frontend": "src/routes/memory.tsx apiListDocumentIndex",
        "authority": "X-Matrix-Actor",
        "reads": "document_index derived from documents",
        "writes": "none",
        "owner": "documents (index is derived)",
        "isolation": "scoped by actor user_id",
        "reader": "same GET; memory UI",
        "negative": "missing actor 401",
        "parallel": "none inventsTruth=false",
    },
    ("POST", "/api/document-index/search"): {
        "reachable": "yes Flask",
        "frontend": "src/routes/memory.tsx apiSearchDocumentIndex",
        "authority": "X-Matrix-Actor",
        "reads": "document_index",
        "writes": "none",
        "owner": "documents",
        "isolation": "scoped by actor",
        "reader": "hits[] in response + memory UI",
        "negative": "unknown cue empty hits",
        "parallel": "none",
    },
    ("GET", "/api/llm/ping"): {
        "reachable": "yes Flask (same handler as POST)",
        "frontend": "src/routes/config.tsx apiPingProvider uses POST; GET is identical probe",
        "authority": "X-Matrix-Actor",
        "reads": "config provider flags",
        "writes": "none — does not call paid provider live",
        "owner": "none (probe)",
        "isolation": "actor required",
        "reader": "config providerOnline",
        "negative": "blocked=BLOCKED_EXTERNAL without key",
        "parallel": "none — not a second backend",
    },
    ("POST", "/api/llm/ping"): {
        "reachable": "yes Flask",
        "frontend": "src/routes/config.tsx apiPingProvider",
        "authority": "X-Matrix-Actor",
        "reads": "config",
        "writes": "none",
        "owner": "none (probe)",
        "isolation": "actor required",
        "reader": "config UI",
        "negative": "BLOCKED_EXTERNAL",
        "parallel": "none",
    },
    ("POST", "/api/llm/characters"): {
        "reachable": "yes Flask",
        "frontend": "src/routes/welt.$worldId.tsx apiGenerateCharacters",
        "authority": "X-Matrix-Actor",
        "reads": "world summary in body / config",
        "writes": "none — draft only commitsTruth=false",
        "owner": "characters TABLE only after explicit save",
        "isolation": "actor",
        "reader": "welt UI draft, not Stamm until POST /api/characters",
        "negative": "does not spawn Stamm",
        "parallel": "none",
    },
    ("POST", "/api/llm/compass"): {
        "reachable": "yes Flask",
        "frontend": "src/routes/charakter.$charId.tsx apiDeriveCompass",
        "authority": "X-Matrix-Actor",
        "reads": "profile body / config",
        "writes": "none — compassJson draft",
        "owner": "character json only after PATCH",
        "isolation": "actor",
        "reader": "charakter UI",
        "negative": "not a fact machine",
        "parallel": "none",
    },
    ("POST", "/api/llm/profile"): {
        "reachable": "yes Flask",
        "frontend": "src/routes/charakter.$charId.tsx apiSuggestProfile",
        "authority": "X-Matrix-Actor",
        "reads": "name/world body",
        "writes": "none — patch draft",
        "owner": "characters after PATCH",
        "isolation": "actor",
        "reader": "charakter UI",
        "negative": "does not write Stamm until user saves",
        "parallel": "none",
    },
    ("POST", "/api/llm/world"): {
        "reachable": "yes Flask",
        "frontend": "src/routes/welt.index.tsx + welt.$worldId.tsx apiGenerateWorld",
        "authority": "X-Matrix-Actor",
        "reads": "prompt / config",
        "writes": "none — draft world commitsTruth=false",
        "owner": "worlds TABLE after POST/PATCH /api/worlds",
        "isolation": "actor",
        "reader": "welt UI draft",
        "negative": "does not persist world",
        "parallel": "none",
    },
    ("POST", "/api/sessions/<session_id>/reset-full"): {
        "reachable": "yes Flask",
        "frontend": "src/routes/index.tsx resetSessionFull → store.apiResetSessionFull",
        "authority": "X-Matrix-Actor session owner",
        "reads": "sessions row",
        "writes": "clears SQL children of THIS session; keeps id+avatar",
        "owner": "sessions + child tables",
        "isolation": "foreign session 403; other users untouched",
        "reader": "GET /api/sessions/<id>",
        "negative": "not DELETE session; B sessions remain",
        "parallel": "none",
    },
    ("POST", "/api/kernel/reset"): {
        "reachable": "yes Flask",
        "frontend": "src/routes/index.tsx kernelReset; src/lib/matrix/kernel-bridge.ts kernelReset → apiKernelReset POST /api/kernel/reset",
        "authority": "X-Matrix-Actor mutating; session owner",
        "reads": "session + children",
        "writes": "kernel reset_chat/runtime/memory then SQL persist",
        "owner": "sessions + turns/relationships/memories depending on kind",
        "isolation": "foreign session 403",
        "reader": "GET /api/sessions/<id> after kernel reset",
        "negative": "unknown kind 400; foreign 403",
        "parallel": "none — not a hidden second reset store",
    },
    ("POST", "/api/vector/search"): {
        "reachable": "yes Flask",
        "frontend": "src/routes/memory.tsx Vektor button → apiVectorSearch POST /api/vector/search",
        "authority": "X-Matrix-Actor",
        "reads": "documents/vector index (search, no new truth)",
        "writes": "none",
        "owner": "documents (index is derived)",
        "isolation": "scoped by actor user_id",
        "reader": "hits[] in memory UI",
        "negative": "empty query empty hits",
        "parallel": "none",
    },
    ("POST", "/api/sessions/<session_id>/snapshots"): {
        "reachable": "yes Flask",
        "frontend": "src/lib/matrix/store.ts addSnapshot → apiCreateSessionSnapshot POST /api/sessions/<id>/snapshots; chat.index.tsx addSnapshot",
        "authority": "X-Matrix-Actor session owner",
        "reads": "session capture",
        "writes": "INSERT snapshots",
        "owner": "snapshots TABLE",
        "isolation": "foreign session 403",
        "reader": "GET /api/snapshots",
        "negative": "missing session 404",
        "parallel": "none — same snapshots owner as POST /api/snapshots",
    },
    ("POST", "/api/snapshots"): {
        "reachable": "yes Flask",
        "frontend": "src/routes/diagnose.tsx runForbiddenLogProbe apiCreateSnapshot POST /api/snapshots; store restore/delete remain on /api/snapshots/<id>",
        "authority": "X-Matrix-Actor session owner",
        "reads": "session capture",
        "writes": "INSERT snapshots",
        "owner": "snapshots TABLE",
        "isolation": "foreign session 403",
        "reader": "GET /api/snapshots",
        "negative": "missing sessionId 400",
        "parallel": "none",
    },
    ("GET", "/api/logs/<log_id>"): {
        "reachable": "yes Flask",
        "frontend": "src/routes/logs.tsx Reader button → apiGetLog GET /api/logs/<id>; diagnose.tsx probe",
        "authority": "X-Matrix-Actor",
        "reads": "logs row",
        "writes": "none",
        "owner": "logs TABLE",
        "isolation": "foreign log 403/404",
        "reader": "same GET; logs UI detail",
        "negative": "missing id 404",
        "parallel": "none",
    },
    ("PUT", "/api/logs/<log_id>"): {
        "reachable": "yes Flask",
        "frontend": "src/routes/diagnose.tsx Log PUT/DELETE prüfen → apiProbeLogPut PUT /api/logs/<id> (expect 405)",
        "authority": "X-Matrix-Actor",
        "reads": "none",
        "writes": "none — 405 METHOD_NOT_ALLOWED append-only",
        "owner": "logs TABLE (append-only gate)",
        "isolation": "actor required",
        "reader": "diagnose probe result 405",
        "negative": "405 always; no overwrite",
        "parallel": "blocked — logs are append-only",
    },
    ("DELETE", "/api/logs/<log_id>"): {
        "reachable": "yes Flask",
        "frontend": "src/routes/diagnose.tsx Log PUT/DELETE prüfen → apiProbeLogDelete DELETE /api/logs/<id> (expect 403)",
        "authority": "X-Matrix-Actor",
        "reads": "none",
        "writes": "none — 403 LOG_DELETE_FORBIDDEN except user-scoped hard reset",
        "owner": "logs TABLE (append-only gate)",
        "isolation": "actor required",
        "reader": "diagnose probe result 403",
        "negative": "403; use DELETE /api/users/<id>/logs for hard reset",
        "parallel": "blocked — no per-row log delete",
    },
    ("PUT", "/api/mcc"): {
        "reachable": "yes Flask",
        "frontend": "none — forbidden snapshot write",
        "authority": "any actor",
        "reads": "none",
        "writes": "none — 409 SNAPSHOT_OWNER_FORBIDDEN",
        "owner": "SQL writers only",
        "isolation": "n/a",
        "reader": "n/a",
        "negative": "409 always",
        "parallel": "blocked — this is the anti-parallelstore gate",
    },
    ("PUT", "/api/sessions/<session_id>/relations"): {
        "reachable": "yes Flask",
        "frontend": "store patchRelation/addRelation apiPutRelation; social.tsx",
        "authority": "X-Matrix-Actor session owner",
        "reads": "relationships pair",
        "writes": "INSERT/UPDATE relationships",
        "owner": "relationships TABLE",
        "isolation": "foreign 403",
        "reader": "GET session.relations",
        "negative": "missing from/to 400",
        "parallel": "none",
    },
}


def _default_meta(method: str, path: str) -> dict[str, str]:
    mutating = method in {"POST", "PUT", "PATCH", "DELETE"}
    owner, frontend, reads, writes, isolation, reader, negative, parallel = _classify(method, path)
    return {
        "reachable": "yes Flask url_map",
        "frontend": frontend,
        "authority": "X-Matrix-Actor" + (" mutating" if mutating else " read"),
        "reads": reads,
        "writes": writes,
        "owner": owner,
        "isolation": isolation,
        "reader": reader,
        "negative": negative,
        "parallel": parallel,
    }


def _classify(method: str, path: str) -> tuple[str, str, str, str, str, str, str, str]:
    """Return owner, frontend, reads, writes, isolation, reader, negative, parallel."""
    mutating = method in {"POST", "PUT", "PATCH", "DELETE"}
    iso = "X-Matrix-Actor; foreign session/world 403"
    neg = "401 missing actor; 403 foreign; 404 missing"
    par = "none — Flask SQLite master, not PGlite/Neon"

    def pack(owner, frontend, reads, writes=None, reader=None):
        w = writes if writes is not None else ("owner table" if mutating else "none")
        rdr = reader or ("matching GET or session hydrate")
        return owner, frontend, reads, w, iso, rdr, neg, par

    if path == "/api/health":
        return pack("none (probe)", "src/lib/matrix/api.ts apiHealth + diagnose.tsx", "sqlite path + VERSION.txt", "none", "JSON ok/master/secondMaster")
    if path == "/api/ids/allocate":
        return pack("backend ID owner (allocation only, no persisted truth)", "src/lib/matrix/id-owner.ts", "provisional tmp_* ids", "none", "canonical ids passed to scoped writers")
    if path == "/api/compass/triggers":
        # B.26: Backend ist Source of Truth für Compass-Trigger.
        # Frontend lädt via syncCompassTriggersFromBackend().
        return pack("none (read-only spec, no SQL owner)", "src/lib/matrix/compass.ts syncCompassTriggersFromBackend", "_COMPASS_TRIGGERS in kernel.py", "none", "JSON triggers/spaces/version")
    if path == "/api/live-log":
        return pack("live log file", "diagnose/logs UI apiLiveLog", "logs/MATRIX10_LIVE_<Version>_<Start>.log tail (one file per backend start)", "none", "GET /api/live-log")
    if path == "/api/mcc" and method == "GET":
        return pack("SQL snapshot read (not a writer)", "store hydrate apiGetMcc", "users/worlds/sessions/...", "none", "store")
    if path == "/api/mcc" and method == "PUT":
        return pack("forbidden — SQL writers only", "none — 409 SNAPSHOT_OWNER_FORBIDDEN", "none", "none — 409", "n/a")
    if path == "/api/import/mcc":
        return pack("SQL owned tables (import cutover)", "store apiImportMcc / welt", "payload + existing SQL", "INSERT/UPDATE owned tables", "GET after import")
    if path.startswith("/api/users"):
        extra = "logs TABLE" if path.endswith("/logs") else "users TABLE"
        return pack(extra, "src/routes/user.tsx + index.tsx + store", "users" + (" + logs" if "logs" in path else ""))
    if path.startswith("/api/worlds"):
        return pack("worlds TABLE", "welt routes + store", "worlds")
    if path.startswith("/api/characters"):
        return pack("characters TABLE", "charakter routes + store", "characters")
    if "/relations" in path:
        return pack("relationships TABLE", "social.tsx addRelation/patchRelation", "relationships pair (manual seed, provenance stamped)")
    if "/memories" in path:
        return pack("memories TABLE", "memory.tsx + chat + store", "memories")
    if "/propositions" in path:
        return pack("propositions TABLE", "timeline.tsx + store", "propositions")
    if "/goals" in path:
        return pack("goals TABLE", "timeline.tsx + store", "goals")
    if "/appointments" in path:
        return pack("appointments TABLE", "chat/timeline store", "appointments")
    if "/graph" in path:
        return pack("graph_edges TABLE", "social.tsx graph helpers", "graph_edges")
    if path.endswith("/recall"):
        return pack("memories + scene_facts + relationships (read)", "chat.$sessionId.tsx apiRecall", "recall bundle", "none — read/compose", "brain/spiegel")
    if path.endswith("/reset-chat"):
        return pack("turns + scene envelope", "index.tsx resetSessionChat", "sessions", "clears chat turns of THIS session", "GET session")
    if path.endswith("/reset-memory"):
        return pack("memories TABLE", "index.tsx resetSessionMemory", "memories", "DELETE memories this session", "GET session.memories")
    if path.endswith("/reset-full"):
        return pack("sessions + SQL children of THIS session", "index.tsx resetSessionFull", "sessions row", "clears children; keeps id+avatar", "GET session")
    if "/snapshots" in path and "/sessions/" in path:
        return pack("snapshots TABLE", "chat/index snapshot UI", "snapshots")
    if path.startswith("/api/sessions"):
        return pack("sessions TABLE", "store.ts session writers + chat/index", "sessions" + (" + SQL children on GET" if method == "GET" else ""))
    if path.startswith("/api/uploads"):
        return pack("uploads TABLE", "upload.tsx store", "uploads")
    if path.startswith("/api/documents"):
        return pack("documents TABLE", "upload.tsx + memory.tsx", "documents")
    if path.startswith("/api/document-index"):
        return pack("documents (index is derived)", "memory.tsx apiListDocumentIndex/apiSearchDocumentIndex", "document_index")
    if path.startswith("/api/reviews"):
        return pack("reviews TABLE", "review.tsx store", "reviews")
    if path.startswith("/api/snapshots"):
        return pack("snapshots TABLE", "index/chat snapshot UI + store", "snapshots")
    if path.startswith("/api/triggers"):
        return pack("triggers TABLE", "triggers.tsx store", "triggers")
    if path.startswith("/api/preferences"):
        return pack("preferences TABLE", "config.tsx + user.tsx", "preferences")
    if path.startswith("/api/config"):
        return pack("config TABLE", "config.tsx store", "config")
    if path.startswith("/api/logs"):
        return pack("logs TABLE", "logs.tsx + diagnose.tsx", "logs")
    if path.startswith("/api/kernel/"):
        return pack(
            "kernel → SQL owners (scene_facts/turns/relationships/runtimes/god_facts)",
            "src/routes/chat.$sessionId.tsx / fate.tsx kernel helpers",
            "session + children",
            "canonical SQL writers via kernel commit" if mutating else "none",
            "GET session + timeline",
        )
    if path == "/api/amaster/system-loop":
        return pack("kernel loop → SQL owners", "diagnose.tsx system-loop", "session", "same as kernel commit", "GET session")
    if path == "/api/analyze":
        return pack("none (analysis draft, commitsTruth=false)", "welt.$worldId.tsx analyse UI", "world body / documents", "none until review resolve", "welt review UI")
    if path == "/api/genre/policy":
        return pack("config/genre policy (no world rewrite)", "welt/config", "policy body", "none or config", "response")
    if path == "/api/vector/search":
        return pack("documents/vector index (search, no new truth)", "memory.tsx search", "document_index", "none", "hits[]")
    if path == "/api/search":
        return pack("documents search (no new truth)", "memory.tsx", "documents", "none", "hits[]")
    if path.startswith("/api/speech/"):
        return pack("none — BLOCKED_EXTERNAL microphone/tts", "chat STT/TTS controls", "audio/text body", "none", "blocked or mock")
    if path.startswith("/api/llm/"):
        return pack(
            "none (draft, commitsTruth=false) until explicit owner write",
            "src/lib/matrix/api.ts llm helpers + welt/charakter/config/chat",
            "prompt/config",
            "none",
            "UI draft",
        )
    raise AssertionError(f"unclassified Flask route {method} {path} — catalog must cover url_map")


def meta_for(method: str, path: str) -> dict[str, str]:
    base = _default_meta(method, path)
    override = EXPLICIT_META.get((method, path))
    if override:
        base.update(override)
    return base


def catalog() -> list[dict[str, Any]]:
    out = []
    for method, path in FLASK_ROUTES:
        item = {"method": method, "path": path}
        item.update(meta_for(method, path))
        out.append(item)
    return out


def live_flask_routes(app) -> list[tuple[str, str]]:
    rules: list[tuple[str, str]] = []
    for rule in app.url_map.iter_rules():
        if rule.endpoint == "static":
            continue
        methods = sorted(m for m in (rule.methods or []) if m not in ("HEAD", "OPTIONS"))
        for method in methods:
            rules.append((method, rule.rule))
    return sorted(rules, key=lambda x: (x[1], x[0]))
