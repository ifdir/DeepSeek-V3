"""SQLite path + schema. Path is project-root relative unless MATRIX_DB is absolute."""

from __future__ import annotations

import json
import os
import sqlite3
import threading
import time
from contextlib import contextmanager
from pathlib import Path
from typing import Any

SCHEMA_STATEMENTS = (
    """
    CREATE TABLE IF NOT EXISTS users (
      id TEXT PRIMARY KEY,
      json TEXT NOT NULL,
      created_at TEXT
    )
    """,
    """
    CREATE TABLE IF NOT EXISTS worlds (
      id TEXT PRIMARY KEY,
      owner_user_id TEXT NOT NULL,
      json TEXT NOT NULL
    )
    """,
    """
    CREATE TABLE IF NOT EXISTS characters (
      id TEXT PRIMARY KEY,
      world_id TEXT NOT NULL,
      owner_user_id TEXT NOT NULL,
      json TEXT NOT NULL
    )
    """,
    """
    CREATE TABLE IF NOT EXISTS sessions (
      id TEXT PRIMARY KEY,
      user_id TEXT NOT NULL,
      world_id TEXT NOT NULL,
      json TEXT NOT NULL
    )
    """,
    """
    CREATE TABLE IF NOT EXISTS scene_facts (
      id TEXT PRIMARY KEY,
      user_id TEXT,
      world_id TEXT,
      session_id TEXT,
      json TEXT NOT NULL
    )
    """,
    """
    CREATE TABLE IF NOT EXISTS memories (
      id TEXT PRIMARY KEY,
      user_id TEXT,
      world_id TEXT,
      session_id TEXT,
      json TEXT NOT NULL
    )
    """,
    """
    CREATE TABLE IF NOT EXISTS relationships (
      id TEXT PRIMARY KEY,
      user_id TEXT,
      world_id TEXT,
      session_id TEXT,
      from_id TEXT,
      to_id TEXT,
      json TEXT NOT NULL
    )
    """,
    """
    CREATE TABLE IF NOT EXISTS propositions (
      id TEXT PRIMARY KEY,
      user_id TEXT,
      world_id TEXT,
      session_id TEXT,
      json TEXT NOT NULL
    )
    """,
    """
    CREATE TABLE IF NOT EXISTS goals (
      id TEXT PRIMARY KEY,
      user_id TEXT,
      world_id TEXT,
      session_id TEXT,
      json TEXT NOT NULL
    )
    """,
    """
    CREATE TABLE IF NOT EXISTS god_facts (
      id TEXT PRIMARY KEY,
      user_id TEXT,
      world_id TEXT,
      session_id TEXT,
      json TEXT NOT NULL
    )
    """,
    """
    CREATE TABLE IF NOT EXISTS turns (
      id TEXT PRIMARY KEY,
      user_id TEXT,
      world_id TEXT,
      session_id TEXT,
      json TEXT NOT NULL
    )
    """,
    """
    CREATE TABLE IF NOT EXISTS witness_knowledge (
      id TEXT PRIMARY KEY,
      user_id TEXT,
      world_id TEXT,
      session_id TEXT,
      character_id TEXT,
      fact_id TEXT,
      access TEXT,
      source_turn_id TEXT,
      turn INTEGER,
      json TEXT NOT NULL,
      -- R3.5 / B.19-Folge: FK-Constraints mit PRAGMA foreign_keys=ON
      -- (schon in db.connect aktiv). character_id referenziert die
      -- Charakter-ID, die im json der characters-Tabelle liegt. Da
      -- characters.id der PK ist, sind alle FKs optional (kein NOT NULL)
      -- weil ein witness-Knowledge-Eintrag ohne Charakter-Zuordnung
      -- legitim ist (z. B. "der Beobachter weiß es").
      FOREIGN KEY (session_id) REFERENCES sessions(id) ON DELETE CASCADE,
      FOREIGN KEY (character_id) REFERENCES characters(id) ON DELETE SET NULL
    )
    """,
    """
    CREATE TABLE IF NOT EXISTS uploads (
      id TEXT PRIMARY KEY,
      user_id TEXT,
      session_id TEXT,
      json TEXT NOT NULL
    )
    """,
    """
    CREATE TABLE IF NOT EXISTS documents (
      id TEXT PRIMARY KEY,
      user_id TEXT,
      json TEXT NOT NULL
    )
    """,
    """
    CREATE TABLE IF NOT EXISTS reviews (
      id TEXT PRIMARY KEY,
      user_id TEXT,
      json TEXT NOT NULL
    )
    """,
    """
    CREATE TABLE IF NOT EXISTS snapshots (
      id TEXT PRIMARY KEY,
      user_id TEXT,
      session_id TEXT,
      json TEXT NOT NULL
    )
    """,
    """
    CREATE TABLE IF NOT EXISTS triggers (
      id TEXT PRIMARY KEY,
      user_id TEXT,
      json TEXT NOT NULL
    )
    """,
    """
    CREATE TABLE IF NOT EXISTS logs (
      id TEXT PRIMARY KEY,
      user_id TEXT,
      json TEXT NOT NULL
    )
    """,
    """
    CREATE TABLE IF NOT EXISTS preferences (
      id TEXT PRIMARY KEY,
      user_id TEXT,
      json TEXT NOT NULL
    )
    """,
    """
    CREATE TABLE IF NOT EXISTS config (
      scope TEXT NOT NULL,
      scope_id TEXT NOT NULL,
      json TEXT NOT NULL,
      PRIMARY KEY (scope, scope_id)
    )
    """,
    """
    CREATE TABLE IF NOT EXISTS meta (
      key TEXT PRIMARY KEY,
      value TEXT
    )
    """,
    """
    CREATE TABLE IF NOT EXISTS app_config (
      id TEXT PRIMARY KEY,
      json TEXT NOT NULL
    )
    """,
    """
    CREATE TABLE IF NOT EXISTS turn_truth (
      id TEXT PRIMARY KEY,
      session_id TEXT,
      user_id TEXT,
      world_id TEXT,
      json TEXT NOT NULL
    )
    """,
    """
    CREATE TABLE IF NOT EXISTS appointments (
      id TEXT PRIMARY KEY,
      user_id TEXT,
      world_id TEXT,
      session_id TEXT,
      json TEXT NOT NULL
    )
    """,
    """
    CREATE TABLE IF NOT EXISTS graph_edges (
      id TEXT PRIMARY KEY,
      user_id TEXT,
      world_id TEXT,
      session_id TEXT,
      from_id TEXT,
      to_id TEXT,
      json TEXT NOT NULL
    )
    """,
    """
    CREATE TABLE IF NOT EXISTS document_index (
      document_id TEXT PRIMARY KEY,
      user_id TEXT NOT NULL,
      json TEXT NOT NULL
    )
    """,
    # Intentionally NOT creating the relations VIEW here.
    # SQLite "CREATE VIEW IF NOT EXISTS" is a no-op when a TABLE of that name
    # already exists, which leaves a writable parallel store. ensure_relations_owner
    # migrates a legacy TABLE then creates the VIEW.
)

RELATIONS_VIEW_SQL = """
CREATE VIEW relations AS
  SELECT id, user_id, world_id, session_id, from_id, to_id, json FROM relationships
"""

RELATIONS_OWNER_META_KEY = "relations_owner_migration"


def _session_scope_trigger(name: str, table: str, error: str) -> tuple[str, str]:
    return (
        name,
        f"""
        CREATE TRIGGER {name}
        BEFORE INSERT ON {table}
        BEGIN
          SELECT RAISE(ABORT, '{error}')
          WHERE NEW.session_id IS NOT NULL
            AND NEW.session_id != ''
            AND (
              NOT EXISTS (SELECT 1 FROM sessions s WHERE s.id = NEW.session_id)
              OR EXISTS (
                SELECT 1 FROM sessions s
                WHERE s.id = NEW.session_id
                  AND (
                    (NEW.user_id IS NOT NULL AND s.user_id IS NOT NEW.user_id)
                    OR (NEW.world_id IS NOT NULL AND s.world_id IS NOT NEW.world_id)
                  )
              )
            );
        END
        """,
    )


CONSISTENCY_TRIGGERS: tuple[tuple[str, str], ...] = (
    (
        "trg_scene_facts_immutable",
        """
        CREATE TRIGGER trg_scene_facts_immutable
        BEFORE UPDATE ON scene_facts
        BEGIN
          SELECT RAISE(ABORT, 'SCENEFACT_IMMUTABLE')
          WHERE json_extract(OLD.json,'$.text') IS NOT json_extract(NEW.json,'$.text')
             OR json_extract(OLD.json,'$.kind') IS NOT json_extract(NEW.json,'$.kind')
             OR json_extract(OLD.json,'$.actorId') IS NOT json_extract(NEW.json,'$.actorId')
             OR json_extract(OLD.json,'$.verb') IS NOT json_extract(NEW.json,'$.verb')
             OR json_extract(OLD.json,'$.authority') IS NOT json_extract(NEW.json,'$.authority')
             OR json_extract(OLD.json,'$.turn') IS NOT json_extract(NEW.json,'$.turn')
             OR OLD.id IS NOT NEW.id
             OR OLD.user_id IS NOT NEW.user_id
             OR OLD.world_id IS NOT NEW.world_id
             OR OLD.session_id IS NOT NEW.session_id;
        END
        """,
    ),
    (
        "trg_turns_immutable",
        """
        CREATE TRIGGER trg_turns_immutable
        BEFORE UPDATE ON turns
        BEGIN
          SELECT RAISE(ABORT, 'TURN_IMMUTABLE')
          WHERE json_extract(OLD.json,'$.speech') IS NOT json_extract(NEW.json,'$.speech')
             OR json_extract(OLD.json,'$.text') IS NOT json_extract(NEW.json,'$.text')
             OR json_extract(OLD.json,'$.speakerId') IS NOT json_extract(NEW.json,'$.speakerId')
             OR json_extract(OLD.json,'$.turn') IS NOT json_extract(NEW.json,'$.turn')
             OR OLD.id IS NOT NEW.id
             OR OLD.user_id IS NOT NEW.user_id
             OR OLD.world_id IS NOT NEW.world_id
             OR OLD.session_id IS NOT NEW.session_id;
        END
        """,
    ),
    (
        "trg_god_facts_immutable",
        """
        CREATE TRIGGER trg_god_facts_immutable
        BEFORE UPDATE ON god_facts
        BEGIN
          SELECT RAISE(ABORT, 'GODFACT_IMMUTABLE')
          WHERE json_extract(OLD.json,'$.text') IS NOT json_extract(NEW.json,'$.text')
             OR json_extract(OLD.json,'$.scope') IS NOT json_extract(NEW.json,'$.scope')
             OR json_extract(OLD.json,'$.turn') IS NOT json_extract(NEW.json,'$.turn')
             OR OLD.id IS NOT NEW.id
             OR OLD.user_id IS NOT NEW.user_id
             OR OLD.world_id IS NOT NEW.world_id
             OR OLD.session_id IS NOT NEW.session_id;
        END
        """,
    ),
    (
        "trg_logs_immutable",
        """
        CREATE TRIGGER trg_logs_immutable
        BEFORE UPDATE ON logs
        BEGIN
          SELECT RAISE(ABORT, 'LOG_IMMUTABLE')
          WHERE OLD.json IS NOT NEW.json
             OR OLD.id IS NOT NEW.id
             OR OLD.user_id IS NOT NEW.user_id;
        END
        """,
    ),
    (
        "trg_turn_truth_immutable",
        """
        CREATE TRIGGER trg_turn_truth_immutable
        BEFORE UPDATE ON turn_truth
        BEGIN
          SELECT RAISE(ABORT, 'TURNTRUTH_IMMUTABLE')
          WHERE json_extract(OLD.json,'$.text') IS NOT json_extract(NEW.json,'$.text')
             OR json_extract(OLD.json,'$.speech') IS NOT json_extract(NEW.json,'$.speech')
             OR OLD.id IS NOT NEW.id
             OR OLD.user_id IS NOT NEW.user_id
             OR OLD.world_id IS NOT NEW.world_id
             OR OLD.session_id IS NOT NEW.session_id;
        END
        """,
    ),
    _session_scope_trigger("trg_scene_facts_scope", "scene_facts", "SCENEFACT_SCOPE"),
    _session_scope_trigger("trg_turns_scope", "turns", "TURN_SCOPE"),
    _session_scope_trigger("trg_god_facts_scope", "god_facts", "GODFACT_SCOPE"),
    _session_scope_trigger("trg_turn_truth_scope", "turn_truth", "TURNTRUTH_SCOPE"),
    _session_scope_trigger("trg_memories_scope", "memories", "MEMORY_SCOPE"),
    (
        "trg_session_world",
        """
        CREATE TRIGGER trg_session_world
        BEFORE INSERT ON sessions
        BEGIN
          SELECT RAISE(ABORT, 'SESSION_WORLD')
          WHERE NEW.world_id IS NOT NULL
            AND NEW.world_id != ''
            AND NOT EXISTS (SELECT 1 FROM worlds w WHERE w.id = NEW.world_id);
        END
        """,
    ),
    (
        "trg_character_world",
        """
        CREATE TRIGGER trg_character_world
        BEFORE INSERT ON characters
        BEGIN
          SELECT RAISE(ABORT, 'CHARACTER_WORLD')
          WHERE NEW.world_id IS NOT NULL
            AND NEW.world_id != ''
            AND NOT EXISTS (SELECT 1 FROM worlds w WHERE w.id = NEW.world_id);
        END
        """,
    ),
)

_SCHEMA_LOCK = threading.RLock()
_FILE_LOCKS_GUARD = threading.Lock()
_FILE_LOCKS: dict[str, threading.Lock] = {}
_WAL_READY: set[str] = set()


_SCHEMA_READY: set[str] = set()


def _file_lock(path: str) -> threading.Lock:
    with _FILE_LOCKS_GUARD:
        lock = _FILE_LOCKS.get(path)
        if lock is None:
            lock = threading.Lock()
            _FILE_LOCKS[path] = lock
        return lock


def _execute_busy(conn: sqlite3.Connection, sql: str) -> sqlite3.Cursor:
    delay = 0.01
    last: sqlite3.OperationalError | None = None
    for _ in range(16):
        try:
            return conn.execute(sql)
        except sqlite3.OperationalError as exc:
            last = exc
            if "locked" not in str(exc).lower():
                raise
            time.sleep(delay)
            delay = min(delay * 2, 0.25)
    assert last is not None
    raise last


def _db_file(conn: sqlite3.Connection) -> str:
    row = conn.execute("PRAGMA database_list").fetchone()
    if row is None:
        return f":memory:{id(conn)}"
    path = str(row["file"] if "file" in row.keys() else row[2] or "")
    if not path or path == ":memory:":
        return f":memory:{id(conn)}"
    return path


def ensure_consistency_triggers(conn: sqlite3.Connection) -> None:
    """DB-level AMASTER consistency: append-only evidence, session scope, world binding.

    Concurrent Flask writes used to CREATE the same trigger and raise
    'trigger already exists' (session start 500). Create only when missing.
    """
    with _SCHEMA_LOCK:
        have = {
            str(r[0])
            for r in conn.execute("SELECT name FROM sqlite_master WHERE type='trigger'").fetchall()
        }
        for name, sql in CONSISTENCY_TRIGGERS:
            if name in have:
                continue
            stmt = sql.replace("CREATE TRIGGER ", "CREATE TRIGGER IF NOT EXISTS ", 1)
            try:
                conn.execute(stmt)
            except sqlite3.OperationalError as exc:
                if "already exists" not in str(exc).lower():
                    raise


QUERY_INDEXES: tuple[tuple[str, str], ...] = (
    # Slim indexes: keys only. JSON is stored in its owner table, not duplicated in indexes.
    ("idx_worlds_owner", "CREATE INDEX IF NOT EXISTS idx_worlds_owner ON worlds(owner_user_id, id)"),
    ("idx_characters_world", "CREATE INDEX IF NOT EXISTS idx_characters_world ON characters(world_id, id, owner_user_id)"),
    ("idx_characters_owner", "CREATE INDEX IF NOT EXISTS idx_characters_owner ON characters(owner_user_id, id, world_id)"),
    ("idx_sessions_user", "CREATE INDEX IF NOT EXISTS idx_sessions_user ON sessions(user_id, id, world_id)"),
    ("idx_sessions_world", "CREATE INDEX IF NOT EXISTS idx_sessions_world ON sessions(world_id, id, user_id)"),
    ("idx_scene_facts_session", "CREATE INDEX IF NOT EXISTS idx_scene_facts_session ON scene_facts(session_id, id, user_id, world_id)"),
    ("idx_scene_facts_user", "CREATE INDEX IF NOT EXISTS idx_scene_facts_user ON scene_facts(user_id, id, session_id)"),
    ("idx_memories_session", "CREATE INDEX IF NOT EXISTS idx_memories_session ON memories(session_id, id, user_id, world_id)"),
    ("idx_memories_user", "CREATE INDEX IF NOT EXISTS idx_memories_user ON memories(user_id, id, session_id)"),
    ("idx_relationships_session_pair", "CREATE INDEX IF NOT EXISTS idx_relationships_session_pair ON relationships(session_id, from_id, to_id, id, user_id, world_id)"),
    ("idx_relationships_user", "CREATE INDEX IF NOT EXISTS idx_relationships_user ON relationships(user_id, id, session_id)"),
    ("idx_propositions_session", "CREATE INDEX IF NOT EXISTS idx_propositions_session ON propositions(session_id, id, user_id, world_id)"),
    ("idx_goals_session", "CREATE INDEX IF NOT EXISTS idx_goals_session ON goals(session_id, id, user_id, world_id)"),
    ("idx_god_facts_session", "CREATE INDEX IF NOT EXISTS idx_god_facts_session ON god_facts(session_id, id, user_id, world_id)"),
    ("idx_turns_session", "CREATE INDEX IF NOT EXISTS idx_turns_session ON turns(session_id, id, user_id, world_id)"),
    ("idx_turn_truth_session", "CREATE INDEX IF NOT EXISTS idx_turn_truth_session ON turn_truth(session_id, id, user_id, world_id)"),
    ("idx_uploads_user", "CREATE INDEX IF NOT EXISTS idx_uploads_user ON uploads(user_id, id, session_id)"),
    ("idx_uploads_session", "CREATE INDEX IF NOT EXISTS idx_uploads_session ON uploads(session_id, id, user_id)"),
    ("idx_snapshots_user", "CREATE INDEX IF NOT EXISTS idx_snapshots_user ON snapshots(user_id, id, session_id)"),
    ("idx_snapshots_session", "CREATE INDEX IF NOT EXISTS idx_snapshots_session ON snapshots(session_id, id, user_id)"),
    ("idx_logs_user", "CREATE INDEX IF NOT EXISTS idx_logs_user ON logs(user_id, id)"),
    ("idx_documents_user", "CREATE INDEX IF NOT EXISTS idx_documents_user ON documents(user_id, id)"),
    ("idx_document_index_user", "CREATE INDEX IF NOT EXISTS idx_document_index_user ON document_index(user_id, document_id)"),
    ("idx_reviews_user", "CREATE INDEX IF NOT EXISTS idx_reviews_user ON reviews(user_id, id)"),
    ("idx_triggers_user", "CREATE INDEX IF NOT EXISTS idx_triggers_user ON triggers(user_id, id)"),
    ("idx_appointments_session", "CREATE INDEX IF NOT EXISTS idx_appointments_session ON appointments(session_id, id, user_id, world_id)"),
    ("idx_graph_edges_session", "CREATE INDEX IF NOT EXISTS idx_graph_edges_session ON graph_edges(session_id, id, user_id, world_id)"),
    ("idx_preferences_user", "CREATE INDEX IF NOT EXISTS idx_preferences_user ON preferences(user_id, id)"),
)


def ensure_query_indexes(conn: sqlite3.Connection) -> None:
    """Covering indexes for list/filter SELECTs."""
    for _name, sql in QUERY_INDEXES:
        conn.execute(sql)


def _child_read_view(name: str, table: str, extra: str = "", extra_json: str = "") -> tuple[str, str]:
    cols = "id, user_id, world_id, session_id"
    if extra:
        cols = f"{cols}, {extra}"
    ident = (
        "json_set(json, '$.id', id, '$.userId', user_id, '$.worldId', world_id, '$.sessionId', session_id"
        + extra_json
        + ")"
    )
    return name, f"CREATE VIEW {name} AS SELECT {cols}, {ident} AS json FROM {table}"


_EVIDENCE_JSON = "json_set(json, '$.id', id, '$.userId', user_id, '$.worldId', world_id, '$.sessionId', session_id)"

READ_VIEWS: tuple[tuple[str, str], ...] = (
    _child_read_view("v_scene_facts", "scene_facts"),
    _child_read_view("v_memories", "memories"),
    _child_read_view("v_god_facts", "god_facts"),
    _child_read_view("v_turns", "turns"),
    _child_read_view("v_turn_truth", "turn_truth"),
    _child_read_view("v_propositions", "propositions"),
    _child_read_view("v_goals", "goals"),
    _child_read_view("v_appointments", "appointments"),
    _child_read_view("v_relationships", "relationships", "from_id, to_id", ", '$.fromId', from_id, '$.toId', to_id"),
    _child_read_view("v_graph_edges", "graph_edges", "from_id, to_id", ", '$.fromId', from_id, '$.toId', to_id"),
    # B.19 (AMASTERv2 §39): WitnessKnowledge als eigene Tabelle mit
    # character_id, fact_id, access, source_turn_id, turn als
    # indizierbare SQL-Spalten für O(1)-Lookups ("Wer hat Fact X gehört?").
    _child_read_view(
        "v_witness_knowledge", "witness_knowledge",
        "character_id, fact_id, access, source_turn_id, turn",
        ", '$.characterId', character_id, '$.factId', fact_id, "
        "'$.sourceTurnId', source_turn_id",
    ),
    (
        "v_worlds",
        """
        CREATE VIEW v_worlds AS
        SELECT id, owner_user_id,
               json_set(json, '$.id', id, '$.ownerUserId', owner_user_id) AS json
        FROM worlds
        """,
    ),
    (
        "v_characters",
        """
        CREATE VIEW v_characters AS
        SELECT id, world_id, owner_user_id,
               json_set(json, '$.id', id, '$.worldId', world_id, '$.ownerUserId', owner_user_id) AS json
        FROM characters
        """,
    ),
    (
        "v_sessions",
        """
        CREATE VIEW v_sessions AS
        SELECT id, user_id, world_id,
               json_set(json, '$.id', id, '$.userId', user_id, '$.worldId', world_id) AS json
        FROM sessions
        """,
    ),
    (
        "v_session_evidence",
        f"""
        CREATE VIEW v_session_evidence AS
        SELECT id, user_id, world_id, session_id, 'scene_fact' AS layer, {_EVIDENCE_JSON} AS json FROM scene_facts
        UNION ALL
        SELECT id, user_id, world_id, session_id, 'turn' AS layer, {_EVIDENCE_JSON} AS json FROM turns
        UNION ALL
        SELECT id, user_id, world_id, session_id, 'god_fact' AS layer, {_EVIDENCE_JSON} AS json FROM god_facts
        UNION ALL
        SELECT id, user_id, world_id, session_id, 'turn_truth' AS layer, {_EVIDENCE_JSON} AS json FROM turn_truth
        """,
    ),
    (
        "v_world_roster",
        """
        CREATE VIEW v_world_roster AS
        SELECT c.id AS character_id, c.world_id, c.owner_user_id,
               json_set(c.json, '$.id', c.id, '$.worldId', c.world_id, '$.ownerUserId', c.owner_user_id) AS character_json,
               json_set(w.json, '$.id', w.id, '$.ownerUserId', w.owner_user_id) AS world_json
        FROM characters c
        LEFT JOIN worlds w ON w.id = c.world_id
        """,
    ),
    (
        "v_user_sessions",
        """
        CREATE VIEW v_user_sessions AS
        SELECT s.id AS session_id, s.user_id, s.world_id,
               json_set(s.json, '$.id', s.id, '$.userId', s.user_id, '$.worldId', s.world_id) AS session_json,
               json_set(w.json, '$.id', w.id, '$.ownerUserId', w.owner_user_id) AS world_json
        FROM sessions s
        LEFT JOIN worlds w ON w.id = s.world_id
        """,
    ),
)

VIEW_ALLOW = frozenset(name for name, _sql in READ_VIEWS)

CHILD_READ_VIEW = {
    "scene_facts": "v_scene_facts",
    "memories": "v_memories",
    "god_facts": "v_god_facts",
    "turns": "v_turns",
    "turn_truth": "v_turn_truth",
    "propositions": "v_propositions",
    "goals": "v_goals",
    "appointments": "v_appointments",
    "relationships": "v_relationships",
    "relations": "v_relationships",
    "graph_edges": "v_graph_edges",
    "witness_knowledge": "v_witness_knowledge",
}


def ensure_read_views(conn: sqlite3.Connection) -> None:
    """Read-only projections. Writes stay on tables. Skip existing under lock."""
    with _SCHEMA_LOCK:
        have = {
            str(r[0])
            for r in conn.execute("SELECT name FROM sqlite_master WHERE type='view'").fetchall()
        }
        for name, sql in READ_VIEWS:
            if name in have:
                continue
            try:
                conn.execute(sql)
            except sqlite3.OperationalError as exc:
                if "already exists" not in str(exc).lower():
                    raise




GASTHAUS_ID = "world_gasthaus_7kreis"
SCHEMA = Path(__file__).resolve().parent / "schema.sql"


def project_root() -> Path:
    return Path(__file__).resolve().parent.parent


def default_db_path() -> Path:
    env = os.environ.get("MATRIX_DB")
    if env:
        p = Path(env)
        if not p.is_absolute():
            p = project_root() / p
        return p
    return project_root() / "data" / "matrix10.sqlite"


def db_path() -> Path:
    return default_db_path()


def _open_conn(p: Path) -> sqlite3.Connection:
    conn = sqlite3.connect(str(p), timeout=30)
    conn.row_factory = sqlite3.Row
    conn.isolation_level = None
    _execute_busy(conn, "PRAGMA busy_timeout=30000")
    # V80 hard deletion: on-disk SQLite pages are wiped when rows are removed;
    # no extra schema or user database is created. WAL is checkpointed by routes.
    _execute_busy(conn, "PRAGMA secure_delete=ON")
    return conn


def connect(path: Path | str | None = None) -> sqlite3.Connection:
    p = Path(path) if path is not None else db_path()
    p.parent.mkdir(parents=True, exist_ok=True)
    key = str(p)
    if key in _WAL_READY:
        conn = _open_conn(p)
        conn.execute("PRAGMA journal_mode=WAL")
        conn.execute("PRAGMA foreign_keys=ON")
        return conn
    with _file_lock(key):
        conn = _open_conn(p)
        _execute_busy(conn, "PRAGMA journal_mode=WAL")
        conn.execute("PRAGMA foreign_keys=ON")
        _WAL_READY.add(key)
        return conn


def _master_object(conn: sqlite3.Connection, name: str) -> tuple[str | None, str | None]:
    row = conn.execute(
        "SELECT type, sql FROM sqlite_master WHERE name=? AND type IN ('table','view')",
        (name,),
    ).fetchone()
    if row is None:
        return None, None
    return str(row["type"]), str(row["sql"] or "")


def _table_columns(conn: sqlite3.Connection, name: str) -> list[str]:
    return [str(r[1]) for r in conn.execute(f"PRAGMA table_info({name})")]


def _parse_json(raw: Any) -> dict[str, Any]:
    if isinstance(raw, dict):
        return dict(raw)
    if raw is None or raw == "":
        return {}
    if isinstance(raw, (bytes, bytearray)):
        raw = raw.decode("utf-8", errors="replace")
    try:
        obj = json.loads(raw)
    except (TypeError, ValueError, json.JSONDecodeError):
        return {"_raw": str(raw)}
    return obj if isinstance(obj, dict) else {"_value": obj}


def _dumps(obj: Any) -> str:
    return json.dumps(obj, ensure_ascii=False, separators=(",", ":"), sort_keys=True)


def _pair_and_payload(row: sqlite3.Row | dict[str, Any], cols: list[str] | None = None) -> tuple[tuple[str, str, str], dict[str, Any], dict[str, Any]]:
    if isinstance(row, sqlite3.Row):
        data = {k: row[k] for k in row.keys()}
    else:
        data = dict(row)
    payload = _parse_json(data.get("json"))
    sid = str(data.get("session_id") or payload.get("sessionId") or payload.get("session_id") or "")
    fid = str(data.get("from_id") or payload.get("fromId") or payload.get("from_id") or "")
    tid = str(data.get("to_id") or payload.get("toId") or payload.get("to_id") or "")
    uid = data.get("user_id") if data.get("user_id") is not None else payload.get("userId") or payload.get("user_id")
    wid = data.get("world_id") if data.get("world_id") is not None else payload.get("worldId") or payload.get("world_id")
    rid = data.get("id") or payload.get("id")
    if sid and not payload.get("sessionId"):
        payload["sessionId"] = sid
    if fid and not payload.get("fromId"):
        payload["fromId"] = fid
    if tid and not payload.get("toId"):
        payload["toId"] = tid
    if uid and not payload.get("userId"):
        payload["userId"] = uid
    if wid and not payload.get("worldId"):
        payload["worldId"] = wid
    if rid and not payload.get("id"):
        payload["id"] = rid
    columns = {
        "id": str(rid) if rid else "",
        "user_id": None if uid is None else str(uid),
        "world_id": None if wid is None else str(wid),
        "session_id": sid or None,
        "from_id": fid or None,
        "to_id": tid or None,
        "json": data.get("json") if isinstance(data.get("json"), str) else _dumps(payload),
    }
    return (sid, fid, tid), payload, columns


def _payload_equivalent(a: dict[str, Any], b: dict[str, Any]) -> bool:
    def norm(d: dict[str, Any]) -> dict[str, Any]:
        out = dict(d)
        out.pop("id", None)
        return json.loads(_dumps(out))

    return norm(a) == norm(b)


def _ensure_relationships_table(conn: sqlite3.Connection) -> None:
    kind, _sql = _master_object(conn, "relationships")
    if kind == "table":
        return
    if kind == "view":
        raise sqlite3.DatabaseError("relationships must be a TABLE, found VIEW")
    conn.execute(
        """
        CREATE TABLE relationships (
          id TEXT PRIMARY KEY,
          user_id TEXT,
          world_id TEXT,
          session_id TEXT,
          from_id TEXT,
          to_id TEXT,
          json TEXT NOT NULL
        )
        """
    )


def _create_relations_view(conn: sqlite3.Connection) -> None:
    kind, sql = _master_object(conn, "relations")
    if kind == "view" and sql and "from relationships" in sql.lower():
        return
    if kind == "view":
        conn.execute("DROP VIEW relations")
    elif kind == "table":
        raise sqlite3.DatabaseError("cannot create relations VIEW while TABLE remains")
    conn.execute(RELATIONS_VIEW_SQL)


def _unique_rel_id(existing: set[str], preferred: str, pair: tuple[str, str, str]) -> str:
    rid = (preferred or "").strip()
    if rid and rid not in existing:
        return rid
    base = f"{pair[0]}:{pair[1]}:{pair[2]}" if any(pair) else (rid or "rel")
    if base not in existing:
        return base
    n = 2
    while f"{base}#{n}" in existing:
        n += 1
    return f"{base}#{n}"


def ensure_relations_owner(conn: sqlite3.Connection) -> dict[str, Any]:
    """Idempotent, transaction-safe cutover to relationships TABLE + relations VIEW.

    CASE A: no `relations` object → create VIEW over relationships.
    CASE B: `relations` is already the compatibility VIEW → validate, do not destroy.
    CASE C: `relations` is a legacy TABLE → copy into relationships, then replace with VIEW.

    Conflict identity is the directed session pair (session_id, from_id, to_id).
    AMASTER RelationshipState owner is `relationships` (current writer and reader).
    On conflict the owner row stays canonical; the legacy payload is kept in meta,
    not discarded.
    """
    started = False
    if not conn.in_transaction:
        conn.execute("BEGIN IMMEDIATE")
        started = True
    try:
        _ensure_relationships_table(conn)
        kind, sql = _master_object(conn, "relations")
        result: dict[str, Any] = {
            "ok": True,
            "case": "A",
            "copied": 0,
            "keptOwner": 0,
            "conflicts": [],
        }
        if kind is None:
            result["case"] = "A"
            _create_relations_view(conn)
        elif kind == "view":
            result["case"] = "B"
            _create_relations_view(conn)
        elif kind == "table":
            result["case"] = "C"
            copied, kept, conflicts = _migrate_relations_table(conn)
            result["copied"] = copied
            result["keptOwner"] = kept
            result["conflicts"] = conflicts
            conn.execute("DROP TABLE relations")
            _create_relations_view(conn)
            conn.execute(
                """
                CREATE TABLE IF NOT EXISTS meta (
                  key TEXT PRIMARY KEY,
                  value TEXT
                )
                """
            )
            conn.execute(
                "INSERT INTO meta(key, value) VALUES(?, ?) ON CONFLICT(key) DO UPDATE SET value=excluded.value",
                (RELATIONS_OWNER_META_KEY, _dumps(result)),
            )
        else:
            raise sqlite3.DatabaseError(f"unexpected relations object type {kind}")

        view_kind, view_sql = _master_object(conn, "relations")
        rel_kind, _ = _master_object(conn, "relationships")
        if rel_kind != "table":
            raise sqlite3.DatabaseError("relationships is not a TABLE after migration")
        if view_kind != "view" or "from relationships" not in (view_sql or "").lower():
            raise sqlite3.DatabaseError("relations is not a VIEW over relationships after migration")
        result["owner"] = "relationships"
        result["compat"] = "view"
        if started:
            conn.execute("COMMIT")
        return result
    except Exception:
        if started:
            conn.execute("ROLLBACK")
        raise


def _migrate_relations_table(conn: sqlite3.Connection) -> tuple[int, int, list[dict[str, Any]]]:
    cols = _table_columns(conn, "relations")
    select = ", ".join(cols) if cols else "*"
    legacy_rows = list(conn.execute(f"SELECT {select} FROM relations"))
    owner_rows = list(
        conn.execute(
            "SELECT id, user_id, world_id, session_id, from_id, to_id, json FROM relationships"
        )
    )
    by_pair: dict[tuple[str, str, str], sqlite3.Row] = {}
    existing_ids: set[str] = set()
    for r in owner_rows:
        pair, _payload, _cols = _pair_and_payload(r)
        by_pair[pair] = r
        if r["id"]:
            existing_ids.add(str(r["id"]))

    copied = 0
    kept = 0
    conflicts: list[dict[str, Any]] = []
    for raw in legacy_rows:
        pair, payload, columns = _pair_and_payload(raw, cols)
        owner = by_pair.get(pair)
        if owner is None:
            rid = _unique_rel_id(existing_ids, columns["id"], pair)
            payload["id"] = rid
            conn.execute(
                "INSERT INTO relationships(id, user_id, world_id, session_id, from_id, to_id, json) VALUES (?,?,?,?,?,?,?)",
                (
                    rid,
                    columns["user_id"],
                    columns["world_id"],
                    columns["session_id"],
                    columns["from_id"],
                    columns["to_id"],
                    _dumps(payload),
                ),
            )
            existing_ids.add(rid)
            by_pair[pair] = conn.execute(
                "SELECT id, user_id, world_id, session_id, from_id, to_id, json FROM relationships WHERE id=?",
                (rid,),
            ).fetchone()
            copied += 1
            continue
        owner_payload = _parse_json(owner["json"])
        if _payload_equivalent(owner_payload, payload):
            kept += 1
            continue
        kept += 1
        conflicts.append(
            {
                "pair": {"sessionId": pair[0], "fromId": pair[1], "toId": pair[2]},
                "ownerId": owner["id"],
                "ownerUserId": owner["user_id"],
                "ownerJson": owner_payload,
                "legacyId": columns["id"],
                "legacyUserId": columns["user_id"],
                "legacyJson": payload,
                "resolved": "relationships",
                "rule": "AMASTER RelationshipState owner is relationships; directed pair; live writer/reader already bound",
            }
        )
    return copied, kept, conflicts


def init_schema(conn: sqlite3.Connection) -> None:
    key = _db_file(conn)
    with _SCHEMA_LOCK:
        if key in _SCHEMA_READY:
            return
        # New databases must shrink after a session is deleted. Existing
        # databases are compacted only by the explicit, backed-up V75 import.
        has_tables = conn.execute(
            "SELECT 1 FROM sqlite_master WHERE type='table' LIMIT 1"
        ).fetchone() is not None
        if not has_tables:
            conn.execute("PRAGMA auto_vacuum=FULL")
        for stmt in SCHEMA_STATEMENTS:
            _execute_busy(conn, stmt)
        try:
            conn.execute("ALTER TABLE uploads ADD COLUMN session_id TEXT")
        except sqlite3.OperationalError:
            pass
        ensure_relations_owner(conn)
        ensure_consistency_triggers(conn)
        ensure_query_indexes(conn)
        ensure_read_views(conn)
        skip = os.environ.get("MATRIX_SKIP_SEED") == "1" or os.environ.get("PYTEST_CURRENT_TEST")
        testing = False
        try:
            from flask import current_app, has_app_context

            testing = bool(has_app_context() and current_app.config.get("TESTING"))
        except Exception:
            testing = False
        # V81: demo world/characters only on truly new DB; NEVER restore deleted rows.
        if not has_tables and not skip and not testing:
            from matrix_api.seed_builtin import seed_if_missing

            seed_if_missing(conn)
        conn.commit()
        _SCHEMA_READY.add(key)


def init_db(conn_or_path: sqlite3.Connection | Path | str | None = None):
    """Alias: init_db(conn) like RECOVERY_B1, or init_db(path) creating a file."""
    if isinstance(conn_or_path, sqlite3.Connection):
        init_schema(conn_or_path)
        return conn_or_path
    p = Path(conn_or_path) if conn_or_path is not None else db_path()
    conn = connect(p)
    try:
        init_schema(conn)
    finally:
        if conn_or_path is None or isinstance(conn_or_path, (Path, str)):
            # path-form historically closed the connection and returned the path
            if not isinstance(conn_or_path, sqlite3.Connection):
                conn.close()
                return p
    return p


@contextmanager
def transaction(conn: sqlite3.Connection):
    conn.execute("BEGIN IMMEDIATE")
    try:
        yield conn
        conn.execute("COMMIT")
    except Exception:
        conn.execute("ROLLBACK")
        raise
