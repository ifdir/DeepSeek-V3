"""Eine gebundene AMASTER-Gesamtschleife in einem Writer-Kontext."""
from __future__ import annotations

from typing import Any, Callable

from matrix_api.amaster_ext import create_appointment, create_graph_edge, recall_patterns
from matrix_api.db import GASTHAUS_ID
from matrix_api import kernel
from matrix_api.pipeline import ingest_upload
from matrix_api.repos import (
    IsolationError,
    WriterError,
    create_character,
    create_session,
    create_session_memory,
    create_upload,
    create_world,
    get_session,
    resolve_review,
    save_session,
    upsert_user,
)

_IDEMPOTENT = {"USE_PATCH", "ID_CONFLICT", "SCENEFACT_IMMUTABLE", "TURN_IMMUTABLE", "GODFACT_IMMUTABLE"}


def _is_idempotent(exc: BaseException) -> bool:
    if isinstance(exc, IsolationError):
        return False
    if not isinstance(exc, WriterError):
        return False
    if exc.error in _IDEMPOTENT:
        return True
    msg = (exc.message or str(exc)).lower()
    return "exists" in msg or "use patch" in msg or "use put" in msg


def _try_step(
    failed: list[dict[str, Any]],
    warnings: list[dict[str, Any]],
    name: str,
    fn: Callable[[], Any],
) -> Any:
    try:
        return fn()
    except IsolationError as exc:
        failed.append({"step": name, "error": str(exc), "code": "ISOLATION"})
        return None
    except WriterError as exc:
        item = {"step": name, "error": exc.message, "code": exc.error}
        if _is_idempotent(exc):
            warnings.append(item)
        else:
            failed.append(item)
        return None
    except KeyError as exc:
        failed.append({"step": name, "error": str(exc), "code": "NOT_FOUND"})
        return None


def run_bound_system(conn, actor: str = "admin") -> dict[str, Any]:
    failed: list[dict[str, Any]] = []
    warnings: list[dict[str, Any]] = []
    upsert_user(conn, {"id": actor, "name": actor})
    _try_step(
        failed,
        warnings,
        "create_world",
        lambda: create_world(
            conn,
            {
                "world": {
                    "id": GASTHAUS_ID,
                    "name": "Gasthaus",
                    "ownerUserId": actor,
                    "places": [{"id": "p1", "name": "Schank"}],
                    "characterIds": [],
                    "long": "",
                    "genre": "",
                }
            },
            actor,
        ),
    )
    _try_step(
        failed,
        warnings,
        "create_character",
        lambda: create_character(conn, {"id": "ch_sys", "name": "Clara", "worldId": GASTHAUS_ID}, actor),
    )
    _try_step(
        failed,
        warnings,
        "create_avatar",
        lambda: create_character(
            conn,
            {"id": "av_sys", "name": "Gast", "worldId": GASTHAUS_ID, "isWorldNative": False},
            actor,
        ),
    )
    session_body = {
        "id": "ses_sys",
        "userId": actor,
        "worldId": GASTHAUS_ID,
        "name": "System",
        "turnIndex": 0,
        "scene": {"placeId": "p1", "placeName": "Schank", "presentIds": ["ch_sys"], "notes": "", "time": "jetzt"},
        "runtimes": {"ch_sys": {"emotion": "wach", "intent": "sprechen", "mobility": 1, "canSpeak": True}},
        "turns": [],
        "facts": [],
        "memories": [],
        "relations": [],
        "godFacts": [],
        "propositions": [],
        "goals": [],
        "avatarId": "av_sys",
    }
    _try_step(failed, warnings, "create_session", lambda: create_session(conn, session_body, actor))

    apt_out = _try_step(
        failed,
        warnings,
        "create_appointment",
        lambda: create_appointment(
            conn, {"sessionId": "ses_sys", "title": "Abend", "when": "heute", "worldId": GASTHAUS_ID}, actor
        ),
    )
    edge_out = _try_step(
        failed,
        warnings,
        "create_graph_edge",
        lambda: create_graph_edge(
            conn,
            {"sessionId": "ses_sys", "fromId": "av_sys", "toId": "ch_sys", "kind": "spricht", "worldId": GASTHAUS_ID},
            actor,
        ),
    )
    mem_out = _try_step(
        failed,
        warnings,
        "create_session_memory",
        lambda: create_session_memory(
            conn,
            "ses_sys",
            {"id": "mem_sys", "text": "Clara im Keller des Gasthauses mit einem Brief.", "kind": "event"},
            actor,
        ),
    )
    rec = _try_step(
        failed,
        warnings,
        "recall_patterns",
        lambda: recall_patterns(conn, "ses_sys", actor, "Clara Keller Brief"),
    ) or {}
    _try_step(
        failed,
        warnings,
        "create_upload",
        lambda: create_upload(
            conn,
            {
                "id": "up_sys",
                "name": "quelle.txt",
                "mime": "text/plain",
                "mode": "A",
                "targetKind": "world",
                "targetId": GASTHAUS_ID,
                "worldId": GASTHAUS_ID,
                "characterId": "ch_sys",
                "text": "Im Gasthaus spielt ein Noir-Drama. Clara wartet.",
                "status": "ready",
            },
            actor,
        ),
    )
    ing = _try_step(failed, warnings, "ingest_upload", lambda: ingest_upload(conn, "up_sys", actor))
    if not isinstance(ing, dict):
        ing = {"reviewIds": []}
    for rid in ing.get("reviewIds") or []:
        _try_step(
            failed,
            warnings,
            f"resolve_review:{rid}",
            lambda rid=rid: resolve_review(conn, rid, {"status": "accepted"}, actor),
        )

    loaded = _try_step(failed, warnings, "get_session", lambda: get_session(conn, actor, "ses_sys"))
    sess = loaded if isinstance(loaded, dict) else None
    if sess is None:
        failed.append({"step": "session_missing", "error": "ses_sys not readable", "code": "NOT_FOUND"})
        return {
            "ok": False,
            "bound": True,
            "failed": failed,
            "warnings": warnings,
            "appointment": (apt_out or {}).get("appointment") if isinstance(apt_out, dict) else None,
            "graph": (edge_out or {}).get("edge") if isinstance(edge_out, dict) else None,
            "memory": bool(mem_out),
            "recallHits": len((rec or {}).get("hits") or []),
            "ingestReviews": len(ing.get("reviewIds") or []),
            "kernelFacts": 0,
            "reloadTurnIndex": None,
        }
    truth = kernel.normalize_truth(
        {
            "id": "t_sys",
            "userId": actor,
            "worldId": GASTHAUS_ID,
            "sessionId": "ses_sys",
            "role": "teilnehmer",
            "speakerId": "ch_sys",
            "avatarId": "av_sys",
            "targetId": "ch_sys",
            "authority": "avatar",
            "presentIds": ["ch_sys"],
            "inputKind": "speech",
            "text": "Wer wartet im Keller?",
        }
    )
    out = kernel.commit_turn(
        sess,
        truth=truth,
        speaker={"id": "ch_sys", "name": "Clara"},
        present=[{"id": "ch_sys", "name": "Clara"}],
        result={"speech": "Ich warte.", "action": None},
    )
    saved = _try_step(failed, warnings, "save_session", lambda: save_session(conn, actor, out))
    reloaded = _try_step(failed, warnings, "reload_session", lambda: get_session(conn, actor, "ses_sys"))
    reload_obj = reloaded if isinstance(reloaded, dict) else saved
    facts = (reload_obj or {}).get("facts") or (saved or {}).get("facts") or []
    ok = len(failed) == 0
    return {
        "ok": ok,
        "bound": True,
        "failed": failed,
        "warnings": warnings,
        "appointment": (apt_out or {}).get("appointment") if isinstance(apt_out, dict) else None,
        "graph": (edge_out or {}).get("edge") if isinstance(edge_out, dict) else None,
        "memory": bool(mem_out) or any(w.get("step") == "create_session_memory" for w in warnings),
        "recallHits": len((rec or {}).get("hits") or []),
        "ingestReviews": len(ing.get("reviewIds") or []),
        "kernelFacts": len(facts),
        "reloadTurnIndex": (reload_obj or {}).get("turnIndex") or (saved or {}).get("turnIndex"),
    }
