"""V39 Konjunktives Gedächtnis (AMASTERv2 §36/§37/§40; Vorbild: MATRIX10 CL1B43v76
services/conjunctive_memory.py — Konzept übernommen, nicht der Code).

Jede Äußerung (Avatar, Bedienperson, Puppet, Figur) bekommt einen validierten
TURN-PLAN: Ereignisart, Sprechakt, Dauerhaftigkeit, Beteiligte, Subjekt/Prädikat/
Objekt, kanonischer Wert, ZEITRAHMEN, Bezug auf frühere Frames. Der Plan kommt
vom konfigurierten LLM (semantisch) oder — ohne Provider — aus einer lokalen
Minimallesung (Sprechakt + deutsche Zeitangaben). Der Kernel validiert, hängt den
Plan an den Rede-Fact und verdichtet dauerhafte Inhalte zu FRAMES mit Status
(vorgeschlagen → angenommen/abgelehnt → erfüllt/widerrufen; Fakten: aktuell →
überholt). Frames sind zeugengebunden und werden im Persona-Brief gerendert
("VEREINBART / GILT ZWISCHEN EUCH"). Der Plan erzeugt keine Weltwahrheit; er
ordnet, was gesagt wurde.
"""
from __future__ import annotations

import re
from datetime import datetime, timedelta
from typing import Any

from .ids import uid

EVENT_KINDS = {
    "claim", "proposal", "acceptance", "request", "disclosure", "state_change",
    "revocation", "refusal", "action", "report", "question", "promise", "smalltalk",
}
SPEECH_ACTS = {"assert", "propose", "accept", "request", "disclose", "refuse", "revoke", "report", "act", "ask", "promise", "chat"}
DURABILITY = {"utterance", "durable_state", "commitment", "knowledge_transition", "action_event"}
PRECISION = {"day", "time", "interval", "relative", "unknown"}
FRAME_OPEN = {"proposed", "accepted", "committed", "requested", "current", "conflict"}

_WEEKDAYS = ["montag", "dienstag", "mittwoch", "donnerstag", "freitag", "samstag", "sonntag"]
_WEEKDAY_RE = re.compile(r"\b(montag|dienstag|mittwoch|donnerstag|freitag|samstag|sonntag)s?\b", re.I)
_REL_RE = re.compile(r"\b(heute|heute abend|heute nacht|morgen|übermorgen|uebermorgen|nächste woche|naechste woche|nächsten|naechsten|am wochenende|gleich|später|spaeter|in (\d+) (minuten|stunden|tagen|wochen))\b", re.I)
_TIME_RE = re.compile(r"\b(?:um\s+)?(\d{1,2})(?::(\d{2}))?\s*uhr(?:\s*(\d{2}))?\b|\b(\d{1,2}):(\d{2})\b", re.I)
_DATE_RE = re.compile(r"\b(\d{1,2})\.(\d{1,2})\.(?:(\d{2,4}))?(?!\d)")
_TIME_WORDS = re.compile(r"\b(mittag|mittags|abend|abends|morgens|früh|frueh|nachmittag|nachmittags|nacht|mitternacht)\b", re.I)
_PROPOSE_RE = re.compile(r"\b(treffen wir uns|lass uns|wollen wir|sollen wir|wie wäre es|wie waere es|schlage vor|ich lade dich|komm(?:st)? (?:du )?(?:mit|vorbei)|sehen wir uns|verabred|termin|hol(?:e)? dich ab|essen gehen|wir könnten|wir koennten)\b", re.I)
_PROMISE_RE = re.compile(r"\b(ich verspreche|versprochen|ich werde .{0,40}\b(kommen|da sein|helfen|bringen|holen|anrufen)|ich bin (?:dann )?da|ich komme|ich bringe|ich hole|abgemacht|einverstanden, ich)\b", re.I)
_ACCEPT_RE = re.compile(r"^\s*(ja|okay|ok|gut|gerne|klar|einverstanden|abgemacht|passt|in ordnung|natürlich|natuerlich|sicher|gern)\b", re.I)
_REFUSE_RE = re.compile(r"^\s*(nein|nö|noe|keine chance|auf keinen fall|lieber nicht|nicht|geht nicht|kann nicht)\b|\b(lehne ab|will nicht|kann nicht kommen|passt (?:mir )?nicht)\b", re.I)
_REVOKE_RE = re.compile(r"\b(absagen|sage ab|ich sage .{0,20}ab|vergiss (?:es|das)|doch nicht|geht nicht mehr|muss (?:leider )?absagen|nicht mehr)\b", re.I)
_DISCLOSE_RE = re.compile(r"\b(ich habe .{0,40}(?:geburtstag|hochzeitstag|jahrestag)|mein geburtstag|ich (?:bin|war) (?:[^.,!?]{0,40}?)(?:verheiratet|geschieden|verlobt|schwanger|krank|allein|arbeitslos|\d+(?: jahre)?(?: alt)?)|ich heiße|ich heisse|ich wohne|ich arbeite|ich komme aus|mein (?:vater|mutter|bruder|schwester|mann|frau|sohn|tochter) (?:ist|war|hat|heißt|heisst))\b", re.I)
_QUESTION_RE = re.compile(r"\?\s*$|^\s*(wann|wo|wer|wie|was|warum|wieso|weshalb|welche[rs]?)\b", re.I)


def _clean(v: Any, n: int = 240) -> str:
    return str(v or "").strip()[:n]


def _norm(s: str) -> str:
    return re.sub(r"\s+", " ", str(s or "").lower()).strip()


def parse_temporal(text: str, now: datetime | None = None) -> dict[str, Any]:
    """Deutsche Zeitangaben → {label, precision, start, end, weekday, time}. Ohne
    Bezugsdatum bleibt es ein Label mit Präzision (der Brief zeigt das Label)."""
    t = str(text or "")
    out: dict[str, Any] = {"label": "", "precision": "unknown", "start": None, "end": None, "weekday": None, "time": None}
    parts: list[str] = []
    wd = _WEEKDAY_RE.search(t)
    if wd:
        out["weekday"] = wd.group(1).lower()
        parts.append(wd.group(0))
        out["precision"] = "day"
    rel = _REL_RE.search(t)
    if rel:
        parts.append(rel.group(0))
        out["precision"] = "relative" if out["precision"] == "unknown" else out["precision"]
    dm = _DATE_RE.search(t)
    if dm:
        parts.append(dm.group(0))
        out["precision"] = "day"
    tm = _TIME_RE.search(t)
    if tm:
        hh = tm.group(1) or tm.group(4)
        mm = tm.group(2) or tm.group(3) or tm.group(5) or "00"
        try:
            h = int(hh)
            m = int(mm)
            if 0 <= h <= 23 and 0 <= m <= 59:
                out["time"] = f"{h:02d}:{m:02d}"
                parts.append(f"{h}:{m:02d} Uhr" if m else f"{h} Uhr")
                out["precision"] = "time"
        except (TypeError, ValueError):
            pass
    tw = _TIME_WORDS.search(t)
    if tw and not out["time"]:
        parts.append(tw.group(0))
        if out["precision"] == "unknown":
            out["precision"] = "relative"
    if not parts:
        return out
    out["label"] = " ".join(dict.fromkeys(p.strip() for p in parts))
    # Bezugsdatum: Start berechnen, wenn möglich
    if now is not None:
        base = now
        if rel:
            r = rel.group(0).lower()
            if "übermorgen" in r or "uebermorgen" in r:
                base = now + timedelta(days=2)
            elif "morgen" in r and "heute" not in r:
                base = now + timedelta(days=1)
            elif "nächste woche" in r or "naechste woche" in r:
                base = now + timedelta(days=7)
            elif rel.group(2) and rel.group(3):
                n = int(rel.group(2))
                unit = rel.group(3).lower()
                base = now + timedelta(**{"minuten": {"minutes": n}, "stunden": {"hours": n}, "tagen": {"days": n}, "wochen": {"weeks": n}}[unit])
        if out["weekday"]:
            target = _WEEKDAYS.index(out["weekday"])
            delta = (target - base.weekday()) % 7
            if delta == 0 and not rel:
                delta = 7 if base.hour >= 20 else 0
            base = base + timedelta(days=delta)
        if dm:
            try:
                y = int(dm.group(3)) if dm.group(3) else base.year
                if y < 100:
                    y += 2000
                base = base.replace(year=y, month=int(dm.group(2)), day=int(dm.group(1)))
            except ValueError:
                pass
        if out["time"]:
            h, m = (int(x) for x in out["time"].split(":"))
            base = base.replace(hour=h, minute=m, second=0, microsecond=0)
            out["start"] = base.isoformat(timespec="minutes")
            out["end"] = (base + timedelta(hours=2)).isoformat(timespec="minutes")
        elif out["weekday"] or dm or rel:
            out["start"] = base.replace(hour=0, minute=0, second=0, microsecond=0).isoformat(timespec="minutes")
            out["end"] = base.replace(hour=23, minute=59, second=0, microsecond=0).isoformat(timespec="minutes")
    return out


def _ground_time_fields(fields: dict[str, Any], literal: str) -> tuple[dict[str, Any], list[str]]:
    """V62 (§24.2 Validierung, wie die Namens-Verankerung in normalize_plan):
    a structured time value is used only when the literal utterance carries
    it — the named weekday, the relative word, the day number of a date, the
    hour of a time. Values the model computed itself are dropped (live 27.10.:
    "diesen Samstag" came with datum 2026-10-29)."""
    low = _norm(literal).replace("ü", "ue")
    nums = {int(x) for x in re.findall(r"\d{1,4}", low)}
    out, dropped = dict(fields), []
    wd = _clean(out.get("wochentag"), 12).lower()
    if wd and not re.search(rf"\b{re.escape(wd)}", low):
        out["wochentag"] = None
        dropped.append("wochentag")
    rel = _clean(out.get("relativ"), 12).lower().replace("ü", "ue")
    if rel and rel != "in_tagen" and not re.search(rf"(?<![a-z]){re.escape(rel)}(?![a-z])", low):
        out["relativ"] = None
        dropped.append("relativ")
    if rel == "in_tagen":
        try:
            if int(out.get("in_tagen")) not in nums:
                out["relativ"] = None
                dropped.append("in_tagen")
        except (TypeError, ValueError):
            out["relativ"] = None
    if out.get("datum"):
        try:
            if datetime.fromisoformat(str(out["datum"])[:10]).day not in nums:
                out["datum"] = None
                dropped.append("datum")
        except ValueError:
            out["datum"] = None
    m = re.match(r"^\s*(\d{1,2})", str(out.get("uhrzeit") or ""))
    if out.get("uhrzeit") and (not m or int(m.group(1)) not in nums):
        out["uhrzeit"] = None
        dropped.append("uhrzeit")
    return out, dropped


def temporal_from_fields(label: str, fields: dict[str, Any], now: datetime | None) -> dict[str, Any]:
    """V62 (AMASTER §37): the planner's STRUCTURED time reading -> window. The
    kernel does the date arithmetic from the bound session date; the text
    reading (parse_temporal) is only the fallback when the planner gives no
    structured value. Contradictory values stay unresolved (§37 "widersprüchliche
    Zeitangaben bleiben ungeklärt"); without a session date only the label."""
    out: dict[str, Any] = {"label": _clean(label, 120), "precision": "unknown", "start": None, "end": None,
                           "weekday": None, "time": None}
    wd = _clean(fields.get("wochentag"), 12).lower() or None
    if wd and wd not in _WEEKDAYS:
        wd = None
    # A day offset only from what the utterance NAMES (closed inventory). A
    # count without the literal "in n Tagen" is the model's own arithmetic and
    # is not used (live 27.10.: "diesen Samstag" came with in_tagen 3 on a
    # Tuesday and made every Saturday window unresolved).
    rel = _clean(fields.get("relativ"), 12).lower().replace("ue", "ü") or None
    n = {"heute": 0, "morgen": 1, "übermorgen": 2, "gestern": -1, "vorgestern": -2}.get(rel or "")
    if rel == "in_tagen":
        try:
            n = int(fields.get("in_tagen"))
            if abs(n) > 400:
                n = None
        except (TypeError, ValueError):
            n = None
    d = None
    if fields.get("datum"):
        try:
            d = datetime.fromisoformat(str(fields.get("datum"))[:10]).date()
        except ValueError:
            d = None
    tm = None
    m = re.match(r"^\s*(\d{1,2}):(\d{2})", str(fields.get("uhrzeit") or ""))
    if m and 0 <= int(m.group(1)) <= 23 and 0 <= int(m.group(2)) <= 59:
        tm = f"{int(m.group(1)):02d}:{int(m.group(2)):02d}"
    out["weekday"], out["time"] = wd, tm
    if not out["label"]:
        out["label"] = " ".join(x for x in ((wd or "").capitalize(), d.strftime("%d.%m.") if d else "", f"{tm} Uhr" if tm else "") if x)
    if wd or d or n is not None:
        out["precision"] = "day"
    if tm:
        out["precision"] = "time"
    if now is None:
        return out
    today = now.date()
    candidates = []
    if d is not None:
        candidates.append(d)
    if n is not None:
        candidates.append(today + timedelta(days=n))
    if wd and not candidates:
        candidates.append(today + timedelta(days=(_WEEKDAYS.index(wd) - today.weekday()) % 7))
    day = candidates[0] if candidates else None
    conflict = (len(set(candidates)) > 1) or (wd is not None and day is not None and _WEEKDAYS[day.weekday()] != wd)
    if conflict:
        out["precision"] = "relative"
        out["ambiguous"] = True
        out["conflict"] = "zeitangaben_widersprechen_sich"
        return out
    if day is None:
        return out
    if wd is None:
        out["weekday"] = _WEEKDAYS[day.weekday()]
    base = datetime(day.year, day.month, day.day)
    if tm:
        h, mi = (int(x) for x in tm.split(":"))
        start = base.replace(hour=h, minute=mi)
        out["start"] = start.isoformat(timespec="minutes")
        out["end"] = (start + timedelta(hours=2)).isoformat(timespec="minutes")
    else:
        out["start"] = base.isoformat(timespec="minutes")
        out["end"] = base.replace(hour=23, minute=59).isoformat(timespec="minutes")
    return out


def literal_plan(text: str, *, actor_id: str, recipient_id: str | None) -> dict:
    """Observed speech with unresolved semantics, not a fabricated claim/deal."""
    return {"event_kind": "report", "speech_act": "report", "durability": "utterance",
            "actor_id": actor_id, "recipient_id": recipient_id or "", "subject": "",
            "predicate": "", "object": "", "canonical_value": str(text),
            "summary": str(text), "temporal": {}, "refers_to": "", "cue_terms": [],
            "source": "unresolved", "validation_status": "source_only"}


def local_plan(text: str, *, actor_id: str, recipient_id: str | None, now: datetime | None = None) -> dict[str, Any]:
    """Minimale lokale Lesung ohne LLM: Sprechakt + Zeitrahmen. Ehrlich markiert (source=local)."""
    t = str(text or "").strip()
    low = t.lower()
    temporal = parse_temporal(t, now)
    kind, act, durability = "claim", "assert", "utterance"
    if _REVOKE_RE.search(low):
        kind, act, durability = "revocation", "revoke", "commitment"
    elif _PROMISE_RE.search(low):
        kind, act, durability = "promise", "promise", "commitment"
    elif _PROPOSE_RE.search(low) or (temporal["label"] and _QUESTION_RE.search(t) and re.search(r"\b(treffen|kommen|sehen|essen|gehen|vorbei|abholen|zusammen)\b", low)):
        kind, act, durability = "proposal", "propose", "commitment"
    elif _REFUSE_RE.search(low):
        kind, act, durability = "refusal", "refuse", "utterance"
    elif _ACCEPT_RE.search(low):
        kind, act, durability = "acceptance", "accept", "commitment"
    elif _DISCLOSE_RE.search(low):
        kind, act, durability = "disclosure", "disclose", "knowledge_transition"
    elif _QUESTION_RE.search(t):
        kind, act, durability = "question", "ask", "utterance"
    if kind == "claim" and temporal["label"] and re.search(r"\b(ist|sind|wird|findet .{0,20} statt|beginnt|endet|hat|habe)\b", low):
        durability = "durable_state"
    return {
        "event_kind": kind,
        "speech_act": act,
        "durability": durability,
        "actor_id": actor_id,
        "recipient_id": recipient_id or "",
        "subject": "",
        "predicate": "",
        "object": "",
        "canonical_value": t[:160],
        "summary": t[:160],
        "temporal": temporal,
        "refers_to": "",
        "cue_terms": [w for w in re.findall(r"[a-zäöüß]{4,}", low)][:8],
        "source": "local",
        "validation_status": "validated",
    }


def normalize_plan(raw: Any, *, actor_id: str, recipient_id: str | None, text: str, now: datetime | None = None, present_ids: list[str] | None = None, figures: list[dict] | None = None) -> dict[str, Any] | None:
    """LLM-Plan validieren: nur erlaubte Werte, Beteiligte aus der Szene, Zeitrahmen
    normalisiert (LLM-Text + lokale Zeitlesung), kein Plan ohne Ereignisart."""
    if not isinstance(raw, dict):
        return None
    if raw.get("source") == "unresolved":
        return literal_plan(text, actor_id=actor_id, recipient_id=recipient_id)
    kind = _clean(raw.get("event_kind") or raw.get("ereignis"), 40).lower()
    act = _clean(raw.get("speech_act") or raw.get("sprechakt"), 40).lower()
    dur = _clean(raw.get("durability") or raw.get("dauer"), 40).lower() or "utterance"
    if kind not in EVENT_KINDS:
        return None
    if act not in SPEECH_ACTS:
        act = {"proposal": "propose", "acceptance": "accept", "request": "request", "disclosure": "disclose", "refusal": "refuse", "revocation": "revoke", "report": "report", "action": "act", "question": "ask", "promise": "promise", "smalltalk": "chat"}.get(kind, "assert")
    if dur not in DURABILITY:
        dur = "commitment" if kind in ("proposal", "promise", "acceptance") else ("knowledge_transition" if kind == "disclosure" else "utterance")
    allowed = set(present_ids or []) | {actor_id, recipient_id or ""}
    rid = _clean(raw.get("recipient_id") or raw.get("empfaenger_id"), 80)
    # The model can propose an addressee; it cannot replace the binding
    # already decided by TurnTruth and the speech component.
    if recipient_id is not None:
        rid = str(recipient_id)
    elif rid and rid not in allowed:
        rid = ""
    # Validate source grounding BEFORE plan→claim/frame. A named third person
    # in the provider's machine proposition must occur in the original utterance
    # or be a canonical participant. This does not rewrite LLM answer text.
    machine_text = " ".join(str(raw.get(k) or "") for k in
        ("subject", "subjekt", "predicate", "praedikat", "object", "objekt", "canonical_value", "wert", "summary", "zusammenfassung"))
    # V65T (§24.1/§24.7, Plan v2 Schritt 2c): a third person the KERNEL bound for this utterance (by name, or a pronoun
    # with exactly one candidate and provenance: betrifft_ids) may be named by the reading; any other stays rejected.
    _bound_refs = {str(x) for x in (raw.get("betrifft_ids") or []) if isinstance(x, str)}
    for fig in (figures or []):
        if not isinstance(fig, dict) or str(fig.get("id") or "") in (str(actor_id), str(rid)) or str(fig.get("id") or "") in _bound_refs:
            continue
        forms = []
        for label in [fig.get("name"), *(fig.get("aliases") or [])]:
            name = str(label or "").strip()
            if len(name) > 1:
                forms.extend((name, name.split()[0]))
        if any(re.search(rf"(?<!\w){re.escape(form)}(?!\w)", machine_text, re.I) and
               not re.search(rf"(?<!\w){re.escape(form)}(?!\w)", str(text), re.I)
               for form in dict.fromkeys(forms)):
            return None
    t_raw = raw.get("temporal") if isinstance(raw.get("temporal"), dict) else {}
    t_text = _clean(t_raw.get("text") or t_raw.get("label") or raw.get("zeit") or "", 120)
    _fields = {k: t_raw.get(k) for k in ("wochentag", "relativ", "in_tagen", "datum", "uhrzeit")}
    if any(v not in (None, "", "null") for v in _fields.values()):
        _fields, _dropped = _ground_time_fields(_fields, f"{t_text} {text}")
        temporal = temporal_from_fields(t_text, _fields, now)
        temporal["reading"] = "structured"
        if _dropped:
            temporal["ungrounded"] = _dropped
    else:
        temporal = parse_temporal(t_text or text, now)
        temporal["reading"] = "text"
    if t_text and not temporal["label"]:
        temporal["label"] = t_text
        temporal["precision"] = _clean(t_raw.get("precision"), 12).lower() if _clean(t_raw.get("precision"), 12).lower() in PRECISION else "relative"
    # V62: provenance of the time reading. "planner" = the semantic planner named
    # a time; "local" = only the offline text reading found one. Readers that
    # decide meaning (foreground arbitration) use the planner reading.
    _structured = temporal.get("reading") == "structured" and any(
        temporal.get(k) for k in ("weekday", "time", "start")) if isinstance(temporal, dict) else False
    temporal["source"] = "planner" if (t_text or _structured) else ("local" if temporal.get("label") else "")
    plan = {
        "event_kind": kind,
        "speech_act": act,
        "durability": dur,
        "actor_id": actor_id,
        "recipient_id": rid or (recipient_id or ""),
        "subject": _clean(raw.get("subject") or raw.get("subjekt"), 80),
        "predicate": _clean(raw.get("predicate") or raw.get("praedikat"), 80).lower(),
        "object": _clean(raw.get("object") or raw.get("objekt"), 120),
        "canonical_value": _clean(raw.get("canonical_value") or raw.get("wert") or raw.get("summary") or raw.get("zusammenfassung") or text, 200),
        "summary": _clean(raw.get("summary") or raw.get("zusammenfassung") or text, 200),
        "temporal": temporal,
        "refers_to": _clean(raw.get("refers_to") or raw.get("bezug"), 120),
        "cue_terms": [_clean(x, 40).lower() for x in (raw.get("cue_terms") or raw.get("stichworte") or []) if _clean(x, 40)][:12],
        # V65S (AMASTER §24.1/§25): the cast figures this input names, bound by kernel.bind_referents (IDs).
        "about_ids": [str(x) for x in (raw.get("betrifft_ids") or []) if isinstance(x, str) and x.strip()][:4],
        "source": "llm",
        "validation_status": "validated",
    }
    if isinstance(raw.get("verweis_bindung"), dict):
        plan["referent_provenance"] = {k: raw["verweis_bindung"].get(k) for k in ("pronomen", "genus", "kandidaten", "gebunden", "belegTurns", "grund")}
    _g = validate_grenze(raw.get("grenze"), text=text, now=now, kind=kind)
    if _g is not None:
        plan["grenze"] = _g
    return plan


GRENZE_SCOPES = ("diese_tat", "jede_beruehrung")

# V65U (AMASTER §37 Zeit, §24.2 Z. 1110 "regel- oder lexikonbasierte Kandidatenerkennung", §24.6 Z. 1226-1242
# Systemwortschatz = Kandidat ohne Wahrheitshoheit, §46.4 Z. 2583 Persistence Scope nur bei eindeutigem Scope;
# Codegutachten v1 N1): the time reader's own reading of an OPEN validity (from now on, without end) - the
# temporal operators of the system language, the same layer as _REL_RE. A candidate only: it never sets a scope by
# itself; validate_grenze needs it AND the semantic reading's scope.
_GELTUNG_RE = re.compile(
    r"(?<![a-zäöüß])(ab jetzt|ab sofort|ab heute|von jetzt an|von nun an|nie wieder|nie mehr|niemals|nimmer|nicht mehr|"
    r"nie|für immer|fuer immer|immer|jederzeit|kein(?:e|en)? (?:einziges )?mal mehr)(?![a-zäöüß])", re.I)


def parse_geltung(text: str) -> dict[str, Any] | None:
    """V65U (§37): the open validity a quote names - {label} or None. Read only, no model."""
    m = _GELTUNG_RE.search(str(text or ""))
    return {"label": m.group(1), "offen": True} if m else None


def validate_grenze(raw: Any, *, text: str, now: datetime | None, kind: str | None = None) -> dict[str, Any] | None:
    """V65T (AMASTER §34.1 Komponente "ausdruecklich gesetzte Grenze", §36.5 Z. 1947-1975 Einwilligung an Handlung,
    Scope und Zeitfenster gebunden, §24.2/§24.7 LLM schlaegt vor, Kernel validiert, §37 Zeit): the proposed boundary
    of this one utterance. Kept only with a literal quote (beleg) from the utterance. The person (wer) stays a name
    here; the kernel binds it to a cast ID. Invalid -> {"status": "ungueltig", grund} (audit, binds nothing). None = no
    boundary proposed.
    V65V (Nachpruefung v1 K1/K4; §36.5 binds Handlung, Scope und Zeit getrennt; §24.2 Z. 1110-1113; §46.3 Z. 2565 kein
    globalisierter Scope; §46.5 Z. 2589 sichere Default = aktueller Scope). V65W (Tiefenpruefung v1 §2 "Fehlzitat"): §46.5 regelt
    den Session-God; der Szenen-Default ist eine Ableitung aus §36.5 Z. 1956 (Gueltigkeitsfenster), Z. 1974 (fruehere Zustimmung
    ist nicht automatisch aktuelle), §20 Z. 914 (Szene = kausaler Raum) und §24.7 (keine geratene Wahrheit), keine direkte
    Vorgabe. Two separate axes:
      ACTION scope - "jede_beruehrung" needs two semantic keys: the proposing reading AND the separate scope reading
        (raw["pruefung"], GRENZE_CHECK_RULES, set server-side) saying every touch, without restriction. A restriction it
        quotes literally makes the boundary "eingeschraenkt" (visible, binds no later act); "diese_tat" narrows it; no
        scope reading -> "unbestaetigt" (visible proposal, binds nothing beyond its own act). A word for the duration is
        never a proof of the action scope (V65U error: "nicht mehr auf die Schulter" became every touch).
      DURATION - a named period grounded in the quote (window); an explicit open validity (the scope reading quotes it
        AND the §37 time reader reads it as open: two keys); otherwise the CURRENT SCENE (geltung "szene", bound to place
        and turn by the kernel) - the safe default instead of dropping the boundary (V65U error K4)."""
    if not isinstance(raw, dict):
        return None
    scope = _clean(raw.get("gilt_fuer"), 20).lower()
    if scope not in GRENZE_SCOPES:
        return None
    beleg = _clean(raw.get("beleg"), 200)
    out: dict[str, Any] = {"gilt_fuer": scope, "wer": _clean(raw.get("wer"), 80), "beleg": beleg, "status": "validiert"}
    if not beleg or _norm(beleg) not in _norm(text):
        return {**out, "status": "ungueltig", "grund": "beleg_nicht_woertlich"}
    _chk0 = raw.get("pruefung") if isinstance(raw.get("pruefung"), dict) else None
    if scope == "diese_tat" and _chk0 is not None and _clean(_chk0.get("umfang"), 24).lower() == "eingeschraenkt":
        # V65X (Nachpruefung V65W E01, live 30.10.: "Du darfst meine Schulter wieder anfassen" was bound as an answer to the
        # kiss; AMASTER §36.5 Z. 1947 an die betreffende Handlung gebunden, §34.3 Provenienz): an answer proposed for one act
        # whose separate scope reading names a body part, kind or manner of touch is read like a restricted boundary (same
        # checks below: literal object and restriction, direction). The reading never WIDENS a one-act answer to every touch.
        scope = "jede_beruehrung"
        out["vorschlag"] = "diese_tat"
    if scope == "jede_beruehrung":
        chk = raw.get("pruefung") if isinstance(raw.get("pruefung"), dict) else None
        umfang = _clean((chk or {}).get("umfang"), 24).lower()
        einschr = _clean((chk or {}).get("einschraenkung"), 160)
        out["umfangPruefung"] = {"umfang": umfang or None, "einschraenkung": einschr or None} if chk is not None else None
        if chk is None:
            return {**out, "status": "unbestaetigt", "grund": "umfang_ungeprueft"}
        gg = _clean(chk.get("gegenstand"), 160)
        wer_parts = {p for p in _norm(out["wer"]).split() if len(p) >= 3}
        if gg and wer_parts & set(re.findall(r"\w+", _norm(gg))):
            # the object of a boundary is never the one who touches (measured: "Lass das, Kvle" read as person "Kvle")
            return {**out, "status": "unbestaetigt", "grund": "gegenstand_ist_beruehrender"}
        if "gegenstand" in chk and not gg and umfang == "jede_beruehrung":
            # the reading says "the person as a whole" but names no words for it (measured: "Ja, das darfst du")
            return {**out, "status": "unbestaetigt", "grund": "gegenstand_fehlt"}
        if gg and _norm(gg) not in _norm(beleg):
            # the reading's object of the boundary must be words of the quote (provenance), else nothing is confirmed
            return {**out, "status": "unbestaetigt", "grund": "gegenstand_nicht_woertlich"}
        if umfang == "eingeschraenkt" or (umfang == "jede_beruehrung" and einschr):
            if not einschr or _norm(einschr) not in _norm(beleg):
                return {**out, "status": "unbestaetigt", "grund": "einschraenkung_nicht_woertlich"}
            # V65W (Tiefenpruefung v1 P06/C1; AMASTER §36.5 Z. 1953-1956 Handlung + Scope + Gueltigkeitsfenster): a
            # restriction quoted literally from the boundary (a body part, a kind or manner of touch) is a VALID boundary of
            # its own scope "eingeschraenkt" - kept with its words and its window (below). It never binds every touch: a
            # later act is covered only when the separate act reading names it as touching exactly that restriction
            # (scene_state.act_consent, grenzBezug). V65V kept it as an unconfirmed note, so the same shoulder was "unknown".
            out.update({"gilt_fuer": "eingeschraenkt", "einschraenkung": einschr, "grund": "umfang_eingeschraenkt"})
        elif umfang != "jede_beruehrung":
            return {**out, "gilt_fuer": "diese_tat", "status": "validiert", "grund": "umfang_diese_tat"}
        _need = {"refusal": "verboten", "acceptance": "erlaubt"}.get(str(kind or "").lower())
        if _need:
            # V65X (live 30.10.: "Nur meine Hand darfst du halten" became a REFUSAL of the hand; AMASTER §24.2 Z. 1113, §34.1
            # Z. 1807-1815, §36.5): a boundary beyond this act needs the reading's direction of its object to agree with the
            # answer's kind - a refusal forbids it, a permission allows exactly it. Missing or contrary -> unconfirmed,
            # visible with its words, binds nothing beyond its own act (an incomplete check never becomes a boundary).
            _ri = _clean(chk.get("richtung"), 12).lower()
            out["umfangPruefung"]["richtung"] = _ri or None
            if _ri != _need:
                return {**out, "gilt_fuer": "diese_tat", "status": "unbestaetigt",
                        "grund": "richtung_fehlt" if not _ri else "richtung_widerspricht"}
    z = raw.get("zeit") if isinstance(raw.get("zeit"), dict) else {}
    fields = {k: z.get(k) for k in ("wochentag", "relativ", "in_tagen", "datum", "uhrzeit")}
    if any(v not in (None, "", "null") for v in fields.values()):
        # a proposed time must be named by the utterance; an ungrounded one never widens the window to "unlimited".
        # V65U (§34.3 Provenienz, §36.5 Z. 1956 Gueltigkeitsfenster): for a boundary beyond this act the time must be
        # part of the boundary's own quote, not any word elsewhere in the speech.
        fields, dropped = _ground_time_fields(fields, beleg if scope == "jede_beruehrung" else text)
        if dropped:
            return {**out, "status": "ungueltig", "grund": "zeit_nicht_woertlich", "zeitVerworfen": dropped}
        t = temporal_from_fields("", fields, now)
        if t.get("ambiguous") or not t.get("end"):
            return {**out, "status": "ungueltig", "grund": "zeit_ungeklaert"}
        out["fenster"] = {"start": t.get("start"), "end": t.get("end"), "label": t.get("label") or ""}
        if scope == "jede_beruehrung":   # also for a restricted boundary (V65W): same duration axis
            out["geltung"] = {"quelle": "zeitleser", "art": "fenster", "label": out["fenster"]["label"]}
    elif scope == "jede_beruehrung" and (parse_temporal(beleg, now) or {}).get("label"):
        # §37 "widerspruechliche Zeitangaben bleiben ungeklaert": the quote names a time the reading left out
        return {**out, "status": "ungueltig", "grund": "zeit_ungeklaert"}
    elif scope == "jede_beruehrung":
        chk = raw.get("pruefung") if isinstance(raw.get("pruefung"), dict) else {}
        gb = _clean(chk.get("geltung_beleg"), 80)
        g = parse_geltung(gb) if (str(chk.get("geltung") or "").lower() == "offen" and gb and _norm(gb) in _norm(beleg)) else None
        if g:
            out["geltung"] = {"quelle": "zeitleser+pruefung", "art": "offen", "label": g["label"]}
        else:
            # V65V (K4): no duration named or not read by both keys -> the current scene, not dropped and not "forever"
            out["geltung"] = {"quelle": "default", "art": "szene", "label": "laufende Szene"}
    return out


def prefer_local_if_richer(llm_plan: dict | None, local: dict) -> dict:
    """A validated semantic plan wins. Regex is not a semantic veto.

    The existing direct/offline kernel compatibility path still accepts its
    explicit local candidate; productive ingress supplies semantic or unresolved.
    """
    return llm_plan if isinstance(llm_plan, dict) else local


def _find_frame(session: dict, plan: dict, *, other_id: str | None) -> dict | None:
    """Bezugsframe für Annahme/Ablehnung/Widerruf/Erfüllung: explizit (refers_to) oder
    der jüngste offene Frame zwischen den Beteiligten mit Stichwortnähe."""
    frames = [f for f in (session.get("frames") or []) if isinstance(f, dict)]
    ref = _norm(plan.get("refers_to") or "")
    if ref:
        for f in reversed(frames):
            if ref == str(f.get("id") or "") or (ref and ref in _norm(f.get("what") or "")):
                return f
        # V62 (§35/§36.2): refers_to names a Proposition [prop_…]; its frame is
        # the one created from the SAME source Fact (binding, not words).
        pid = ref.strip("[]")
        prop = next((p for p in session.get("propositions") or [] if isinstance(p, dict) and _norm(p.get("id") or "") == pid), None)
        if prop is not None:
            src_ids = {str(f.get("id") or "") for f in session.get("facts") or [] if isinstance(f, dict)
                       and _norm(f.get("proposition_id") or f.get("propositionId") or "") == pid} | {
                str(e.get("factId") or "") for e in (prop.get("evidence") or []) if isinstance(e, dict)}
            src_ids.discard("")
            for f in reversed(frames):
                if src_ids & {str(x) for x in (f.get("sourceFactIds") or [])}:
                    return f
    actor = str(plan.get("actor_id") or "")
    cues = set(plan.get("cue_terms") or [])
    best, best_score = None, -1.0
    for f in reversed(frames):
        if f.get("status") not in FRAME_OPEN:
            continue
        parties = {str(f.get("who") or ""), str(f.get("whom") or "")}
        # V62 (§25, §36.2): an answer addressed to X concerns a matter between
        # the speaker AND X — not any open frame of the speaker with someone else.
        if other_id:
            if not {actor, str(other_id)} <= parties:
                continue
        elif actor not in parties:
            continue
        score = 1.0 + len(cues & set(f.get("cues") or [])) * 2.0
        if str(f.get("who") or "") == (other_id or "") and str(f.get("whom") or "") == actor:
            score += 1.5
        if score > best_score:
            best, best_score = f, score
    return best


def _frame_window(f: dict) -> tuple[datetime, datetime] | None:
    w = f.get("when") if isinstance(f.get("when"), dict) else {}
    try:
        if w.get("start") and w.get("end"):
            return datetime.fromisoformat(str(w["start"])), datetime.fromisoformat(str(w["end"]))
    except ValueError:
        return None
    return None


def _time_bound_parties(f: dict) -> set[str]:
    """Whose time a dated matter binds (§36, §37): an agreement (proposed or
    accepted) binds both parties; a request binds the person ASKED; a promise
    binds the one who promised."""
    who, whom = str(f.get("who") or ""), str(f.get("whom") or "")
    kind = f.get("kind")
    out = {who, whom} if kind == "vereinbarung" else ({whom} if kind == "bitte" else ({who} if kind == "versprechen" else set()))
    return out - {""}


def mark_time_conflicts(session: dict, frame: dict, *, turn: int, fact_id: str) -> list[str]:
    """V62 (AMASTER §37 "Doppelbuchungen werden nicht durch Vergessen gelöst.
    Sie erzeugen Konflikt ..."): a dated agreement/request/promise whose window
    overlaps another OPEN dated one of a shared party is marked on both sides
    (timeConflicts with the other's id, what, who, status, shared ids). The
    conflict is state; the figures decide (accept, refuse, revoke, renegotiate)."""
    win = _frame_window(frame)
    if win is None:
        return []
    parties = {str(frame.get("who") or ""), str(frame.get("whom") or "")} - {""}
    bound = _time_bound_parties(frame)
    hits: list[str] = []
    for other in session.get("frames") or []:
        if not isinstance(other, dict) or other is frame or other.get("id") == frame.get("id"):
            continue
        if other.get("status") not in ("proposed", "accepted", "committed", "requested"):
            continue
        if other.get("kind") not in ("vereinbarung", "bitte", "versprechen"):
            continue
        ow = _frame_window(other)
        o_parties = {str(other.get("who") or ""), str(other.get("whom") or "")} - {""}
        # only a person whose TIME both matters bind can be double-booked
        # (acceptance run D 27.10.: Mara's own request "über den Samstag reden"
        # was dated Saturday and marked against Clara's request)
        shared = bound & _time_bound_parties(other)
        # A double booking binds one person to two DIFFERENT counterparts at
        # the same time; two matters of the same pair are not a double booking
        # (live 27.10.: "Ich kann nicht bis Samstag warten" was dated Saturday).
        if ow is None or not shared or o_parties == parties or not (win[0] < ow[1] and ow[0] < win[1]):
            continue
        for a, b in ((frame, other), (other, frame)):
            rows = [c for c in (a.get("timeConflicts") or []) if isinstance(c, dict) and c.get("id") != b.get("id")]
            rows.append({"id": b.get("id"), "what": str(b.get("what") or "")[:160], "who": b.get("who"), "whom": b.get("whom"),
                         "status": b.get("status"), "shared": sorted(shared), "turn": turn, "factId": fact_id})
            a["timeConflicts"] = rows[-4:]
            a.setdefault("history", []).append({"turn": turn, "factId": fact_id, "by": "kernel", "event": "time_conflict", "with": b.get("id")})
        hits.append(str(other.get("id")))
    return hits


def proposal_opens_matter(plan: Any) -> bool:
    """V62 (AMASTER §24.7 Ambiguität, §36.3 Angebot): a plan of kind
    "proposal" opens an agreement only when the planner's own durability reads
    it as an offer (PLAN_RULES: "Vorschlag/Bitte/Versprechen/Termin =
    commitment; Smalltalk/Frage = utterance"). event_kind "proposal" together
    with durability "utterance" is a contradictory reading and creates no open
    matter. Every other event kind is unaffected."""
    if not isinstance(plan, dict):
        return False
    if str(plan.get("event_kind") or "") != "proposal":
        return True
    return str(plan.get("durability") or "") in ("commitment", "durable_state")


def apply_plan(session: dict, plan: dict, *, fact_id: str, turn: int, witnesses: list[str], names: dict[str, str] | None = None) -> dict[str, Any]:
    """Plan → Frames (Current-State-Reduktion). Gibt Änderung zurück (für Turn-Record/Fact)."""
    if not isinstance(plan, dict) or not plan.get("event_kind"):
        return {}
    frames = session.setdefault("frames", [])
    kind = plan["event_kind"]
    actor = str(plan.get("actor_id") or "")
    recipient = str(plan.get("recipient_id") or "")
    temporal = plan.get("temporal") if isinstance(plan.get("temporal"), dict) else {}
    durable = plan.get("durability") in ("commitment", "durable_state", "knowledge_transition")
    change: dict[str, Any] = {}
    now_id = str(fact_id)

    def _new(frame_kind: str, status: str, what: str) -> dict:
        f = {
            "id": uid("frame"),
            "kind": frame_kind,
            "status": status,
            "who": actor,
            "whom": recipient,
            "what": what[:200],
            "subject": _clean(plan.get("subject"), 80),
            "predicate": _clean(plan.get("predicate"), 80),
            "object": _clean(plan.get("object"), 120),
            "when": {k: temporal.get(k) for k in ("label", "precision", "start", "end", "weekday", "time", "ambiguous")},
            "cues": list(plan.get("cue_terms") or [])[:12],
            "history": [{"turn": turn, "factId": now_id, "by": actor, "event": kind}],
            "witnesses": [str(w) for w in (witnesses or []) if w],
            "sourceFactIds": [now_id],
            "createdTurn": turn,
            "updatedTurn": turn,
        }
        frames.append(f)
        return f

    def _existing_obligation(what: str) -> tuple[dict | None, bool]:
        """Find the same ongoing obligation, not merely someone in the same room.

        Exact textual repeats are the same event. A generic (unstructured)
        follow-up request after an accepted request by the same initiator and
        same addressee is a clarification of the still-unfulfilled obligation,
        not proof of fulfilment and not a new unrelated contract. An explicit
        different object/predicate always makes a separate request. The raw
        speech Fact is always preserved in either case.
        """
        what_norm = _norm(what)
        concrete = bool(_clean(plan.get("predicate")) or _clean(plan.get("object")))
        frame_kind = {"proposal": "vereinbarung", "request": "bitte", "promise": "versprechen"}.get(kind)
        for old in reversed(frames):
            if old.get("kind") != frame_kind or old.get("status") not in FRAME_OPEN:
                continue
            if str(old.get("who") or "") != actor or str(old.get("whom") or "") != recipient:
                continue
            old_concrete = bool(_clean(old.get("predicate")) or _clean(old.get("object")))
            if concrete != old_concrete:
                continue
            if concrete:
                same = (_norm(old.get("predicate")) == _norm(plan.get("predicate")) and
                        _norm(old.get("object")) == _norm(plan.get("object")))
                if same:
                    return old, False
                continue
            old_text = _norm(old.get("what"))
            if what_norm and old_text and what_norm == old_text:
                return old, False
            # When the plan names a different explicit referent, never join
            # unrelated requests merely because their participants match.
            # Without structured objects this is a *sequential follow-up*,
            # not evidence of a new independent contract or proof of fulfilment.
            # Only the most recent applicable frame may receive that follow-up;
            # keep the exact utterance + source Fact and the original terms.
            ref = str(plan.get("refers_to") or "").strip()
            old_what = _norm(old.get("what"))
            refers_here = not ref or ref == str(old.get("id") or "") or (old_what and _norm(ref) in old_what)
            last_open = next((x for x in reversed(frames) if x.get("status") in FRAME_OPEN and x.get("kind") in ("bitte", "vereinbarung", "versprechen")), None)
            if kind == "request" and old.get("status") == "accepted" and refers_here and last_open is old:
                return old, True
        return None, False

    if kind in ("proposal", "request", "promise"):
        what = plan.get("summary") or plan.get("canonical_value") or ""
        dup, continuation = _existing_obligation(what)
        if dup is not None:
            entry = {"turn": turn, "factId": now_id, "by": actor,
                     "event": "request_clarified" if continuation else f"{kind}_repeated"}
            if continuation:
                entry["text"] = str(what)[:200]
                dup.setdefault("clarifications", []).append(dict(entry))
            dup.setdefault("history", []).append(entry)
            dup["updatedTurn"] = turn
            if now_id not in dup.setdefault("sourceFactIds", []):
                dup["sourceFactIds"].append(now_id)
            for w in witnesses or []:
                if w and w not in dup.get("witnesses", []):
                    dup.setdefault("witnesses", []).append(str(w))
            change = {"updated": dup["id"], "status": dup["status"],
                      "continuation": continuation, "repeated": not continuation}
        elif kind == "promise":
            f = _new("versprechen", "committed", what)
            change = {"created": f["id"], "status": "committed"}
            _conf = mark_time_conflicts(session, f, turn=turn, fact_id=now_id)
            if _conf:
                change["timeConflicts"] = _conf
        elif kind == "proposal" and not proposal_opens_matter(plan):
            # V62: a contradictory "proposal" read as utterance opens no NEW
            # agreement frame; a repeat of an existing frame is still recorded above.
            change = {}
        else:
            f = _new("vereinbarung" if kind == "proposal" else "bitte", "proposed" if kind == "proposal" else "requested", what)
            change = {"created": f["id"], "status": f["status"]}
            _conf = mark_time_conflicts(session, f, turn=turn, fact_id=now_id)
            if _conf:
                change["timeConflicts"] = _conf
    elif kind in ("acceptance", "refusal", "revocation"):
        f = _find_frame(session, plan, other_id=recipient)
        # V60 (AMASTER §36.2/§36.3): only the addressee of a proposal/request
        # accepts or refuses it; the initiator cannot accept her own frame.
        if f is not None and kind in ("acceptance", "refusal") and str(f.get("whom") or "") and actor != str(f.get("whom") or ""):
            f = None
        if f is not None:
            new_status = {"acceptance": "accepted", "refusal": "refused", "revocation": "revoked"}[kind]
            f["status"] = new_status
            f["updatedTurn"] = turn
            f.setdefault("history", []).append({"turn": turn, "factId": now_id, "by": actor, "event": kind})
            f.setdefault("sourceFactIds", []).append(now_id)
            for w in witnesses or []:
                if w and w not in f.get("witnesses", []):
                    f.setdefault("witnesses", []).append(str(w))
            if kind == "acceptance" and temporal.get("label") and not (f.get("when") or {}).get("label"):
                f["when"] = {k: temporal.get(k) for k in ("label", "precision", "start", "end", "weekday", "time")}
            change = {"updated": f["id"], "status": new_status}
            if kind == "acceptance":
                _conf = mark_time_conflicts(session, f, turn=turn, fact_id=now_id)
                if _conf:
                    change["timeConflicts"] = _conf
    elif kind in ("report", "state_change", "action") and durable:
        f = _find_frame(session, plan, other_id=recipient)
        if f is not None and f.get("status") in ("accepted", "committed", "requested"):
            f["status"] = "fulfilled"
            f["updatedTurn"] = turn
            f.setdefault("history", []).append({"turn": turn, "factId": now_id, "by": actor, "event": kind})
            change = {"updated": f["id"], "status": "fulfilled"}
        else:
            f = _new("zustand", "current", plan.get("summary") or plan.get("canonical_value") or "")
            change = {"created": f["id"], "status": "current"}
    elif kind in ("disclosure", "claim") and durable:
        # überholt frühere gleiche Aussagen (Subjekt+Prädikat) — historische bleiben Erinnerung
        subj, pred = _norm(plan.get("subject") or actor), _norm(plan.get("predicate") or "")
        for old in frames:
            if old.get("kind") in ("fakt",) and old.get("status") == "current" and _norm(old.get("subject") or "") == subj and pred and _norm(old.get("predicate") or "") == pred:
                old["status"] = "superseded"
                old["updatedTurn"] = turn
        f = _new("fakt", "current", plan.get("summary") or plan.get("canonical_value") or "")
        f["subject"] = plan.get("subject") or actor
        f["predicate"] = plan.get("predicate") or ""
        f["object"] = plan.get("object") or ""
        change = {"created": f["id"], "status": "current"}
    return change


def frames_for(session: dict, character_id: str, *, limit: int = 8) -> list[dict]:
    """Zeugengebundene Frames für eine Figur: offene zuerst, dann jüngste."""
    frames = [f for f in (session.get("frames") or []) if isinstance(f, dict)]
    mine = [f for f in frames if character_id in (f.get("witnesses") or []) or character_id in (str(f.get("who") or ""), str(f.get("whom") or ""))]
    open_first = sorted(mine, key=lambda f: (0 if f.get("status") in FRAME_OPEN else 1, -int(f.get("updatedTurn") or 0)))
    return open_first[:limit]


_STATUS_DE = {
    "proposed": "vorgeschlagen, noch nicht beantwortet", "requested": "erbeten, offen", "accepted": "vereinbart",
    "committed": "versprochen", "refused": "abgelehnt", "revoked": "abgesagt/widerrufen", "fulfilled": "erfüllt",
    "current": "gilt aktuell", "superseded": "überholt", "conflict": "widersprüchlich",
}


def render_frames(frames: list[dict], names: dict[str, str] | None = None, now: datetime | None = None) -> list[str]:
    """Zeilen für den Persona-Brief."""
    names = names or {}
    out: list[str] = []
    for f in frames:
        who = names.get(str(f.get("who") or ""), str(f.get("who") or "")) or "—"
        whom = names.get(str(f.get("whom") or ""), str(f.get("whom") or ""))
        when = f.get("when") or {}
        wlabel = str(when.get("label") or "").strip()
        if when.get("start") and now is not None:
            # V62 (§37): distance in calendar days from the bound session date
            # (before: timedelta.days truncation against the moving wall clock).
            try:
                dt = datetime.fromisoformat(str(when["start"]))
                days = (dt.date() - now.date()).days
                date_s = dt.strftime("%d.%m.") + (f" {when.get('time')} Uhr" if when.get("time") else "")
                dist = ("heute" if days == 0 else "morgen" if days == 1 else "übermorgen" if days == 2
                        else f"in {days} Tagen" if days > 2 else "vorbei")
                wlabel += f" ({date_s}, {dist})"
            except ValueError:
                pass
        if when.get("ambiguous"):
            wlabel += " (Zeitangabe ungeklärt)"
        hist = f.get("history") or []
        first = hist[0] if hist else {}
        last = hist[-1] if hist else {}
        # V60 (AMASTER §36.3, §68 Nr. 10): a durable statement someone MADE is
        # that person's claim; the frame does not turn it into world truth.
        if f.get("kind") == "fakt" and f.get("status") == "current":
            out.append(f"- Behauptung von {who}: {str(f.get('what') or '')[:140]} — gesagt in Turn {first.get('turn')}, nicht bestätigt")
            continue
        line = f"- {str(f.get('kind') or '').capitalize()}: {str(f.get('what') or '')[:140]}"
        if wlabel:
            line += f" — {wlabel}"
        line += f" — {_STATUS_DE.get(str(f.get('status')), str(f.get('status')))}"
        # Reflect the newest committed clarification of the SAME obligation.
        # Its source Fact is not a second agreement or a completed action.
        clar = [c for c in (f.get("clarifications") or []) if isinstance(c, dict) and c.get("text")]
        if clar:
            line += f" — letzte Präzisierung (Turn {clar[-1].get('turn')}): {str(clar[-1]['text'])[:140]}"
        # V62 (§37 Doppelbuchung): the committed conflict, mirrored.
        for c in (f.get("timeConflicts") or [])[:2]:
            if isinstance(c, dict) and c.get("what"):
                line += (f" — ÜBERSCHNEIDET SICH ZEITLICH mit „{str(c.get('what'))[:110]}“"
                         f" ({names.get(str(c.get('who') or ''), str(c.get('who') or ''))}, {_STATUS_DE.get(str(c.get('status')), str(c.get('status')))})")
        line += f" (von {who}" + (f" an {whom}" if whom and whom != who else "") + f", Turn {first.get('turn')}"
        if last is not first and last.get("event"):
            line += f"; zuletzt {names.get(str(last.get('by') or ''), str(last.get('by') or ''))}: {last.get('event')} Turn {last.get('turn')}"
        line += ")"
        out.append(line)
    return out


def temporal_question(text: str) -> bool:
    low = str(text or "").lower()
    return bool(re.search(r"\b(wann|welcher tag|welche uhrzeit|um wie viel uhr|termin|verabred|treffen wir uns|wo treffen|ausgemacht|abgemacht|versprochen|vereinbart)\b", low))
