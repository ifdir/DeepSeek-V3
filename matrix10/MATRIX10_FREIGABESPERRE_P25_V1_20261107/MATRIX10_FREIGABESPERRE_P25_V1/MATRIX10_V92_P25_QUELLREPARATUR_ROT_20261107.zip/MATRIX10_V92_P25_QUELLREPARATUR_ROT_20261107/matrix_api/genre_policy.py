"""Genre-Policy lokal. Findet, erfindet keine Kanon-Wahrheit."""
from __future__ import annotations

from typing import Any

TONE = {
    "noir": {"register": "knapp", "violence": "implizit", "lexicon": ["schatten", "regen", "schuld"]},
    "drama": {"register": "getragen", "violence": "selten", "lexicon": ["bruch", "pflicht"]},
    "fantasy": {"register": "episch", "violence": "abenteuer", "lexicon": ["rune", "eid"]},
    "horror": {"register": "beklemmend", "violence": "dunkel", "lexicon": ["furcht"]},
}


def evaluate_genre(genre: str, text: str = "") -> dict[str, Any]:
    key = (genre or "").strip().lower()
    policy = TONE.get(key, {"register": "neutral", "violence": "moderat", "lexicon": []})
    hits = [w for w in policy.get("lexicon") or [] if w in (text or "").lower()]
    return {"ok": True, "genre": genre, "policy": policy, "textHits": hits, "inventsTruth": False}
