"""AMASTER Kap. 37 Termine, 33 Graph-Kanten, 40 Recall-Muster. SQLite-Owner."""
from __future__ import annotations

import re
import uuid
from typing import Any

from matrix_api.repos import WriterError, _dumps, _loads, _touch_session

TOKEN = re.compile(r"[a-zäöüß]{4,}", re.I)


def _id(prefix: str, body: dict) -> str:
    oid = body.get("id")
    if oid:
        return str(oid)
    return f"{prefix}_{uuid.uuid4().hex[:10]}"


def create_appointment(conn, body: Any, actor: str) -> dict[str, Any]:
    data = body if isinstance(body, dict) else {}
    sid = str(data.get("sessionId") or data.get("session_id") or "")
    if not sid:
        raise WriterError("appointment requires sessionId", 400, "BAD_REQUEST")
    row = conn.execute("SELECT user_id, world_id FROM sessions WHERE id=?", (sid,)).fetchone()
    if row is None:
        raise WriterError("session not found", 404, "NOT_FOUND")
    if row[0] != actor and actor != "admin":
        raise WriterError("session not owned", 403, "SESSION_OWNER_FORBIDDEN")
    aid = _id("apt", data)
    when = data.get("when") or data.get("at") or ""
    payload = {
        "id": aid,
        "sessionId": sid,
        "userId": actor,
        "worldId": data.get("worldId") or row[1],
        "when": when,
        "title": data.get("title") or "Termin",
        "note": data.get("note") or "",
        "status": data.get("status") or "open",
    }
    conflict_of = None
    if str(when).strip():
        for r in conn.execute("SELECT id, json FROM appointments WHERE session_id=?", (sid,)):
            existing = _loads(r[1]) if r[1] else {}
            if not isinstance(existing, dict):
                continue
            estatus = str(existing.get("status") or "open")
            if estatus in ("closed", "revoked", "cancelled", "superseded"):
                continue
            if str(existing.get("when") or "") == str(when):
                conflict_of = existing.get("id") or r[0]
                payload["status"] = "conflict"
                payload["conflictOf"] = conflict_of
                note = str(payload.get("note") or "").strip()
                payload["note"] = (note + " " if note else "") + f"Doppelbuchung zu {conflict_of}"
                break
    conn.execute(
        "INSERT INTO appointments(id,user_id,world_id,session_id,json) VALUES (?,?,?,?,?)",
        (aid, actor, payload["worldId"], sid, _dumps(payload)),
    )
    _touch_session(conn, sid)
    out = {"ok": True, "appointment": payload}
    if conflict_of:
        out["conflict"] = True
        out["conflictOf"] = conflict_of
    return out


def list_appointments(conn, session_id: str, actor: str) -> dict[str, Any]:
    row = conn.execute("SELECT user_id FROM sessions WHERE id=?", (session_id,)).fetchone()
    if row is None:
        raise WriterError("session not found", 404, "NOT_FOUND")
    if row[0] != actor and actor != "admin":
        raise WriterError("session not owned", 403, "SESSION_OWNER_FORBIDDEN")
    items = []
    for r in conn.execute("SELECT json FROM appointments WHERE session_id=?", (session_id,)):
        obj = _loads(r[0])
        if isinstance(obj, dict):
            items.append(obj)
    return {"ok": True, "appointments": items}


def create_graph_edge(conn, body: Any, actor: str) -> dict[str, Any]:
    data = body if isinstance(body, dict) else {}
    sid = str(data.get("sessionId") or "")
    if not sid:
        raise WriterError("edge requires sessionId", 400, "BAD_REQUEST")
    row = conn.execute("SELECT user_id, world_id FROM sessions WHERE id=?", (sid,)).fetchone()
    if row is None:
        raise WriterError("session not found", 404, "NOT_FOUND")
    if row[0] != actor and actor != "admin":
        raise WriterError("session not owned", 403, "SESSION_OWNER_FORBIDDEN")
    eid = _id("ge", data)
    payload = {
        "id": eid,
        "sessionId": sid,
        "userId": actor,
        "worldId": data.get("worldId") or row[1],
        "fromId": data.get("fromId") or data.get("from_id"),
        "toId": data.get("toId") or data.get("to_id"),
        "kind": data.get("kind") or "related",
        "note": data.get("note") or "",
        "sourceTurnId": data.get("sourceTurnId") or data.get("source_turn_id"),
    }
    if not payload["fromId"] or not payload["toId"]:
        raise WriterError("edge requires fromId and toId", 400, "BAD_REQUEST")
    conn.execute(
        "INSERT INTO graph_edges(id,user_id,world_id,session_id,from_id,to_id,json) VALUES (?,?,?,?,?,?,?)",
        (eid, actor, payload["worldId"], sid, payload["fromId"], payload["toId"], _dumps(payload)),
    )
    _touch_session(conn, sid)
    return {"ok": True, "edge": payload}


def list_graph_edges(conn, session_id: str, actor: str) -> dict[str, Any]:
    row = conn.execute("SELECT user_id FROM sessions WHERE id=?", (session_id,)).fetchone()
    if row is None:
        raise WriterError("session not found", 404, "NOT_FOUND")
    if row[0] != actor and actor != "admin":
        raise WriterError("session not owned", 403, "SESSION_OWNER_FORBIDDEN")
    items = []
    for r in conn.execute("SELECT json FROM graph_edges WHERE session_id=?", (session_id,)):
        obj = _loads(r[0])
        if isinstance(obj, dict):
            items.append(obj)
    return {"ok": True, "edges": items}


def recall_patterns(conn, session_id: str, actor: str, cue: str, character_id: str | None = None) -> dict[str, Any]:
    row = conn.execute("SELECT user_id FROM sessions WHERE id=?", (session_id,)).fetchone()
    if row is None:
        raise WriterError("session not found", 404, "NOT_FOUND")
    if row[0] != actor and actor != "admin":
        raise WriterError("session not owned", 403, "SESSION_OWNER_FORBIDDEN")
    cue_toks = set(TOKEN.findall((cue or "").lower()))
    hits = []
    for r in conn.execute("SELECT id, json FROM memories WHERE session_id=?", (session_id,)):
        obj = _loads(r[1]) if r[1] else {}
        if not isinstance(obj, dict):
            continue
        mem_cid = str(obj.get("characterId") or obj.get("character_id") or "")
        if character_id and mem_cid and mem_cid != str(character_id):
            continue
        text = str(obj.get("text") or obj.get("content") or "")
        toks = set(TOKEN.findall(text.lower()))
        overlap = cue_toks & toks
        score = (len(overlap) / len(cue_toks)) if cue_toks else 0.0
        if score > 0:
            hits.append(
                {
                    "id": r[0],
                    "sourceMemoryId": r[0],
                    "sourceKind": "memory",
                    "derived": True,
                    "inventsTruth": False,
                    "layer": "cache",
                    "score": round(score, 3),
                    "overlap": sorted(overlap)[:8],
                    "text": text[:180],
                    "characterId": mem_cid,
                }
            )
    hits.sort(key=lambda x: x["score"], reverse=True)
    return {
        "ok": True,
        "engine": "pattern-overlap-v1",
        "inventsTruth": False,
        "derivedFrom": "memories",
        "owner": "recall-cache",
        "cue": cue,
        "characterId": character_id,
        "hits": hits[:20],
    }
