"""V43 Strukturierte God-Extraktion (Vorbild: Ursprungssystem services/structured_god_extractor.py —
„kaputte Resttexte wie [GOTT-FAKT] … landen nicht mehr im Profil“).

Freier God-Text wird in Einzelanweisungen zerlegt: je Anweisung Ziel (anwesende oder Welt-Figur,
Szene, Welt), Art (koerper | wissen | beziehung | szene | welt | zustand | zeit) und der wirksame
Text. Der Kernel wendet jede Anweisung über die bestehenden God-Scopes an (apply_god), sodass
jede Tatsache dort landet, wo sie wirkt (PhysicalState, Wissen, Beziehung, Szene). Was sich
nicht sicher binden lässt, wird als UNKLAR zurückgegeben — nicht angewendet, nicht erfunden.
"""
from __future__ import annotations

import re
from typing import Any

ARTEN = {"koerper", "wissen", "beziehung", "szene", "welt", "zustand", "zeit", "handlung"}
ART_TO_SCOPE = {"koerper": "body", "wissen": "knowledge", "beziehung": "relationship", "szene": "scene", "welt": "world", "zustand": "character", "zeit": "time", "handlung": "action"}

_SPLIT_RE = re.compile(r"(?<=[.!?;])\s+|\s+(?:und dann|danach|außerdem|ausserdem|zugleich|gleichzeitig)\s+|\s*;\s*", re.I)
_BODY_RE = re.compile(r"\b(gebrochen|bruch|verletzt|blutet|wunde|schmerz|ohnmächtig|ohnmaechtig|bewusstlos|schläft|schlaeft|stumm|gefesselt|geknebelt|blind|handstand|liegt|sitzt|steht auf|kniet|erschöpft|erschoepft|krank|fieber|betrunken|müde|muede)\w*", re.I)
_KNOW_RE = re.compile(r"\b(weiß|weiss|erfährt|erfaehrt|hat erfahren|kennt|hat gesehen|hat gehört|hat gehoert|findet heraus|entdeckt|bemerkt|glaubt|ahnt)\b", re.I)
_REL_RE = re.compile(r"\b(hasst|liebt|vertraut|misstraut|verachtet|fürchtet|fuerchtet|bewundert|ist (?:in|mit) .{0,20}(?:verliebt|verfeindet|befreundet|verheiratet)|feind|freund|verzeiht|versöhnt|versoehnt)\w*", re.I)
_SCENE_RE = re.compile(r"\b(licht|tür|tuer|fenster|regen|gewitter|es klopft|es klingelt|stromausfall|dunkel|nebel|feuer|rauch|lärm|laerm|musik|schuss|sirene|im raum|der raum|die tür|das licht|draußen|draussen|explodiert|beben)\w*", re.I)
_TIME_RE = re.compile(r"\b(stunde|stunden|tage später|jahre später|am nächsten morgen|am naechsten morgen|inzwischen|später|spaeter|zeit vergeht|abend|nacht|morgen früh)\b", re.I)
_PERSON_ACT_RE = re.compile(r"\b(lacht|weint|sagt|schreit|geht|kommt|betritt|verlässt|verlaesst|steht|sitzt|schaut|nimmt|gibt|rennt|flieht|greift|umarmt|küsst|kuesst|schlägt|schlaegt|erscheint|taucht auf|spricht|flüstert|fluestert)\b", re.I)
_WORLD_RE = re.compile(r"\b(die welt|das land|die stadt|das dorf|krieg|gesetz|regierung|könig|koenig|seuche|winter kommt|die regel)\b", re.I)


def split_clauses(text: str) -> list[str]:
    parts = [p.strip(" ,;") for p in _SPLIT_RE.split(str(text or "")) if p and p.strip(" ,;")]
    out: list[str] = []
    for p in parts:
        # "X hat A und Y hat B" → an "und <Name>" trennen
        sub = re.split(r"\s+und\s+(?=[A-ZÄÖÜ][a-zäöüß]+\s+(?:hat|ist|weiß|weiss|erfährt|erfaehrt|kennt|liebt|hasst|geht|kommt|liegt|sitzt|steht))", p)
        out.extend(s.strip(" ,;") for s in sub if s.strip(" ,;"))
    return out[:12]


def _source_occurrences(text: str, figures: list[dict]) -> tuple[list[dict], list[dict]]:
    """The canonical names-in-this-input reader; no model output can introduce a person.
    Ambiguous or unproven spans remain unbound. Keep IDs, not first-name matches.
    """
    from matrix_api.kernel import name_occurrences
    occurrences = name_occurrences(text, figures)
    single = [o for o in occurrences if o.get("state") == "ok" and len(o.get("ids") or ()) == 1]
    unclear = [o for o in occurrences if o.get("state") != "ok" or len(o.get("ids") or ()) != 1]
    return single, unclear


def _match_figure(clause: str, figures: list[dict]) -> dict | None:
    occurrences, unclear = _source_occurrences(clause, figures)
    if unclear and (not occurrences or unclear[0]["a"] < occurrences[0]["a"]):
        return None  # a leading unknown/ambiguous name may be the actual actor
    if not occurrences:
        return None
    fid = next(iter(occurrences[0]["ids"]))
    return next((f for f in figures if str(f.get("id")) == fid), None)


def _other_figure(clause: str, figures: list[dict], exclude_id: str | None) -> dict | None:
    occurrences, unclear = _source_occurrences(clause, figures)
    if unclear:
        return None  # never convert a duplicate or incomplete name into a target
    for o in occurrences:
        fid = next(iter(o["ids"]))
        if fid != str(exclude_id or ""):
            return next((f for f in figures if str(f.get("id")) == fid), None)
    return None


def _name_ids(label: str, figures: list[dict]) -> set[str]:
    from matrix_api.kernel import figure_ids_for_name
    return figure_ids_for_name(label, figures)


def _in_source(source: str, quote: str) -> bool:
    # No approximate textual evidence: a valid quote is contiguous in the original input.
    return bool(str(quote or "").strip() and str(quote).strip().casefold() in str(source or "").casefold())


def _source_parties(source: str, figures: list[dict]) -> tuple[list[str], bool]:
    ok, bad = _source_occurrences(source, figures)
    # The first ambiguous or unknown name poisons person binding, never pick another by order.
    return [next(iter(o["ids"])) for o in ok], bool(bad)


def _classify(clause: str, has_target: bool) -> str:
    if _KNOW_RE.search(clause):
        return "wissen"
    if _BODY_RE.search(clause):
        return "koerper"
    if _REL_RE.search(clause):
        return "beziehung"
    if _TIME_RE.search(clause) and not has_target:
        return "zeit"
    if _SCENE_RE.search(clause):
        return "szene"
    if _WORLD_RE.search(clause):
        return "welt"
    if has_target and _PERSON_ACT_RE.search(clause):
        return "handlung"
    return "zustand" if has_target else "szene"


def local_god_instructions(text: str, figures: list[dict], present_ids: list[str] | None = None) -> tuple[list[dict[str, Any]], list[dict[str, Any]]]:
    """Lokale Zerlegung ohne LLM. Liefert (anweisungen, unklar)."""
    out: list[dict[str, Any]] = []
    unclear: list[dict[str, Any]] = []
    present = set(present_ids or [])
    for clause in split_clauses(text):
        fig = _match_figure(clause, figures)
        art = _classify(clause, bool(fig))
        if art in ("koerper", "wissen", "beziehung", "zustand", "handlung") and not fig:
            unclear.append({"text": clause, "grund": "Ziel-Figur nicht erkannt"})
            continue
        if not fig and art == "szene" and (
            _PERSON_ACT_RE.search(clause) or
            re.search(r"\b(ich|du|mein|meine|dein|deine|mir|dir)\b", clause, re.I)
        ) and not _SCENE_RE.search(clause):
            # A first-/second-person role cannot be invented from a God command.
            unclear.append({"text": clause, "grund": "handelnde Person ist nicht eindeutig gebunden"})
            continue
        item: dict[str, Any] = {"art": art, "text": clause, "targetId": str(fig.get("id")) if fig else None, "targetName": fig.get("name") if fig else None, "source": "local", "confidence": 0.6}
        if art == "zeit" and _SCENE_RE.search(clause):
            # Zeitsprung UND Szenenereignis in einem Satz → beides
            out.append({"art": "zeit", "text": clause, "targetId": None, "targetName": None, "source": "local", "confidence": 0.6})
            item = {"art": "szene", "text": clause, "targetId": None, "targetName": None, "source": "local", "confidence": 0.6}
        if art in ("beziehung", "handlung"):
            other = _other_figure(clause, figures, str(fig.get("id")) if fig else None)
            if art == "beziehung" and not other:
                unclear.append({"text": clause, "grund": "Beziehung braucht zwei Figuren"})
                continue
            if other:
                item["otherId"] = str(other.get("id"))
                item["otherName"] = other.get("name")
        if fig and present and str(fig.get("id")) not in present and art in ("koerper", "handlung"):
            item["note"] = "Figur nicht anwesend — wirkt auf ihren Zustand, nicht in der Szene"
        out.append(item)
    return out, unclear


def normalize_llm_instructions(raw: Any, figures: list[dict], *, source_text: str | None = None) -> tuple[list[dict[str, Any]], list[dict[str, Any]]]:
    """Validate semantic proposals against the ORIGINAL God input and the shared figure-ID reader.

    A model's rewritten text is never the authority for actor/target identity.  For
    action facts the action must be grounded in a literal source clause; novel text
    cannot silently become a completed world event.  No name dictionary that drops
    duplicate full names or aliases is permitted.
    """
    out: list[dict[str, Any]] = []
    unclear: list[dict[str, Any]] = []
    if not isinstance(raw, dict):
        return out, unclear
    source = str(source_text or "")
    for r in raw.get("anweisungen") or raw.get("instructions") or []:
        if not isinstance(r, dict):
            continue
        art = str(r.get("art") or r.get("kind") or "").strip().lower()
        txt = str(r.get("text") or "").strip()
        ziel = str(r.get("ziel") or r.get("target") or "").strip()
        if art not in ARTEN or not txt:
            unclear.append({"text": txt or str(r)[:120], "grund": "Art unbekannt"})
            continue
        item: dict[str, Any] = {"art": art, "text": txt[:300], "source": "llm", "confidence": 0.8}
        if source_text is not None:
            # Source binding is required for ALL owners, not just the action
            # writer. Otherwise a model can invent a body/knowledge/world fact
            # about the RIGHT person and both later body readings would examine
            # its fabricated wording, not the operator's request.
            quote = str(r.get("beleg") or "").strip()
            if not quote and _in_source(source, txt):
                quote = txt
            if (not _in_source(source, quote) or
                    (art in ("koerper", "wissen", "beziehung", "zustand", "handlung")
                     and len(quote.split()) < 2)):
                unclear.append({"text": txt, "grund": "Modellbehauptung hat keinen vollständigen wörtlichen Beleg im Originalauftrag"})
                continue
            item["beleg"] = quote[:300]
            item["text"] = quote[:300]
            # Bind identities at the EXACT source site of this instruction,
            # not a figure somewhere else in a multi-instruction God input.
            source_ids, source_unclear = _source_parties(quote, figures)
        else:
            source_ids, source_unclear = [], False
        if art in ("koerper", "wissen", "beziehung", "zustand", "handlung"):
            candidates = _name_ids(ziel, figures)
            if len(candidates) != 1:
                unclear.append({"text": txt, "grund": "Figur fehlt oder ist mehrdeutig", "ziel": ziel[:80]})
                continue
            fid = next(iter(candidates))
            fig = next(f for f in figures if str(f.get("id")) == fid)
            if source_text is not None:
                # A knowledge statement binds its holder, not every person or
                # capitalized noun in the asserted content. For example
                # "Johann weiss, dass Mara Geld versteckt" contains a known
                # knowledge holder Johann, even when the older name-extent
                # candidate cannot distinguish "Mara Geld" from a longer name.
                # Never invent a canonical ID for the predicate's other people;
                # the original text is preserved as the knowledge proposition.
                # For body, relationships and physical actions all relevant
                # parties still need proven names, with no unresolved span.
                if art == "wissen":
                    _ok, _bad = _source_occurrences(quote, figures)
                    _owner_places = [o for o in _ok if o.get("ids") == {fid}]
                    _first_owner = min((o["a"] for o in _owner_places), default=None)
                    _owner_proven = (_first_owner is not None and
                                     not any(o.get("a", -1) < _first_owner for o in _bad))
                else:
                    _owner_proven = fid in source_ids and not source_unclear
                if not _owner_proven:
                    unclear.append({"text": txt, "grund": "handelnde/betroffene Figur nicht eindeutig im Originalauftrag gebunden"})
                    continue
            if art == "handlung":
                # Actor is the first explicit figure of this source command. A named
                # victim must never be silently promoted to the acting figure.
                if source_text is not None and (not source_ids or source_ids[0] != fid):
                    unclear.append({"text": txt, "grund": "Handlungsakteur widerspricht Originalauftrag"})
                    continue
                if source_text is not None:
                    # The source quote above is already verified; in particular
                    # never write the imperative rephrased by the provider.
                    item["text"] = item["beleg"]
            item["targetId"] = fid
            item["targetName"] = fig.get("name")
            if art in ("beziehung", "handlung"):
                other_name = str(r.get("andere") or r.get("other") or "").strip()
                others = _name_ids(other_name, figures) if other_name else set()
                if other_name and len(others) != 1:
                    unclear.append({"text": txt, "grund": "zweite Figur fehlt oder ist mehrdeutig"})
                    continue
                if not other_name:
                    # A relational fact needs an explicit second party; for actions
                    # with no named other person the target remains unset.
                    others = set()
                if source_text is not None and others and (source_unclear or not others <= set(source_ids)):
                    unclear.append({"text": txt, "grund": "zweite Figur nicht im Originalauftrag gebunden"})
                    continue
                if art == "beziehung" and not others:
                    unclear.append({"text": txt, "grund": "Beziehung braucht zwei Figuren"})
                    continue
                if others:
                    oid = next(iter(others))
                    if oid == fid:
                        unclear.append({"text": txt, "grund": "Beziehung/Handlung ist nicht eindeutig zwischen zwei Figuren"})
                        continue
                    other = next(f for f in figures if str(f.get("id")) == oid)
                    item["otherId"] = oid
                    item["otherName"] = other.get("name")
        elif source_text is not None:
            # The same literal-source rule above covers scene, time and world.
            item["text"] = item["beleg"]
        out.append(item)
    for u in raw.get("unklar") or raw.get("unclear") or []:
        if isinstance(u, str) and u.strip():
            unclear.append({"text": u.strip()[:200], "grund": "vom Provider als unklar gemeldet"})
    return out[:12], unclear[:12]
