"""V42 Wahrheitsstatus & Widerspruchserkennung (Vorbild: Ursprungssystem models/memory.py
TruthStatus CLAIMED/CONFIRMED/REFUTED/CONFLICTED/SELF_DECEIVED, detect_lies_and_contradictions,
knowledge_graph perspektivisch; AMASTERv2 §41/§42: Wissen ist figurengebunden — ein Widerspruch
existiert nur relativ zu dem, was DIESE Figur weiß).

Bausteine:
- Behauptungsregister `session["claims"]`: jede Behauptung/Offenbarung (aus dem Turn-Plan V39)
  mit Sprecher, Subjekt, Prädikat, Wert, Turn, Fact, Zeugen und truthStatus.
- Widerspruchsprüfung für die antwortende Figur: die aktuelle Äußerung gegen (a) ihr Stammwissen,
  (b) von ihr bezeugte Behauptungen/Frames, (c) frühere Behauptungen desselben Sprechers
  (Selbstwiderspruch). Lokal: gleiches Subjekt+Prädikat mit anderem Wert / Negation. Mit Provider:
  semantische Prüfung, vom Kernel auf bekannte Bezüge validiert.
- Wirkung (kanonisch, begrenzt): truthStatus "conflicted"/"refuted", contradiction-Fact (zeugengebunden),
  Vertrauen der Figur zum Sprecher −0.1 (gerichtet), Emotion Misstrauen/Skepsis mit Ursache;
  Brief-Abschnitt "WIDERSPRUCH, DEN DU BEMERKST".
"""
from __future__ import annotations

import re
from typing import Any

from .ids import uid

CLAIM_KINDS = {"claim", "disclosure", "report", "state_change"}
TRUTH_STATUS = {"claimed", "confirmed", "conflicted", "refuted", "self_contradiction", "withdrawn"}
_NEG_RE = re.compile(r"\b(nicht|kein|keine|keinen|nie|niemals|nix)\b", re.I)


def _norm(s: Any) -> str:
    return re.sub(r"\s+", " ", str(s or "")).strip().lower()


def _tokens(s: Any) -> set[str]:
    return {t for t in re.findall(r"[a-zäöüß0-9]{3,}", _norm(s)) if t not in ("und", "der", "die", "das", "ist", "ein", "eine", "nicht", "mit", "von", "den", "dem")}


def register_claim(session: dict, plan: dict, *, fact_id: str, turn: int, witnesses: list[str]) -> dict | None:
    """Behauptung/Offenbarung aus dem Turn-Plan ins Register (Wahrheitsstatus 'claimed')."""
    if not isinstance(plan, dict) or plan.get("event_kind") not in CLAIM_KINDS:
        return None
    text = str(plan.get("summary") or plan.get("canonical_value") or "").strip()
    if not text or len(text) < 4:
        return None
    # Floskeln ("Aha.", "Moment.") sind keine Behauptungen: dauerhafter Inhalt oder mindestens vier Wörter
    if plan.get("durability") not in ("durable_state", "knowledge_transition", "commitment") and len(text.split()) < 4:
        return None
    claims = session.setdefault("claims", [])
    entry = {
        "id": uid("claim"),
        "by": str(plan.get("actor_id") or ""),
        "to": str(plan.get("recipient_id") or ""),
        "subject": str(plan.get("subject") or plan.get("actor_id") or "")[:80],
        "predicate": str(plan.get("predicate") or "")[:80],
        "value": str(plan.get("object") or plan.get("canonical_value") or "")[:200],
        "text": text[:200],
        "negated": bool(_NEG_RE.search(text)),
        "turn": turn,
        "factId": fact_id,
        "witnesses": [str(w) for w in (witnesses or []) if w],
        "truthStatus": "claimed",
        "evidence": [],
        "conflictsWith": [],
    }
    claims.append(entry)
    if len(claims) > 200:
        del claims[: len(claims) - 200]
    return entry


def _same_topic(a: dict, b: dict) -> bool:
    """Only a common grounded subject and predicate; lexical word overlap
    does not establish a contradiction (especially across third parties)."""
    return bool(a.get("predicate") and b.get("predicate") and
                a.get("subject") and b.get("subject") and
                _norm(a["predicate"]) == _norm(b["predicate"]) and
                _norm(a["subject"]) == _norm(b["subject"]))


def _opposed_values(a: dict, b: dict) -> bool:
    """Contradiction is a negation of the SAME proposition, not extra detail.
    Different values may be compatible (a person can help two people).
    """
    av = _norm(a.get("value") or a.get("object") or a.get("text"))
    bv = _norm(b.get("value") or b.get("object") or b.get("text"))
    av = _NEG_RE.sub("", av).strip()
    bv = _NEG_RE.sub("", bv).strip()
    return bool(av and av == bv and bool(a.get("negated")) != bool(b.get("negated")))


def local_contradictions(session: dict, character: dict, *, utterer_id: str, plan: dict | None, text: str) -> list[dict[str, Any]]:
    """Lokale Widerspruchsprüfung (ohne LLM): gleiches Thema, anderer Wert oder Negation —
    gegen bezeugte Behauptungen (fremd und eigene des Sprechers) und aktuelle Frames der Figur."""
    if not isinstance(plan, dict) or plan.get("event_kind") not in CLAIM_KINDS:
        return []
    cid = str(character.get("id") or "")
    cur = {"subject": plan.get("subject") or utterer_id, "predicate": plan.get("predicate") or "", "object": plan.get("object") or "", "text": plan.get("summary") or plan.get("canonical_value") or text, "negated": bool(_NEG_RE.search(str(plan.get("summary") or text)))}
    out: list[dict[str, Any]] = []
    for c in session.get("claims") or []:
        if not isinstance(c, dict) or c.get("truthStatus") == "withdrawn":
            continue
        if cid not in (c.get("witnesses") or []) and str(c.get("by")) != cid:
            continue  # nur, was die Figur selbst mitbekommen hat (Perspektive)
        if not _same_topic(cur, c):
            continue
        if not _opposed_values(cur, c):
            continue
        art = "selbstwiderspruch" if str(c.get("by")) == str(utterer_id) else "fremdwissen"
        out.append({"art": art, "aussage": str(cur["text"])[:160], "bekannt": str(c.get("text"))[:160], "quelle": f"Turn {c.get('turn')}" + (" (derselbe Sprecher)" if art == "selbstwiderspruch" else ""), "claimId": c.get("id"), "sicherheit": 0.6, "grund": "gleiches Thema, anderer Inhalt"})
    # Frames (Vereinbarungen/Fakten), die der Figur bekannt sind
    for f in session.get("frames") or []:
        if not isinstance(f, dict) or f.get("status") not in ("accepted", "committed", "current"):
            continue
        if cid not in (f.get("witnesses") or []):
            continue
        fr = {"subject": f.get("subject") or f.get("who"), "predicate": f.get("predicate") or "", "text": f.get("what")}
        if _same_topic(cur, fr) and _opposed_values(cur, {**fr, "negated": bool(_NEG_RE.search(str(fr.get("text") or "")))}):
            out.append({"art": "vereinbarung", "aussage": str(cur["text"])[:160], "bekannt": str(f.get("what"))[:160], "quelle": f"Vereinbarung Turn {(f.get('history') or [{}])[0].get('turn')}", "frameId": f.get("id"), "sicherheit": 0.5, "grund": "widerspricht einer Vereinbarung"})
    seen: set[str] = set()
    uniq: list[dict[str, Any]] = []
    for i in out:
        key = _norm(i.get("bekannt"))
        if key in seen:
            continue
        seen.add(key)
        uniq.append(i)
    return uniq[:4]


def validate_llm_contradictions(raw: Any, session: dict, character: dict, *,
                                evidence: list[dict[str, Any]] | None = None,
                                statement: str = "") -> list[dict[str, Any]]:
    """Model interpretation cannot manufacture a contradiction SceneFact.
    Its supporting prior claim/frame must already be independently grounded
    by the structural comparison. The caller's original statement is authority
    for the new utterance; provider prose is not an evidence record.
    """
    if not isinstance(raw, dict) or not evidence:
        return []
    rows = raw.get("widersprueche") or raw.get("contradictions") or []
    if not isinstance(rows, list):
        return []
    out = []
    for row in rows:
        if not isinstance(row, dict):
            continue
        # The original utterance and existing claim IDs must be the evidence.
        if statement and _norm(row.get("aussage") or row.get("claim")) != _norm(statement):
            continue
        claim_id = str(row.get("claimId") or "")
        frame_id = str(row.get("frameId") or "")
        known = _norm(row.get("bekannt") or row.get("known"))
        hit = next((x for x in evidence if isinstance(x, dict) and
                    ((claim_id and claim_id == x.get("claimId")) or
                     (frame_id and frame_id == x.get("frameId")) or
                     (known and known == _norm(x.get("bekannt"))))), None)
        if not hit:
            continue
        out.append(hit)  # evidence controls impact, not self-rated confidence
        if len(out) >= 3:
            break
    return out


def apply_contradictions(session: dict, character: dict, items: list[dict], *, utterer_id: str, cause_fact_id: str, turn: int) -> dict[str, Any]:
    """Kanonische Wirkung: Status im Register, contradiction-Fact, Vertrauen −0.1 zum Sprecher,
    Emotion Misstrauen/Skepsis mit Ursache. Nur für die Figur, die den Widerspruch bemerkt."""
    if not items:
        return {}
    cid = str(character.get("id") or "")
    strong = [i for i in items if float(i.get("sicherheit") or 0) >= 0.5]
    if not strong:
        return {}
    for i in strong:
        for c in session.get("claims") or []:
            if isinstance(c, dict) and c.get("id") == i.get("claimId"):
                c["truthStatus"] = "conflicted"
                c.setdefault("conflictsWith", []).append(cause_fact_id)
        for c in session.get("claims") or []:
            if isinstance(c, dict) and c.get("factId") == cause_fact_id:
                c["truthStatus"] = "self_contradiction" if i.get("art") == "selbstwiderspruch" else "conflicted"
                if i.get("claimId"):
                    c.setdefault("conflictsWith", []).append(i["claimId"])
    rt = session.setdefault("runtimes", {}).setdefault(cid, {"characterId": cid, "emotion": "wach"})
    before = {k: rt.get(k) for k in ("emotion", "trust", "activeCause")}
    top = max(strong, key=lambda i: float(i.get("sicherheit") or 0))
    if str(rt.get("emotion") or "wach") in ("wach", "calm", "") or float(top.get("sicherheit") or 0) >= 0.7:
        rt["emotion"] = "Misstrauen" if top.get("art") == "selbstwiderspruch" else "Skepsis"
    rt["trust"] = round(max(0.0, float(rt.get("trust") or 0.5) - 0.1), 3)
    rt["activeCause"] = cause_fact_id
    rt["activeCauseText"] = f"Widerspruch bemerkt: {top.get('aussage')} vs. {top.get('bekannt')}"[:160]
    rel_delta = None
    if utterer_id and utterer_id != cid:
        rels = session.setdefault("relations", [])
        hit = next((r for r in rels if isinstance(r, dict) and r.get("fromId") == cid and r.get("toId") == utterer_id), None)
        if hit is None:
            hit = {"id": f"{session.get('id')}:{cid}:{utterer_id}", "fromId": cid, "toId": utterer_id, "kind": "knows", "trust": 0.4, "closeness": 0.2, "fear": 0.1, "hostility": 0.0, "note": ""}
            rels.append(hit)
        b = float(hit.get("trust") or 0)
        hit["trust"] = round(max(0.0, b - 0.1), 3)
        hit["note"] = (str(hit.get("note") or "")[:120] + f" | Widerspruch bemerkt (Turn {turn})").strip(" |")[:240]
        hit["sourceFactId"] = cause_fact_id
        rel_delta = {"toId": utterer_id, "trust": {"from": b, "to": hit["trust"]}}
    from .kernel import make_fact, fact_provenance  # lazy import (Kernel importiert dieses Modul)

    fact = make_fact(
        turn=turn,
        actorId=cid,
        targetId=utterer_id or None,
        kind="contradiction",
        event_kind="contradiction",
        text=f"{character.get('name') or cid} bemerkt Widerspruch: „{top.get('aussage')}“ gegen „{top.get('bekannt')}“ ({top.get('quelle')})",
        authority="character",
        **fact_provenance(session, cause_fact_id),   # V65Z (A01): the cause's Quellturn, cause_fact_id
        truth={"user_id": session.get("userId"), "world_id": session.get("worldId"), "session_id": session.get("id")},
        scene=session.get("scene") or {},
        witnessedBy=[cid],
        affected_ids=[cid] + ([utterer_id] if utterer_id else []),
        payload={"kind": "contradiction", "items": strong[:3], "runtimeDelta": {k: {"from": before.get(k), "to": rt.get(k)} for k in before if before.get(k) != rt.get(k)}, "relationDelta": rel_delta, "sourceFactId": cause_fact_id},
        source_type="truth",
        provenance="kernel",
        validated=True,
    )
    session.setdefault("facts", []).append(fact)
    return {"factId": fact["id"], "items": strong[:3], "runtimeDelta": fact["payload"]["runtimeDelta"], "relationDelta": rel_delta}


def render_contradictions(items: list[dict]) -> list[str]:
    out = []
    for i in items or []:
        art = {"selbstwiderspruch": "widerspricht sich selbst", "vereinbarung": "widerspricht einer Vereinbarung", "fremdwissen": "widerspricht deinem Wissen"}.get(str(i.get("art")), "widerspricht")
        out.append(f"- Gesagt: „{i.get('aussage')}“ — {art}: „{i.get('bekannt')}“ ({i.get('quelle')}; Sicherheit {float(i.get('sicherheit') or 0):.1f})")
    return out


def claims_for(session: dict, character_id: str, limit: int = 6) -> list[dict]:
    """Behauptungen mit Konfliktstatus, die die Figur kennt (für Spiegel/Brief)."""
    rows = [c for c in (session.get("claims") or []) if isinstance(c, dict) and (character_id in (c.get("witnesses") or []) or str(c.get("by")) == character_id) and c.get("truthStatus") in ("conflicted", "self_contradiction", "refuted")]
    return rows[-limit:]


def register_denial(session: dict, speaker: dict, speech_fact: dict, items: list[dict], *, hearers: list[dict],
                    avatar_id: str | None, turn: int) -> dict[str, Any] | None:
    """V65R (AMASTER §34.1 Z. 1787, §36.3 Z. 1937 "Self-Claim, Irrtum oder Luege", §36.4 Z. 1941 "Widerspruch
    erzeugt neue Evidenz", §50 Z. 2817 Figuren duerfen luegen, Z. 3357 SceneFacts append-only; Pruefung v2.9 Q-C).
    V65T (Gegenpruefung v3.2 Befund 4; Plan v2 Schritt 3): reinstated as the EXECUTOR of a validated component - the
    segment of her own speech that denies an event she experienced, saw or did (kernel.apply_statement_components:
    literal segment, event = her own accessible act). It owns no truth; the act stays as it is. New evidence only:
    - a claim in the register (truthStatus "gegen_eigenes_erleben", conflictsWith = the act Facts);
    - a contradiction SceneFact known only to her (she knows what she experienced; the hearers heard a claim);
    - hearers who themselves witnessed one of the denied acts notice it over the existing path (apply_contradictions).
    The acts, her words and every memory stay as they are. Nothing is corrected, no answer filtered."""
    if not items or not isinstance(speech_fact, dict):
        return None
    sid = str(speaker.get("id") or "")
    hear_ids = [str(h.get("id")) for h in hearers or [] if isinstance(h, dict) and h.get("id")]
    beleg = str(items[0].get("beleg") or "")[:200]
    entry = {"id": uid("claim"), "by": sid, "to": str(speech_fact.get("targetId") or ""), "subject": sid, "predicate": "bestreitet",
             "value": "; ".join(str(i.get("text") or "") for i in items)[:200], "text": beleg, "negated": True, "turn": turn,
             "factId": speech_fact.get("id"), "witnesses": list(dict.fromkeys(hear_ids + [sid])), "truthStatus": "gegen_eigenes_erleben",
             "evidence": [str(i.get("factId")) for i in items], "conflictsWith": [str(i.get("factId")) for i in items]}
    from .kernel import make_fact, fact_provenance  # lazy import (Kernel importiert dieses Modul)
    turns_txt = ", ".join(f"Turn {i.get('turn')} ({str(i.get('text') or '')[:60]})" for i in items[:4])
    fact = make_fact(
        turn=turn, actorId=sid, targetId=speech_fact.get("targetId") or None, kind="contradiction",
        event_kind="aussage_gegen_erleben",
        text=f"{speaker.get('name') or sid} sagt „{beleg}“ — geschehen ist (selbst erlebt, gesehen oder getan): {turns_txt}",
        authority="character", **fact_provenance(session, speech_fact.get("id")),   # V65Z (A01)
        truth={"user_id": session.get("userId"), "world_id": session.get("worldId"), "session_id": session.get("id")},
        scene=session.get("scene") or {}, witnessedBy=[sid], affected_ids=[sid],
        payload={"kind": "aussage_gegen_erleben", "items": items[:6], "claimId": entry["id"], "statementFactId": speech_fact.get("id")},
        source_type="truth", provenance="kernel", validated=True,
    )
    session.setdefault("facts", []).append(fact)
    speech_fact["gegenErleben"] = {"factIds": [str(i.get("factId")) for i in items], "beleg": beleg, "claimId": entry["id"], "factId": fact["id"]}
    noticed = []
    facts_by_id = {str(f.get("id")): f for f in session.get("facts") or [] if isinstance(f, dict)}
    for h in hearers or []:
        hid = str((h or {}).get("id") or "")
        if not hid or hid == sid or hid == str(avatar_id or ""):
            continue
        seen = [i for i in items if hid in (facts_by_id.get(str(i.get("factId"))) or {}).get("witnessedBy", [])]
        if not seen:
            continue
        res = apply_contradictions(session, h, [{"art": "fremdwissen", "aussage": beleg, "bekannt": str(i.get("text") or "")[:160],
                                                 "quelle": f"Turn {i.get('turn')} (selbst gesehen)", "sicherheit": 0.6} for i in seen],
                                   utterer_id=sid, cause_fact_id=str(speech_fact.get("id")), turn=turn)
        if res:
            noticed.append({"hearer": hid, **res})
    # the claim is registered after the hearers' notice, so that path (which re-marks the claims of the cause
    # Fact as "conflicted") keeps its own semantics and this status stays readable
    claims = session.setdefault("claims", [])
    claims.append(entry)
    if len(claims) > 200:
        del claims[: len(claims) - 200]
    return {"claimId": entry["id"], "factId": fact["id"], "noticed": noticed}
