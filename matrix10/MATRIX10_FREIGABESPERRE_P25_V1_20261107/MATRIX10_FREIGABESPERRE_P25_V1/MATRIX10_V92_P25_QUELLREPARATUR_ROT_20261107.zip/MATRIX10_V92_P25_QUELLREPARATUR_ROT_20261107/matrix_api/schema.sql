-- MATRIX10 canonical SQLite schema. TARGET of SCHEMA_STATEMENTS + ensure_relations_owner.
-- Live init uses matrix_api.db.init_schema, not this file directly.
-- Owner table for directed session edges is relationships; relations is a VIEW.
-- A legacy TABLE named relations is migrated by ensure_relations_owner
-- (CREATE VIEW IF NOT EXISTS is a no-op when the TABLE already exists).

PRAGMA foreign_keys = ON;

CREATE TABLE IF NOT EXISTS users (
  id TEXT PRIMARY KEY,
  json TEXT NOT NULL,
  created_at TEXT
);

CREATE TABLE IF NOT EXISTS worlds (
  id TEXT PRIMARY KEY,
  owner_user_id TEXT NOT NULL,
  json TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS characters (
  id TEXT PRIMARY KEY,
  world_id TEXT NOT NULL,
  owner_user_id TEXT NOT NULL,
  json TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS sessions (
  id TEXT PRIMARY KEY,
  user_id TEXT NOT NULL,
  world_id TEXT NOT NULL,
  json TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS scene_facts (
  id TEXT PRIMARY KEY,
  user_id TEXT,
  world_id TEXT,
  session_id TEXT,
  json TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS memories (
  id TEXT PRIMARY KEY,
  user_id TEXT,
  world_id TEXT,
  session_id TEXT,
  json TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS relationships (
  id TEXT PRIMARY KEY,
  user_id TEXT,
  world_id TEXT,
  session_id TEXT,
  from_id TEXT,
  to_id TEXT,
  json TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS propositions (
  id TEXT PRIMARY KEY,
  user_id TEXT,
  world_id TEXT,
  session_id TEXT,
  json TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS goals (
  id TEXT PRIMARY KEY,
  user_id TEXT,
  world_id TEXT,
  session_id TEXT,
  json TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS god_facts (
  id TEXT PRIMARY KEY,
  user_id TEXT,
  world_id TEXT,
  session_id TEXT,
  json TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS turns (
  id TEXT PRIMARY KEY,
  user_id TEXT,
  world_id TEXT,
  session_id TEXT,
  json TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS uploads (
  id TEXT PRIMARY KEY,
  user_id TEXT,
  session_id TEXT,
  json TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS documents (
  id TEXT PRIMARY KEY,
  user_id TEXT,
  json TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS reviews (
  id TEXT PRIMARY KEY,
  user_id TEXT,
  json TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS snapshots (
  id TEXT PRIMARY KEY,
  user_id TEXT,
  session_id TEXT,
  json TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS triggers (
  id TEXT PRIMARY KEY,
  user_id TEXT,
  json TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS logs (
  id TEXT PRIMARY KEY,
  user_id TEXT,
  json TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS preferences (
  id TEXT PRIMARY KEY,
  user_id TEXT,
  json TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS config (
  scope TEXT NOT NULL,
  scope_id TEXT NOT NULL,
  json TEXT NOT NULL,
  PRIMARY KEY (scope, scope_id)
);

CREATE TABLE IF NOT EXISTS meta (
  key TEXT PRIMARY KEY,
  value TEXT
);

CREATE TABLE IF NOT EXISTS app_config (
  id TEXT PRIMARY KEY,
  json TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS turn_truth (
  id TEXT PRIMARY KEY,
  session_id TEXT,
  user_id TEXT,
  world_id TEXT,
  json TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS appointments (
  id TEXT PRIMARY KEY,
  user_id TEXT,
  world_id TEXT,
  session_id TEXT,
  json TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS graph_edges (
  id TEXT PRIMARY KEY,
  user_id TEXT,
  world_id TEXT,
  session_id TEXT,
  from_id TEXT,
  to_id TEXT,
  json TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS document_index (
  document_id TEXT PRIMARY KEY,
  user_id TEXT NOT NULL,
  json TEXT NOT NULL
);

CREATE VIEW relations AS
  SELECT id, user_id, world_id, session_id, from_id, to_id, json FROM relationships;

-- Consistency triggers (live init applies the same set from matrix_api.db.ensure_consistency_triggers).
-- SceneFacts/Turns/GodFacts/Logs: json and identity are append-only. DELETE remains for session teardown.
-- Session children must match the session's user_id/world_id. Character/Session need an existing world.

-- Compact key indexes: JSON lives only in owner rows; startup does not duplicate JSON in an index.

CREATE INDEX IF NOT EXISTS idx_worlds_owner ON worlds(owner_user_id, id);
CREATE INDEX IF NOT EXISTS idx_characters_world ON characters(world_id, id, owner_user_id);
CREATE INDEX IF NOT EXISTS idx_characters_owner ON characters(owner_user_id, id, world_id);
CREATE INDEX IF NOT EXISTS idx_sessions_user ON sessions(user_id, id, world_id);
CREATE INDEX IF NOT EXISTS idx_sessions_world ON sessions(world_id, id, user_id);
CREATE INDEX IF NOT EXISTS idx_scene_facts_session ON scene_facts(session_id, id, user_id, world_id);
CREATE INDEX IF NOT EXISTS idx_scene_facts_user ON scene_facts(user_id, id, session_id);
CREATE INDEX IF NOT EXISTS idx_memories_session ON memories(session_id, id, user_id, world_id);
CREATE INDEX IF NOT EXISTS idx_memories_user ON memories(user_id, id, session_id);
CREATE INDEX IF NOT EXISTS idx_relationships_session_pair ON relationships(session_id, from_id, to_id, id, user_id, world_id);
CREATE INDEX IF NOT EXISTS idx_relationships_user ON relationships(user_id, id, session_id);
CREATE INDEX IF NOT EXISTS idx_propositions_session ON propositions(session_id, id, user_id, world_id);
CREATE INDEX IF NOT EXISTS idx_goals_session ON goals(session_id, id, user_id, world_id);
CREATE INDEX IF NOT EXISTS idx_god_facts_session ON god_facts(session_id, id, user_id, world_id);
CREATE INDEX IF NOT EXISTS idx_turns_session ON turns(session_id, id, user_id, world_id);
CREATE INDEX IF NOT EXISTS idx_turn_truth_session ON turn_truth(session_id, id, user_id, world_id);
CREATE INDEX IF NOT EXISTS idx_uploads_user ON uploads(user_id, id, session_id);
CREATE INDEX IF NOT EXISTS idx_uploads_session ON uploads(session_id, id, user_id);
CREATE INDEX IF NOT EXISTS idx_snapshots_user ON snapshots(user_id, id, session_id);
CREATE INDEX IF NOT EXISTS idx_snapshots_session ON snapshots(session_id, id, user_id);
CREATE INDEX IF NOT EXISTS idx_logs_user ON logs(user_id, id);
CREATE INDEX IF NOT EXISTS idx_documents_user ON documents(user_id, id);
CREATE INDEX IF NOT EXISTS idx_document_index_user ON document_index(user_id, document_id);
CREATE INDEX IF NOT EXISTS idx_reviews_user ON reviews(user_id, id);
CREATE INDEX IF NOT EXISTS idx_triggers_user ON triggers(user_id, id);
CREATE INDEX IF NOT EXISTS idx_appointments_session ON appointments(session_id, id, user_id, world_id);
CREATE INDEX IF NOT EXISTS idx_graph_edges_session ON graph_edges(session_id, id, user_id, world_id);
CREATE INDEX IF NOT EXISTS idx_preferences_user ON preferences(user_id, id);

-- Read-only views. Writes stay on tables. Live init: ensure_read_views (DROP+CREATE).
-- json_set overlays SQL identity so GET cannot leak a stale userId in the blob.
CREATE VIEW IF NOT EXISTS v_scene_facts AS
  SELECT id, user_id, world_id, session_id,
         json_set(json, '$.id', id, '$.userId', user_id, '$.worldId', world_id, '$.sessionId', session_id) AS json
  FROM scene_facts;
CREATE VIEW IF NOT EXISTS v_memories AS
  SELECT id, user_id, world_id, session_id,
         json_set(json, '$.id', id, '$.userId', user_id, '$.worldId', world_id, '$.sessionId', session_id) AS json
  FROM memories;
CREATE VIEW IF NOT EXISTS v_god_facts AS
  SELECT id, user_id, world_id, session_id,
         json_set(json, '$.id', id, '$.userId', user_id, '$.worldId', world_id, '$.sessionId', session_id) AS json
  FROM god_facts;
CREATE VIEW IF NOT EXISTS v_turns AS
  SELECT id, user_id, world_id, session_id,
         json_set(json, '$.id', id, '$.userId', user_id, '$.worldId', world_id, '$.sessionId', session_id) AS json
  FROM turns;
CREATE VIEW IF NOT EXISTS v_turn_truth AS
  SELECT id, user_id, world_id, session_id,
         json_set(json, '$.id', id, '$.userId', user_id, '$.worldId', world_id, '$.sessionId', session_id) AS json
  FROM turn_truth;
CREATE VIEW IF NOT EXISTS v_propositions AS
  SELECT id, user_id, world_id, session_id,
         json_set(json, '$.id', id, '$.userId', user_id, '$.worldId', world_id, '$.sessionId', session_id) AS json
  FROM propositions;
CREATE VIEW IF NOT EXISTS v_goals AS
  SELECT id, user_id, world_id, session_id,
         json_set(json, '$.id', id, '$.userId', user_id, '$.worldId', world_id, '$.sessionId', session_id) AS json
  FROM goals;
CREATE VIEW IF NOT EXISTS v_appointments AS
  SELECT id, user_id, world_id, session_id,
         json_set(json, '$.id', id, '$.userId', user_id, '$.worldId', world_id, '$.sessionId', session_id) AS json
  FROM appointments;
CREATE VIEW IF NOT EXISTS v_relationships AS
  SELECT id, user_id, world_id, session_id, from_id, to_id,
         json_set(json, '$.id', id, '$.userId', user_id, '$.worldId', world_id, '$.sessionId', session_id, '$.fromId', from_id, '$.toId', to_id) AS json
  FROM relationships;
CREATE VIEW IF NOT EXISTS v_graph_edges AS
  SELECT id, user_id, world_id, session_id, from_id, to_id,
         json_set(json, '$.id', id, '$.userId', user_id, '$.worldId', world_id, '$.sessionId', session_id, '$.fromId', from_id, '$.toId', to_id) AS json
  FROM graph_edges;
CREATE VIEW IF NOT EXISTS v_worlds AS
  SELECT id, owner_user_id, json_set(json, '$.id', id, '$.ownerUserId', owner_user_id) AS json FROM worlds;
CREATE VIEW IF NOT EXISTS v_characters AS
  SELECT id, world_id, owner_user_id, json_set(json, '$.id', id, '$.worldId', world_id, '$.ownerUserId', owner_user_id) AS json FROM characters;
CREATE VIEW IF NOT EXISTS v_sessions AS
  SELECT id, user_id, world_id, json_set(json, '$.id', id, '$.userId', user_id, '$.worldId', world_id) AS json FROM sessions;
CREATE VIEW IF NOT EXISTS v_session_evidence AS
  SELECT id, user_id, world_id, session_id, 'scene_fact' AS layer,
         json_set(json, '$.id', id, '$.userId', user_id, '$.worldId', world_id, '$.sessionId', session_id) AS json FROM scene_facts
  UNION ALL SELECT id, user_id, world_id, session_id, 'turn' AS layer,
         json_set(json, '$.id', id, '$.userId', user_id, '$.worldId', world_id, '$.sessionId', session_id) AS json FROM turns
  UNION ALL SELECT id, user_id, world_id, session_id, 'god_fact' AS layer,
         json_set(json, '$.id', id, '$.userId', user_id, '$.worldId', world_id, '$.sessionId', session_id) AS json FROM god_facts
  UNION ALL SELECT id, user_id, world_id, session_id, 'turn_truth' AS layer,
         json_set(json, '$.id', id, '$.userId', user_id, '$.worldId', world_id, '$.sessionId', session_id) AS json FROM turn_truth;
CREATE VIEW IF NOT EXISTS v_world_roster AS
  SELECT c.id AS character_id, c.world_id, c.owner_user_id,
         json_set(c.json, '$.id', c.id, '$.worldId', c.world_id, '$.ownerUserId', c.owner_user_id) AS character_json,
         json_set(w.json, '$.id', w.id, '$.ownerUserId', w.owner_user_id) AS world_json
  FROM characters c LEFT JOIN worlds w ON w.id = c.world_id;
CREATE VIEW IF NOT EXISTS v_user_sessions AS
  SELECT s.id AS session_id, s.user_id, s.world_id,
         json_set(s.json, '$.id', s.id, '$.userId', s.user_id, '$.worldId', s.world_id) AS session_json,
         json_set(w.json, '$.id', w.id, '$.ownerUserId', w.owner_user_id) AS world_json
  FROM sessions s LEFT JOIN worlds w ON w.id = s.world_id;





