"""Persistent turn trace: one file per backend start, logs/MATRIX10_LIVE_<Version>_<Startzeit>.log (V65F). No secrets."""
from __future__ import annotations

import json
import os
import threading
import time
import traceback
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

_LOCK = threading.Lock()
_SENSITIVE = ("apiKey", "api_key", "authorization", "password", "token", "secret", "OPENAI", "sk-")


def _root() -> Path:
    # matrix_api/live_log.py -> repo root
    return Path(__file__).resolve().parents[1]


_START: dict[str, Any] = {}


def _build_ids() -> tuple[str, str]:
    """BUILD_ID and the short version tag (e.g. V65F) from VERSION.txt."""
    build, tag = "UNKNOWN", "UNKNOWN"
    try:
        for line in (_root() / "VERSION.txt").read_text(encoding="utf-8").splitlines():
            if line.startswith("BUILD_ID="):
                build = line.split("=", 1)[1].strip() or build
    except Exception:
        pass
    for part in build.split("_"):
        if part[:1] == "V" and part[1:3].isdigit():
            tag = part
            break
    return build, tag


def log_path() -> Path:
    """V65F (AMASTER §65 Diagnose zeigt Buildstand; Logs dienen der
    Nachvollziehbarkeit): every start of the backend writes its OWN log file,
    named with version and start time, beginning with a LOG_START record (build,
    database, process). Before, all starts appended to one MATRIX10_LIVE.log and
    an old run could be read as the current one. An existing MATRIX10_LIVE.log
    stays untouched; MATRIX_LIVE_LOG (tests, measurements) still wins."""
    env = os.environ.get("MATRIX_LIVE_LOG")
    if env:
        return Path(env)
    if _START.get("path") is None:
        build, tag = _build_ids()
        started = datetime.now()
        p = _root() / "logs" / f"MATRIX10_LIVE_{tag}_{started.strftime('%Y-%m-%d_%H-%M-%S')}.log"
        n = 1
        while p.exists():
            n += 1
            p = p.with_name(f"MATRIX10_LIVE_{tag}_{started.strftime('%Y-%m-%d_%H-%M-%S')}_{n}.log")
        p.parent.mkdir(parents=True, exist_ok=True)
        _START.update({"path": p, "build": build, "tag": tag, "started": started.astimezone().isoformat(timespec="seconds")})
    return _START["path"]


def _start_record() -> str | None:
    """The first line of a per-start log (written once, before the first record)."""
    if _START.get("written") or os.environ.get("MATRIX_LIVE_LOG"):
        return None
    _START["written"] = True
    return json.dumps({"ts": datetime.now(timezone.utc).isoformat(), "stage": "LOG_START", "build": _START.get("build"),
                       "version": _START.get("tag"), "started_local": _START.get("started"),
                       "db": os.environ.get("MATRIX_DB") or "", "pid": os.getpid()}, ensure_ascii=False)


def _scrub(obj: Any) -> Any:
    if isinstance(obj, dict):
        out = {}
        for k, v in obj.items():
            kl = str(k).lower()
            if any(s.lower() in kl for s in _SENSITIVE) or (isinstance(v, str) and v.startswith("sk-")):
                out[k] = "[REDACTED]"
            else:
                out[k] = _scrub(v)
        return out
    if isinstance(obj, list):
        return [_scrub(x) for x in obj[:40]]
    if isinstance(obj, str) and len(obj) > 800:
        return obj[:800] + "…"
    return obj


def live_log(stage: str, *, trace_id: str, turn_id: str | None = None, **fields: Any) -> None:
    rec = {
        "ts": datetime.now(timezone.utc).isoformat(),
        "stage": stage,
        "trace_id": trace_id,
        "turn_id": turn_id or trace_id,
        **_scrub(fields),
    }
    line = json.dumps(rec, ensure_ascii=False, default=str)
    path = log_path()
    with _LOCK:
        path.parent.mkdir(parents=True, exist_ok=True)
        head = _start_record()
        with path.open("a", encoding="utf-8") as f:
            if head:
                f.write(head + "\n")
            f.write(line + "\n")
            f.flush()
            os.fsync(f.fileno())


def live_error(
    *,
    trace_id: str,
    stage: str,
    exc: BaseException,
    last_successful_stage: str | None = None,
    turn_id: str | None = None,
) -> None:
    tb = traceback.extract_tb(exc.__traceback__)
    frame = tb[-1] if tb else None
    live_log(
        "ERROR",
        trace_id=trace_id,
        turn_id=turn_id,
        failed_stage=stage,
        exception_type=type(exc).__name__,
        message=str(exc)[:500],
        file=frame.filename if frame else None,
        function=frame.name if frame else None,
        line=frame.lineno if frame else None,
        last_successful_stage=last_successful_stage,
        cause=str(exc.__cause__)[:300] if exc.__cause__ else None,
    )


_RT_KEYS = ("emotion", "intensity", "fear", "trust", "anger", "shame", "stress", "lust",
            "intent", "restrained", "gagged", "mobility", "consciousness", "pain", "position")
_REL_KEYS = ("trust", "closeness", "fear", "hostility", "respect", "attraction", "kind")


def session_delta(before: dict | None, after: dict | None, *, source_turn_id: str | None = None,
                  names: dict | None = None) -> dict[str, Any]:
    """V60 (AMASTER §54 Punkt 15, §68 Nr. 70): read-only diff of one commit.

    Shows what the writers actually changed: Facts, Memories, Runtime,
    Relationships, Propositions/Goals lifecycle, SceneState beats. It reads two
    session snapshots and writes nothing back; it is a diagnosis view only.
    """
    b = before if isinstance(before, dict) else {}
    a = after if isinstance(after, dict) else {}
    nm = {str(k): str(v) for k, v in (names or {}).items()}

    def n(cid: Any) -> str:
        return nm.get(str(cid or ""), str(cid or "")) if cid else "—"

    def ids(rows: Any) -> set:
        return {str(r.get("id")) for r in (rows or []) if isinstance(r, dict) and r.get("id")}

    out: dict[str, Any] = {}
    old_f = ids(b.get("facts"))
    facts = []
    for f in a.get("facts") or []:
        if not isinstance(f, dict) or str(f.get("id")) in old_f:
            continue
        if source_turn_id and str(f.get("sourceTurnId") or f.get("source_turn_id") or "") not in ("", str(source_turn_id)):
            continue
        plan = f.get("plan") if isinstance(f.get("plan"), dict) else {}
        eff = f.get("effect") if isinstance(f.get("effect"), dict) else {}
        facts.append(
            f"{f.get('kind')}:{n(f.get('actorId'))}->{n(f.get('targetId'))}"
            f" valid={f.get('validated')}" + (f" reason={f.get('rejection_reason')}" if f.get('rejection_reason') else "")
            + f" auth={f.get('authority')}"
            + (f" plan={plan.get('event_kind')}/{plan.get('source')}" if plan else "")
            + (f" refers={plan.get('refers_to')}" if plan.get("refers_to") else "")
            + (f" prop={f.get('proposition_id') or f.get('propositionId')}" if (f.get('proposition_id') or f.get('propositionId')) else "")
            + (f" effect={eff.get('effectKind')}" if eff else "")
            + (f" goal={f.get('goal_id') or f.get('goalId')}" if (f.get('goal_id') or f.get('goalId')) else "")
            # V61: profile rule x fact bindings (owner, rule number).
            + ("".join(f" regel={n(t.get('ownerId'))}#{t.get('rule')}" for t in (f.get('profileTriggers') or []) if isinstance(t, dict)))
            + f" | {str(f.get('text') or '')[:160]}")
    out["facts"] = facts
    old_m = ids(b.get("memories"))
    out["memories"] = [f"{n(m.get('characterId'))} [{m.get('kind')}] {str(m.get('text') or '')[:160]}"
                       for m in a.get("memories") or [] if isinstance(m, dict) and str(m.get("id")) not in old_m]
    rts = []
    brt = b.get("runtimes") or {}
    for cid, rt in (a.get("runtimes") or {}).items():
        if not isinstance(rt, dict):
            continue
        prev = brt.get(cid) if isinstance(brt.get(cid), dict) else {}
        ch = [f"{k} {prev.get(k)!s}→{rt.get(k)!s}" for k in _RT_KEYS if prev.get(k) != rt.get(k)]
        if ch:
            rts.append(f"{n(cid)}: " + ", ".join(ch))
    out["runtime"] = rts
    rels = []
    brel = {(str(r.get("fromId")), str(r.get("toId"))): r for r in b.get("relations") or [] if isinstance(r, dict)}
    for r in a.get("relations") or []:
        if not isinstance(r, dict):
            continue
        prev = brel.get((str(r.get("fromId")), str(r.get("toId"))), {})
        ch = [f"{k} {prev.get(k)!s}→{r.get(k)!s}" for k in _REL_KEYS if prev.get(k) != r.get(k)]
        if ch:
            rels.append(f"{n(r.get('fromId'))}->{n(r.get('toId'))}: " + ", ".join(ch))
    out["relations"] = rels
    bprops = {str(p.get("id")): p for p in b.get("propositions") or [] if isinstance(p, dict)}
    props = []
    for p in a.get("propositions") or []:
        if not isinstance(p, dict):
            continue
        prev = bprops.get(str(p.get("id")))
        evid = len(p.get("evidence") or [])
        if prev is None:
            props.append(f"NEU {p.get('id')} {n(p.get('actorId'))}->{n(p.get('targetId'))} [{p.get('status')}] {str(p.get('text') or '')[:120]}")
        elif prev.get("status") != p.get("status") or len(prev.get("evidence") or []) != evid:
            props.append(f"{p.get('id')} {prev.get('status')}→{p.get('status')} evidence {len(prev.get('evidence') or [])}→{evid}")
    out["propositions"] = props
    bgoals = {str(g.get("id")): g for g in b.get("goals") or [] if isinstance(g, dict)}
    goals = []
    for g in a.get("goals") or []:
        if not isinstance(g, dict):
            continue
        prev = bgoals.get(str(g.get("id")))
        if prev is None:
            goals.append(f"NEU {n(g.get('ownerId'))} [{g.get('status')}] {str(g.get('text') or '')[:100]}")
        elif prev.get("status") != g.get("status") or len(prev.get("recentExperiences") or []) != len(g.get("recentExperiences") or []):
            goals.append(f"{n(g.get('ownerId'))} {str(g.get('text') or '')[:60]}: {prev.get('status')}→{g.get('status')}"
                         f" evidence {len(prev.get('recentExperiences') or [])}→{len(g.get('recentExperiences') or [])}")
    out["goals"] = goals
    bst = b.get("sceneState") if isinstance(b.get("sceneState"), dict) else {}
    ast = a.get("sceneState") if isinstance(a.get("sceneState"), dict) else {}
    bb = {str(x.get("id")): x for x in bst.get("openBeats") or [] if isinstance(x, dict)}
    beats = []
    for x in ast.get("openBeats") or []:
        if not isinstance(x, dict):
            continue
        prev = bb.get(str(x.get("id")))
        if prev is None or prev.get("status") != x.get("status"):
            beats.append(f"{x.get('kind')} {n(x.get('by'))}->{n(x.get('owner'))} [{(prev or {}).get('status', 'neu')}→{x.get('status')}] {str(x.get('text') or '')[:100]}")
    out["beats"] = beats
    if bst.get("status") != ast.get("status") or bst.get("escalation") != ast.get("escalation"):
        out["scene"] = f"{bst.get('status')}→{ast.get('status')} escalation {bst.get('escalation')}→{ast.get('escalation')}"
    return out


def prompt_sections(brief: str) -> dict[str, list[str]]:
    """V60: the brief that was really sent, split at its own section headers."""
    sections: dict[str, list[str]] = {}
    current = "KOPF"
    for line in str(brief or "").split("\n"):
        s = line.rstrip()
        if not s:
            continue
        head = s.split(":", 1)[0] if ":" in s else ""
        head = head.split("(", 1)[0].strip()
        if head and head.upper() == head and len(head) >= 4 and any(ch.isalpha() for ch in head) and not s.startswith("-"):
            current = head
        sections.setdefault(current, []).append(s[:400])
    return sections


def new_trace_id(prefix: str = "tr") -> str:
    return f"{prefix}_{int(time.time() * 1000)}_{os.getpid()}"


def read_tail(limit: int = 80) -> dict[str, Any]:
    """Read last N JSON lines. Does not change write semantics."""
    p = log_path()
    if not p.exists():
        return {"ok": True, "lines": [], "file": p.name, "count": 0}
    rows: list[str] = []
    with _LOCK:
        with p.open("r", encoding="utf-8") as fh:
            for line in fh:
                s = line.strip()
                if s:
                    rows.append(s)
    n = max(0, min(int(limit or 80), 200))
    tail = rows[-n:] if n else []
    parsed: list[Any] = []
    for raw in tail:
        try:
            parsed.append(_scrub(json.loads(raw)))
        except Exception:
            parsed.append({"raw": raw[:400]})
    return {"ok": True, "lines": parsed, "file": p.name, "count": len(parsed)}
