import hashlib
import random
import time


# B.27 (AMASTERv2): deterministische ID-Vergabe.
#
# Wenn uid() mit session_id+n aufgerufen wird, ist die ID reproduzierbar
# (sha256(session_id + ":" + n)[:8]). Das macht Snapshot- und Test-Vergleiche
# stabil und identische Sessions miteinander vergleichbar.
#
# Ohne session_id: altes random/time-Verhalten (backward-kompatibel).
#
# Beispiel:
#   uid("fact", session_id="ses_abc", n=3)  -> immer "fact_5e9c4b7a" (solange
#                                              session_id="ses_abc", n=3)
#   uid("fact")                            -> "fact_18a2f9c0_4837" (random)


def _deterministic_id(prefix: str, session_id: str, n: int, kind: str | None = None) -> str:
    """B.27: hash-basierte ID. Stabil für gleiche (prefix, session_id, n[, kind])."""
    bits = f"{prefix}:{session_id}:{n}"
    if kind is not None:
        bits = f"{bits}:{kind}"
    h = hashlib.sha256(bits.encode("utf-8")).hexdigest()[:8]
    return f"{prefix}_{h}"


_SEQ = 0


def uid(
    prefix: str = "id",
    *,
    session_id: str | None = None,
    n: int | None = None,
    kind: str | None = None,
) -> str:
    """Generate an ID. Deterministic when session_id + n are given.

    Args:
        prefix: short tag (e.g. "fact", "mem", "ln")
        session_id: if given, the ID becomes deterministic
        n: counter within the session (each kernel step increments)
        kind: optional sub-counter domain (e.g. "fact" vs "mem") so
              that two different kinds with the same n get distinct IDs

    Returns:
        A string ID. If both session_id and n are given, the result is
        a deterministic hash; otherwise, a time+random fallback.
    """
    if session_id is not None and n is not None:
        return _deterministic_id(prefix, session_id, n, kind)
    # Backward-kompatibler Fallback (random). V25.1: 32 Zufallsbits + Prozesszähler,
    # damit Massen-Rekeys (Session-Duplikat) innerhalb derselben Millisekunde nicht
    # kollidieren (vorher 4 Dezimalstellen → Geburtstagskollisionen → 409).
    global _SEQ
    _SEQ = (_SEQ + 1) % 0xFFFF
    return f"{prefix}_{int(time.time() * 1000):x}_{random.getrandbits(32):08x}{_SEQ:04x}"

