"""Actor helper + owner guards. Shared Gasthaus requires id AND owner=admin.

ID alone never grants shared visibility. Do not weaken B1R2.1/B1R2.2 gates.
"""

from __future__ import annotations

import os

from flask import jsonify, request

from matrix_api.db import GASTHAUS_ID

ACTOR_HEADER = "X-Matrix-Actor"
ACTOR_HEADER_FALLBACK = "X-Matrix-User"
ACTOR_HEADER_USER_ID = "X-Matrix-User-Id"


def read_actor_raw() -> str | None:
    raw = (
        request.headers.get(ACTOR_HEADER)
        or request.headers.get(ACTOR_HEADER_FALLBACK)
        or request.headers.get(ACTOR_HEADER_USER_ID)
    )
    if raw is None:
        return None
    actor = str(raw).strip()
    return actor or None


def default_dev_actor() -> str | None:
    if os.environ.get("MATRIX_DEV_DEFAULT_ACTOR") == "1":
        return "admin"
    return None


def get_actor(*, mutating: bool) -> tuple[str | None, tuple | None]:
    """Return (actor, error_response).

    Missing header: admin only when MATRIX_DEV_DEFAULT_ACTOR=1.
    Mutating routes without actor → 401.
    GET /api/health does not call this.
    """
    actor = read_actor_raw() or default_dev_actor()
    if actor:
        return actor, None
    if mutating:
        body = jsonify(
            {
                "ok": False,
                "error": "UNAUTHORIZED",
                "message": "X-Matrix-Actor (or X-Matrix-User) required",
            }
        )
        return None, (body, 401)
    return None, None


def actor_or_401(*, mutating: bool = True):
    return get_actor(mutating=mutating)


def user_is_self(user_id: str, actor: str) -> bool:
    return user_id == actor


def world_is_owned(owner: str, actor: str) -> bool:
    return owner == actor


def is_shared_gasthaus(world_id: str, owner: str) -> bool:
    """Shared Gasthaus ONLY when id==world_gasthaus_7kreis AND owner==admin.

    ID alone never grants shared visibility. A private row with the Gasthaus
    id (owner!=admin) is not readable by other actors.
    """
    return world_id == GASTHAUS_ID and owner == "admin"


def world_is_readable(world_id: str, owner: str, actor: str) -> bool:
    """Shared Gasthaus: readable only when id==world_gasthaus_7kreis AND owner==admin."""
    if owner == actor:
        return True
    if is_shared_gasthaus(world_id, owner):
        return True
    return False


def world_is_selectable(world_id: str, owner: str, actor: str) -> bool:
    """Frontend/server selection: own worlds or the shared admin Gasthaus seed."""
    return world_is_readable(world_id, owner, actor)


def session_owner_ok(session_user_id: str, actor: str) -> bool:
    return session_user_id == actor
