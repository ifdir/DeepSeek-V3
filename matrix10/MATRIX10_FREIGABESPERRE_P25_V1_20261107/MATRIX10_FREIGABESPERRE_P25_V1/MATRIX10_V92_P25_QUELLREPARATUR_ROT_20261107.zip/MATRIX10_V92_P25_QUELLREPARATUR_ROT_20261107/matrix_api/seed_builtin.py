"""First-run SQL seed: admin + authored Gasthaus + full native Stamm.

Client-only seed is not a Reader. Fresh unzip must have the world in SQLite
before POST /api/sessions can bind. Tests with Flask TESTING skip this.
"""

from __future__ import annotations

import json
from pathlib import Path
from datetime import datetime, timezone

from matrix_api.db import GASTHAUS_ID

_CHAR_IDS = [
    "char_g7_clara",
    "char_g7_johann",
    "char_g7_mara",
    "char_g7_gustav",
    "char_g7_robert",
]


def _now() -> str:
    return datetime.now(timezone.utc).replace(microsecond=0).isoformat().replace("+00:00", "Z")


def _dumps(obj: dict) -> str:
    return json.dumps(obj, ensure_ascii=False, separators=(",", ":"))


def _seed_templates() -> tuple[dict, list[dict]]:
    """Read the build-time snapshot of the existing authored UI templates.

    The full Gasthaus character/world template already exists in
    src/lib/matrix/seed-gasthaus.ts. V83/V84 erroneously inserted a SECOND,
    truncated version into the canonical SQLite during first-run initialization.
    The included gasthaus_seed.json is generated from that exact TS source at
    BUILD time; neither Node nor a frontend JSON blob is needed at runtime.
    Only missing rows are inserted. Existing user data are never rewritten.
    """
    source = Path(__file__).with_name("gasthaus_seed.json")
    data = json.loads(source.read_text(encoding="utf-8"))
    world = data.get("world")
    chars = data.get("characters")
    if not isinstance(world, dict) or world.get("id") != GASTHAUS_ID:
        raise ValueError("gasthaus seed: world identity mismatch")
    if not isinstance(chars, list) or len(chars) != len(_CHAR_IDS) or {c.get("id") for c in chars if isinstance(c, dict)} != set(_CHAR_IDS):
        raise ValueError("gasthaus seed: five original figures required")
    for ch in chars:
        if not ch.get("personality") or not isinstance(ch.get("compass"), dict) or not ch.get("goals"):
            raise ValueError("gasthaus seed: incomplete character stem: " + str(ch.get("id")))
    # Ownership is assigned here by the server, never as a client-provided
    # claim. The IDs and all profile values are exactly the authored templates.
    return world, [{**ch, "ownerUserId": "admin"} for ch in chars]


def _admin() -> dict:
    return {
        "id": "admin",
        "name": "admin",
        "language": "de",
        "defaultRole": "teilnehmer",
        "lastWorldId": None,
        "lastSessionId": None,
        "tts": False,
        "sttMode": "dictation",
        "largeType": False,
        "highContrast": False,
        "createdAt": _now(),
    }


def seed_if_missing(conn) -> None:
    """Idempotent. Never overwrites existing rows."""
    if conn.execute("SELECT 1 FROM users WHERE id=?", ("admin",)).fetchone() is None:
        payload = _admin()
        conn.execute(
            "INSERT INTO users(id, json, created_at) VALUES (?,?,?)",
            ("admin", _dumps(payload), payload["createdAt"]),
        )
    full_world, chars = _seed_templates()
    if conn.execute("SELECT 1 FROM worlds WHERE id=?", (GASTHAUS_ID,)).fetchone() is None:
        conn.execute(
            "INSERT INTO worlds(id, owner_user_id, json) VALUES (?,?,?)",
            (GASTHAUS_ID, "admin", _dumps(full_world)),
        )
    for ch in chars:
        if conn.execute("SELECT 1 FROM characters WHERE id=?", (ch["id"],)).fetchone() is None:
            conn.execute(
                "INSERT INTO characters(id, world_id, owner_user_id, json) VALUES (?,?,?,?)",
                (ch["id"], GASTHAUS_ID, "admin", _dumps(ch)),
            )
