"""Lokale Weltanalyse. Kein LLM, keine neue Wahrheit ohne Review."""
from __future__ import annotations

import re
from typing import Any

NAME = re.compile(r"\b([A-ZÄÖÜ][a-zäöüß]{2,}(?:\s+[A-ZÄÖÜ][a-zäöüß]{2,})?)\b")
GENRES = (
    "Psychothriller",
    "Thriller",
    "Noir",
    "Krimi",
    "Horror",
    "Romance",
    "Science-Fiction",
    "Western",
    "Drama",
    "Fantasy",
)
PLACE_HINTS = (
    "Gasthaus",
    "Keller",
    "Schank",
    "Markt",
    "Hafen",
    "Wald",
    "Schloss",
    "Tempel",
    "Hafenstadt",
    "Kneipe",
    "Salon",
    "Kirche",
    "Brücke",
    "Platz",
    "Theke",
    "Kammer",
    "Hof",
    "Gasse",
    "Kai",
    "Turm",
    "Stadt",
    "Dorf",
    "Insel",
    "Burg",
    "Palast",
    "Taverne",
    "Bahnhof",
    "Straße",
    "Zimmer",
    "Saal",
    "Haus",
    "Villa",
    "Bibliothek",
    "Büro",
    "Arbeitszimmer",
    "Therapiezimmer",
    "Schlafzimmer",
    "Küche",
    "Garten",
    "Rosengarten",
    "Cafe",
    "Café",
    "Anwesen",
    "Herrenhaus",
    "Auffahrt",
    "Strand",
)
LOC_PAT = re.compile(
    r"\b(?:[Ii]m|[Ii]n der|[Ii]n dem|[Aa]m|[Aa]uf dem|[Aa]uf der|[Bb]eim|[Bb]ei der|[Vv]or dem|[Hh]inter dem)\s+"
    r"([A-ZÄÖÜ][\wÄÖÜäöüß\-]{2,40}(?:\s+[A-ZÄÖÜ][\wÄÖÜäöüß\-]{2,30})?)"
)
# Deutsche Präpositionalidiome — Grammatik, kein Buchfilter.
LOCATIVE_IDIOM = {
    "gegensatz",
    "anfang",
    "ende",
    "nähe",
    "rahmen",
    "klaren",
    "grunde",
    "prinzip",
    "allgemeinen",
    "laufe",
    "zuge",
    "stich",
    "stande",
    "blick",
    "sinn",
    "moment",
    "augenblick",
    "stande",
    "herzen",
    "folge",
    "stande",
}
FRONT_RE = re.compile(
    r"copyright|©|alle rechte vorbehalten|isbn[\s-]|titelblatt|"
    r"dieses ebook|ebook darf|für den persönlichen gebrauch|"
    r"werk der fiktion|impressum|inhaltsverzeichnis",
    re.I,
)
COMMON_NOUN = {
    "frau",
    "mann",
    "name",
    "leben",
    "kind",
    "mutter",
    "vater",
    "haus",
    "zeit",
    "welt",
    "tag",
    "nacht",
    "stimme",
    "hand",
    "kopf",
    "auge",
    "augen",
    "mädchen",
    "jahre",
    "geschichte",
    "familie",
    "gruppe",
    "herr",
    "dame",
    "mensch",
    "leute",
    "ding",
    "ort",
    "platz",
    "zimmer",
    "weg",
    "blick",
    "gesicht",
    "moment",
    "augenblick",
    "technologie",
    "gefühl",
    "farbe",
    "wie",
    "morgen",
    "abend",
    "obst",
    "fell",
    "abschluss",
    "frühstück",
    "stille",
    "worte",
    "brise",
    "recht",
    "männer",
    "bücher",
    "schön",
}
NAME_FUNC = {
    "ihre",
    "alle",
    "wenn",
    "wie",
    "was",
    "wo",
    "wer",
    "hallo",
    "hey",
    "ja",
    "nein",
    "bitte",
    "danke",
    "gut",
    "guten",
    "etwas",
    "welcher",
    "welche",
    "welches",
    "dickes",
    "also",
    "besuchen",
    "copyright",
    "dieses",
    "sofern",
    "keine",
    "unsere",
    "seine",
    "meine",
    "doch",
    "warum",
    "wieso",
    "weshalb",
    "deshalb",
    "trotzdem",
    "obwohl",
    "unser",
    "euer",
    "dein",
    "eure",
    "deine",
    "dann",
    "danach",
    "daher",
    "darum",
    "damit",
    "hier",
    "dort",
    "damals",
    "tja",
    "nun",
    "nur",
    "beide",
    "weitere",
    "einige",
    "viele",
    "solche",
    "jene",
    "alle",
    "einmal",
    "sofort",
    "später",
    "früher",
    "zuletzt",
    "zuerst",
    "dennoch",
    "dabei",
    "dafür",
    "davon",
    "dazu",
    "der",
    "die",
    "das",
    "ihrer",
    "ihren",
    "ihrem",
    "eures",
    "eurer",
    "unserer",
    "hat",
    "hatte",
    "wird",
    "kann",
    "soll",
    "muss",
    "lässt",
    "ein",
    "eine",
    "einen",
    "einem",
    "eines",
    "einer",
    "mit",
    "als",
    "zum",
    "zur",
    "beim",
    "nach",
    "über",
    "unter",
    "oder",
    "und",
    "sie",
    "er",
    "ich",
    "wir",
    "ihr",
    "kein",
    "jede",
    "jeder",
    "mein",
}
SUBPLACE_MARKERS = ("im ", "in der ", "unter dem ", "über der ", "hinter ", "neben ")
FACTION_HINTS = ("Fraktion", "Gilde", "Orden", "Bund", "Familie", "Clique", "Kartell", "Kirche", "Bande")
RULE_MARKERS = ("darf nicht", "verboten", "verbietet", "regel:", "gesetz", "tabu", "niemand darf", "niemand außer", "anweisung")
CONFLICT_MARKERS = ("konflikt", "krieg", "streit", "fehde", "verrat", "pakt")
ITEM_HINTS = (
    "waffe",
    "brief",
    "schlüssel",
    "ring",
    "buch",
    "amulett",
    "vertrag",
    "karte",
    "dose",
    "flasche",
    "tablette",
    "tabletten",
    "pille",
    "pillen",
    "tagebuch",
    "kamera",
    "kameras",
    "handy",
    "tablet",
)
CULTURE_MARKERS = ("sprache", "dialekt", "brauch", "ritual", "fest", "tracht", "glaube", "religion")
SECRET_MARKERS = (
    "geheimnis",
    "geheimnisse",
    "heimlich",
    "verborgen",
    "verschweig",
    "niemand weiß",
    "niemand darf",
    "nur sie weiß",
    "nicht sagen",
    "nicht erzähl",
    "unbekannt",
    "stillschweigen",
)
KNOWLEDGE_BOUND_MARKERS = ("wissen nicht", "kennt nicht", "darf nicht wissen", "wissensgrenze", "niemand darf", "darf das wissen", "verborgen bleibt", "weiß nicht", "weiss nicht")
STORY_GOAL_MARKERS = ("ziel", "will ", "möchte", "muss ", "soll ", "versucht", "sucht ", "braucht ", "bewachen", "helfen")
TRAIT_WORDS = (
    "stolz",
    "ängstlich",
    "kühl",
    "impulsiv",
    "loyal",
    "gierig",
    "barsch",
    "streng",
    "freundlich",
    "distanziert",
    "hart",
    "weich",
    "misstrauisch",
    "vorsichtig",
    "ruhig",
    "nervös",
    "scharf",
    "kontrolliert",
)
FEAR_MARKERS = ("fürchtet", "furcht", "ängst", "angst", "angst vor", "panik", "schreck", "unsicher", "falle", "in gefahr")
APPEAR_MARKERS = ("auge", "haar", "stimme", "gesicht", "narbe", "kleid", "anzug", "blass", "schön", "klein", "groß", "schlank", "blick")
VALUE_MARKERS = ("anstand", "ehre", "gewissen", "pflicht", "familie", "kontrolle", "ordnung", "loyal")
COMPASS_TRIGGERS = {
    "Bedrohung": ("bedroh", "gefahr", "angriff", "kontroll", "waffe"),
    "Angst": ("angst", "furcht", "fürcht", "panik", "schreck"),
    "Verrat": ("verrat", "lüge", "luege", "betrug", "geheim"),
    "Lust": ("lust", "begehr", "verlangen", "kuss", "schatz"),
    "Geld": ("geld", "zahl", "bezahl", "schuld", "lohn"),
    "Trennung": ("trennung", "verlässt mich", "verlass mich", "allein gelassen", "geh weg"),
    "Gewalt": ("gewalt", "schlag", "kampf", "packt", "zwang"),
    "Mord": ("mord", "tot", "töt", "leiche"),
    "Eifersucht": ("eifersucht", "neid", "rival"),
    "Verlust": ("verlust", "verloren", "trauer", "vermiss"),
    "Abhaengigkeit": ("abhängig", "abhaeng", "lohn", "arbeit"),
    "Moral": ("recht", "unrecht", "gewissen", "anstand"),
    "Risiko": ("risik", "wagn", "chance"),
    "Schutz": ("schütz", "schuetz", "schutz", "haus"),
    "Macht": ("macht", "kontrolle", "befehl", "herrsch", "anweisung"),
}
FATE_MARKERS = (
    "schicksal",
    "unausweichlich",
    "prophezeiung",
    "omen",
    "nächster schlag",
    "falle",
    "warnung",
    "in gefahr",
    "leben in gefahr",
    "getötet",
    "überwacht",
    "darf nicht wissen",
)
START_MARKERS = ("beginnt", "start", "eröffnung", "zuerst", "eingangsszene")
REL_MARKERS = (
    ("heiratet", "bindung"),
    ("ehefrau", "bindung"),
    ("ehemann", "bindung"),
    ("liebe zu", "liebe"),
    ("liebt", "liebe"),
    ("hasst", "feind"),
    ("vertraut", "vertrauen"),
    ("verrät", "verrat"),
    ("beschützt", "schutz"),
    ("fürchtet", "angst"),
    ("warnung", "angst"),
    ("warnte", "angst"),
    ("überwacht", "angst"),
    ("arbeitet für", "dienst"),
    ("mädchen für alles", "dienst"),
    ("haushälter", "dienst"),
    ("assistent", "dienst"),
    ("dient", "dienst"),
    ("familie", "familie"),
    ("tochter", "familie"),
    ("sohn", "familie"),
    ("nachbar", "nachbar"),
)
ARC_MARKERS = (
    "nicht mehr",
    "nicht länger",
    "zum ersten mal",
    "endlich",
    "inzwischen",
    "verändert",
    "geworden",
    "früher",
    "damals",
    "plötzlich",
    "immer noch",
    "seit jahren",
    "nie wieder",
    "traut sich",
    "wagt ",
)
ROLE_HINTS = (
    "Wirtin",
    "Wirt",
    "Gast",
    "Soldat",
    "Priester",
    "Händler",
    "Dieb",
    "Detektiv",
    "König",
    "Magier",
    "Arzt",
    "Spitzel",
    "Kapitän",
    "Richter",
)
STOP = {
    "im",
    "der",
    "die",
    "das",
    "ein",
    "eine",
    "und",
    "mit",
    "von",
    "den",
    "dem",
    "des",
    "ist",
    "sind",
    "auch",
    "aber",
    "oder",
    "sein",
    "noir",
    "drama",
    "kapitel",
    "inhalt",
    "impressum",
    "verlag",
    "seite",
    "buch",
    "autor",
    "szene",
    "titel",
    "vorwort",
    "anhang",
    "prolog",
    "epilog",
    "nacht",
    "morgen",
    "abend",
    "mittag",
    "brief",
    "wein",
    "nicht",
    "würde",
    "würden",
    "meinen",
    "meiner",
    "meinem",
    "meines",
    "schon",
    "während",
    "vielleicht",
    "haben",
    "hatte",
    "hatten",
    "werden",
    "können",
    "konnte",
    "dieser",
    "diese",
    "dieses",
    "durch",
    "wieder",
    "immer",
    "zwischen",
    "nichts",
    "etwas",
    "einen",
    "einem",
    "einer",
    "eines",
    "waren",
    "waren",
    "seine",
    "seiner",
    "ihren",
    "ihrer",
    "ihrem",
    "keine",
    "keinen",
    "wurde",
    "worden",
    "selbst",
    "andere",
    "anderen",
    "sagen",
    "sagt",
    "sagte",
    "gehen",
    "kommt",
    "kommen",
    "stehen",
    "stehen",
    "machen",
    "macht",
    "wirklich",
    "einfach",
    "plötzlich",
    "langsam",
    "schnell",
    "könnte",
    "bevor",
    "jetzt",
    "alles",
    "zurück",
    "siegel",
    "gildensiegel",
    "theke",
    "hafen",
    "keller",
    "gilde",
}

PERSON_VERBS = (
    "sagt",
    "fragt",
    "wartet",
    "geht",
    "steht",
    "kennt",
    "legt",
    "bringt",
    "liebt",
    "hasst",
    "sieht",
    "hört",
    "nimmt",
    "gibt",
    "kommt",
    "läuft",
    "flüstert",
    "schreit",
    "lächelt",
    "stirbt",
    "lebt",
    "sitzt",
    "öffnet",
    "nimmt",
    "trägt",
    "ruft",
    "antwortet",
    "schweigt",
    "trinkt",
    "isst",
    "zieht",
    "hält",
    "bleibt",
    "reicht",
    "nickt",
    "blickt",
    "fährt",
    "packt",
    "stürmt",
    "dreht",
    "lacht",
    "weint",
    "flieht",
)
PERSON_VERB_RE = re.compile(r"^(?:" + "|".join(PERSON_VERBS) + r")\b", re.I)
SPEECH_BEFORE_RE = re.compile(
    r"\b(?:sagte|fragte|rief|flüsterte|fluesterte|antwortete|meinte|erwiderte|murmelte|schrie)\s+$",
    re.I,
)
APPOSITION_RE = re.compile(
    r"^\s*,\s*(?:der|die|das)\s+(?:Frau|Mann|Dame|Herr|Arzt|Wirt|[A-ZÄÖÜ][a-zäöüß]{2,}in)\b"
)


def _unique(items: list[Any], key: str = "name") -> list[Any]:
    seen: set[str] = set()
    out: list[Any] = []
    for it in items:
        k = str(it.get(key) if isinstance(it, dict) else it).strip().lower()
        if not k or k in seen:
            continue
        seen.add(k)
        out.append(it)
    return out


def _sentences(raw: str) -> list[str]:
    return [s.strip() for s in re.split(r"[.\n!?]+", raw) if s.strip()]


def _near_name(sent: str, name: str) -> bool:
    return name.lower() in sent.lower()


def _html_unescape(s: str) -> str:
    table = {
        '&quot;': '"',
        '&#34;': '"',
        '&amp;': '&',
        '&nbsp;': ' ',
        '&#39;': "'",
        '&apos;': "'",
        '&lt;': '<',
        '&gt;': '>',
    }
    out = s or ""
    for a, b in table.items():
        out = out.replace(a, b)
    return out


def strip_front_matter(raw: str) -> str:
    """Paratext vor der Erzählung: Rechtstext, TOC, Autorenzeile. Kein Buchtitel-Filter."""
    text = raw or ""
    heading = re.compile(
        r"^(TITELBLATT|PROLOG|EPILOG|KAPITEL|CHAPTER|BAND|INHALT|INHALTSVERZEICHNIS)\b",
        re.I,
    )
    author_line = re.compile(r"\bist autor(?:in)?\b|\bis the author\b", re.I)
    blocks = re.split(r"\n\s*\n+", text)
    kinds: list[str] = []
    for b in blocks:
        s = b.strip()
        if not s:
            kinds.append("empty")
        elif heading.match(s) and len(s) < 80:
            kinds.append("head")
        elif FRONT_RE.search(s) or author_line.search(s):
            kinds.append("skip")
        elif len(s) >= 120:
            kinds.append("prose")
        else:
            kinds.append("short")
    toc_end = None
    run = 0
    last_head = -1
    for i, k in enumerate(kinds):
        if k == "head":
            run += 1
            last_head = i
            if run >= 3:
                toc_end = last_head
        elif k == "empty":
            continue
        else:
            run = 0
    start = toc_end + 1 if toc_end is not None else 0
    story_re = re.compile(
        r"^(?:#{1,3}\s*)?(?:PROLOG|EPILOG|KAPITEL\s+|CHAPTER\s+)\b",
        re.I,
    )

    def _from(i: int) -> str:
        j = i
        while j > start:
            prev = blocks[j - 1].strip()
            pk = kinds[j - 1]
            if pk == "empty":
                j -= 1
                continue
            if prev.startswith("#") or heading.match(prev):
                j -= 1
                continue
            break
        return "\n\n".join(blocks[j:]).strip()

    for i, b in enumerate(blocks):
        s = b.strip()
        if not story_re.match(s):
            continue
        if len(s) >= 80 or (i + 1 < len(blocks) and kinds[i + 1] in ("prose", "head", "short")):
            return _from(i)
    for i in range(start, len(blocks)):
        if kinds[i] == "prose":
            return _from(i)
    for i, k in enumerate(kinds):
        if k == "prose":
            return _from(i)
    return text


HEADING_SKIP = re.compile(
    r"^(?:#{1,3}\s*)?(?:prolog|epilog|kapitel|chapter|band|inhalt|inhaltsverzeichnis|titelblatt|copyright|impressum)\b",
    re.I,
)
GEO_EXTRA = re.compile(
    r"\b(?:in|im|in der|in dem|von|aus|nach|bei)\s+"
    r"([A-ZÄÖÜ][A-Za-zÄÖÜäöüß'\-]+(?:\s+[A-ZÄÖÜ][A-Za-zÄÖÜäöüß'\-]+)+)"
)
NOW_MARKERS = (
    "uber",
    "smartphone",
    "handy",
    "internet",
    "e-mail",
    "email",
    "silicon valley",
    "wlan",
    "gps",
    "app ",
    "online",
)
PAST_MARKERS = ("kutsche", "kerzenschein", "telegramm", "pferdewagen", "mittelalter")
AGE_PAT = re.compile(
    r"(\d{1,2})\s+Jahre(?:\s+alt)?|Ende\s+(?:zwanzig|dreißig|vierzig|fünfzig)|Mitte\s+(?:zwanzig|dreißig|vierzig)|Teenager|Jugendliche[rn]?",
    re.I,
)
MALE_NEAR = re.compile(r"\b(er|ihn|ihm|sein|seine|seinen|seinem|seiner)\b", re.I)
FEMALE_NEAR = re.compile(r"\b(sie|ihr|ihre|ihren|ihrem|ihrer)\b", re.I)
MALE_TITLE = re.compile(r"\b(?:Mr|Herr)\.?\s+$")
FEMALE_TITLE = re.compile(r"\b(?:Mrs|Miss|Ms|Frau|Fräulein)\.?\s+$")


def _source_title(raw: str) -> str:
    for m in re.finditer(r"^##\s+(.+)$", raw or "", re.M):
        t = m.group(1).strip()
        if 8 <= len(t) <= 80 and not HEADING_SKIP.match(t) and not FRONT_RE.search(t):
            return t
    for line in (raw or "").splitlines()[:48]:
        t = line.strip()
        if t.startswith("#"):
            t = re.sub(r"^#+\s*", "", t).strip()
        if not (12 <= len(t) <= 72):
            continue
        if HEADING_SKIP.match(t) or FRONT_RE.search(t):
            continue
        if t[0].isupper() and t.count(" ") <= 8 and not t.endswith((".", "!", "?")):
            return t
    return ""


def _chapter_timeline(raw: str) -> list[dict[str, Any]]:
    text = raw or ""
    hashes = list(re.compile(r"^##\s+(.+)$", re.M).finditer(text))
    named = list(
        re.compile(
            r"^(?:#{1,3}\s*)?(Prolog|Epilog|Kapitel\s+\d+[^\n]{0,60}|Chapter\s+\d+[^\n]{0,60})\s*$",
            re.M | re.I,
        ).finditer(text)
    )
    matches = hashes or named
    out: list[dict[str, Any]] = []
    seen: set[str] = set()
    for i, m in enumerate(matches):
        title = (m.group(1) if m.lastindex else m.group(0)).replace("#", "").strip()
        k = title.lower()
        if k in seen or FRONT_RE.search(title):
            continue
        seen.add(k)
        end = matches[i + 1].start() if i + 1 < len(matches) else len(text)
        body = text[m.end() : end]
        sent = ""
        for s in _sentences(body):
            t = _strip_heading_prefix(s)
            if len(t) < 40:
                continue
            if re.match(r"^(?:PROLOG|EPILOG|KAPITEL|CHAPTER)\b", t, re.I):
                continue
            sent = t[:200]
            break
        out.append(
            {
                "id": f"tl_{len(out)}",
                "when": title[:48],
                "text": sent or title[:160],
                "order": len(out),
                "derived": True,
            }
        )
        if len(out) >= 40:
            break
    return out


def _keywords(raw: str) -> list[str]:
    counts: dict[str, int] = {}
    for w in re.findall(r"[A-Za-zÄÖÜäöüß]{5,}", raw or ""):
        k = w.lower()
        if k in STOP or k in COMMON_NOUN or k in NAME_FUNC:
            continue
        counts[k] = counts.get(k, 0) + 1
    floor = 3 if sum(1 for n in counts.values() if n >= 3) >= 4 else 2
    ranked = sorted(((n, w) for w, n in counts.items() if n >= floor), reverse=True)
    return [w for _n, w in ranked[:12]]


GENERIC_PLACE = {
    "straße",
    "strasse",
    "zimmer",
    "haus",
    "villa",
    "platz",
    "hof",
    "ort",
    "orte",
    "weg",
    "stadt",
    "raum",
    "halle",
    "flur",
}


def _display_title(raw: str) -> str:
    t = re.sub(r"\s+", " ", raw or "").strip()
    if not t:
        return ""
    letters = re.sub(r"[^A-Za-zÄÖÜäöüß]", "", t)
    if len(letters) >= 8 and letters == letters.upper():
        lower = t.lower()
        return re.sub(r"(^|[\s\-–—:]\s*)(\S)", lambda m: m.group(1) + m.group(2).upper(), lower)
    return t


INTRO_BEFORE = re.compile(
    r"(?:ich bin|das ist|dies ist|er ist|sie ist|mein name ist|ich heiße|"
    r"er heißt|sie heißt|namens|übrigens)\s+$",
    re.I,
)
TITLE_FIRST = {"miss", "mr", "mrs", "ms", "herr", "frau", "fräulein", "dr"}
TITLE_NAME = re.compile(
    r"\b(?:Miss|Mr|Mrs|Ms|Herr|Frau|Fräulein|Dr)\.?\s+([A-ZÄÖÜ][a-zäöüß]{2,})\b"
)
DET_BEFORE = re.compile(
    r"(?:der|die|das|dem|den|des|ein|eine|einem|einen|einer|eines|"
    r"ins|im|am|vom|zum|zur|beim|"
    r"mein|meine|meinen|meinem|meiner|"
    r"sein|seine|seinen|seinem|"
    r"ihr|ihre|ihren|ihrem|"
    r"dieser|diese|dieses|diesen|diesem|jenem|jeden|jedem|"
    r"kein|keine|keinen)\s+$",
    re.I,
)


def _window_hit(raw: str, start: int, end: int) -> str | None:
    """'agency' | 'bare' | None (determiner). Same window as _agency_hits."""
    before = raw[max(0, start - 24) : start]
    if DET_BEFORE.search(before):
        return None
    if INTRO_BEFORE.search(before):
        return "agency"
    rest = raw[end : end + 40]
    if PERSON_VERB_RE.search(rest.strip()) or APPOSITION_RE.search(rest):
        return "agency"
    if SPEECH_BEFORE_RE.search(before):
        return "agency"
    if end < len(raw) and raw[end : end + 1] == ":":
        return "agency"
    n = raw[start:end]
    window = raw[max(0, start - 2) : end + 8]
    if re.search(rf'["«»„“]\s*{re.escape(n)}\s*[!?,.]|{re.escape(n)}\s*!', window):
        return "agency"
    return "bare"


def _agency_hits(n: str, raw: str) -> int:
    n_hits = 0
    for m in re.finditer(rf"\b{re.escape(n)}\b", raw):
        if _window_hit(raw, m.start(), m.end()) == "agency":
            n_hits += 1
    return n_hits


def _bare_mentions(n: str, raw: str) -> int:
    n_hits = 0
    for m in re.finditer(rf"\b{re.escape(n)}\b", raw):
        if _window_hit(raw, m.start(), m.end()) is not None:
            n_hits += 1
    return n_hits


def _has_agency(n: str, raw: str) -> bool:
    """Roman: Vollname, Vorstellung, Titel — nicht nur Verb nach Großschreibung."""
    hits = _agency_hits(n, raw)
    if " " in n.strip():
        return hits >= 1 or _bare_mentions(n, raw) >= 2
    if len(raw) < 2500:
        return hits >= 1
    return hits >= 2


def _lexical_person(n: str) -> bool:
    """Person-Kandidat ohne Buchscan. Grammatik, keine Figurenliste."""
    parts = [p for p in n.split() if p]
    if not parts:
        return False
    low = n.lower()
    first = parts[0].lower()
    if low in STOP or first in STOP or first in NAME_FUNC or first in TITLE_FIRST or low in COMMON_NOUN:
        return False
    if any(p.lower() in NAME_FUNC for p in parts):
        return False
    if len(parts) == 1 and (re.search(r"(ion|ung|heit|keit|schaft|nis)$", first) or first.endswith("lich")):
        return False
    if any(p.lower() in COMMON_NOUN for p in parts):
        return False
    if n in PLACE_HINTS or n in FACTION_HINTS or n in ROLE_HINTS:
        return False
    if any(h.lower() == low for h in PLACE_HINTS + FACTION_HINTS + ITEM_HINTS):
        return False
    if FRONT_RE.search(n):
        return False
    return True


def _is_person_name(n: str, raw: str) -> bool:
    if not _lexical_person(n):
        return False
    return _has_agency(n, raw)


def _has_agency_counts(n: str, agency: dict[str, int], bare: dict[str, int], raw_len: int) -> bool:
    hits = agency.get(n, 0)
    if " " in n.strip():
        return hits >= 1 or bare.get(n, 0) >= 2
    if raw_len < 2500:
        return hits >= 1
    return hits >= 2


def _collect_person_names(raw: str) -> tuple[list[str], dict[str, int], dict[str, int]]:
    """Ein Durchlauf über NAME/Titel. Kein Volltext-Scan pro Nomen."""
    agency: dict[str, int] = {}
    bare: dict[str, int] = {}
    order: list[str] = []
    seen: set[str] = set()
    titled: set[str] = set()

    def bump(n: str, start: int, end: int) -> None:
        kind = _window_hit(raw, start, end)
        if kind == "agency":
            agency[n] = agency.get(n, 0) + 1
            bare[n] = bare.get(n, 0) + 1
        elif kind == "bare":
            bare[n] = bare.get(n, 0) + 1
        k = n.lower()
        if k not in seen and _lexical_person(n):
            seen.add(k)
            order.append(n)

    for m in NAME.finditer(raw):
        n = m.group(1).strip()
        bump(n, m.start(), m.end())
        parts = n.split()
        if len(parts) == 2:
            bump(parts[0], m.start(), m.start() + len(parts[0]))
    for tm in TITLE_NAME.finditer(raw):
        n = tm.group(1).strip()
        titled.add(n.lower())
        bump(n, tm.start(1), tm.end(1))
    merged = _merge_person_names(order)
    out: list[str] = []
    for n in merged:
        ok = _has_agency_counts(n, agency, bare, len(raw))
        if not ok and n.lower() in titled and bare.get(n, 0) >= 2:
            ok = True
        if ok:
            out.append(n)
    return out, agency, bare


def _index_name_mentions(
    sents: list[str], names: list[str], alias_map: dict[str, list[str]]
) -> tuple[dict[str, list[tuple[int, str]]], list[list[str]]]:
    needles = {n: [x.lower() for x in _person_needles(n, alias_map.get(n) or [])] for n in names}
    word_re = re.compile(r"[A-Za-zÄÖÜäöüß]+")
    by_name: dict[str, list[tuple[int, str]]] = {n: [] for n in names}
    by_sent: list[list[str]] = []
    for i, sent in enumerate(sents):
        sl = sent.lower()
        words = set(word_re.findall(sl))
        present: list[str] = []
        for n in names:
            hit = False
            for nd in needles[n]:
                if " " in nd:
                    if nd in sl:
                        hit = True
                        break
                elif nd in words:
                    hit = True
                    break
            if hit:
                present.append(n)
                by_name[n].append((i, sent))
        by_sent.append(present)
    return by_name, by_sent


def _merge_person_names(names: list[str]) -> list[str]:
    """Clara + Clara Mertens → Clara Mertens. Miss Just + Emily Just → Emily Just."""
    full = [n for n in names if " " in n]
    out: list[str] = []
    seen: set[str] = set()
    for n in full:
        k = n.lower()
        if k in seen:
            continue
        seen.add(k)
        out.append(n)
    last_of_full = {f.split()[-1].lower() for f in full}
    for n in names:
        k = n.lower()
        if k in seen:
            continue
        if any(n.lower() == f.split()[0].lower() or n.lower() in f.lower() for f in full):
            continue
        if n.lower() in last_of_full:
            continue
        seen.add(k)
        out.append(n)
    return out


WEAK_ROLE = {"frau", "mann", "mensch", "person", "jemand", "leute", "kind", "sache", "ding", "name"}


def _named_role(n: str, raw: str) -> str:
    """Rolle aus der Namensgebung des Romans, nicht aus einer Hint-Liste."""
    for m in re.finditer(rf"\b{re.escape(n)}\b", raw):
        rest = raw[m.end() : m.end() + 180]
        cut = re.search(r"[.!?]", rest)
        if cut and cut.start() > 2:
            rest = rest[: cut.end()]
        elif cut and cut.start() <= 2:
            nxt = rest[cut.end() :]
            cut2 = re.search(r"[.!?]", nxt)
            rest = nxt[: cut2.end()] if cut2 else nxt
        ap = re.match(r"\s*,\s*(?:der|die|das)\s+([A-ZÄÖÜ][a-zäöüß]{3,}(?:in)?)", rest)
        if ap:
            role = ap.group(1).strip()
            if role.lower() not in WEAK_ROLE:
                return role
        isrole = re.search(
            r"\bist\s+(?:ihre |eure |deine |die |der |eine |ihr )?(?:neue[rs]? )?([A-ZÄÖÜa-zäöüß]{4,})",
            rest,
            re.I,
        )
        if isrole:
            role = isrole.group(1).strip()
            if role.lower() not in WEAK_ROLE and re.search(r"(in|mädchen|arzt|wirt|assistent)$", role, re.I):
                return role
    found = re.search(rf"ich bin {re.escape(n)}\s*,\s*(?:der|die)\s+([^.,]{{3,40}})", raw, re.I)
    if found:
        role = found.group(1).strip()[:40]
        if role.lower() not in WEAK_ROLE:
            return role
    first = (n.split() or [""])[0]
    extra = re.search(
        rf"ich bin übrigens\s+{re.escape(first)}\s*,\s*([^\"»«.!?]{{8,60}})",
        raw,
        re.I,
    )
    if extra:
        role = extra.group(1).strip().strip(",")[:40]
        if role.lower() not in WEAK_ROLE:
            return role
    return ""


def _name_aliases(n: str, raw: str, sents: list[str] | None = None) -> list[str]:
    """Titel- und Rufname aus dem Text, nicht erfunden."""
    parts = [p for p in n.split() if p]
    out: list[str] = []
    if len(parts) >= 2:
        first, last = parts[0], parts[-1]
        out.append(first)
        given = set()
        for gm in re.finditer(rf"\b([A-ZÄÖÜ][a-zäöüß]{{2,}})\s+{re.escape(last)}\b", raw):
            g = gm.group(1)
            if g.lower() not in TITLE_FIRST:
                given.add(g.lower())
        same_last = len(given)
        rows = sents if sents is not None else None
        for title in ("Miss", "Mr", "Mrs", "Ms", "Herr", "Frau", "Fräulein", "Dr"):
            titled = rf"{re.escape(title)}\.?\s+{re.escape(last)}"
            if not re.search(rf"\b{titled}\b", raw):
                continue
            if same_last > 1:
                if rows is None:
                    rows = _sentences(raw)
                same_sent = any(
                    last.lower() in s.lower() and re.search(titled, s) and re.search(rf"\b{re.escape(first)}\b", s)
                    for s in rows
                )
                if not same_sent:
                    continue
            alias = f"{title} {last}"
            if alias.lower() != n.lower():
                out.append(alias)
    seen: set[str] = set()
    uniq: list[str] = []
    for a in out:
        k = a.lower()
        if k in seen or k == n.lower():
            continue
        seen.add(k)
        uniq.append(a)
    return uniq


def _name_etymon(n: str, raw: str, sents: list[str] | None = None) -> str:
    """Erster Satz, der den Namen setzt. Keine Wörterbuch-Etymologie."""
    parts = [p for p in n.split() if p]
    first = parts[0] if parts else n
    last = parts[-1] if parts else n
    markers = (
        rf"ich bin\s+{re.escape(n)}",
        rf"das ist\s+{re.escape(n)}",
        rf"dies ist\s+{re.escape(n)}",
        rf"mein name ist\s+{re.escape(n)}",
        rf"ich heiße\s+{re.escape(n)}",
        rf"ich bin übrigens\s+{re.escape(n)}",
        rf"{re.escape(n)}\s*,\s*(?:der|die)\s+",
        rf"(?:Miss|Mr|Mrs|Ms|Herr|Frau|Fräulein)\.?\s+{re.escape(last)}",
    )
    rows = sents if sents is not None else _sentences(raw)
    first_l = first.lower()
    n_l = n.lower()
    for s in rows:
        sl = s.lower()
        if n_l not in sl and first_l not in sl:
            continue
        if any(re.search(p, s, re.I) for p in markers):
            return re.sub(r"\s+", " ", s).strip()[:240]
    for s in rows:
        if n_l in s.lower():
            return re.sub(r"\s+", " ", s).strip()[:240]
    return ""


def _person_needles(n: str, aliases: list[str] | None = None) -> list[str]:
    out = [n, *(aliases or [])]
    parts = n.split()
    if parts:
        out.append(parts[0])
    seen: set[str] = set()
    res: list[str] = []
    for x in sorted(out, key=len, reverse=True):
        k = x.lower().strip()
        if len(k) < 3 or k in seen:
            continue
        seen.add(k)
        res.append(x)
    return res


def _in_sent(sent: str, n: str, aliases: list[str] | None = None) -> bool:
    for needle in _person_needles(n, aliases):
        if re.search(rf"\b{re.escape(needle)}\b", sent):
            return True
    return False


def _family_extras(raw: str, names: list[str]) -> list[str]:
    known = {n.split()[0].lower() for n in names if n.split()}
    extra: list[str] = []
    for m in re.finditer(r"Familie\s+[A-ZÄÖÜ][a-zäöüß]+:\s*([^.!?]{8,120})", raw):
        toks = re.findall(r"\b[A-ZÄÖÜ][a-zäöüß]{2,}\b", m.group(1))
        toks = [t for t in toks if t.lower() not in TITLE_FIRST]
        if sum(1 for t in toks if t.lower() in known) < 2:
            continue
        for t in toks:
            if t.lower() in known or t.lower() in STOP or t.lower() in COMMON_NOUN:
                continue
            if t not in extra:
                extra.append(t)
    return extra


def _character_arc(
    n: str,
    raw: str,
    aliases: list[str] | None = None,
    sents: list[str] | None = None,
    mentions: list[tuple[int, str]] | None = None,
) -> list[dict[str, Any]]:
    """Anfang / Umschlag / Später aus dem Text. Kein erfundener Bogen."""
    if mentions is None:
        rows = sents if sents is not None else _sentences(raw)
        mention_list = [(i, s) for i, s in enumerate(rows) if _in_sent(s, n, aliases)]
    else:
        mention_list = mentions
    if not mention_list:
        return []
    beats: list[dict[str, Any]] = []

    def _pack(kind: str, i: int, s: str) -> dict[str, Any]:
        return {"beat": kind, "order": i, "text": re.sub(r"\s+", " ", s).strip()[:220]}

    first_i, first_s = mention_list[0]
    beats.append(_pack("start", first_i, first_s))
    changes = [
        (i, s)
        for i, s in mention_list[1:]
        if any(m in s.lower() for m in ARC_MARKERS)
    ]
    picked = changes[:2]
    if len(changes) > 3:
        picked = [changes[0], changes[len(changes) // 2]]
    for i, s in picked:
        if i == first_i:
            continue
        beats.append(_pack("change", i, s))
    skip = re.compile(rf"\b(?:vergiss|ohne|statt)\s+{re.escape(n.split()[0])}\b", re.I)
    later = None
    for i, s in reversed(mention_list):
        if i == first_i or skip.search(s):
            continue
        later = (i, s)
        break
    if later:
        beats.append(_pack("later", later[0], later[1]))
    seen: set[str] = set()
    out: list[dict[str, Any]] = []
    for b in beats:
        k = b["text"].lower()
        if k in seen:
            continue
        seen.add(k)
        out.append(b)
    return out[:4]


def _quotes_in(text: str) -> list[str]:
    found: list[str] = []
    for pat in (r'"([^"]{8,120})"', r"„([^“]{8,120})“", r"»([^«]{8,120})«", r"«([^»]{8,120})»"):
        for q in re.findall(pat, text or ""):
            t = q.strip()
            if t and t not in found:
                found.append(t)
    return found


def formed_biography(name: str, nearby: list[str], role: str = "", etymon: str = "", *, narrator: bool = False) -> str:
    """Zusammenziehen von Originalsätzen — kein Neuschreiben, kein fremdes Ich."""
    picked: list[str] = []
    first = (name.split() or [""])[0]
    first_l = first.lower()
    ich_own = re.compile(rf"ich bin\s+{re.escape(first)}\b", re.I) if first else None

    def _owned(s: str) -> bool:
        t = (s or "").strip()
        if not t:
            return False
        if ich_own and ich_own.search(t):
            return True
        if re.search(r"\b(?:ich|mir|mich|mein|meine|meinen|meinem|meiner)\b", t, re.I):
            return bool(narrator)
        if first_l and first_l not in t.lower() and (name or "").lower() not in t.lower():
            return False
        return True

    def add(s: str) -> None:
        t = " ".join((s or "").split())
        if not t or t in picked or not _owned(t):
            return
        picked.append(t[:280])

    if etymon:
        add(etymon)
    role_l = (role or "").lower()
    for s in nearby:
        sl = s.lower()
        if not _owned(s):
            continue
        if role_l and role_l in sl:
            add(s)
        elif ich_own and ich_own.search(s):
            add(s)
        elif any(m in sl for m in ("heißt", "ist die ", "ist der ")) and not re.search(r"\bich\b", sl):
            add(s)
        if len(picked) >= 3:
            break
    if len(picked) < 2:
        for s in nearby:
            add(s)
            if len(picked) >= 3:
                break
    return " ".join(picked)[:1200]


def compass_from_passages(passages: list[str]) -> dict[str, Any]:
    out: dict[str, Any] = {}
    for space, triggers in COMPASS_TRIGGERS.items():
        hit = next((p for p in passages if _hit_marker(p, triggers)), None)
        if not hit:
            continue
        line = " ".join(hit.split())[:160]
        if space == "Trennung" and re.search(r"mund verlassen|worte.{0,24}verlassen", line, re.I):
            continue
        out[space] = {
            "space": space,
            "stance": 0.55,
            "threshold": 0.42,
            "drive": line,
            "reaction": line,
            "bodyCue": "",
        }
    return out


def _strip_heading_prefix(s: str) -> str:
    t = (s or "").strip()
    lead = re.compile(
        r"^(?:#+\s*)*(?:(?:prolog|epilog|kapitel|chapter|band|titelblatt)"
        r"(?:\s+[A-ZÄÖÜ0-9][\w\-äöüß]*)?\s*)+",
        re.I,
    )
    prev = None
    while t != prev:
        prev = t
        t = re.sub(r"^#+\s*", "", t.strip())
        t = lead.sub("", t)
        t = " ".join(t.split())
    return t


_AGENT_VERBS = (
    "sagt",
    "sagte",
    "spricht",
    "sprach",
    "geht",
    "ging",
    "hat",
    "hatte",
    "ist",
    "war",
    "arbeitet",
    "arbeitete",
    "kennt",
    "kannte",
    "bleibt",
    "blieb",
    "fragt",
    "fragte",
    "will",
    "wollte",
    "muss",
    "musste",
    "kommt",
    "kam",
    "ruft",
    "rief",
    "wartet",
    "wartete",
    "öffnet",
    "öffnet",
    "sieht",
    "sah",
    "nimmt",
    "nahm",
    "lacht",
    "fürchtet",
    "bleibt",
    "steht",
    "steht",
    "gibt",
    "gab",
    "nimmt",
)


def _name_is_agent(name: str, sent: str, *, narrator: bool = False) -> bool:
    """True when the figure acts in the sentence, not when she is only mentioned."""
    first = (name.split() or [""])[0]
    if len(first) < 2:
        return False
    if re.search(rf"ich bin\s+{re.escape(first)}", sent, re.I):
        return True
    if re.search(rf"mein name ist\s+{re.escape(name)}", sent, re.I):
        return True
    if re.search(rf"mein name ist\s+{re.escape(first)}", sent, re.I):
        return True
    stripped = sent.strip().strip('"„»«“')
    if narrator and re.match(r"^\s*(?:und\s+)?ich\b", stripped, re.I):
        quoted = sent.strip().startswith(('"', "„", "»")) or sent.strip().endswith(('"', "“", "»"))
        if quoted and not re.search(r"\b(?:sage|antworte|sagte)\s+ich\b", sent, re.I):
            return False
        if re.search(r"\bdass Sie mir\b|\bSie mir helfen\b", sent) and not re.search(r"\bsage ich\b", sent, re.I):
            return False
        return True
    poss = re.search(rf"\b{re.escape(first)}s\b", sent)
    own = re.search(rf"\b{re.escape(first)}\b(?!s)", sent)
    if poss and not own:
        return False
    if not own and not re.search(rf"\b{re.escape(name)}\b", sent, re.I):
        return False
    if re.match(r"^\s*(?:und\s+)?ich\b", stripped, re.I):
        return False
    if re.match(rf"^{re.escape(name)}\s*,\s*(?:der|die|das)\b", stripped) and re.search(r"\bich\b", sent, re.I):
        return False
    if re.search(
        rf"\b(?:mit|zu|von|bei|für|an|auf|über|nach)\s+(?:dem|der|die|den|einem|einer)?\s*"
        rf"(?:\w+\s+){{0,2}}{re.escape(first)}\b",
        sent,
        re.I,
    ) and not re.search(rf"\b{re.escape(first)}\b\s+(?:{'|'.join(_AGENT_VERBS)})\b", sent, re.I):
        if not (stripped.startswith(first) or stripped.startswith(name)):
            return False
    if stripped.startswith(first) or stripped.startswith(name):
        return True
    last = name.split()[-1] if len(name.split()) > 1 else ""
    name_pat = re.escape(first) + (rf"(?:\s+{re.escape(last)})?" if last and last.lower() != first.lower() else "")
    verbs = "|".join(_AGENT_VERBS)
    if re.search(rf"\b{name_pat}\b\s+(?:{verbs})\b", sent, re.I):
        return True
    if re.search(rf"\b{name_pat}\b\s*,\s*(?:der|die)\s+", sent, re.I):
        return True
    return False


def _hit_marker(sent: str, markers: tuple[str, ...] | list[str]) -> bool:
    sl = sent.lower()
    for m in markers:
        if " " in m or m.endswith(" "):
            if m in sl:
                return True
        elif re.search(rf"\b{re.escape(m)}\b", sl):
            return True
    return False


def _rel_weights(kind: str) -> tuple[float, float, float]:
    k = (kind or "kennt").lower()
    if k in ("liebe", "bindung", "familie"):
        return 0.75, 0.75, 0.1
    if k == "vertrauen":
        return 0.85, 0.6, 0.1
    if k in ("angst", "feind", "verrat"):
        return 0.25, 0.2, 0.65
    if k == "dienst":
        return 0.45, 0.35, 0.2
    if k == "schutz":
        return 0.6, 0.5, 0.25
    if k == "nachbar":
        return 0.55, 0.35, 0.2
    return 0.5, 0.4, 0.1


def _knowledge_passages(name: str, nearby: list[str], *, narrator: bool = False) -> list[str]:
    cues = ("weiß", "weiss", "kennt", "verborgen", "geheim", "wissen")
    out: list[str] = []
    first = (name.split() or [""])[0]
    ich_own = re.compile(rf"ich bin\s+{re.escape(first)}\b", re.I) if first else None
    for s in nearby:
        sl = s.lower()
        if not (_hit_marker(s, cues) or "darf nicht wissen" in sl or "nicht wissen" in sl or "niemand sagt" in sl):
            continue
        if not narrator and re.search(r"\b(?:ich|mir|mich|mein|meine|meinen|meinem|meiner)\b", s, re.I) and not (
            ich_own and ich_own.search(s)
        ):
            continue
        if narrator:
            if re.match(r"^\s*(?:und\s+)?ich\b", s.strip(), re.I) or _name_is_agent(name, s, narrator=True):
                out.append(s[:200])
        elif _name_is_agent(name, s, narrator=False):
            out.append(s[:200])
        if len(out) >= 6:
            break
    return out


def _occupation_from_text(text: str) -> str:
    t = text or ""
    m = re.search(r"\bfür die\s+([^.,;!?\"»«]{2,40})\s+gearbeitet\b", t, re.I)
    if m:
        return f"arbeitet für die {m.group(1).strip()}"[:80]
    m = re.search(r"\barbeitet(?:e)?\s+als\s+([^.,;!?\"»«]{3,40})", t, re.I)
    if m:
        return m.group(1).strip()[:80]
    m = re.search(r"\b(?:tätig|arbeitet(?:e)?)\s+bei\s+([^.,;!?\"»«]{3,40})", t, re.I)
    if m:
        return f"bei {m.group(1).strip()}"[:80]
    return ""


def _detect_narrator(names: list[str], raw: str, sents: list[str]) -> str:
    """First-person book: who says 'ich bin NAME' as the I of the story, not a quoted greeting."""
    ich = sum(1 for s in sents[:160] if re.match(r"^\s*(?:und\s+)?ich\b", (s or "").strip(), re.I))
    named_hits = {
        n: len(re.findall(rf"ich bin\s+{re.escape((n.split() or [''])[0])}\b", raw, re.I))
        for n in names
        if (n.split() or [""])[0]
    }
    need = 8 if len(sents) >= 80 else (1 if any(named_hits.values()) else 3)
    if ich < need and not any(named_hits.values()):
        return ""
    scores: dict[str, int] = {n: 0 for n in names}
    for n in names:
        first = (n.split() or [""])[0]
        if len(first) < 2:
            continue
        sage = re.findall(
            rf"ich bin\s+{re.escape(first)}\b.{{0,80}}(?:sage|antworte|sagte|rief)\s+ich",
            raw,
            re.I,
        )
        scores[n] += 4 * len(sage)
        scores[n] += named_hits.get(n, 0)
        if re.search(rf"mein name ist\s+{re.escape(n)}.{{0,48}}anrufbeantworter", raw, re.I):
            scores[n] -= 6
    if not scores:
        return ""
    best = max(scores, key=lambda k: scores[k])
    return best if scores[best] >= 1 else ""


def _ich_passages(sents: list[str], *, limit: int = 16) -> list[str]:
    marked: list[str] = []
    plain: list[str] = []
    drive_m = STORY_GOAL_MARKERS + FEAR_MARKERS + SECRET_MARKERS
    for s in sents:
        t = (s or "").strip()
        quoted = t.startswith(('"', "„", "»", "«")) or t.endswith(('"', "“", "»", "«"))
        if quoted and not re.search(r"\b(?:sage|antworte|sagte)\s+ich\b", t, re.I):
            continue
        if re.search(r"\bdass Sie mir\b|\bSie mir helfen\b", t) and not re.search(r"\bsage ich\b", t, re.I):
            continue
        if not re.match(r"^\s*(?:und\s+)?ich\b", t, re.I) or len(t) < 24:
            continue
        chunk = t[:420]
        if _hit_marker(chunk, drive_m):
            marked.append(chunk)
        else:
            plain.append(chunk)
        if len(marked) >= limit:
            break
    out = marked[:limit]
    for p in plain:
        if len(out) >= limit:
            break
        if p not in out:
            out.append(p)
    return out


def _gender_from_passages(name: str, passages: list[str]) -> str:
    first = (name.split() or [""])[0]
    male = 0
    female = 0
    for p in passages:
        for m in re.finditer(rf"\b{re.escape(first)}\b", p):
            before = p[max(0, m.start() - 16) : m.start()]
            rest = p[m.end() : m.end() + 80]
            if MALE_TITLE.search(before) or MALE_NEAR.search(rest):
                male += 1
            if FEMALE_TITLE.search(before) or FEMALE_NEAR.search(rest):
                female += 1
    if male > female and male:
        return "männlich"
    if female > male and female:
        return "weiblich"
    return ""


def _age_from_passages(passages: list[str]) -> str:
    for s in passages:
        m = AGE_PAT.search(s)
        if m:
            return m.group(0).strip()[:40]
    return ""


def fill_profile_from_passages(
    name: str,
    passages: list[str],
    role: str = "",
    etymon: str = "",
    *,
    narrator: bool = False,
) -> dict[str, Any]:
    nearby = [" ".join((p or "").split()) for p in passages if (p or "").strip()]
    first = (name.split() or [""])[0]
    ich_own = re.compile(rf"ich bin\s+{re.escape(first)}\b", re.I) if first else None
    if not narrator:
        narrator = any(
            re.search(
                rf"ich bin\s+{re.escape(first)}|mein name ist\s+{re.escape(name)}",
                s,
                re.I,
            )
            for s in nearby
            if first
        ) and any(re.search(r"\bsage ich\b|\bantworte ich\b", s, re.I) for s in nearby)
    agent = [s for s in nearby if _name_is_agent(name, s, narrator=narrator)]
    speech = []
    for s in nearby:
        for q in _quotes_in(s):
            if q not in speech:
                speech.append(q)
    drive_raw = agent + [q for q in speech if q not in agent]
    drive: list[str] = []
    for s in drive_raw:
        parts = re.split(r"(?<=[.!?])\s+", s) if len(s) > 180 else [s]
        for part in parts:
            t = part.strip()
            if len(t) < 12:
                continue
            if not narrator and re.search(r"\b(?:ich|mir|mich|mein|meine|meinen|meinem|meiner)\b", t, re.I) and not (
                ich_own and ich_own.search(t)
            ):
                continue
            if narrator or t in speech or _name_is_agent(name, t, narrator=narrator):
                if t not in drive:
                    drive.append(t)
    blob = " ".join(drive)
    low = blob.lower()
    traits = [w for w in TRAIT_WORDS if w in low]
    personality_bits = [x for x in (role, *traits) if x]
    personality = " · ".join(personality_bits)
    if narrator:
        for s in drive:
            if re.search(r"ich bin wie\b|ich war schon\b|ich fühle\b", s, re.I) and len(s) > 24:
                extra = s[:140]
                personality = f"{personality} · {extra}" if personality else extra
                break
    if not personality:
        for s in agent:
            if not s.startswith('"') and first and first.lower() in s.lower():
                personality = s[:180]
                break
    appearance = next((s[:160] for s in nearby if any(w in s.lower() for w in APPEAR_MARKERS)), "")

    def _rank(s: str) -> int:
        score = 0
        if re.search(r"\b[A-ZÄÖÜ][a-zäöüß]{2,}\b", s[1:]):
            score += 2
        if _hit_marker(s, ("helfen", "angst", "geheimnis", "karriere", "warnung")):
            score += 2
        return score

    def _rank_fear(s: str) -> int:
        score = _rank(s)
        if _hit_marker(s, ("angst", "furcht", "fürchtet", "panik", "falle", "in gefahr")):
            score += 4
        if "unsicher" in s.lower():
            score -= 1
        return score

    goals = sorted([s[:160] for s in drive if _hit_marker(s, STORY_GOAL_MARKERS)], key=_rank, reverse=True)[:3]
    fears = sorted([s[:160] for s in drive if _hit_marker(s, FEAR_MARKERS)], key=_rank_fear, reverse=True)[:3]
    secrets = sorted([s[:160] for s in drive if _hit_marker(s, SECRET_MARKERS)], key=_rank, reverse=True)[:3]
    values = [w for w in VALUE_MARKERS if w in low][:4]
    conflicts = [s[:160] for s in drive if _hit_marker(s, CONFLICT_MARKERS)][:3]
    taboos = [s[:160] for s in drive if _hit_marker(s, ("darf nicht", "nicht sagen", "will nicht darüber", "niemand darf", "tabu"))][:3]
    phrases: list[str] = []
    for s in nearby:
        qs = _quotes_in(s)
        if not qs:
            continue
        own_quote = narrator and bool(re.search(r"\b(?:sage|antworte|sagte)\s+ich\b", s, re.I))
        spoken = bool(re.search(rf"\b{re.escape(first)}\b\s+(?:sagt|sagte|fragt|fragte|ruft|rief)\b", s, re.I))
        if own_quote or spoken or (_name_is_agent(name, s, narrator=narrator) and qs):
            for q in qs:
                if q not in phrases:
                    phrases.append(q)
        if len(phrases) >= 4:
            break
    likes = []
    dislikes = []
    for s in drive:
        lm = re.search(r"\b(?:liebt|mag|gerne|gern)\s+(.{3,40})|\b(?:gefällt mir|mag ich|liebe ich)\b.{0,40}", s, re.I)
        if lm:
            likes.append(lm.group(0).strip()[:80])
        dm = re.search(r"\b(?:hasst|verabscheut|verachtet)\s+(.{3,40})", s, re.I)
        if dm:
            dislikes.append(dm.group(0).strip()[:80])
    humor = next((s[:160] for s in drive if re.search(r"\b(?:lacht|witz|humor|spottet)\b", s, re.I)), "")
    gender = _gender_from_passages(name, nearby)
    if not gender and role:
        rl = role.lower()
        if any(x in rl for x in ("haushälterin", "tochter", "ehefrau", "mädchen", "assistentin", "pflegerin")) or (
            rl.endswith("in") and not rl.endswith("ein")
        ):
            gender = "weiblich"
        elif any(x in rl for x in ("fahrer", "mogul", "ehemann", "sohn", "assistent", "nachbar")):
            gender = "männlich"
    age = _age_from_passages(agent or nearby)
    occupation = role or _occupation_from_text(" ".join(nearby)) or _occupation_from_text(" ".join(speech))
    return {
        "biography": formed_biography(name, nearby, role, etymon, narrator=narrator),
        "personality": personality,
        "appearance": appearance,
        "goals": goals,
        "fears": fears,
        "secrets": secrets,
        "values": values,
        "conflictStyle": conflicts[0] if conflicts else "",
        "typicalPhrases": phrases,
        "coreFacts": traits,
        "compass": compass_from_passages(drive),
        "gender": gender,
        "age": age,
        "occupation": occupation,
        "likes": likes[:3],
        "dislikes": dislikes[:3],
        "humor": humor,
        "taboos": taboos,
    }


def passages_for_name(
    text: str,
    name: str,
    *,
    max_passages: int = 8,
    width: int = 420,
    sents: list[str] | None = None,
    mentions: list[tuple[int, str]] | None = None,
) -> list[str]:
    """Originalsätze, in denen die Figur vorkommt — kein neuer Roman."""
    raw = text or ""
    n = (name or "").strip()
    if not raw.strip() or len(n) < 2:
        return []
    rows = sents if sents is not None else _sentences(raw)
    out: list[str] = []
    seen: set[str] = set()
    if mentions is not None:
        hits = mentions
    else:
        needle = n.lower()
        first = n.split()[0].lower() if n.split() else needle
        hits = []
        for i, s in enumerate(rows):
            sl = s.lower()
            if needle not in sl and (len(first) < 3 or first not in sl):
                continue
            hits.append((i, s))
    for i, s in hits:
        chunk = s.strip()
        if i + 1 < len(rows) and len(chunk) < width:
            nxt = rows[i + 1].strip()
            if nxt:
                chunk = f"{chunk}. {nxt}"
        chunk = chunk[:width]
        key = chunk.lower()
        if key in seen:
            continue
        seen.add(key)
        out.append(chunk)
        if len(out) >= max_passages:
            break
    return out


def source_knowledge_for(text: str, name: str, cue: str = "", *, limit: int = 10) -> list[str]:
    """Cue-Treffer aus dem Original, gebunden an die Figur."""
    hits = passages_for_name(text, name, max_passages=limit, width=420)
    cue_words = [w for w in re.findall(r"[A-Za-zÄÖÜäöüß]{4,}", cue or "") if w.lower() not in STOP]
    if not cue_words or not (text or "").strip():
        return hits[:limit]
    sents = _sentences(text)
    n = (name or "").strip().lower()
    first = n.split()[0] if n else ""
    extra: list[str] = []
    for s in sents:
        sl = s.lower()
        if first and first not in sl and n not in sl:
            continue
        if any(w.lower() in sl for w in cue_words):
            t = s.strip()[:420]
            if t and t not in extra and t not in hits:
                extra.append(t)
        if len(extra) >= 4:
            break
    merged: list[str] = []
    for item in extra + hits:
        if item not in merged:
            merged.append(item)
        if len(merged) >= limit:
            break
    return merged


def analyze_text(text: str, world_id: str | None = None, source_title: str = "") -> dict[str, Any]:
    original = _html_unescape(text or "")
    raw = strip_front_matter(original)
    if not raw.strip():
        return {
            "ok": False,
            "error": "parse_empty",
            "llm": False,
            "worldId": world_id,
            "world": {},
            "characterCandidates": [],
            "spawnCandidates": [],
            "keywords": [],
        }
    lower = raw.lower()
    sents = _sentences(raw)
    genre_blob = f"{source_title}\n{original[:4000]}\n{raw[:2500]}".lower()
    genre = next((g for g in GENRES if g.lower() in genre_blob), "")
    names, agency_counts, bare_counts = _collect_person_names(raw)
    loc_hits: dict[str, int] = {}
    loc_span: dict[str, str] = {}
    for m in LOC_PAT.finditer(raw):
        loc = m.group(1).strip()
        key = loc.lower()
        if key in STOP or key in LOCATIVE_IDIOM or loc in ROLE_HINTS:
            continue
        if key in COMMON_NOUN or loc.lower() in COMMON_NOUN or key in GENERIC_PLACE:
            continue
        toks = loc.split()
        if toks[0].lower() in GENERIC_PLACE:
            continue
        if any(t.lower() in NAME_FUNC or t.lower() in STOP for t in toks):
            continue
        if re.search(r"(ion|ung|heit|keit|schaft)$", toks[-1].lower()) and toks[-1] not in PLACE_HINTS:
            continue
        loc_hits[key] = loc_hits.get(key, 0) + 1
        loc_span[key] = loc
    places = []
    for key, loc in loc_span.items():
        keep = (" " in loc) or (loc in PLACE_HINTS and loc.lower() not in COMMON_NOUN and loc.lower() not in GENERIC_PLACE)
        if not keep:
            continue
        desc = next((s[:180] for s in sents if loc.lower() in s.lower() and len(s) > 24), loc)
        rules_here = [
            s[:160]
            for s in sents
            if loc.lower() in s.lower()
            and any(m in s.lower() for m in ("tabu", "verschlossen", "überwacht", "verboten", "kamera", "nicht betreten"))
        ][:2]
        places.append(
            {
                "id": f"pl_{len(places)}_{key.replace(' ', '_')[:24]}",
                "name": loc,
                "description": desc,
                "connections": [],
                "rules": rules_here,
                "tags": ["derived"],
            }
        )
        if len(places) >= 8:
            break
    room_pat = re.compile(
        r"\b((?:[A-ZÄÖÜ][\w'’\-]+\s+){0,2}(?:Bibliothek|Büro|Arbeitszimmer|Therapiezimmer|Schlafzimmer|Küche|Garten|Rosengarten|Cafe|Café|Anwesen|Herrenhaus|Auffahrt|Strand))\b"
    )
    have_pl = {str(p.get("name") or "").lower() for p in places}
    for sent in sents:
        for m in room_pat.finditer(sent):
            loc = m.group(1).strip()
            if loc.lower() in have_pl or loc.lower() in GENERIC_PLACE:
                continue
            rules_here = [
                sent[:160]
            ] if any(x in sent.lower() for x in ("tabu", "verschlossen", "überwacht", "verboten", "kamera")) else []
            places.append(
                {
                    "id": f"pl_{len(places)}_{loc.replace(' ', '_')[:24]}",
                    "name": loc,
                    "description": sent[:180],
                    "connections": [],
                    "rules": rules_here,
                    "tags": ["derived"],
                }
            )
            have_pl.add(loc.lower())
            if len(places) >= 12:
                break
        if len(places) >= 12:
            break
    articles = {"die", "der", "das", "ein", "eine", "dem", "den", "des", "im", "am"}
    place_l = {str(p.get("name") or "").lower() for p in places}
    cleaned: list[str] = []
    for n in names:
        parts = n.split()
        if parts and parts[0].lower() in articles:
            n = " ".join(parts[1:]).strip()
        if not n or n.lower() in STOP or n.lower() in place_l:
            continue
        if n.lower() in {"szene", "kapitel", "buch", "autor"}:
            continue
        cleaned.append(n)
    for extra in _family_extras(raw, cleaned):
        if extra not in cleaned:
            cleaned.append(extra)
    firsts = {n.split()[0].lower() for n in cleaned if n.split()}
    cleaned = [
        n
        for n in cleaned
        if not (
            n.split()
            and n.split()[0].lower().endswith("s")
            and n.split()[0].lower()[:-1] in firsts
        )
    ]
    family = set(_family_extras(raw, cleaned))

    def _quality(n: str) -> int:
        q = min(agency_counts.get(n, 0), 3) + min(bare_counts.get(n, 0), 2)
        if " " in n:
            q += 12
        if n in family:
            q += 10
        if re.search(
            rf"ich bin\s+{re.escape(n)}|das ist\s+{re.escape(n)}|dies ist\s+{re.escape(n)}|mein name ist\s+{re.escape(n)}",
            raw,
            re.I,
        ):
            q += 8
        return q

    cleaned.sort(key=_quality, reverse=True)
    names = cleaned[:24]
    subplaces = []
    for sent in sents:
        sl = sent.lower()
        for parent in places:
            pname = str(parent["name"]).lower()
            if pname not in sl:
                continue
            m = re.search(
                rf"\b(?:im|in der|in dem|am|auf dem|auf der|unter dem|über der|hinter|neben)\s+({re.escape(parent['name'])})\b",
                sent,
                re.I,
            )
            if not m:
                continue
            sub = m.group(0)
            if len(sub) > 48 or sub.lower() == pname:
                continue
            subplaces.append(
                {
                    "id": f"sub_{len(subplaces)}",
                    "name": sub,
                    "parent": parent["name"],
                    "relation": "liegt_in",
                }
            )
    place_relations = []
    for a in places:
        for b in places:
            if a["name"] == b["name"]:
                continue
            blob = f"{a['name']} {b['name']}".lower()
            if blob in lower or f"{a['name'].lower()} im {b['name'].lower()}" in lower:
                place_relations.append({"from": a["name"], "to": b["name"], "kind": "verbunden"})
    if not place_relations:
        for sub in subplaces:
            parent = str(sub.get("parent") or "")
            child = str(sub.get("name") or "")
            if parent and child and parent.lower() not in child.lower():
                place_relations.append({"from": child, "to": parent, "kind": sub.get("relation") or "liegt_in"})
            elif parent and child:
                place_relations.append({"from": child, "to": parent, "kind": sub.get("relation") or "liegt_in"})
    for p in places:
        p["connections"] = [r["to"] for r in place_relations if r["from"] == p["name"]][:6]
    house = next((p for p in places if re.search(r"villa|anwesen|haus|herrenhaus|palast|schloss", p.get("name") or "", re.I)), None)
    if house:
        for p in places:
            if p is house:
                continue
            if not re.search(r"zimmer|küche|bibliothek|büro|garten|salon|kammer|keller", p.get("name") or "", re.I):
                continue
            p["parentId"] = house["id"]
            if house["name"] not in p["connections"]:
                p["connections"].append(house["name"])
    factions = []
    for sent in sents:
        m = re.search(
            r"\b(?:die|der|das)\s+([A-ZÄÖÜ][a-zäöüß]{2,})(?:s)?\s+(?:verbietet|befiehlt|herrscht|kontrolliert|regiert)\b",
            sent,
        )
        if not m:
            continue
        name = m.group(1)
        if any(str(f.get("name") or "").lower() == name.lower() for f in factions):
            continue
        factions.append({"id": f"fac_{name.lower()}", "name": name, "description": sent[:180], "members": []})
    rules = []
    for i, sent in enumerate(sents):
        sl = sent.lower()
        if FRONT_RE.search(sent):
            continue
        if any(m in sl for m in RULE_MARKERS) and len(sent) > 8:
            kind = "rechtlich" if "gesetz" in sl or "verboten" in sl else "sozial"
            rules.append({"id": f"rule_{i}", "kind": kind, "text": sent[:240]})
        if len(rules) >= 8:
            break
    conflicts = []
    for sent in sents:
        if FRONT_RE.search(sent):
            continue
        if _hit_marker(sent, CONFLICT_MARKERS) and len(sent) > 24:
            conflicts.append(sent[:200])
        if len(conflicts) >= 6:
            break
    items = []
    seen_item: set[str] = set()
    for hint in ITEM_HINTS:
        if not re.search(rf"\b{re.escape(hint)}\b", lower):
            continue
        if hint.rstrip("n") in seen_item or hint in seen_item:
            continue
        hit = next((s for s in sents if re.search(rf"\b{re.escape(hint)}\b", s.lower()) and len(s) > 16), "")
        label = hint[0].upper() + hint[1:]
        items.append(f"{label}: {hit[:140]}" if hit else label)
        seen_item.add(hint)
        seen_item.add(hint.rstrip("n"))
    culture = [s[:200] for s in sents if any(m in s.lower() for m in CULTURE_MARKERS)][:6]
    language = []
    if "dialekt" in lower or "spricht" in lower:
        language = [s[:160] for s in sents if "spricht" in s.lower() or "dialekt" in s.lower()][:4]
    history = [s[:240] for s in sents if any(w in s.lower() for w in ("früher", "damals", "geschichte", "vor jahren", "einst"))][:8]
    timeline = _chapter_timeline(raw)
    world_knowledge = [s[:200] for s in sents if any(w in s.lower() for w in ("bekannt", "jeder weiß", "öffentlich", "offenbar"))][:6]
    secret_knowledge = [s[:200] for s in sents if any(m in s.lower() for m in SECRET_MARKERS)][:6]
    knowledge_bounds = [s[:200] for s in sents if any(m in s.lower() for m in KNOWLEDGE_BOUND_MARKERS)][:6]
    start_scenes = []
    for s in sents:
        st = s.strip()
        if not st or st.startswith("#") or HEADING_SKIP.match(st) or len(st) < 40:
            continue
        if st.upper() in {"PROLOG", "EPILOG"} or st.upper().startswith("KAPITEL ") or st.upper().startswith("CHAPTER "):
            continue
        cleaned = _strip_heading_prefix(st)
        if len(cleaned) < 40:
            continue
        start_scenes = [cleaned[:200]]
        break
    story_goals = [s[:200] for s in sents if any(m in s.lower() for m in STORY_GOAL_MARKERS)][:6]
    fate_beats = [s[:200] for s in sents if _hit_marker(s, FATE_MARKERS)][:6]
    figure_relations = []
    alias_map = {n: _name_aliases(n, raw, sents=sents) for n in names}
    by_name, by_sent = _index_name_mentions(sents, names, alias_map)
    seen_pairs: set[tuple[str, str]] = set()
    for sent, present in zip(sents, by_sent):
        if len(present) < 2:
            continue
        sl = sent.lower()
        kind = "kennt"
        for needle, label in REL_MARKERS:
            if " " in needle:
                hit = needle in sl
            else:
                hit = bool(re.search(rf"\b{re.escape(needle)}\b", sl))
            if hit:
                kind = label
                break
        for a in present:
            for b in present:
                if a == b:
                    continue
                key = (a, b)
                if key in seen_pairs:
                    continue
                seen_pairs.add(key)
                figure_relations.append(
                    {
                        "from": a,
                        "to": b,
                        "kind": kind,
                        "text": sent[:180],
                        "derived": True,
                        "trust": _rel_weights(kind)[0],
                        "closeness": _rel_weights(kind)[1],
                        "fear": _rel_weights(kind)[2],
                    }
                )
    spawn = []
    narrator_name = _detect_narrator(names, raw, sents)
    ich_pool = _ich_passages(sents) if narrator_name else []
    for n in names:
        nearby = passages_for_name(raw, n, max_passages=8, width=420, sents=sents, mentions=by_name.get(n) or [])
        if not nearby:
            nearby = [s for s in sents if _near_name(s, n)][:8]
        if narrator_name and n == narrator_name:
            for p in ich_pool:
                if p not in nearby:
                    nearby.append(p)
        blob = " ".join(nearby)[:2400]
        role = _named_role(n, raw)
        origin = next((p["name"] for p in places if p["name"].lower() in blob.lower()), "")
        aliases = alias_map.get(n) or []
        etymon = _name_etymon(n, raw, sents=sents)
        arc = _character_arc(n, raw, aliases, sents=sents, mentions=by_name.get(n) or [])
        rels = []
        seen_t: set[str] = set()
        for r in figure_relations:
            other = r.get("to") if r.get("from") == n else (r.get("from") if r.get("to") == n else None)
            if not other or other == n or str(other).lower() in seen_t:
                continue
            seen_t.add(str(other).lower())
            rels.append(r)
            if len(rels) >= 4:
                break
        is_narr = bool(narrator_name and n == narrator_name)
        knowledge = _knowledge_passages(n, nearby, narrator=is_narr)
        profile = fill_profile_from_passages(n, nearby, role, etymon, narrator=is_narr)
        goals = list(profile.get("goals") or [])
        fears = list(profile.get("fears") or [])
        secrets = list(profile.get("secrets") or [])
        taboos = list(profile.get("taboos") or [])
        conflicts_n = [str(profile.get("conflictStyle") or "")] if profile.get("conflictStyle") else []
        body = str(profile.get("appearance") or "")
        traits = list(profile.get("coreFacts") or [])
        bio = str(profile.get("biography") or "")
        gender = str(profile.get("gender") or "")
        age = str(profile.get("age") or "")
        occupation = str(profile.get("occupation") or role or "")
        if not role and occupation:
            role = occupation
        typical = origin
        for p in places:
            if str(p["name"]).lower() in blob.lower():
                typical = p["name"]
                break
        binding = []
        for r in rels:
            other = r.get("to") if r.get("to") != n else r.get("from")
            if not other or other == n:
                continue
            kind = r.get("kind") or "kennt"
            label = f"{kind} · {other}"
            if label not in binding:
                binding.append(label)
            if len(binding) >= 4:
                break
        compass = profile.get("compass") or {}
        reactions = []
        for k, v in compass.items():
            if not isinstance(v, dict):
                continue
            drive = str(v.get("drive") or "").strip()
            if len(drive) < 24:
                continue
            if re.match(r"^ich bin\s+\w+", drive, re.I) and len(drive) < 90:
                continue
            if k == "Trennung" and re.search(r"mund verlassen|worte.{0,24}verlassen", drive, re.I):
                continue
            reactions.append(f"{k}: {drive[:140]}")
            if len(reactions) >= 4:
                break
        world_notes = etymon or (bio.split(".")[0].strip() if bio else "")
        direct = [k for k, v in (("role", role), ("origin", origin), ("biography", bio[:240]), ("gender", gender), ("age", age)) if v]
        spawn.append(
            {
                "name": n,
                "role": role,
                "origin": origin,
                "age": age,
                "gender": gender,
                "occupation": occupation,
                "typicalPlace": typical,
                "species": "Mensch" if gender else "",
                "worldNotes": world_notes[:240],
                "likes": list(profile.get("likes") or []),
                "dislikes": list(profile.get("dislikes") or []),
                "humor": profile.get("humor") or "",
                "bindingPatterns": binding,
                "reactionRules": reactions,
                "aliases": aliases,
                "nameEtymon": etymon,
                "development": arc,
                "biography": bio,
                "personality": profile.get("personality") or "",
                "appearance": body,
                "goals": goals,
                "fears": fears,
                "conflicts": conflicts_n,
                "relationships": rels,
                "knowledge": knowledge,
                "coreFacts": traits,
                "secrets": secrets,
                "taboos": taboos,
                "values": list(profile.get("values") or []),
                "conflictStyle": profile.get("conflictStyle") or "",
                "typicalPhrases": list(profile.get("typicalPhrases") or []),
                "speech": "",
                "body": body,
                "traits": traits,
                "compass": compass,
                "source": "analyze",
                "uncertain": not bool(role and origin),
                "directFields": direct,
                "derivedFields": [k for k, v in (("goals", goals), ("fears", fears), ("conflicts", conflicts_n), ("relationships", rels), ("knowledge", knowledge), ("traits", traits), ("development", arc), ("gender", gender), ("age", age)) if v],
                "worldRef": world_id,
            }
        )
    char_cands = []
    for sp in spawn:
        char_cands.append(
            {
                "name": sp["name"],
                "role": sp["role"],
                "origin": sp["origin"],
                "age": sp.get("age") or "",
                "gender": sp.get("gender") or "",
                "occupation": sp.get("occupation") or sp["role"],
                "typicalPlace": sp.get("typicalPlace") or "",
                "species": sp.get("species") or ("Mensch" if sp.get("gender") else ""),
                "worldNotes": sp.get("worldNotes") or "",
                "likes": list(sp.get("likes") or []),
                "dislikes": list(sp.get("dislikes") or []),
                "humor": sp.get("humor") or "",
                "bindingPatterns": list(sp.get("bindingPatterns") or []),
                "reactionRules": list(sp.get("reactionRules") or []),
                "aliases": list(sp.get("aliases") or []),
                "nameEtymon": sp.get("nameEtymon") or "",
                "development": list(sp.get("development") or []),
                "biography": sp["biography"],
                "personality": sp.get("personality") or "",
                "appearance": sp.get("appearance") or "",
                "goals": list(sp.get("goals") or []),
                "fears": list(sp.get("fears") or []),
                "knowledge": list(sp.get("knowledge") or []),
                "coreFacts": list(sp.get("coreFacts") or sp.get("traits") or []),
                "secrets": list(sp.get("secrets") or []),
                "taboos": list(sp.get("taboos") or []),
                "values": list(sp.get("values") or []),
                "conflictStyle": sp.get("conflictStyle") or "",
                "typicalPhrases": list(sp.get("typicalPhrases") or []),
                "compass": dict(sp.get("compass") or {}),
                "relationships": list(sp.get("relationships") or []),
            }
        )
    name_l = {n.lower() for n in names}
    firsts = {n.split()[0].lower() for n in names if n.split()}
    geo: list[str] = []
    for p in places:
        nm = str(p.get("name") or "").strip()
        if nm and nm not in geo:
            geo.append(nm)
    for m in GEO_EXTRA.finditer(raw):
        loc = m.group(1).strip()
        if "." in loc or "," in loc:
            continue
        if loc.lower() in name_l or loc.lower() in STOP:
            continue
        toks = loc.split()
        if toks and toks[0].lower() in firsts:
            continue
        if any(t.lower() in NAME_FUNC or t.lower() in STOP or t.lower() in COMMON_NOUN or t.lower() in GENERIC_PLACE for t in toks):
            continue
        if any(t.lower().endswith(("zimmer", "anfängen", "anfang", "seite", "wegen", "stimme", "blick", "worten")) for t in toks):
            continue
        if toks and toks[-1].lower() in {"worten", "stimme", "augen", "blick", "händen", "gesicht", "hände"}:
            continue
        if toks and toks[0].lower().rstrip(".") in TITLE_FIRST:
            continue
        head = toks[0].rstrip("'’sS")
        if head.lower() in firsts:
            continue
        if toks and toks[0].endswith("s") and toks[0][:-1].lower() in firsts:
            continue
        if any(loc.lower() == g.lower() for g in geo):
            continue
        if loc not in geo:
            geo.append(loc)
        if len(geo) >= 8:
            break
    geography = ", ".join(geo[:6])
    for row in list(spawn) + list(char_cands):
        blob = f"{row.get('biography') or ''} {' '.join(row.get('knowledge') or [])} {row.get('worldNotes') or ''}"
        lowb = blob.lower()
        if not row.get("typicalPlace"):
            for loc in geo:
                if loc and loc.lower() in lowb:
                    row["typicalPlace"] = loc
                    break
        if not row.get("speechRegister") and row.get("typicalPhrases"):
            row["speechRegister"] = "Rede aus dem Original"
    if any(w in lower for w in NOW_MARKERS):
        epoch = "Gegenwart"
    elif any(w in lower for w in PAST_MARKERS):
        epoch = "historisch"
    else:
        epoch = ""
    short = ""
    for s in start_scenes + sents:
        t = _strip_heading_prefix(s)
        if len(t) >= 40:
            short = t[:180]
            break
    if not short:
        short = _strip_heading_prefix(" ".join(raw.split())[:220])[:180]
    long_bits = [short]
    if geography:
        long_bits.append(f"Schauplatz: {geography}.")
    extra = _strip_heading_prefix(start_scenes[0]) if start_scenes else ""
    if extra and extra not in short:
        long_bits.append(extra)
    atmosphere = _strip_heading_prefix(start_scenes[0][:180] if start_scenes else short)
    purpose_src = next(( _strip_heading_prefix(s) for s in story_goals if len(_strip_heading_prefix(s)) >= 24), "")
    purpose = purpose_src[:180] if purpose_src else (f"Schauplatz: {geography}" if geography else atmosphere)
    title = _source_title(raw) or _display_title(source_title)
    fate_seeds: list[dict[str, Any]] = []
    seen_seed: set[str] = set()
    _FATE_MUST_NOT = "Kein erfundenes Wissen. Abwesende wissen nichts. Avatar nicht steuern."

    def _seed_score(text: str) -> int:
        t = _strip_heading_prefix(text)
        tl = t.lower()
        score = sum(3 for m in ("falle", "warnung", "in gefahr", "getötet", "überwacht", "leben in gefahr") if m in tl)
        if re.match(r"^\s*(?:und\s+)?ich\b", t, re.I):
            score -= 4
        return score

    pool = list(conflicts) + list(fate_beats) + list(secret_knowledge) + list(story_goals)
    for s in sorted(pool, key=_seed_score, reverse=True):
        t = _strip_heading_prefix(s)
        key = t.lower()[:72]
        if len(t) < 28 or key in seen_seed:
            continue
        if re.match(r"^\s*(?:und\s+)?ich\b", t, re.I) and _seed_score(t) < 2:
            continue
        seen_seed.add(key)
        tags = [sp for sp, trigs in COMPASS_TRIGGERS.items() if _hit_marker(t, trigs)][:3]
        fate_seeds.append(
            {
                "id": f"seed_{len(fate_seeds) + 1}",
                "title": t[:48].rstrip(" ,;"),
                "pressure": t[:160],
                "tags": tags or ["Bedrohung"],
                "beat": t[:240],
                "mustNot": _FATE_MUST_NOT,
            }
        )
        if len(fate_seeds) >= 5:
            break
    story_beats = []
    for i, ev in enumerate(timeline[:8]):
        if not isinstance(ev, dict):
            continue
        txt = str(ev.get("text") or "").strip()
        if not txt:
            continue
        story_beats.append(
            {
                "id": f"beat_{i + 1}",
                "title": str(ev.get("when") or ev.get("title") or txt)[:48],
                "text": txt[:240],
            }
        )
    return {
        "ok": True,
        "llm": False,
        "worldId": world_id,
        "world": {
            "name": title,
            "short": short,
            "long": " ".join(long_bits)[:1200],
            "genre": genre,
            "tone": genre or "",
            "epoch": epoch,
            "geography": geography,
            "atmosphere": atmosphere,
            "purpose": purpose,
            "places": _unique(places),
            "subplaces": _unique(subplaces),
            "placeRelations": place_relations[:12],
            "factions": _unique(factions),
            "rules": rules,
            "conflicts": conflicts,
            "history": history,
            "timeline": timeline,
            "items": items,
            "culture": culture,
            "language": language,
            "worldKnowledge": world_knowledge,
            "secretKnowledge": secret_knowledge,
            "knowledgeBounds": knowledge_bounds,
            "knowledgeLimits": knowledge_bounds,
            "startScenes": start_scenes,
            "typicalScenes": start_scenes,
            "storyGoals": story_goals,
            "worldGoals": story_goals,
            "secrets": secret_knowledge,
            "fateBeats": fate_beats,
            "fateSeeds": fate_seeds,
            "storyBeats": story_beats,
            "fateEnabled": True,
            "figureRelations": figure_relations[:16],
            "narratorName": narrator_name,
        },
        "characterCandidates": char_cands,
        "spawnCandidates": spawn,
        "keywords": _keywords(raw),
    }
