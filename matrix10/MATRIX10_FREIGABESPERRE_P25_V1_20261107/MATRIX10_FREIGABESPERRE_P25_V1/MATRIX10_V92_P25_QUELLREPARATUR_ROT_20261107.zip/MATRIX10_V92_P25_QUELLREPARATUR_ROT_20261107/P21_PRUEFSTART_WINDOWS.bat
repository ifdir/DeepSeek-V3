@echo off
setlocal
cd /d "%~dp0"
echo Matrix10 P21 - Quelldateien pruefen, NICHT produktiv starten.
where py >nul 2>&1
if %errorlevel%==0 (
  py -3 "P21_PRUEFSTART.py"
) else (
  python "P21_PRUEFSTART.py"
)
echo.
echo Ergebnis: P21_PRUEFBERICHT_LAUF.txt
pause
